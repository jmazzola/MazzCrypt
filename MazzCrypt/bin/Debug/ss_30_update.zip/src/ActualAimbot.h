#ifndef _ACTUALAIMBOT_H_
#define _ACTUALAIMBOT_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

#include <random>

#define M_PI       3.14159265358979323846

[junk_enable /]

class ActualAimbot
{
public:

	ActualAimbot(CSGO* c)
	{
		[add_junk 1 5 /]
		m_Target = NULL;
		csgo = c;
	}

	~ActualAimbot() = default;

	void ClampAngles(CVector& angle)
	{
		while (angle.y > 180.0f)
			angle.y -= 360.0f;

		[add_junk 1 5 /]

		while (angle.y < -180.0f)
			angle.y += 360.0f;

		[add_junk 1 5 /]

		if (angle.x > 89.0f)
			angle.x = 89.0f;

		[add_junk 1 5 /]

		if (angle.x < -89.0f)
			angle.x = -89.0f;

		[add_junk 1 5 /]

		if (angle.z != 0.0f)
			angle.z = 0.0f;
	}

	CVector2D WorldToScreen(CVector point)
	{
		CVector returnVector(0, 0, 0);
		[add_junk 1 5 /]
		float w = csgo->m_ViewMatrix[12] * point.x + csgo->m_ViewMatrix[13] * point.y + csgo->m_ViewMatrix[14] * point.z + csgo->m_ViewMatrix[15];
		if (w >= 0.01f)
		{
			float inverseWidth = 1.0f / w;
			[add_junk 1 5 /]

			[swap_lines]
			returnVector.x = (csgo->m_iWindowWidth / 2.0f) + (0.5f * ((csgo->m_ViewMatrix[0] * point.x + csgo->m_ViewMatrix[1] * point.y + csgo->m_ViewMatrix[2] * point.z + csgo->m_ViewMatrix[3]) * inverseWidth) * csgo->m_iWindowWidth + 0.5f);
			returnVector.y = (csgo->m_iWindowHeight / 2.0f) - (0.5f * ((csgo->m_ViewMatrix[4] * point.x + csgo->m_ViewMatrix[5] * point.y + csgo->m_ViewMatrix[6] * point.z + csgo->m_ViewMatrix[7]) * inverseWidth) * csgo->m_iWindowHeight + 0.5f);
			[/swap_lines]

			[add_junk 1 5 /]
		}

		[add_junk 1 5 /]

		return returnVector;
	}

	Player* GetPlayerClosestToCrosshair(int bone)
	{
		int index = -1;
		float best = FLT_MAX;

		if (m_Target)
		{
			[add_junk 1 5 /]
			return m_Target;
		}

		for (int i = 1; i < 64; i++)
		{
			[add_junk 1 5 /]

			Player ply = csgo->m_Players[i];

			bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));

			if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Enemies) && !bEnemy)
			{
				[add_junk 1 5 /]
				continue;
			}
			else if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Teammates) && bEnemy)
			{
				[add_junk 1 5 /]
				continue;
			}

			if (!IsTargetValid(&ply, bone))
			{
				[add_junk 1 5 /]
				continue;
			}

			float tmp = GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(&ply, bone));

			if (tmp < best)
			{
				[swap_lines]
				best = tmp;
				index = i;
				[/swap_lines]

				[add_junk 1 5 /]
			}
		}

		if (index != -1)
			return &csgo->m_Players[index];
		else
		{
			[add_junk 1 5 /]
			return NULL;
		}
	}

	Player* GetPlayerClosestToPlayer(int bone)
	{
		[swap_lines]
		int index = -1;
		float best = FLT_MAX;
		[/swap_lines]

		[add_junk 1 5 /]

		if (m_Target)
			return m_Target;

		for (int i = 1; i < 64; i++)
		{
			Player ply = csgo->m_Players[i];
			[add_junk 1 5 /]
			bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));

			if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Enemies) && !bEnemy)
			{
				[add_junk 1 5 /]
				continue;
			}
			else if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Teammates) && bEnemy)
			{
				[add_junk 1 5 /]
				continue;
			}

			if (!IsTargetValid(&ply, bone))
				continue;

			float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length());

			if (dist < best)
			{
				best = dist;
				[add_junk 1 5 /]
				index = i;
			}
		}

		if (index != -1)
		{
			[add_junk 1 5 /]
			return &csgo->m_Players[index];
		}
		else
			return NULL;
	}

	Player* GetPlayerLowestHP(int bone)
	{
		[swap_lines]
		int index = -1;
		int best = INT_MAX;
		[/swap_lines]

		[add_junk 1 5 /]

		if (m_Target)
			return m_Target;

		for (int i = 1; i < 64; i++)
		{
			Player ply = csgo->m_Players[i];
			[add_junk 1 5 /]
			bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));

			if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Enemies) && !bEnemy)
			{
				[add_junk 1 5 /]
				continue;
			}
			else if ((csgo->m_Hacks.tActualAimbotOptions.targetType.type == Target_Teammates) && bEnemy)
			{
				continue;
			}

			if (!IsTargetValid(&ply, bone))
			{
				[add_junk 1 5 /]
				continue;
			}

			if (ply.iHealth < best)
			{
				best = ply.iHealth;
				[add_junk 1 5 /]
				index = i;
			}
		}

		if (index != -1)
			return &csgo->m_Players[index];
		else
			return NULL;
	}

	void MakeVector(CVector angle, CVector& vector)
	{
		[swap_lines]
		float pitch = float(angle[0] * M_PI / 180);
		float yaw = float(angle[1] * M_PI / 180);
		[/swap_lines]
		float tmp = float(cos(pitch));

		[swap_lines]
		vector.x = float(-tmp * -cos(yaw));
		vector.y = float(sin(yaw)*tmp);
		vector.z = float(-sin(pitch));
		[/swap_lines]

		[add_junk 1 5 /]
	}

	float GetFov(CVector angle, CVector src, CVector dst)
	{
		CVector ang, aim;
		ang = CalcAngle(src, dst);

		[add_junk 1 5 /]
		MakeVector(angle, aim);
		[add_junk 1 5 /]
		MakeVector(ang, ang);

		float mag = FastSQRT(pow(aim.x, 2) + pow(aim.y, 2) + pow(aim.z, 2));
		[add_junk 1 5 /]
		float u_dot_v = aim.DotProduct(ang);

		return RAD2DEG(acos(u_dot_v / (pow(mag, 2))));
	}

	CVector CalcAngle(CVector src, CVector dst)
	{
		CVector ret;
		CVector vDelta = src - dst;
		[add_junk 1 5 /]
		float fHyp = FastSQRT((vDelta.x * vDelta.x) + (vDelta.y * vDelta.y));

		[swap_lines]
		ret.x = (atanf(vDelta.z / fHyp)) * (180.0f / (float)M_PI);
		ret.y = (atanf(vDelta.y / vDelta.x)) * (180.0f / (float)M_PI);
		[/swap_lines]

		[add_junk 1 5 /]

		if (vDelta.x >= 0.0f)
			ret.y += 180.0f;

		return ret;
	}

	bool IsTargetValid(Player* ply, int bone)
	{
		[add_junk 1 5 /]

		if (ply->baseAddr == NULL || ply->bIsDormant || !ply->bAlive)
		{
			[add_junk 1 5 /]
			return false;
		}

		if (ply->fImmuneTime >= 0.001f)
			return false;

		[add_junk 1 5 /]

		if (csgo->m_Hacks.tActualAimbotOptions.bVisibleCheck && !csgo->IsSpottedBy(*ply, csgo->m_Me))
			return false;

		[add_junk 1 5 /]

		if (!csgo->m_Hacks.tActualAimbotOptions.bRageMode && GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(ply, bone)) > csgo->m_Hacks.tActualAimbotOptions.fFOVRadius)
			return false;

		[add_junk 1 5 /]

		if (csgo->m_Hacks.tActualAimbotOptions.bJumpCheck && !(ply->iFlags & (1 << 0)))
			return false;

		return true;
	}

	void DropTarget()
	{
		m_Target = NULL;
		[add_junk 1 5 /]
	}

	bool CanShoot()
	{
		DWORD baseCombatHandle = csgo->m_Mem.Read<DWORD>(csgo->m_Me.baseAddr + csgo->m_dynamicOffsets.netvar_hActiveWeapon);
		baseCombatHandle &= 0xFFF;
		[add_junk 1 5 /]
		DWORD weapBase = csgo->m_Mem.Read<DWORD>(csgo->m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);

		float nextPrimaryAttack = csgo->m_Mem.Read<float>(weapBase + csgo->m_dynamicOffsets.netvar_flNextPrimaryAttack);
		float tickBase = csgo->m_Mem.Read<float>(csgo->m_dwLocalBase + csgo->m_dynamicOffsets.netvar_nTickBase);
		[add_junk 1 5 /]
		float intervalPerTick = csgo->m_Mem.Read<float>(csgo->m_dwGlobalVarsBase + 0x20);
		float flServerTime = tickBase * intervalPerTick;

		return (!(nextPrimaryAttack > flServerTime));
	}

	void Start()
	{
		[add_junk 1 5 /]

		while (!csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop)
		{
			if (GetAsyncKeyState(VK_END))
				csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop = true;

			if (!csgo->m_Hacks.CheckBit(BIT_AIMBOT))
			{
				DropTarget();
				[add_junk 1 5 /]
				continue;
			}

			[swap_lines]
			int axis = rand() % (2 - 0 + 1) + 0;
			float offset = RAND_FLOAT(-20.0f, 20.0f);
			[/swap_lines]

			[add_junk 1 5 /]

			[swap_lines]
			int boneToAimAt = 0;
			float rcsScale = 0.0f;
			[/swap_lines]

			switch (csgo->GetWeaponType(csgo->m_Me))
			{
				case  WeapType_Pistol:
				{
					[add_junk 1 5 /]
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone;
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale;
					break;
				}

				case  WeapType_Sniper:
				{
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone;
					[add_junk 1 5 /]
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale;
					break;
				}

				case  WeapType_Rifle:
				{
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone;
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale;
					[add_junk 1 5 /]
					break;
				}

				case  WeapType_SMG:
				{
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone;
					[add_junk 1 5 /]
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale;
					break;
				}

				case  WeapType_LMG:
				{
					[add_junk 1 5 /]
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone;
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale;
					break;
				}
				case  WeapType_Shotgun:
				{
					[swap_lines]
					boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone;
					rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale;
					[/swap_lines]

					[add_junk 1 5 /]

					break;
				}

				default:
				{
					[add_junk 1 5 /]
					continue;
				}
			}

			if (m_Target && !IsTargetValid(m_Target, boneToAimAt))
			{
				DropTarget();
				[add_junk 1 5 /]
			}

			if (csgo->m_Me.bIsReloading || !csgo->m_Me.iAmmo_Primary)
				continue;

			if (csgo->m_Hacks.tActualAimbotOptions.bRageMode)
				csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor = 1.0f;

			switch (csgo->m_Hacks.tActualAimbotOptions.eAimMethod.type)
			{
				case ClosestToCrosshair:
				{
					[add_junk 1 5 /]
					m_Target = GetPlayerClosestToCrosshair(boneToAimAt);
					break;
				}
				case ClosestToPlayer:
				{
					m_Target = GetPlayerClosestToPlayer(boneToAimAt);
					[add_junk 1 5 /]
					break;
				}
				case LowestHP:
				{
					m_Target = GetPlayerLowestHP(boneToAimAt);
					[add_junk 1 5 /]
					break;
				}
			}

			if (m_Target == nullptr)
				continue;

			[swap_lines]
			CVector targetOrigin = m_Target->vOrigin;
			CVector enemyPos = csgo->BonePosition(m_Target, boneToAimAt);
			[/swap_lines]

			float check = (float)abs((targetOrigin - enemyPos).Length());

			if (check > 75.0f)
				continue;

			[swap_lines]
			CVector viewAngles = csgo->m_Me.vViewAngles;
			CVector position = csgo->m_Me.vOrigin + csgo->m_Me.vVecViewOffset;
			[/swap_lines]
			[add_junk 1 5 /]

			[swap_lines]
			CVector myVelocity = csgo->m_Me.vVelocity;
			CVector targetVelocity = m_Target->vVelocity;
			CVector distVec = csgo->BonePosition(m_Target, boneToAimAt) - enemyPos;
			[/swap_lines]

			float dist = FastSQRT((distVec.x * distVec.x) + (distVec.y * distVec.y) + (distVec.z * distVec.z));

			if (dist > 0.001f)
			{
				[swap_lines]
				enemyPos.x += (targetVelocity.x) / dist;
				enemyPos.y += (targetVelocity.y) / dist;
				enemyPos.z += (targetVelocity.z) / dist;
				[/swap_lines]

				[add_junk 1 5 /]

				[swap_lines]
				enemyPos.x -= (myVelocity.x) / dist;
				enemyPos.y -= (myVelocity.y) / dist;
				enemyPos.z -= (myVelocity.z) / dist;
				[/swap_lines]
			}

			viewAngles = CalcAngle(position, enemyPos);
			ClampAngles(viewAngles);


 			CVector punchAngle(csgo->m_Me.vPunchAngles.x, csgo->m_Me.vPunchAngles.y, 0.0f);
			[add_junk 1 5 /]
			viewAngles -= punchAngle * rcsScale;

			ClampAngles(viewAngles);

			CVector curView = csgo->m_Me.vViewAngles;
			[add_junk 1 5 /]
			CVector qDelta(viewAngles.x - curView.x, viewAngles.y - curView.y, 0.0f);

			ClampAngles(qDelta);

			[swap_lines]
			viewAngles.x = curView.x + qDelta.x / csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor;
			viewAngles.y = curView.y + qDelta.y / csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor;
			[/swap_lines]

			[add_junk 1 5 /]

			ClampAngles(viewAngles);

			if (!csgo->m_Hacks.tActualAimbotOptions.bSilentAim)
			{
				[add_junk 1 5 /]
				csgo->m_Mem.Write<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles, viewAngles);
			}
			else
			{
				if (!CanShoot())
					continue;

				int seqNum = 0;
				CVector oldAngles;
				[add_junk 1 5 /]
				DWORD userCMD = csgo->m_dynamicOffsets.userCMDOffset; //b8d8c94

				int curSequenceNum = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr + 0x4C7C);
				curSequenceNum += 1;

				userCMD += (curSequenceNum % 150) * 0x64;

				[add_junk 1 5 /]

				csgo->m_Mem.Write<bool>(csgo->m_dynamicOffsets.bSendPacketOffset, false);

				while (seqNum != curSequenceNum)
				{
					oldAngles = csgo->m_Mem.Read<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles);
					seqNum = csgo->m_Mem.Read<int>(userCMD + 0x4);
				}

				for (int i = 0; i < 20; i++)
				{
					csgo->m_Mem.Write<CVector>(userCMD + 0xC, viewAngles);
					[add_junk 1 5 /]
				}

				csgo->m_Mem.Write<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles, oldAngles);
				[add_junk 1 5 /]
				std::this_thread::sleep_for(std::chrono::milliseconds(6));

				csgo->m_Mem.Write<bool>(csgo->m_dynamicOffsets.bSendPacketOffset, true);
			}

			[add_junk 1 5 /]

			std::this_thread::sleep_for(std::chrono::milliseconds(5));
		}

	}

private:
	[swap_lines]
	CSGO* csgo;
	Player* m_Target;
	[/swap_lines]

	[add_junk_datamembers 1 10 /]
};

#endif //_ACTUALAIMBOT_H_

[junk_disable /]