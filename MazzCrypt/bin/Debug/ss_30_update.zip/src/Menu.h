#ifndef _MENU_H_
#define _MENU_H_

#include "stdafx.h"
#include "D3D.h"
#include "Vector.h"
#include <string>
#include <vector>

#define MenuFont pD3DMenu->m_hFontMenu
#define WMFont pD3DMenu->m_hFontWatermark
#define DescFont pD3DMenu->m_hFontDescription

[junk_enable /]

class MenuItem
{
public:
	[swap_lines]
	MenuItem() = default;
	virtual ~MenuItem() = default;
	MenuItem(std::string name, std::string desc, CVector2D pos, CVector2D scale);
	virtual void Render() = 0;
	[/swap_lines]

	[swap_lines]
	CVector2D m_Scale;
	CVector2D m_Position;
	std::string m_szName;
	std::string m_szDesc;
	bool m_bVisible = false;
	[/swap_lines]

	[add_junk_datamembers 1 9 /]

};

class Form : public MenuItem
{
public:

	[swap_lines]
	Form() = default;
	virtual ~Form() override = default;
	Form(std::string name, CVector2D pos, CVector2D scale);
	virtual void Render() override;
	[/swap_lines]

	void AddItem(MenuItem* item)
	{
		[add_junk 2 3 /]
		m_Items.push_back(item);
	}

	std::vector<MenuItem*> m_Items;

	[add_junk_datamembers 1 4 /]
};

typedef void(*CallbackType)(void);

class Button : public MenuItem
{
public:
	[swap_lines]
	Button() = default;
	virtual ~Button() override = default;
	Button(std::string name, std::string desc, CVector2D pos, int width, CallbackType callback, MenuItem* parent);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	MenuItem* m_Parent;
	CallbackType m_callbackFunc;
	int m_nWidth;
	[/swap_lines]

	[add_junk_datamembers 1 5 /]
};

class CheckBox : public MenuItem
{
public:

	[swap_lines]
	CheckBox() = default;
	virtual ~CheckBox() = default;
	CheckBox(std::string name, std::string desc, CVector2D pos, bool* var, MenuItem* parent);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	MenuItem* m_Parent;
	bool* m_pbToggleVar;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]
};

class Slider_Float : public MenuItem
{
public:

	[swap_lines]
	Slider_Float() = default;
	virtual ~Slider_Float() override = default;
	Slider_Float(std::string name, std::string desc, CVector2D pos, float* var, float min, float max, int width, MenuItem* parent);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	float m_fMin;
	float m_fMax;
	int m_nWidth;
	float* m_pfVar;
	MenuItem* m_Parent;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]
};

class Slider_Int : public MenuItem
{
public:

	[swap_lines]
	Slider_Int() = default;
	virtual ~Slider_Int() override = default;
	Slider_Int(std::string name, std::string desc, CVector2D pos, int* var, int min, int max, int width, MenuItem* parent);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	int m_nMin;
	int m_nMax;
	int m_nWidth;
	int* m_pfVar;
	MenuItem* m_Parent;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]
};

class ComboBox : public MenuItem
{
public:

	[swap_lines]
	ComboBox() = default;
	virtual ~ComboBox() override = default;
	ComboBox(std::string name, std::string desc, CVector2D pos, int width, int* var, std::vector<std::string> elements, MenuItem* parent, int offset = 0);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	std::vector<std::string> m_vElements;
	int* m_pnVar;
	MenuItem* m_Parent;
	int m_nWidth;
	bool m_bCollapsed;
	int m_nOffset;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]
};

class KeyBox : public MenuItem
{
public:

	[swap_lines]
	KeyBox() = default;
	virtual ~KeyBox() override = default;
	KeyBox(std::string name, std::string desc, CVector2D pos, int width, int* key, MenuItem* parent);
	virtual void Render() override;
	[/swap_lines]

	[swap_lines]
	MenuItem* m_Parent;
	bool m_bClicked;
	int m_nWidth;
	int* m_pnKey;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]
};

#endif

[junk_disable /]