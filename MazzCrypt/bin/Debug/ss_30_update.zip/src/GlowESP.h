#ifndef _GLOWESP_H_
#define _GLOWESP_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Renderer.h"

struct GlowObjectDefinition
{
	DWORD			pEntity;
	CVector			rgb;
	float			a; // 0x10
	unsigned char	unk1[16];
	bool			bRenderWhenOccluded; // 0x24
	bool			bRenderWhenUnoccluded; // 0x25
	bool			bFullBloom; // 0x26
	unsigned char	unk2[14];

};

[junk_enable /]

class GlowESP
{
public:

	GlowESP() 
	{
		[add_junk 1 4 /]
	}

	void WriteGlowStruct(DWORD& mObj, GlowObjectDefinition& glowObj)
	{
		[swap_lines]
		csgo->m_Mem.Write<CVector>(mObj + 0x4, glowObj.rgb);
		csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
		csgo->m_Mem.Write<bool>(mObj + 0x24, glowObj.bRenderWhenOccluded);
		csgo->m_Mem.Write<bool>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
		csgo->m_Mem.Write<bool>(mObj + 0x26, glowObj.bFullBloom);
		[/swap_lines]

		[add_junk 1 4 /]
	}

	void Start()
	{
		while (!csgo->m_Hacks.tThreadHandling.bGlowThreadStop)
		{
			[swap_lines]
			static DWORD objGlowArray = 0;
			static int objCount = 0;
			[/swap_lines]

			[add_junk 1 4 /]

			if (GetAsyncKeyState(VK_END))
				csgo->m_Hacks.tThreadHandling.bGlowThreadStop = true;

			if (csgo->m_Hacks.CheckBit(BIT_GLOWESP))
			{
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				[add_junk 1 4 /]
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);

				if (objGlowArray != NULL)
				{
					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						[add_junk 1 4 /]
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						if (!glowObj.pEntity)
							continue;

						if (csgo->m_Hacks.tGlowOptions.bGlowBomb)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CC4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4)
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowBomb_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowBomb_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]

								WriteGlowStruct(mObj, glowObj);
							}


						}

						if (csgo->m_Hacks.tGlowOptions.bBombInfo)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4 && csgo->m_Mem.Read<bool>(glowObj.pEntity + csgo->m_dynamicOffsets.netvar_bBombTicking))
							{
								// 0x10 = p_gGlobalVars->curTime
								float bombTime = csgo->m_Mem.Read<float>(glowObj.pEntity + csgo->m_dynamicOffsets.netvar_flC4Blow) - csgo->m_Mem.Read<float>(csgo->m_dwGlobalVarsBase + 0x10);
								float r, g, b;

								if (bombTime >= 10.0f)
								{
									[swap_lines]
									r = 0.0f;
									g = 1.0f;
									b = 0.0f;
									[/swap_lines]
								}
								else if (bombTime >= 5.0f)
								{
									[swap_lines]
									r = 0.0f;
									g = 0.0f;
									b = 1.0f;
									[/swap_lines]
								}
								else
								{
									[swap_lines]
									r = 1.0f;
									g = 0.0f;
									b = 0.0f;
									[/swap_lines]
								}

								[swap_lines]
								glowObj.rgb = CVector(r,g,b);
								glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowBomb_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]
								WriteGlowStruct(mObj, glowObj);
							}
						}

						#pragma region Grenade Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowGrenades)
						{
							if (csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fNades_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fNades_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]

								WriteGlowStruct(mObj, glowObj);
							}
						}

						if (csgo->m_Hacks.tGlowOptions.bGlowWeapons)
						{
							if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fWeapons_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fWeapons_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]

								WriteGlowStruct(mObj, glowObj);
							}

						}

						#pragma region Chicken Glow Check

						if (csgo->m_Hacks.tGlowOptions.bChickenGlow)
						{
							[add_junk 1 4 /]

							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CChicken)
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fChickenRGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fChicken_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]

								WriteGlowStruct(mObj, glowObj);
							}

						}

						if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CCSPlayer)
						{
							for (int i = 1; i < 64; i++)
							{
								Player ply = csgo->m_Players[i];

								if (ply.baseAddr != glowObj.pEntity)
									continue;

								[swap_lines]
								float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length()) * 0.01905f;
								bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));
								[/swap_lines]

								[add_junk 1 4 /]

								if ((csgo->m_Hacks.tGlowOptions.targetType.type == Target_Enemies) && !bEnemy)
								{
									[add_junk 1 4 /]
									continue;
								}
								else if ((csgo->m_Hacks.tGlowOptions.targetType.type == Target_Teammates) && bEnemy)
								{
									[add_junk 1 4 /]
									continue;
								}

								CVector targetColor = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB) : (csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB);
								[add_junk 1 4 /]
								float targetAlpha = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemy_A) : (csgo->m_Hacks.tGlowOptions.fGlowTeam_A);
								[add_junk 1 4 /]
								CVector visibleColor = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB) : (csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB);
								float visibleAlpha = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A) : (csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A);
								[add_junk 1 4 /]
								bool isVisible = (csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->IsSpottedBy(ply, csgo->m_Me));

								[swap_lines]
								glowObj.rgb = (isVisible) ? visibleColor : targetColor;
								glowObj.a = (isVisible) ? visibleAlpha : targetAlpha;
								[/swap_lines]

								[add_junk 1 4 /]

								if (!csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->m_Hacks.tGlowOptions.bHealthGlow)
								{
									glowObj.rgb = targetColor;
									[add_junk 1 4 /]
									glowObj.a = targetAlpha;
								}

								if (csgo->m_Hacks.tGlowOptions.bHealthGlow)
								{
									int health = ply.iHealth;

									[swap_lines]
									glowObj.rgb = CVector((100.f - health) / 100.f, health / 100.f, 0.f);
									glowObj.a = 0.7f;
									[/swap_lines]

									[add_junk 1 4 /]
								}

								if (csgo->m_Hacks.tGlowOptions.bFlashGlow && ply.fFlashDuration > 0.001f)
								{
									glowObj.rgb = CVector(1.f, 1.f, 1.f);
									[add_junk 1 4 /]
									glowObj.a = 0.7f;
								}

								if (csgo->m_Hacks.tGlowOptions.bDefuseGlow && ply.bIsDefusing)
								{
									glowObj.rgb = csgo->m_Hacks.tGlowOptions.fDefuse_RGB;
									[add_junk 1 4 /]
									glowObj.a = csgo->m_Hacks.tGlowOptions.fDefuse_A;
								}

								if (ply.bIsDormant || dist >= csgo->m_Hacks.tGlowOptions.fMaxDist)
									glowObj.a = 0.0f;

								[swap_lines]
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 4 /]

								WriteGlowStruct(mObj, glowObj);
							}
						}
#pragma endregion
					}
				}
			}
			else
			{
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);

				if (objGlowArray != NULL)
				{
					#pragma region Toggle Off

					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						[add_junk 1 4 /]
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)) || csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity))
							|| csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CC4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4
							|| csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CChicken)
						{
							[swap_lines]
							glowObj.rgb = CVector(0, 0, 0);
							glowObj.a = 0.0f;
							glowObj.bRenderWhenOccluded = true;
							glowObj.bRenderWhenUnoccluded = false;
							glowObj.bFullBloom = false;
							[/swap_lines]

							[add_junk 1 4 /]

							WriteGlowStruct(mObj, glowObj);
						}

					}
				}

				[add_junk 1 4 /]
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}

	GlowESP(CSGO* c)
	{
		[add_junk 1 4 /]
		csgo = c;
	}

	~GlowESP() = default;


private:

	CSGO* csgo;

	[add_junk_datamembers 1 8 /]
};

#endif

[junk_disable /]