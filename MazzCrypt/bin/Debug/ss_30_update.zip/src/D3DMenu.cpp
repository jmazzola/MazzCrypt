#include "D3DMenu.h"
#include "CSGO.h"
#include "Renderer.h"

#include "Decrypt.h"

D3DMenu* pD3DMenu = new D3DMenu();

[junk_enable /]
[enc_string_enable /]

D3DMenu::D3DMenu()
{
	[add_junk 1 7 /]
	m_pMiscForm = m_pAimlockForm = m_pGlowESPForm = m_pSubtleAimbotForm = nullptr;
	m_nCurrentTab = 0;
	[add_junk 1 7 /]
	m_bVisible = false;
}

D3DMenu::~D3DMenu()
{
	for (auto& item : m_vGlowESPItems)
	{
		delete item;
		[add_junk 1 7 /]
		item = nullptr;
	}

	for (auto& item : m_vSubtleAimbotItems)
	{
		[add_junk 1 7 /]
		delete item;
		item = nullptr;
	}

	for (auto& item : m_vAimlockItems)
	{
		delete item;
		item = nullptr;
		[add_junk 1 7 /]
	}

	for (auto& item : m_vMiscItems)
	{
		delete item;
		[add_junk 1 7 /]
		item = nullptr;
	}

	for (auto& item : m_vESPItems)
	{
		delete item;
		[add_junk 1 7 /]
		item = nullptr;
	}

	delete m_pSubtleAimbotForm;
	[add_junk 1 7 /]
	delete m_pGlowESPForm;
	delete m_pAimlockForm;
	[add_junk 1 7 /]
	delete m_pMiscForm;
	delete m_pESPForm;

	m_pESPForm = m_pMiscForm = m_pAimlockForm = m_pSubtleAimbotForm = m_pGlowESPForm = nullptr;

	[add_junk 1 7 /]
}

void D3DMenu::InitMenu(CVector2D pos, CVector2D scale)
{
	m_pGlowESPForm = new Form("Glow ESP [" + miscUtils->GetStringFromKey(pCSGO->m_Hacks.tGlowOptions.iKey) + "]", pos, scale);
	m_pSubtleAimbotForm = new Form("Subtle Aimbot [" + miscUtils->GetStringFromKey(pCSGO->m_Hacks.tSubtleAimbotOptions.iKey) + "]", pos, scale);
	m_pAimlockForm = new Form("Aimlock [" + miscUtils->GetStringFromKey(pCSGO->m_Hacks.tActualAimbotOptions.iAimKey) + "]", pos, scale);
	m_pMiscForm = new Form("Misc", pos, scale);
	m_pESPForm = new Form("ESP [" + miscUtils->GetStringFromKey(pCSGO->m_Hacks.tESPOptions.iKey) + "]", pos, scale);

	int x = 148, xspace = 150;

	[swap_lines]
	std::vector<std::string> targetType = { "Enemies Only", "Teammates Only", "Everyone" };
	std::vector<std::string> aimType = { "Closest to Crosshair", "Closest to Player", "Lowest HP" };
	std::vector<std::string> bones = { "", "Lower Chest", "Sternum", " Upper Chest", "Stomach", "Neck", "Head" };
	std::vector<std::string> chats = { "Advertisement", "Custom chat.txt" };
	std::vector<std::string> boxes = { "Bounding", "Shitty Cornered" };
	std::vector<std::string> hbars = { "Left", "Right" };
	[/swap_lines]

	[add_junk 1 7 /]

	m_vGlowESPItems.push_back(new Button("GlowESP", "Go to GlowESP Menu", CVector2D(10, 50), 130, []() { pD3DMenu->m_nCurrentTab = 0; }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("Subtle Aimbot", "Go to Subtle Aimbot Menu", CVector2D(10, 80), 130, []() { pD3DMenu->m_nCurrentTab = 1; }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("Aimlock", "Go to Aimlock Menu", CVector2D(10, 110), 130, []() { pD3DMenu->m_nCurrentTab = 2; }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("Misc", "Go to Misc Menu", CVector2D(10, 140), 130, []() { pD3DMenu->m_nCurrentTab = 3; }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("ESP", "Go to ESP Menu", CVector2D(10, 170), 130, []() { pD3DMenu->m_nCurrentTab = 4; }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("Load", "Load Settings", CVector2D(10, 400), 130, []() { miscUtils->LoadINISettings("settings.ini", pCSGO); }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Button("Save", "Save Settings", CVector2D(10, 430), 130, []() { miscUtils->SaveINISettings("settings.ini", pCSGO); }, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Active", "Toggle GlowESP", CVector2D(x, 45), &pCSGO->m_Hacks.tGlowOptions.bActivated, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new ComboBox("Target Type", "Pick Target Type", CVector2D(x + xspace, 45), 125, &pCSGO->m_Hacks.tGlowOptions.targetType.type, targetType, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Flashed", "Toggle Flashed", CVector2D(x, 75), &pCSGO->m_Hacks.tGlowOptions.bFlashGlow, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Bomb", "Toggle Bomb", CVector2D(x, 105), &pCSGO->m_Hacks.tGlowOptions.bGlowBomb, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Bomb Information", "Toggle Bomb Info", CVector2D(x, 135), &pCSGO->m_Hacks.tGlowOptions.bBombInfo, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Grenades", "Toggle Grenades", CVector2D(x, 165), &pCSGO->m_Hacks.tGlowOptions.bGlowGrenades, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Weapons", "Toggle Weapons", CVector2D(x, 195), &pCSGO->m_Hacks.tGlowOptions.bGlowWeapons, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Chickens", "Toggle Chickens", CVector2D(x, 225), &pCSGO->m_Hacks.tGlowOptions.bChickenGlow, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Defuser", "Toggle Defuser", CVector2D(x, 255), &pCSGO->m_Hacks.tGlowOptions.bDefuseGlow, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Visibility", "Toggle Visible Check", CVector2D(x, 285), &pCSGO->m_Hacks.tGlowOptions.bVisibleGlow, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new CheckBox("Override for Health", "Override colors to show health", CVector2D(x, 315), &pCSGO->m_Hacks.tGlowOptions.bHealthGlow, m_pGlowESPForm));
	m_vGlowESPItems.push_back(new Slider_Float("Max Render Distance", "The maximum distance a target is from you to render", CVector2D(x, 345), &pCSGO->m_Hacks.tGlowOptions.fMaxDist, 1.0f, 100.0f, 200, m_pGlowESPForm));

	m_vSubtleAimbotItems.push_back(new Button("GlowESP", "Go to GlowESP Menu", CVector2D(10, 50), 130, []() { pD3DMenu->m_nCurrentTab = 0; }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("Subtle Aimbot", "Go to Subtle Aimbot Menu", CVector2D(10, 80), 130, []() { pD3DMenu->m_nCurrentTab = 1; }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("Aimlock", "Go to Aimlock Menu", CVector2D(10, 110), 130, []() { pD3DMenu->m_nCurrentTab = 2; }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("Misc", "Go to Misc Menu", CVector2D(10, 140), 130, []() { pD3DMenu->m_nCurrentTab = 3; }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("ESP", "Go to ESP Menu", CVector2D(10, 170), 130, []() { pD3DMenu->m_nCurrentTab = 4; }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("Load", "Load Settings", CVector2D(10, 400), 130, []() { miscUtils->LoadINISettings("settings.ini", pCSGO); }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Button("Save", "Save Settings", CVector2D(10, 430), 130, []() { miscUtils->SaveINISettings("settings.ini", pCSGO); }, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Active", "Toggle Subtle Aimbot", CVector2D(x, 45), &pCSGO->m_Hacks.tSubtleAimbotOptions.bActivated, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new ComboBox("Target Type", "Pick Target Type", CVector2D(x + xspace, 45), 125, &pCSGO->m_Hacks.tSubtleAimbotOptions.targetType.type, targetType, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Rage Mode", "Insta-snap to the target", CVector2D(x, 75), &pCSGO->m_Hacks.tSubtleAimbotOptions.bRageMode, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Visibility", "Toggle Visibility Check", CVector2D(x, 105), &pCSGO->m_Hacks.tSubtleAimbotOptions.bVisibleCheck, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Jump Check", "Toggle it working on jumping targets", CVector2D(x, 135), &pCSGO->m_Hacks.tSubtleAimbotOptions.bJumpCheck, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Intelligent Aim", "Shoot at the chest after firing past a certain limit", CVector2D(x, 165), &pCSGO->m_Hacks.tSubtleAimbotOptions.bIntelligentAim, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new CheckBox("Random Position", "Randomize aim at location around bone", CVector2D(x, 195), &pCSGO->m_Hacks.tSubtleAimbotOptions.bRandomPos, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Slider_Float("Smooth Factor", "How smooth the aimbot is", CVector2D(x, 225), &pCSGO->m_Hacks.tSubtleAimbotOptions.fSmoothFactor, 1.0f, 100.0f, 150, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new ComboBox("Aim At [Rifle]", "What bone to aim at while firing a rifle", CVector2D(x, 255), 135, &pCSGO->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone, bones, m_pSubtleAimbotForm, 1));
	m_vSubtleAimbotItems.push_back(new Slider_Int("Min Chance [Rifle]", "The minimum of how many shots fired before it aims at the bone", CVector2D(x, 300), &pCSGO->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance, 0, 29, 150, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Slider_Int("Max Chance [Rifle]", "The maximum of how many shots fired before it aims at the bone", CVector2D(x, 330), &pCSGO->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance, 0, 29, 150, m_pSubtleAimbotForm));
	m_vSubtleAimbotItems.push_back(new Slider_Float("RCS Factor [Rifle]", "How much recoil control should be with every shot towards the aimed bone", CVector2D(x, 360), &pCSGO->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale, 0.0f, 1.0f, 150, m_pSubtleAimbotForm));

	m_vAimlockItems.push_back(new Button("GlowESP", "Go to GlowESP Menu", CVector2D(10, 50), 130, []() { pD3DMenu->m_nCurrentTab = 0; }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("Subtle Aimbot", "Go to Subtle Aimbot Menu", CVector2D(10, 80), 130, []() { pD3DMenu->m_nCurrentTab = 1; }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("Aimlock", "Go to Aimlock Menu", CVector2D(10, 110), 130, []() { pD3DMenu->m_nCurrentTab = 2; }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("Misc", "Go to Misc Menu", CVector2D(10, 140), 130, []() { pD3DMenu->m_nCurrentTab = 3; }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("ESP", "Go to ESP Menu", CVector2D(10, 170), 130, []() { pD3DMenu->m_nCurrentTab = 4; }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("Load", "Load Settings", CVector2D(10, 400), 130, []() { miscUtils->LoadINISettings("settings.ini", pCSGO); }, m_pAimlockForm));
	m_vAimlockItems.push_back(new Button("Save", "Save Settings", CVector2D(10, 430), 130, []() { miscUtils->SaveINISettings("settings.ini", pCSGO); }, m_pAimlockForm));
	m_vAimlockItems.push_back(new CheckBox("Active", "Toggle Subtle Aimbot", CVector2D(x, 45), &pCSGO->m_Hacks.tActualAimbotOptions.bActivated, m_pAimlockForm));
	m_vAimlockItems.push_back(new ComboBox("Target Type", "Pick Target Type", CVector2D(x + xspace, 45), 135, &pCSGO->m_Hacks.tActualAimbotOptions.targetType.type, targetType, m_pAimlockForm));
	m_vAimlockItems.push_back(new ComboBox("Aim Method", "Pick Aim Method", CVector2D(x + xspace, 90), 135, &pCSGO->m_Hacks.tActualAimbotOptions.eAimMethod.type, aimType, m_pAimlockForm));
	m_vAimlockItems.push_back(new CheckBox("Rage Mode", "Insta-snap to the target", CVector2D(x, 75), &pCSGO->m_Hacks.tActualAimbotOptions.bRageMode, m_pAimlockForm));
	m_vAimlockItems.push_back(new CheckBox("Visibility", "Toggle Visibility Check", CVector2D(x, 105), &pCSGO->m_Hacks.tActualAimbotOptions.bVisibleCheck, m_pAimlockForm));
	m_vAimlockItems.push_back(new CheckBox("Jump Check", "Toggle it working on jumping targets", CVector2D(x, 135), &pCSGO->m_Hacks.tActualAimbotOptions.bJumpCheck, m_pAimlockForm));
	m_vAimlockItems.push_back(new Slider_Float("Smooth Factor", "How smooth the aimbot is", CVector2D(x, 165), &pCSGO->m_Hacks.tActualAimbotOptions.fSmoothFactor, 1.0f, 10.0f, 150, m_pAimlockForm));
	m_vAimlockItems.push_back(new Slider_Float("FOV", "The amount of degrees a target has to be within their Field of View", CVector2D(x, 195), &pCSGO->m_Hacks.tActualAimbotOptions.fFOVRadius, 1.0f, 360.0f, 150, m_pAimlockForm));


	m_vMiscItems.push_back(new Button("GlowESP", "Go to GlowESP Menu", CVector2D(10, 50), 130, []() { pD3DMenu->m_nCurrentTab = 0; }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("Subtle Aimbot", "Go to Subtle Aimbot Menu", CVector2D(10, 80), 130, []() { pD3DMenu->m_nCurrentTab = 1; }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("Aimlock", "Go to Aimlock Menu", CVector2D(10, 110), 130, []() { pD3DMenu->m_nCurrentTab = 2; }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("Misc", "Go to Misc Menu", CVector2D(10, 140), 130, []() { pD3DMenu->m_nCurrentTab = 3; }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("ESP", "Go to ESP Menu", CVector2D(10, 170), 130, []() { pD3DMenu->m_nCurrentTab = 4; }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("Load", "Load Settings", CVector2D(10, 400), 130, []() { miscUtils->LoadINISettings("settings.ini", pCSGO); }, m_pMiscForm));
	m_vMiscItems.push_back(new Button("Save", "Save Settings", CVector2D(10, 430), 130, []() { miscUtils->SaveINISettings("settings.ini", pCSGO); }, m_pMiscForm));
	m_vMiscItems.push_back(new CheckBox("Bunnyhop", "Toggle Bhop", CVector2D(x, 45), &pCSGO->m_Hacks.tBhopOptions.bActivated, m_pMiscForm));
	m_vMiscItems.push_back(new CheckBox("Fakelag", "Toggle Fakelag", CVector2D(x, 75), &pCSGO->m_Hacks.tFakeLagOptions.bActivated, m_pMiscForm));
	m_vMiscItems.push_back(new Slider_Int("Packets Dropped", "How many packets we lag", CVector2D(x, 105), &pCSGO->m_Hacks.tFakeLagOptions.iLagInterval, 1, 100, 150, m_pMiscForm));
	m_vMiscItems.push_back(new CheckBox("Chatspam", "Toggle chatspam", CVector2D(x, 145), &pCSGO->m_Hacks.tChatSpamOptions.bActivated, m_pMiscForm));
	m_vMiscItems.push_back(new ComboBox("Chatspam Type", "Pick what type of Chatspam", CVector2D(x + xspace, 145), 135, &pCSGO->m_Hacks.tChatSpamOptions.eSpamMethod.type, chats, m_pMiscForm));
	m_vMiscItems.push_back(new CheckBox("Random Lines", "Toggle spam random lines of custom chat", CVector2D(x, 175), &pCSGO->m_Hacks.tChatSpamOptions.bRandomParse, m_pMiscForm));
	m_vMiscItems.push_back(new Slider_Int("Spam Interval", "How many ms we send a say command", CVector2D(x, 205), &pCSGO->m_Hacks.tChatSpamOptions.iChatInterval, 1, 10, 150, m_pMiscForm));

	m_vESPItems.push_back(new Button("GlowESP", "Go to GlowESP Menu", CVector2D(10, 50), 130, []() { pD3DMenu->m_nCurrentTab = 0; }, m_pESPForm));
	m_vESPItems.push_back(new Button("Subtle Aimbot", "Go to Subtle Aimbot Menu", CVector2D(10, 80), 130, []() { pD3DMenu->m_nCurrentTab = 1; }, m_pESPForm));
	m_vESPItems.push_back(new Button("Aimlock", "Go to Aimlock Menu", CVector2D(10, 110), 130, []() { pD3DMenu->m_nCurrentTab = 2; }, m_pESPForm));
	m_vESPItems.push_back(new Button("Misc", "Go to Misc Menu", CVector2D(10, 140), 130, []() { pD3DMenu->m_nCurrentTab = 3; }, m_pESPForm));
	m_vESPItems.push_back(new Button("ESP", "Go to ESP Menu", CVector2D(10, 170), 130, []() { pD3DMenu->m_nCurrentTab = 4; }, m_pESPForm));
	m_vESPItems.push_back(new Button("Load", "Load Settings", CVector2D(10, 400), 130, []() { miscUtils->LoadINISettings("settings.ini", pCSGO); }, m_pESPForm));
	m_vESPItems.push_back(new Button("Save", "Save Settings", CVector2D(10, 430), 130, []() { miscUtils->SaveINISettings("settings.ini", pCSGO); }, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Active", "Toggle ESP", CVector2D(x, 45), &pCSGO->m_Hacks.tESPOptions.bActivated, m_pESPForm));
	m_vESPItems.push_back(new ComboBox("Target Type", "Pick Target Type", CVector2D(x + xspace, 45), 135, &pCSGO->m_Hacks.tESPOptions.targetType.type, targetType, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Names", "Toggle showing target names", CVector2D(x, 75), &pCSGO->m_Hacks.tESPOptions.bShowNames, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Boxes", "Toggle showing target boxes", CVector2D(x, 105), &pCSGO->m_Hacks.tESPOptions.bShowBox, m_pESPForm));
	m_vESPItems.push_back(new ComboBox("Box Type", "Pick what box type to draw", CVector2D(x + xspace, 105), 135, &pCSGO->m_Hacks.tESPOptions.boxType.type, boxes, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Health Bar", "Toggle showing target health bars", CVector2D(x, 155), &pCSGO->m_Hacks.tESPOptions.bShowHealthBar, m_pESPForm));
	m_vESPItems.push_back(new ComboBox("Health Bar Type", "Toggle showing target health bars", CVector2D(x + xspace, 155), 135, &pCSGO->m_Hacks.tESPOptions.hBarType.type, hbars, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Distance", "Toggle showing target distance", CVector2D(x, 185), &pCSGO->m_Hacks.tESPOptions.bShowDistance, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Weapon", "Toggle showing target weapon", CVector2D(x, 215), &pCSGO->m_Hacks.tESPOptions.bShowWeapon, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("John Woo", "Toggle showing target weapon with silly names", CVector2D(x + xspace, 215), &pCSGO->m_Hacks.tESPOptions.bShowSillyWeapons, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Rank/Wins", "Toggle showing target MM info", CVector2D(x, 245), &pCSGO->m_Hacks.tESPOptions.bShowMMInfo, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Snaplines", "Toggle showing target snaplines", CVector2D(x, 275), &pCSGO->m_Hacks.tESPOptions.bSnapLines, m_pESPForm));
	m_vESPItems.push_back(new CheckBox("Visibility", "Toggle showing target visibility", CVector2D(x, 305), &pCSGO->m_Hacks.tESPOptions.bVisibleCheck, m_pESPForm));
	m_vESPItems.push_back(new Slider_Float("Max Render Distance", "The maximum distance a target is from you to render", CVector2D(x, 335), &pCSGO->m_Hacks.tESPOptions.fMaxDist, 1.0f, 100.0f, 200, m_pESPForm));

	for (auto& item : m_vGlowESPItems)
		m_pGlowESPForm->AddItem(item);
	
	for (auto& item : m_vSubtleAimbotItems)
		m_pSubtleAimbotForm->AddItem(item);

	[add_junk 1 7 /]

	for (auto& item : m_vAimlockItems)
		m_pAimlockForm->AddItem(item);

	[add_junk 1 7 /]

	for (auto& item : m_vMiscItems)
		m_pMiscForm->AddItem(item);

	for (auto& item : m_vESPItems)
		m_pESPForm->AddItem(item);

	[add_junk 1 7 /]
}

void D3DMenu::DrawMouse()
{
	POINT cur;
	GetCursorPos(&cur);
	ScreenToClient(miscUtils->GetGameWindow(), &cur);

	pRenderer->DrawRect(cur.x + 1, cur.y, 1, 17, CVector(3, 6, 26));

	for (int i = 0; i < 11; i++)
	{
		pRenderer->DrawRect(cur.x + 2 + i, cur.y + 1 + i, 1, 1, CVector(3, 6, 26));
		pRenderer->DrawRect(cur.x + 7, cur.y + 12, 6, 1, CVector(3, 6, 26));
		[add_junk 1 7 /]
		pRenderer->DrawRect(cur.x + 6, cur.y + 12, 1, 1, CVector(3, 6, 26));
		pRenderer->DrawRect(cur.x + 5, cur.y + 13, 1, 1, CVector(3, 6, 26));
		[add_junk 1 7 /]
		pRenderer->DrawRect(cur.x + 4, cur.y + 14, 1, 1, CVector(3, 6, 26));
		pRenderer->DrawRect(cur.x + 3, cur.y + 15, 1, 1, CVector(3, 6, 26));
		[add_junk 1 7 /]
		pRenderer->DrawRect(cur.x + 2, cur.y + 16, 1, 1, CVector(3, 6, 26));
	}

	for (int i = 0; i < 4; i++)
	{
		pRenderer->DrawRect(cur.x + 2 + i, cur.y + 2 + i, 1, 14 - (i * 2), CVector(255, 255, 255));
		pRenderer->DrawRect(cur.x + 6, cur.y + 6, 1, 6, CVector(255, 255, 255));
		pRenderer->DrawRect(cur.x + 7, cur.y + 7, 1, 5, CVector(255, 255, 255));
		[add_junk 1 7 /]
		pRenderer->DrawRect(cur.x + 8, cur.y + 8, 1, 4, CVector(255, 255, 255));
		[add_junk 1 7 /]
		pRenderer->DrawRect(cur.x + 9, cur.y + 9, 1, 3, CVector(255, 255, 255));
		pRenderer->DrawRect(cur.x + 10, cur.y + 10, 1, 2, CVector(255, 255, 255));
		pRenderer->DrawRect(cur.x + 11, cur.y + 11, 1, 1, CVector(255, 255, 255));
		[add_junk 1 7 /]
	}
}

void D3DMenu::Render()
{
	if (!m_bVisible)
		return;

	switch (m_nCurrentTab)
	{
		case 0:
		{
			m_pGlowESPForm->Render();
			[add_junk 1 7 /]
			break;
		}
		case 1:
		{
			m_pSubtleAimbotForm->Render();
			[add_junk 1 7 /]
			break;
		}
		case 2:
		{
			m_pAimlockForm->Render();
			[add_junk 1 7 /]
			break;
		}
		case 3:
		{
			m_pMiscForm->Render();
			[add_junk 1 7 /]
			break;
		}
		case 4:
		{
			m_pESPForm->Render();
			[add_junk 1 7 /]
			break;
		}
	}

	DrawMouse();

	[add_junk 1 7 /]
}

[junk_disable /]
[enc_string_disable /]