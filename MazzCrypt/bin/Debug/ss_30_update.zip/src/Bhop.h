#ifndef _BHOP_H_
#define _BHOP_H_

#include "stdafx.h"
#include "CSGO.h"

#define	FL_ONGROUND				(1<<0)	
#define FL_DUCKING				(1<<1)	
#define	FL_WATERJUMP			(1<<3)	
#define FL_ONTRAIN				(1<<4) 
#define FL_INRAIN				(1<<5)	
#define FL_FROZEN				(1<<6) 
#define FL_ATCONTROLS			(1<<7)
#define	FL_CLIENT				(1<<8)	
#define FL_FAKECLIENT			(1<<9)	
#define	FL_INWATER				(1<<10)

[junk_enable /]

class BHop
{
public:

	BHop(CSGO* c)
	{
		[add_junk 1 3 /]
		csgo = c;
	}

	~BHop() = default;

	void Start()
	{
		[add_junk 1 3 /]

		while (!csgo->m_Hacks.tThreadHandling.bBhopThreadStop)
		{
			if (GetAsyncKeyState(VK_END))
				csgo->m_Hacks.tThreadHandling.bBhopThreadStop = true;

 			if (csgo->m_Hacks.CheckBit(BIT_BHOP) && miscUtils->IsCSGOActiveWindow())
			{
				if (csgo->IsMouseEnabled())
				{
					[add_junk 1 3 /]
					continue;
				}

				if (csgo->m_Mem.Read<int>(csgo->m_Me.baseAddr + csgo->m_dynamicOffsets.netvar_fFlags) & FL_ONGROUND)
				{
					csgo->m_Mem.Write<DWORD>(csgo->m_dwClientBase + csgo->m_dynamicOffsets.jumpOffset, 5);
					[add_junk 1 3 /]
					std::this_thread::sleep_for(std::chrono::milliseconds(10));
					csgo->m_Mem.Write<DWORD>(csgo->m_dwClientBase + csgo->m_dynamicOffsets.jumpOffset, 4);
					[add_junk 1 3 /]
				}
				else
				{
					csgo->m_Mem.Write<DWORD>(csgo->m_dwClientBase + csgo->m_dynamicOffsets.jumpOffset, 4);
					[add_junk 1 3 /]
					std::this_thread::sleep_for(std::chrono::milliseconds(10));
				}
			}

			[add_junk 1 3 /]

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}

private:

	CSGO* csgo;

	[add_junk_datamembers 1 6 /]
};

#endif

[junk_disable /]