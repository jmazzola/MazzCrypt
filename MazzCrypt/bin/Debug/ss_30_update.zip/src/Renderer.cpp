#include "Renderer.h"

Renderer* pRenderer = new Renderer();

[junk_enable /]

Renderer::Renderer() : m_pDevice(nullptr)
{
}

Renderer::~Renderer()
{
	if (!m_pFonts.empty())
	{
		[add_junk 1 4 /]
		for (auto& font : m_pFonts)
		{
			delete font;
			font = nullptr;
		}
	}
}

void Renderer::PreFrame()
{
	if (!m_pFonts.empty())
	{
		[add_junk 1 4 /]
		for (auto& font : m_pFonts)
		{
			if (font)
				font->PreFrame();
		}
	}

	m_pDevice->SetFVF(Vertex_t::FVF);
}

void Renderer::PostFrame()
{
	[add_junk 1 4 /]

	if (!m_pFonts.empty())
	{
		for (auto& font : m_pFonts)
		{
			if (font)
				font->PostFrame();
		}
	}
}

void Renderer::OnReset()
{
	if (!m_pFonts.empty())
	{
		[add_junk 1 4 /]
		for (auto& font : m_pFonts)
		{
			if (font)
				font->OnReset();
		}
	}
}

unsigned long Renderer::CreateFont(const std::string& szFontName, int nFontSize, DWORD dwFlags)
{
	Font* pFont = new Font(m_pDevice, szFontName, nFontSize, dwFlags);
	[add_junk 1 4 /]
	m_pFonts.push_back(pFont);

	return (m_pFonts.size() - 1);
}

void Renderer::DrawRect(int x, int y, int w, int h, CVector color)
{
	Vertex_t vList[4];
	D3DCOLOR clr = D3DCOLOR_RGBA((int)color.x, (int)color.y, (int)color.z, 255);

	BuildVertex(XMFLOAT4(x, y + h, 0, 1), clr, vList, 0);
	BuildVertex(XMFLOAT4(x, y, 0, 1), clr, vList, 1);
	[add_junk 1 4 /]
	BuildVertex(XMFLOAT4(x + w, y + h, 0, 1), clr, vList, 2);
	BuildVertex(XMFLOAT4(x + w, y, 0, 1), clr, vList, 3);

	[add_junk 1 4 /]

	m_pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vList, sizeof(Vertex_t));
}

void Renderer::DrawRectOutlined(int x, int y, int w, int h, CVector fill, CVector outline)
{
	DrawRect(x, y, w, h, fill);
	[add_junk 1 4 /]
	DrawBorderBox(x, y, w, h, 1, outline);
}

void Renderer::DrawBorderBox(int x, int y, int w, int h, int t, CVector color)
{
	DrawRect(x, y, w, t, color);
	DrawRect(x, y, t, h, color);
	[add_junk 1 4 /]
	DrawRect(x + w, y, t, h, color);
	DrawRect(x, y + h, w + t, t, color);
	[add_junk 1 4 /]
}

void Renderer::DrawLine(int x0, int y0, int x1, int y1, CVector color)
{
	Vertex_t vList[2];
	D3DCOLOR clr = D3DCOLOR_RGBA((int)color.x, (int)color.y, (int)color.z, 255);

	BuildVertex(XMFLOAT4(x0, y0, 0, 0), clr, vList, 0);
	[add_junk 1 4 /]
	BuildVertex(XMFLOAT4(x1, y1, 0, 0), clr, vList, 1);

	m_pDevice->DrawPrimitiveUP(D3DPT_LINELIST, 2, vList, sizeof(Vertex_t));
}

void Renderer::DrawCircle(float x, float y, float r, float s, CVector color)
{
	float Step = M_PI * 2.0 / s;
	for (float a = 0; a < (M_PI*2.0); a += Step)
	{
		float x1 = r * cos(a) + x;
		[add_junk 1 4 /]
		float y1 = r * sin(a) + y;
		float x2 = r * cos(a + Step) + x;
		[add_junk 1 4 /]
		float y2 = r * sin(a + Step) + y;

		DrawLine(x1, y1, x2, y2, color);
	}
}

void Renderer::DrawText(unsigned long font, int x, int y, DWORD align, CVector color, const char* szText, ...)
{
	Font* pFont = m_pFonts[font];

	if (!pFont)
		return;

	char buffer[1024] = { 0 };

	va_list args;
	va_start(args, szText);
	vsprintf(buffer, szText, args);
	va_end(args);

	int w = 0, h = 0;
	pFont->GetTextSize(buffer, w, h);

	[add_junk 1 4 /]

	if (align & FONT_RENDER_RIGHT)
		x -= w;
	else if (align & FONT_RENDER_CENTER_H)
		x -= w / 2;
	
	if (align & FONT_RENDER_CENTER_V)
		y -= h / 2;

	pFont->DrawText(x, y, color, buffer);

	[add_junk 1 4 /]
}

void Renderer::DrawShadowText(unsigned long font, int x, int y, int shadowLength, DWORD align, CVector color, const char* szText, ...)
{
	char buffer[1024] = { 0 };

	[add_junk 1 4 /]

	va_list args;
	va_start(args, szText);
	vsprintf(buffer, szText, args);
	va_end(args);

	DrawText(font, x, y + shadowLength, align, Color_Black, buffer);
	[add_junk 1 4 /]
	DrawText(font, x, y, align, color, buffer);
}

[junk_disable /]