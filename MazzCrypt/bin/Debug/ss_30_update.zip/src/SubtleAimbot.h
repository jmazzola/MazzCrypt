#ifndef _AIMBOT_H_
#define _AIMBOT_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

#include <random>

[junk_enable /]

void PreventDivideByZero(int& min, int& max)
{
	if (min > max)
		min = max;
}

class SubtleAimbot
{
public:

	void Start()
	{
		[swap_lines]
		int axis = -1;
		float offset = FLT_MAX;
		[/swap_lines]

		[add_junk 1 4 /]

		while (!csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop)
		{
			if (GetAsyncKeyState(VK_END))
				csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = true;

			if (csgo->m_Hacks.CheckBit(BIT_SUBTLEAIMBOT))
			{
				int randomShotTime = 0;
				int boneToAimAt = 0;
				[add_junk 1 4 /]
				float rcsScale = 0.0f;

				switch (csgo->GetWeaponType(csgo->m_Me))
				{
					case  WeapType_Pistol:
					{
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance);
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone;
						[add_junk 1 4 /]
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale;
						break;
					}

					case  WeapType_Sniper:
					{
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance);
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone;
						[add_junk 1 4 /]
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale;
						break;
					}


					case  WeapType_Rifle:
					{
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance);
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone;
						[add_junk 1 4 /]
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale;
						break;
					}

					case  WeapType_SMG:
					{
						[add_junk 1 4 /]
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance);
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone;
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale;
						break;
					}

					case  WeapType_LMG:
					{
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance);
						[add_junk 1 4 /]
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone;
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale;
						break;
					}

					case  WeapType_Shotgun:
					{
						PreventDivideByZero(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance);
						randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance);
						boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone;
						[add_junk 1 4 /]
						rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale;
						break;
					}

					default:
					{
						[add_junk 1 4 /]
						continue;
					}

				}

				if (csgo->m_Hacks.tSubtleAimbotOptions.bRageMode)
				{
					rcsScale = 1.0f;
					randomShotTime = 0;
					[add_junk 1 4 /]
					csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor = 100.0f;
				}

				if (csgo->m_Me.iShotsFired > randomShotTime && !csgo->m_Me.bIsReloading && csgo->m_Me.iAmmo_Primary)
				{
					Player* enemy = PlayerInCross();

					if (!enemy)
						continue;

					if (csgo->m_Hacks.tSubtleAimbotOptions.bIntelligentAim && (csgo->m_Me.iShotsFired > randomShotTime + rand() % RAND_INT(1, 3)))
					{
						int bones[2] = { Bone_Neck, Bone_Spine2 };
						[add_junk 1 4 /]
						boneToAimAt = bones[rand() % (1 - 0 + 1) + 0];
					}

					// Better method
					CVector enemyPos = csgo->BonePosition(enemy, boneToAimAt);

					if (enemyPos.x <= 0.0f && enemyPos.y <= 0.0f && enemyPos.z <= 0.0f)
						continue;


					enemyPos = BetterVelocityComp(enemyPos, enemy->vVelocity);

					if (csgo->m_Hacks.tSubtleAimbotOptions.bRandomPos && (csgo->GetWeaponType(csgo->m_Me) !=  WeapType_Pistol))
					{
						switch (axis)
						{
							case 0:
							{
								enemyPos.x += offset;
								[add_junk 1 4 /]
								break;
							}

							case 1:
							{
								enemyPos.y += offset;
								break;
							}

							case 2:
							{
								enemyPos.z += offset;
								[add_junk 1 4 /]
								break;
							}
						}
					}

					CVector aimAngle = CalcAngle(csgo->m_Me.vEyePos, enemyPos);
					ClampAngles(aimAngle);

					CVector punchAngle(csgo->m_Me.vPunchAngles.x, csgo->m_Me.vPunchAngles.y, 0.0f);
					aimAngle -= punchAngle * (2.0f * rcsScale);
					[add_junk 1 4 /]
					ClampAngles(aimAngle);

					SetAimbotAngles(aimAngle, csgo->m_Me.vViewAngles);
				}
			}

			axis = rand() % (2 - 0 + 1) + 0;
			offset = RAND_FLOAT(-10.0f, 10.0f);
			[add_junk 1 4 /]
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}

	bool IsTargetValid(Player* ply)
	{
		[add_junk 1 4 /]

		if (csgo->m_Hacks.tSubtleAimbotOptions.bVisibleCheck && !csgo->IsSpottedBy(*ply, csgo->m_Me))
			return false;

		if (csgo->m_Hacks.tSubtleAimbotOptions.bJumpCheck && !(ply->iFlags & (1 << 0)))
			return false;

		if (!ply->bAlive || ply->bIsDormant || ply->fImmuneTime >= 0.0001f)
			return false;

		return true;
	}

	Player* PlayerInCross()
	{
		int playerInCrosshair = csgo->m_Mem.Read<int>(csgo->m_dwLocalBase + csgo->m_dynamicOffsets.crosshairIndex);

		if (!playerInCrosshair)
			return NULL;

		int playerIdx = 0;

		for (int i = 1; i < 64; i++)
		{
			Player ply = csgo->m_Players[i];

			bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));

			if ((csgo->m_Hacks.tSubtleAimbotOptions.targetType.type == Target_Enemies) && !bEnemy)
			{
				[add_junk 1 4 /]
				continue;
			}
			else if ((csgo->m_Hacks.tSubtleAimbotOptions.targetType.type == Target_Teammates) && bEnemy)
			{
				[add_junk 1 4 /]
				continue;
			}

			if (!IsTargetValid(&ply))
				continue;

			if (ply.iID == playerInCrosshair)
				return &csgo->m_Players[i];
		}

		[add_junk 1 4 /]

		return NULL;
	}

	void ClampAngles(CVector& angle)
	{
		while (angle.y > 180.0f)
			angle.y -= 360.0f;

		while (angle.y < -180.0f)
			angle.y += 360.0f;

		if (angle.x > 89.0f)
			angle.x = 89.0f;

		if (angle.x < -89.0f)
			angle.x = -89.0f;

		if (angle.z != 0.0f)
			angle.z = 0.0f;
	}

	CVector CalcAngle(CVector& src, CVector& dst)
	{
		CVector ret;
		CVector vDelta = src - dst;
		float fHyp = FastSQRT((vDelta.x * vDelta.x) + (vDelta.y * vDelta.y));

		[swap_lines]
		ret.x = (atan(vDelta.z / fHyp) * (float)(180.0f / 3.14159));
		ret.y = (atan(vDelta.y / vDelta.x) * (float)(180.0f / 3.14159));
		[/swap_lines]

		[add_junk 1 4 /]

		if (vDelta.x >= 0.0f)
			ret.y += 180.0f;

		return ret;
	}

	CVector VelocityCompensate(CVector& myVel, CVector& enemyVel)
	{
		float smoothAmount = csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor;

		CVector output;

		output.x = output.x + (enemyVel.x / 100.0f) * (40.0f / smoothAmount);
		output.y = output.y + (enemyVel.y / 100.0f) * (40.0f / smoothAmount);
		[add_junk 1 4 /]
		output.z = output.z + (enemyVel.z / 100.f) * (40.0f / smoothAmount);

		output.x = output.x - (myVel.x / 100.0f) * (40.0f / smoothAmount);
		output.y = output.y - (myVel.y / 100.0f) * (40.0f / smoothAmount);
		[add_junk 1 4 /]
		output.z = output.z - (myVel.z / 100.0f) * (40.0f / smoothAmount);

		return output;
	}

	CVector BetterVelocityComp(CVector enemyPos, CVector enemyVel)
	{
		CVector distVec = csgo->m_Me.vOrigin - enemyPos;
		float dist = FastSQRT((distVec.x * distVec.x) + (distVec.y * distVec.y) + (distVec.z * distVec.z));

		enemyPos.x += (enemyVel.x) / dist;
		enemyPos.y += (enemyVel.y) / dist;
		enemyPos.z += (enemyVel.z) / dist;
		[add_junk 1 4 /]
		enemyPos.x -= (csgo->m_Me.vVelocity.x) / dist;
		[add_junk 1 4 /]
		enemyPos.y -= (csgo->m_Me.vVelocity.y) / dist;
		enemyPos.z -= (csgo->m_Me.vVelocity.z) / dist;
		[add_junk 1 4 /]
		return enemyPos;
	}

	void SetAimbotAngles(CVector& dest, CVector& orig)
	{
		CVector smoothAngles;
		float smoothAmount = csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor;

		smoothAngles.x = dest.x - orig.x;
		smoothAngles.y = dest.y - orig.y;
		[add_junk 1 4 /]
		smoothAngles.z = 0.0f;
		ClampAngles(smoothAngles);

		smoothAngles.x = orig.x + smoothAngles.x / 100.0f * smoothAmount;
		[add_junk 1 4 /]
		smoothAngles.y = orig.y + smoothAngles.y / 100.0f * smoothAmount;
		smoothAngles.z = 0.0f;
		ClampAngles(smoothAngles);

		csgo->m_Mem.Write<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles, smoothAngles);

	}

	SubtleAimbot(CSGO* c)
	{
		[add_junk 1 4 /]
		csgo = c;
	}

	~SubtleAimbot() = default;

private:

	CSGO* csgo;

	[add_junk_datamembers 1 10 /]

};

#endif

[junk_disable /]