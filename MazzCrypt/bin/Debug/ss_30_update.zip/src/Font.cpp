#include "Font.h"

[junk_enable /]

Font::Font(IDirect3DDevice9* pDevice, const std::string& szFontName, int fontSize, DWORD dwFlags) : m_pDevice(pDevice), m_pFont(nullptr), m_pSprite(nullptr), m_szFontName(szFontName), m_nFontSize(fontSize), m_dwFlags(dwFlags)
{
	[add_junk 1 5 /]
}

Font::~Font()
{
	if (m_pFont)
	{
		m_pFont->Release();
		[add_junk 1 5 /]
		m_pFont = nullptr;
	}

	[add_junk 1 5 /]

	if (m_pSprite)
	{
		m_pSprite->Release();
		m_pSprite = nullptr;
		[add_junk 1 5 /]
	}
}

void Font::PreFrame()
{
	if (!m_pDevice)
		return;

	if (m_dwFlags & FONT_SPRITE)
	{
		if (!m_pSprite)
			D3DXCreateSprite(m_pDevice, &m_pSprite);

		if (m_pSprite)
			m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);

		[add_junk 1 5 /]
	}

	if (!m_pFont)
	{
		UINT weight = (m_dwFlags & FONT_BOLD) ? FW_HEAVY : FW_NORMAL;
		BOOL italic = (m_dwFlags & FONT_ITALIC) ? TRUE : FALSE;
		[add_junk 1 5 /]
		UINT aa = (m_dwFlags & FONT_ANTIALIAS) ? CLEARTYPE_NATURAL_QUALITY : NONANTIALIASED_QUALITY;
		D3DXCreateFont(m_pDevice, m_nFontSize, NULL, weight, NULL, italic, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, aa, DEFAULT_PITCH | FF_DONTCARE, m_szFontName.c_str(), &m_pFont);
	}
}

void Font::PostFrame()
{
	if (!m_pDevice)
		return;

	[add_junk 1 5 /]

	if (m_dwFlags & FONT_SPRITE)
	{
		if (m_pSprite)
			m_pSprite->End();
	}
}

void Font::OnReset()
{
	if (m_pFont)
	{
		m_pFont->OnLostDevice();
		[add_junk 1 5 /]
		m_pFont->OnResetDevice();
	}

	if (m_dwFlags & FONT_SPRITE)
	{
		if (m_pSprite)
		{
			m_pSprite->OnLostDevice();
			[add_junk 1 5 /]
			m_pSprite->OnResetDevice();
		}
	}

}

void Font::DrawText(int x, int y, CVector color, const char* szText)
{
	if (!m_pDevice || !m_pFont || !szText)
		return;

	[add_junk 1 5 /]

	if (m_dwFlags & FONT_OUTLINED)
	{
		RECT outline[4] = 
		{
			{ x + 1, y, 0, 0 },
			{ x - 1, y, 0, 0 },
			{ x, y + 1, 0, 0 },
			{ x, y - 1, 0, 0 }
		};

		[add_junk 1 5 /]

		for (auto& rect : outline)
			m_pFont->DrawTextA(m_pSprite, szText, -1, &rect, DT_NOCLIP, D3DCOLOR_RGBA(0, 0, 0, 255));
	}


	RECT rect = { x, y, 0, 0 }; 
	m_pFont->DrawTextA(m_pSprite, szText, -1, &rect, DT_NOCLIP, D3DCOLOR_RGBA((int)color.x, (int)color.y, (int)color.z , 255));
}

void Font::GetTextSize(const char* szText, int& width, int& height)
{
	if (!m_pDevice || !m_pFont || !szText)
		return;

	RECT rect = {0,0,0,0};

	m_pFont->DrawTextA(m_pSprite, szText, -1, &rect, DT_CALCRECT, D3DCOLOR_RGBA(0, 0, 0, 0));

	[swap_lines]
	width = rect.right - rect.left;
	height = rect.bottom - rect.top;
	[/swap_lines]

	[add_junk 1 5 /]
}

[junk_disable /]