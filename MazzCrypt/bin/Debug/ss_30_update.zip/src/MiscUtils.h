#ifndef _MISCUTILS_H_
#define _MISCUTILS_H_

#include "stdafx.h"
#include "Vector.h"
#include <string>

class CSGO;

class CMiscUtils
{
public:

	CMiscUtils() = default;
	~CMiscUtils() = default;

	std::string GenerateRandomString(int length = 15);
	void GenerateRandomWindowTitle(int length = 15);
	void DeleteSelf(char* szProgramPath);
	void AllowDebugging();
	void PrintLine(std::string szStr);

	int GetKeyFromString(std::string str);
	std::string GetStringFromKey(int key);

	void ParseColor(std::string str, CVector& clr);
	std::string GetStringFromColor(CVector color);

	bool LoadINISettings(std::string fileName, CSGO* csgo);
	bool SaveINISettings(std::string fileName, CSGO* csgo);
	bool LoadCustomChat(std::string fileName, CSGO* csgo);
	bool IsActiveWindow();
	bool DoesCSGOExist();
	bool IsCSGOActiveWindow();
	HWND GetGameWindow();

	void DisableQuickEdit();

	std::string GetHash(std::string fileName);

	void SetUpMinidump();

};

extern CMiscUtils* miscUtils;
#endif // _MISCUTILS_H_

