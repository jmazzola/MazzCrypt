#include "Menu.h"
#include "Renderer.h"
#include "MiscUtils.h"
#include "D3DMenu.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

template <typename T> 
T clamp(const T& value, const T& low, const T& high)
{
	[add_junk 1 4 /]
	return value < low ? low : (value > high ? high : value);
}

bool IsClicked(CVector2D position, CVector2D bounds)
{
	POINT curPos;
	GetCursorPos(&curPos);
	[add_junk 1 4 /]
	ScreenToClient(miscUtils->GetGameWindow(), &curPos);

	return (curPos.x > position.x && curPos.y > position.y &&
			curPos.x < position.x + bounds.x && curPos.y < position.y + bounds.y &&
			(GetAsyncKeyState(VK_LBUTTON) & 1));
}

bool IsInBounds(CVector2D position, CVector2D bounds)
{
	POINT curPos;
	GetCursorPos(&curPos);
	[add_junk 1 4 /]
	ScreenToClient(miscUtils->GetGameWindow(), &curPos);

	return (curPos.x > position.x && curPos.y > position.y &&
			curPos.x < position.x + bounds.x && curPos.y < position.y + bounds.y);
}

CVector2D GetTextSize(int font, const char* desc)
{
	POINT curPos;
	GetCursorPos(&curPos);
	[add_junk 1 4 /]
	ScreenToClient(miscUtils->GetGameWindow(), &curPos);
	[add_junk 1 4 /]
	int textW, textH;
	pRenderer->m_pFonts[DescFont]->GetTextSize(desc, textW, textH);
	return CVector2D(textW, textH);
}

// -- MenuItem --
MenuItem::MenuItem(std::string name, std::string desc, CVector2D pos, CVector2D scale)
{
	m_szName = name;
	m_szDesc = "";
	[add_junk 1 4 /]
	m_Position = pos;
	m_Scale = scale;
}

// -- Form --
Form::Form(std::string name, CVector2D pos, CVector2D scale)
{
	m_szName = name;
	m_Position = pos;
	[add_junk 1 4 /]
	m_Scale = scale;
	m_bVisible = true;
	[add_junk 1 4 /]
	m_szDesc = "The Menu";
}

void Form::Render()
{
	[add_junk 1 4 /]

	if (m_bVisible)
	{
		pRenderer->DrawRect(m_Position.x, m_Position.y, m_Scale.x, m_Scale.y, Color_BG);
		[add_junk 1 4 /]
		pRenderer->DrawRect(m_Position.x, m_Position.y, m_Scale.x, m_Scale.y - 460 , Color_Header);
		[add_junk 1 4 /]
		pRenderer->DrawText(MenuFont, m_Position.x + (m_Scale.y / 2), m_Position.y + (m_Scale.y - 460) / 2 - 10, FONT_RENDER_CENTER_H, Color_White, m_szName.c_str());
		pRenderer->DrawRect(m_Position.x, (m_Scale.y - 40) + m_Position.y, m_Scale.x, m_Scale.y - 460, Color_Header);
		[add_junk 1 4 /]
		pRenderer->DrawText(DescFont, m_Position.x + (m_Scale.y / 2), m_Position.y + (m_Scale.y + 460 ) / 2 - 10, FONT_RENDER_CENTER_H, Color_White, m_szDesc.c_str());


		for (auto& child : m_Items)
			child->Render();
	}
}

// -- Button --
Button::Button(std::string name, std::string desc, CVector2D pos, int width, CallbackType callback, MenuItem* parent)
{
	[swap_lines]
	m_szName = name;
	m_szDesc = desc;
	m_Position = pos;
	m_nWidth = width;
	m_callbackFunc = callback;
	m_Parent = parent;
	[/swap_lines]

	[add_junk 1 4 /]
}

void Button::Render()
{
	auto correctPos = m_Parent->m_Position + m_Position;
	int height = 16;

	[add_junk 1 4 /]

	if (IsInBounds(correctPos, CVector2D(m_nWidth, height)))
		pRenderer->DrawRect(correctPos.x, correctPos.y, m_nWidth, height, CVector(55, 55, 55));
	else
		pRenderer->DrawRect(correctPos.x, correctPos.y, m_nWidth, height, CVector(158, 158, 158));

	pRenderer->DrawText(DescFont, correctPos.x + m_nWidth / 2, correctPos.y, FONT_RENDER_CENTER_H, Color_White, m_szName.c_str());

	[add_junk 1 4 /]

	if (IsClicked(correctPos, CVector2D(m_nWidth, height)))
		m_callbackFunc();

	[add_junk 1 4 /]

	if (IsInBounds(correctPos, CVector2D(m_nWidth, height)))
		m_Parent->m_szDesc = m_szDesc;

}

// -- CheckBox --
CheckBox::CheckBox(std::string name, std::string desc, CVector2D pos, bool* var, MenuItem* parent)
{
	m_szName = name;
	m_szDesc = desc;
	[add_junk 1 4 /]
	m_Position = pos;
	m_Scale = CVector2D(15, 15);
	m_pbToggleVar = var;
	[add_junk 1 4 /]
	m_Parent = parent;
}

void CheckBox::Render()
{
	auto correctPos = m_Parent->m_Position + m_Position;
	[add_junk 1 4 /]
	auto textBounds = GetTextSize(DescFont, m_szName.c_str());

	if (IsClicked(correctPos, m_Scale + textBounds))
	{
		[add_junk 1 4 /]
		(!*m_pbToggleVar) ? *m_pbToggleVar = true : *m_pbToggleVar = false;
	}

	pRenderer->DrawRect(correctPos.x, correctPos.y, m_Scale.x, m_Scale.y, Color_Black);

	[add_junk 1 4 /]

	if (*m_pbToggleVar)
		pRenderer->DrawRect(correctPos.x + 2, correctPos.y + 2, 11, 11, Color_Ticked);

	pRenderer->DrawText(DescFont, correctPos.x + 20, correctPos.y - 2, FONT_RENDER_LEFT, Color_White, m_szName.c_str());


	if (IsInBounds(correctPos, m_Scale + textBounds))
	{
		[add_junk 1 4 /]
		m_Parent->m_szDesc = m_szDesc;
	}
}

// -- Slider [floats]--
Slider_Float::Slider_Float(std::string name, std::string desc, CVector2D pos, float* var, float min, float max, int width, MenuItem* parent)
{
	[swap_lines]
	m_szName = name;
	m_szDesc = desc;
	m_Position = pos;
	m_pfVar = var;
	m_fMin = min;
	m_fMax = max;
	m_nWidth = width;
	m_Parent = parent;
	[/swap_lines]

	[add_junk 1 4 /]
}

void Slider_Float::Render()
{
	auto correctPos = m_Parent->m_Position + m_Position;

	pRenderer->DrawText(DescFont, correctPos.x, correctPos.y, FONT_RENDER_LEFT, Color_White, m_szName.c_str());
	pRenderer->DrawRect(correctPos.x, correctPos.y + 18, m_nWidth + 1, 13, CVector(158, 158, 158));
	[add_junk 1 4 /]
	pRenderer->DrawRect(correctPos.x + 1, correctPos.y + 19, (*m_pfVar * m_nWidth / m_fMax) - 1, 11, CVector(1, 87, 155));
	pRenderer->DrawText(DescFont, correctPos.x + m_nWidth - 20, correctPos.y, FONT_RENDER_LEFT, CVector(255, 255, 255), "%2.1f", *m_pfVar);

	if (IsInBounds(CVector2D(correctPos.x, correctPos.y + 19), CVector2D(m_nWidth + 2, 13)))
	{
		m_Parent->m_szDesc = m_szDesc;

		[add_junk 1 4 /]
		
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
		{
			POINT curPos;
			GetCursorPos(&curPos);
			[add_junk 1 4 /]
			ScreenToClient(miscUtils->GetGameWindow(), &curPos);

			float diff = (curPos.x - (correctPos.x + 1));
			[add_junk 1 4 /]
			float percent = (diff / m_nWidth);
			float range = m_fMax - m_fMin;
			[add_junk 1 4 /]
			range *= percent;
			*m_pfVar = clamp(roundf(m_fMin + range), m_fMin, m_fMax);
		}
	}
}

// -- Slider [ints]
Slider_Int::Slider_Int(std::string name, std::string desc, CVector2D pos, int* var, int min, int max, int width, MenuItem* parent)
{
	m_szName = name;
	m_szDesc = desc;
	[add_junk 1 4 /]
	m_Position = pos;
	m_pfVar = var;
	m_nMin = min;
	m_nMax = max;
	[add_junk 1 4 /]
	m_nWidth = width;
	m_Parent = parent;
}

void Slider_Int::Render()
{
	auto correctPos = m_Parent->m_Position + m_Position;

	pRenderer->DrawText(DescFont, correctPos.x, correctPos.y, FONT_RENDER_LEFT, Color_White, m_szName.c_str());
	pRenderer->DrawRect(correctPos.x, correctPos.y + 18, m_nWidth + 1, 13, CVector(158, 158, 158));
	[add_junk 1 4 /]
	pRenderer->DrawRect(correctPos.x + 1, correctPos.y + 19, (*m_pfVar * m_nWidth / m_nMax) - 1, 11, CVector(1, 87, 155));
	pRenderer->DrawText(DescFont, correctPos.x + m_nWidth - 20, correctPos.y, FONT_RENDER_LEFT, CVector(255, 255, 255), "%d", *m_pfVar);

	if (IsInBounds(CVector2D(correctPos.x, correctPos.y + 19), CVector2D(m_nWidth + 2, 13)))
	{
		m_Parent->m_szDesc = m_szDesc;

		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
		{
			POINT curPos;
			GetCursorPos(&curPos);
			ScreenToClient(miscUtils->GetGameWindow(), &curPos);

			float diff = (curPos.x - (correctPos.x + 1));
			[add_junk 1 4 /]
			float percent = (diff / m_nWidth);
			int range = m_nMax - m_nMin;
			[add_junk 1 4 /]
			range *= percent;
			*m_pfVar = clamp((m_nMin + range), m_nMin, m_nMax);
		}
	}
}

// -- ComboBox --
ComboBox::ComboBox(std::string name, std::string desc, CVector2D pos, int width, int* var, std::vector<std::string> elements, MenuItem* parent, int offset)
{
	[swap_lines]
	m_szName = name;
	m_szDesc = desc;
	m_Position = pos;
	m_nWidth = width;
	m_pnVar = var;
	m_vElements = elements;
	m_Parent = parent;
	m_bCollapsed = false;
	m_nOffset = offset;
	[/swap_lines]

	[add_junk 1 4 /]
}

void ComboBox::Render()
{
	auto correctPos = m_Parent->m_Position + m_Position;
	int height = 18;

	pRenderer->DrawText(DescFont, correctPos.x, correctPos.y, FONT_RENDER_LEFT, Color_White, m_szName.c_str());
	pRenderer->DrawRect(correctPos.x, correctPos.y + height + 2, m_nWidth, height, CVector(158, 158, 158));
	[add_junk 1 4 /]
	pRenderer->DrawText(DescFont, correctPos.x + m_nWidth / 2, correctPos.y + height + 2, FONT_RENDER_CENTER_H, Color_White, m_vElements[*m_pnVar].c_str());

	CVector2D* itemPos = new CVector2D[m_vElements.size()];
	CVector2D* itemBounds = new CVector2D[m_vElements.size()];

	if (!m_bCollapsed)
	{
		pRenderer->DrawRect(correctPos.x + m_nWidth, correctPos.y + height + 2, height, height, CVector(33, 33, 33));
		[add_junk 1 4 /]
		pRenderer->DrawText(DescFont, correctPos.x + m_nWidth + 3, correctPos.y + height + 2, FONT_RENDER_LEFT, Color_White, "d");
	}
	else
	{
		pRenderer->DrawRect(correctPos.x + m_nWidth, correctPos.y + height + 2, height, height, CVector(33, 33, 33));
		pRenderer->DrawText(DescFont, correctPos.x + m_nWidth + 3, correctPos.y + height + 2, FONT_RENDER_LEFT, Color_White, "u");

		for (int i = 0; i < m_vElements.size(); i++)
		{
			itemPos[i] = CVector2D(correctPos.x, correctPos.y + height + 3 + height * (i + 1));
			[add_junk 1 4 /]
			itemBounds[i] = CVector2D(m_nWidth + height, height);

			if (IsInBounds(itemPos[i], itemBounds[i]))
			{
				[add_junk 1 4 /]

				m_Parent->m_szDesc = std::string("Change ") + m_szName + " to " + m_vElements[i].c_str();
				pRenderer->DrawRect(correctPos.x, correctPos.y + height + 3 + height * (i + 1), m_nWidth + height, height, CVector(55, 55, 55));
			}
			else
			{
				pRenderer->DrawRect(correctPos.x, correctPos.y + height + 3 + height * (i + 1), m_nWidth + height, height, CVector(33, 33, 33));
			}

			pRenderer->DrawText(DescFont, correctPos.x + m_nWidth / 2, correctPos.y + height + 3 + height * (i + 1), FONT_RENDER_CENTER_H, Color_White, m_vElements[i].c_str());
		}
	}

	if (IsInBounds(CVector2D(correctPos.x, correctPos.y + height + 2), CVector2D(m_nWidth + height + 2, height + 2)))
		m_Parent->m_szDesc = m_szDesc;

	if (IsClicked(CVector2D(correctPos.x, correctPos.y + height + 2), CVector2D(m_nWidth + height + 2, height)))
		m_bCollapsed = !m_bCollapsed;

	for (int i = 0; i < m_vElements.size(); i++)
	{
		if (IsClicked(itemPos[i], itemBounds[i]))
		{
			*m_pnVar = i;
			[add_junk 1 4 /]
			m_bCollapsed = false;
		}
	}

	delete[] itemBounds;
	delete[] itemPos;
}

// -- KeyBox --
KeyBox::KeyBox(std::string name, std::string desc, CVector2D pos, int width, int* key, MenuItem* parent)
{
	m_szName = name;
	[add_junk 1 4 /]
	m_szDesc = desc;
	m_Position = pos;
	m_nWidth = width;
	[add_junk 1 4 /]
	m_pnKey = key;
	m_Parent = parent;
}

void KeyBox::Render()
{
	[add_junk 1 4 /]
}

[junk_disable /]
[enc_string_disable /]