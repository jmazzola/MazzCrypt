#ifndef _D3DMENU_H_
#define _D3DMENU_H_

#include "Menu.h"

[junk_enable /]

class D3DMenu
{
public:
	[swap_lines]
	D3DMenu();
	~D3DMenu();
	void InitMenu(CVector2D pos, CVector2D scale);
	void Render();
	void DrawMouse();
	[/swap_lines]

	[swap_lines]
	int m_nCurrentTab;
	Form* m_pGlowESPForm, *m_pSubtleAimbotForm, *m_pAimlockForm, *m_pMiscForm, *m_pESPForm;
	std::vector<MenuItem*> m_vGlowESPItems, m_vSubtleAimbotItems, m_vAimlockItems, m_vMiscItems, m_vESPItems;
	unsigned long m_hFontWatermark;
	unsigned long m_hFontMenu;
	unsigned long m_hFontDescription;
	bool m_bVisible;
	[/swap_lines]

	[add_junk_datamembers 1 9 /]
};

#endif

extern D3DMenu* pD3DMenu;

[junk_disable /]