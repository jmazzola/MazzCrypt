#ifndef _CSGO_H_
#define _CSGO_H_

#include "Vector.h"
#include "Memory.h"
#include "MiscUtils.h"
#include "dt_recv.h"
#include <vector>
#include <string>
#include <thread>

#include "Decrypt.h"

#define BIT_CHATSPAM 0
#define BIT_SUBTLEAIMBOT 1
#define BIT_GLOWESP 2
#define BIT_SPINBOT 3
#define BIT_BHOP 4
#define BIT_AIMBOT 5
#define BIT_FAKELAG 6
#define BIT_ESP 7

#define m_Me m_Players[0]

typedef void* (*CreateInterfaceFn)(const char*, int*);

[junk_enable /]
[enc_string_enable /]

// Enums
enum EWeaponType
{
	WeapType_Pistol = 0,
	WeapType_Rifle = 1,
	WeapType_SMG = 2,
	WeapType_Sniper = 3,
	WeapType_KnifeType = 4,
	WeapType_Grenade = 5,
	WeapType_LMG = 6,
	WeapType_Shotgun = 7,
	WeapType_ZeusGun = 8,
	WeapType_C4Explosive = 9,
};

enum ESpectatorView
{
	SV_NotSpectating = 0,
	SV_DeathCam = 1,
	SV_FreezeCam = 2,
	SV_Fixed = 3,
	SV_FirstPerson = 4,
	SV_ThirdPerson = 5,
	SV_Free = 6,
};

enum EWeaponIDs
{
	WID_None = 0,
	WID_Deagle = 1,
	WID_Dual_Berettas = 2,
	WID_Five_Seven = 3,
	WID_Glock = 4,
	WID_AK47 = 7,
	WID_AUG = 8,
	WID_AWP = 9,
	WID_FAMAS = 10,
	WID_G3SG1_Auto = 11,
	WID_Galil = 13,
	WID_M249 = 14,
	WID_M4A4 = 16,
	WID_MAC10 = 17,
	WID_P90 = 19,
	WID_UMP45 = 24,
	WID_XM1014 = 25,
	WID_PPBizon = 26,
	WID_MAG7 = 27,
	WID_Negev = 28,
	WID_SawedOff = 29,
	WID_Tec9 = 30,
	WID_Zeus = 31,
	WID_P2000 = 32,
	WID_MP7 = 33,
	WID_MP9 = 34,
	WID_Nova = 35,
	WID_P250 = 36,
	WID_SCAR_Auto = 38,
	WID_SG553 = 39,
	WID_Scout = 40,
	WID_Knife = 42,
	WID_Flashbang = 43,
	WID_HEFrag = 44,
	WID_Smoke = 45,
	WID_Molly = 46,
	WID_Decoy = 47,
	WID_Firebomb = 48,
	WID_C4 = 49,
	WID_MusicKit = 58,
	WID_Default_Knife = 59,
	WID_M4A1S = 60,
	WID_USP = 61,
	WID_TradeUpContract = 62,
	WID_CZ75 = 63,
	WID_Revolver = 64,
	WID_BayonetKnife = 500,
	WID_FlipKnife = 505,
	WID_GutKnife = 506,
	WID_KarambitKnife = 507,
	WID_M9BayonetKnife = 508,
	WID_HuntsmanKnife = 509,
	WID_FalchionKnife = 512,
	WID_BowieKnife = 514,
	WID_ButterflyKnife = 515,
	WID_ShadowDaggerKnife = 516,
};

enum EClassIDs
{
	CID_CAI_BaseNPC = 0,
	CID_CAK47 = 1,
	CID_CBaseAnimating = 2,
	CID_CBaseAnimatingOverlay = 3,
	CID_CBaseAttributableItem = 4,
	CID_CBaseButton = 5,
	CID_CBaseCombatCharacter = 6,
	CID_CBaseCombatWeapon = 7,
	CID_CBaseCSGrenade = 8,
	CID_CBaseCSGrenadeProjectile = 9,
	CID_CBaseDoor = 10,
	CID_CBaseEntity = 11,
	CID_CBaseFlex = 12,
	CID_CBaseGrenade = 13,
	CID_CBaseParticleEntity = 14,
	CID_CBasePlayer = 15,
	CID_CBasePropDoor = 16,
	CID_CBaseTeamObjectiveResource = 17,
	CID_CBaseTempEntity = 18,
	CID_CBaseToggle = 19,
	CID_CBaseTrigger = 20,
	CID_CBaseViewModel = 21,
	CID_CBaseVPhysicsTrigger = 22,
	CID_CBaseWeaponWorldModel = 23,
	CID_CBeam = 24,
	CID_CBeamSpotlight = 25,
	CID_CBoneFollower = 26,
	CID_CBreakableProp = 27,
	CID_CBreakableSurface = 28,
	CID_CC4 = 29,
	CID_CCascadeLight = 30,
	CID_CChicken = 31,
	CID_CColorCorrection = 32,
	CID_CColorCorrectionVolume = 33,
	CID_CCSGameRulesProxy = 34,
	CID_CCSPlayer = 35,
	CID_CCSPlayerResource = 36,
	CID_CCSRagdoll = 37,
	CID_CCSTeam = 38,
	CID_CDEagle = 39,
	CID_CDecoyGrenade = 40,
	CID_CDecoyProjectile = 41,
	CID_CDynamicLight = 42,
	CID_CDynamicProp = 43,
	CID_CEconEntity = 44,
	CID_CEmbers = 45,
	CID_CEntityDissolve = 46,
	CID_CEntityFlame = 47,
	CID_CEntityFreezing = 48,
	CID_CEntityParticleTrail = 49,
	CID_CEnvAmbientLight = 50,
	CID_CEnvDetailController = 51,
	CID_CEnvDOFController = 52,
	CID_CEnvParticleScript = 53,
	CID_CEnvProjectedTexture = 54,
	CID_CEnvQuadraticBeam = 55,
	CID_CEnvScreenEffect = 56,
	CID_CEnvScreenOverlay = 57,
	CID_CEnvTonemapController = 58,
	CID_CEnvWind = 59,
	CID_CFireCrackerBlast = 60,
	CID_CFireSmoke = 61,
	CID_CFireTrail = 62,
	CID_CFish = 63,
	CID_CFlashbang = 64,
	CID_CFogController = 65,
	CID_CFootstepControl = 66,
	CID_CFunc_Dust = 67,
	CID_CFunc_LOD = 68,
	CID_CFuncAreaPortalWindow = 69,
	CID_CFuncBrush = 70,
	CID_CFuncConveyor = 71,
	CID_CFuncLadder = 72,
	CID_CFuncMonitor = 73,
	CID_CFuncMoveLinear = 74,
	CID_CFuncOccluder = 75,
	CID_CFuncReflectiveGlass = 76,
	CID_CFuncRotating = 77,
	CID_CFuncSmokeVolume = 78,
	CID_CFuncTrackTrain = 79,
	CID_CGameRulesProxy = 80,
	CID_CHandleTest = 81,
	CID_CHEGrenade = 82,
	CID_CHostage = 83,
	CID_CHostageCarriableProp = 84,
	CID_CIncendiaryGrenade = 85,
	CID_CInferno = 86,
	CID_CInfoLadderDismount = 87,
	CID_CInfoOverlayAccessor = 88,
	CID_CItem_Healthshot = 89,
	CID_CKnife = 90,
	CID_CKnifeGG = 91,
	CID_CLightGlow = 92,
	CID_CMaterialModifyControl = 93,
	CID_CMolotovGrenade = 94,
	CID_CMolotovProjectile = 95,
	CID_CMovieDisplay = 96,
	CID_CParticleFire = 97,
	CID_CParticlePerformanceMonitor = 98,
	CID_CParticleSystem = 99,
	CID_CPhysBox = 100,
	CID_CPhysBoxMultiplayer = 101,
	CID_CPhysicsProp = 102,
	CID_CPhysicsPropMultiplayer = 103,
	CID_CPhysMagnet = 104,
	CID_CPlantedC4 = 105,
	CID_CPlasma = 106,
	CID_CPlayerResource = 107,
	CID_CPointCamera = 108,
	CID_CPointCommentaryNode = 109,
	CID_CPoseController = 110,
	CID_CPostProcessController = 111,
	CID_CPrecipitation = 112,
	CID_CPrecipitationBlocker = 113,
	CID_CPredictedViewModel = 114,
	CID_CProp_Hallucination = 115,
	CID_CPropDoorRotating = 116,
	CID_CPropJeep = 117,
	CID_CPropVehicleDriveable = 118,
	CID_CRagdollManager = 119,
	CID_CRagdollProp = 120,
	CID_CRagdollPropAttached = 121,
	CID_CRopeKeyframe = 122,
	CID_CSCAR17 = 123,
	CID_CSceneEntity = 124,
	CID_CSensorGrenade = 125,
	CID_CSensorGrenadeProjectile = 126,
	CID_CShadowControl = 127,
	CID_CSlideshowDisplay = 128,
	CID_CSmokeGrenade = 129,
	CID_CSmokeGrenadeProjectile = 130,
	CID_CSmokeStack = 131,
	CID_CSpatialEntity = 132,
	CID_CSpotlightEnd = 133,
	CID_CSprite = 134,
	CID_CSpriteOriented = 135,
	CID_CSpriteTrail = 136,
	CID_CStatueProp = 137,
	CID_CSteamJet = 138,
	CID_CSun = 139,
	CID_CSunlightShadowControl = 140,
	CID_CTeam = 141,
	CID_CTeamplayRoundBasedRulesProxy = 142,
	CID_CTEArmorRicochet = 143,
	CID_CTEBaseBeam = 144,
	CID_CTEBeamEntPoint = 145,
	CID_CTEBeamEnts = 146,
	CID_CTEBeamFollow = 147,
	CID_CTEBeamLaser = 148,
	CID_CTEBeamPoints = 149,
	CID_CTEBeamRing = 150,
	CID_CTEBeamRingPoint = 151,
	CID_CTEBeamSpline = 152,
	CID_CTEBloodSprite = 153,
	CID_CTEBloodStream = 154,
	CID_CTEBreakModel1 = 155,
	CID_CTEBSPDecal = 156,
	CID_CTEBubbles = 157,
	CID_CTEBubbleTrail = 158,
	CID_CTEClientProjectile = 159,
	CID_CTEDecal = 160,
	CID_CTEDust = 161,
	CID_CTEDynamicLight = 162,
	CID_CTEEffectDispatch = 163,
	CID_CTEEnergySplash = 164,
	CID_CTEExplosion = 165,
	CID_CTEFireBullets = 166,
	CID_CTEFizz = 167,
	CID_CTEFootprintDecal = 168,
	CID_CTEFoundryHelpers = 169,
	CID_CTEGaussExplosion = 170,
	CID_CTEGlowSprite = 171,
	CID_CTEImpact = 172,
	CID_CTEKillPlayerAttachments = 173,
	CID_CTELargeFunnel = 174,
	CID_CTEMetalSparks = 175,
	CID_CTEMuzzleFlash = 176,
	CID_CTEParticleSystem = 177,
	CID_CTEPhysicsProp = 178,
	CID_CTEPlantBomb = 179,
	CID_CTEPlayerAnimEvent = 180,
	CID_CTEPlayerDecal = 181,
	CID_CTEProjectedDecal = 182,
	CID_CTERadioIcon = 183,
	CID_CTEShatterSurface = 184,
	CID_CTEShowLine = 185,
	CID_CTesla = 186,
	CID_CTESmoke = 187,
	CID_CTESparks = 188,
	CID_CTESprite = 189,
	CID_CTESpriteSpray = 190,
	CID_CTest_ProxyToggle_Networkable = 191,
	CID_CTestTraceline = 192,
	CID_CTEWorldDecal = 193,
	CID_CTriggerPlayerMovement = 194,
	CID_CTriggerSoundOperator = 195,
	CID_CVGuiScreen = 196,
	CID_CVoteController = 197,
	CID_CWaterBullet = 198,
	CID_CWaterLODControl = 199,
	CID_CWeaponAug = 200,
	CID_CWeaponAWP = 201,
	CID_CWeaponBaseItem = 202,
	CID_CWeaponBizon = 203,
	CID_CWeaponCSBase = 204,
	CID_CWeaponCSBaseGun = 205,
	CID_CWeaponCycler = 206,
	CID_CWeaponElite = 207,
	CID_CWeaponFamas = 208,
	CID_CWeaponFiveSeven = 209,
	CID_CWeaponG3SG1 = 210,
	CID_CWeaponGalil = 211,
	CID_CWeaponGalilAR = 212,
	CID_CWeaponGlock = 213,
	CID_CWeaponHKP2000 = 214,
	CID_CWeaponM249 = 215,
	CID_CWeaponM3 = 216,
	CID_CWeaponM4A1 = 217,
	CID_CWeaponMAC10 = 218,
	CID_CWeaponMag7 = 219,
	CID_CWeaponMP5Navy = 220,
	CID_CWeaponMP7 = 221,
	CID_CWeaponMP9 = 222,
	CID_CWeaponNegev = 223,
	CID_CWeaponNOVA = 224,
	CID_CWeaponP228 = 225,
	CID_CWeaponP250 = 226,
	CID_CWeaponP90 = 227,
	CID_CWeaponSawedoff = 228,
	CID_CWeaponSCAR20 = 229,
	CID_CWeaponScout = 230,
	CID_CWeaponSG550 = 231,
	CID_CWeaponSG552 = 232,
	CID_CWeaponSG556 = 233,
	CID_CWeaponSSG08 = 234,
	CID_CWeaponTaser = 235,
	CID_CWeaponTec9 = 236,
	CID_CWeaponTMP = 237,
	CID_CWeaponUMP45 = 238,
	CID_CWeaponUSP = 239,
	CID_CWeaponXM1014 = 240,
	CID_CWorld = 241,
	CID_DustTrail = 242,
	CID_MovieExplosion = 243,
	CID_ParticleSmokeGrenade = 244,
	CID_RocketTrail = 245,
	CID_SmokeTrail = 246,
	CID_SporeExplosion = 247,
	CID_SporeTrail = 248,

};

struct EBones
{
public:
	#define Bone_Spine0 1
	#define Bone_Spine1 2
	#define Bone_Spine2 3
	#define Bone_Spine3 4
	#define Bone_Neck 5
	#define Bone_Head 6
	#define Bone_LeftClavicle 7
	#define Bone_LeftUpperarm 8
	#define Bone_LeftLowerarm 9
	#define Bone_LeftHand 10
	#define Bone_RightClavicle 11
	#define Bone_RightUpperarm 12
	#define Bone_RightLowerarm 13
	#define Bone_RightHand 14
	#define Bone_LeftUpperleg 15
	#define Bone_LeftLowerleg 16
	#define Bone_LeftAnkle 17
	#define Bone_RightUpperleg 18
	#define Bone_RightLowerleg 19
	#define Bone_RightAnkle 20
	#define Bone_MAX 21

	int bone;
};

enum EHitboxes
{
	// These are outdated as fuck
	HB_Pelvis = 0,
	HB_LeftThigh = 1,
	HB_LeftCalf = 2,
	HB_LeftFoot = 3,
	HB_RightThigh = 4,
	HB_RightCalf = 5,
	HB_RightFoot = 6,
	HB_Spine1 = 7,
	HB_Spine2 = 8,
	HB_Spine3 = 9,
	HB_Neck = 10,
	HB_Head = 11,
	HB_LeftUpperArm = 12,
	HB_LeftForearm = 13,
	HB_LeftHand = 14,
	HB_RightUpperArm = 15,
	HB_RightForearm = 16,
	HB_RightHand = 17,
	HB_LeftClavicle = 18,
	HB_RightClavicle = 19,
	HB_Helmet = 20,
	HB_Spine4 = 21,
};

enum ETeams : int
{
	Team_NoTeam = 0,
	Team_Spectator = 1,
	Team_Terrorists = 2,
	Team_CounterTerrorists = 3,
};

//enum ETargetType : int
//{
//	Target_Enemies = 0,
//	Target_Teammates = 1,
//	Target_Everyone = 2,
//};

struct ETargetType
{
#define Target_Enemies 0
#define Target_Teammates 1
#define Target_Everyone 2

public:

	int type;

	std::string ToString()
	{
		switch (type)
		{
			case Target_Enemies:
				return "Enemies Only";
			case Target_Teammates:
				return "Teammates Only";
			case Target_Everyone:
				return "Everyone Only";
			default:
				return "Unknown Target Type";
		}
	}
};

//enum EAimMethod : int
//{
//	ClosestToCrosshair = 0,
//	ClosestToPlayer = 1,
//	LowestHP = 2,
//	FullRage = 3,
//};

struct EAimMethod
{
	#define ClosestToCrosshair 0 
	#define ClosestToPlayer 1 
	#define LowestHP 2 
	#define FullRage 3 

	int type;

	std::string ToString()
	{
		switch (type)
		{
			case ClosestToCrosshair:
			return "Closest To Crosshair";
			case ClosestToPlayer:
			return "Closest to Player";
			case LowestHP:
			return "Lowest HP";
			case FullRage:
			return "Full Rage";
			default:
			return "Unknown Aim Method";
		}
	}

public:
};

struct ESpamMethod
{
public:

	#define Advertisement 0
	#define ParsedFile 1

	int type;

	std::string ToString()
	{
		switch (type)
		{
			case 0:
			return "Advertisement";
			case 1:
			return "Custom chat.txt";
			default:
			return "Unknown Chat Type";
		}
	}
};

struct EBoxType
{
public:
#define BoxType_BoundingBox 0
#define BoxType_CornerBox 1

	int type;

	std::string ToString()
	{
		switch (type)
		{
			case 0:
			return "Bounding Box";
			case 1:
			return "Cornered Box";
			default:
			return "Unknown Box Type";
		}
	}
};

struct EHealthBarType
{
public:
#define HealthBarType_Vertical_Left 0
#define HealthBarType_Vertical_Right 1

	int type;

	std::string ToString()
	{
		switch (type)
		{
			case 0:
			return "Vertical Left";
			case 1:
			return "Vertical Right";
			default:
			return "Unknown Health Bar Type";
		}
	}
};

enum SpinMethod : int
{
	Actual_Spinbot = 0,
	FakeDown_Jitter = 1,
	FakeUp_Jitter = 2,
};

enum ESignOnState : int
{
	SOS_None = 0,
	SOS_Challenge = 1,
	SOS_Connected = 2,
	SOS_New = 3,
	SOS_Prespawn = 4,
	SOS_Spawn = 5,
	SOS_Full = 6,
	SOS_ChangeLevel = 7,
};

// TODO: make this sigscan, kthx.
enum EOffsets
{
	/*LocalPlayer = 0xA77D2C,
	EntityBase = 0x4A19D84,
	EnginePtr = 0x5D2284,*/
	Jump = 0x4AAAAF8,
	/*ViewMatrix = 0x4A0F314,
	GlowObject = 0x4B2CD34,*/
	RadarBase = 0x4A4EA2C,
	/*ScoreBoard = 0x4A39FDC,*/
	/*GameResources = 0x2E90C2C,*/

	Names = 0x9D0,
	ClanTag = 0x4110,

	CompetitiveRank = 0x1A3C,
	CompetitiveWins = 0x1B40,

	ActiveWeapon = 0x12B8,		//m_hActiveWeapon
	ActiveWeapID = 0x1C,
	Id = 0x64,
	SignOnState = 0x100,		//0xE8 before revolvo
	Dormant = 0xE9,				//m_bDormant
	Health = 0xFC,				//m_iHealth
	Team = 0xF0,				//m_iTeamNum 
	Flags = 0x100,				//m_fFlags
	VecViewOffset = 0x104,		//m_vecViewOffset[0]
	VecVelocity = 0x110,		//m_vecVelocity[0]
	Origin = 0x134,				//m_vecOrigin -> CS_BasePlayer
	OwnerEntity = 0x148,		//m_hOwner
	LifeState = 0x25B,			//m_lifeState
	Spotted = 0x935,			//m_bSpotted
	BoneMatrix = 0xA74,
	PunchVector = 0x13E0,		// 13E8 | F3 0F 7E 82 E8 13 ?? ?? 8B 82 F0 13 ?? ?? [xmm0, qword ptr [edx+PunchVector] ]
	SkinOwnerLow = 0x14F0,
	SkinOwnerHigh = 0x14F4,
	SkinPaint = 0x14F8,
	SkinSeed = 0x14FC,
	SkinWear = 0x1500,
	SkinStatTrak = 0x1504,
	PrimaryAmmo = 0x15B8,		//m_iClip1
	SecondaryAmmo = 0x15BC,		//m_iClip2
	IsReloading = 0x15F9,		//m_bInReload
	SpectatorView = 0x173C,		//m_iObserverMode 
	SpectatorTarget = 0x1750,	//m_hObserverTarget
	ShotsFired = 0x8660,		//m_iShotsFired
	FlashDuration = 0x86A8,		//m_flFlashDuration
	IsDefusing = 0x1C4C,		//m_bIsDefusing
	HasImmunity = 0x1C58,		//m_bGunGameImmunity
	FlashMaxAlpha = 0x86A4,		//m_flFlashMaxAlpha
	HasHelmet = 0x8C9C,			//m_bHasHelmet
	Armor = 0x8CA4,				//m_ArmorValue 
	HasDefuseKit = 0x8CB4,		//m_bHasDefuser
	Class = 0x8CA0,				//m_iClass
	//CrosshairID = 0x2410,		//m_iCrosshairID
	AccuracyPenalty = 0x1668,	//m_fAccuracyPenalty
	FOVStart = 0x15B0,			//m_iFOVStart
	/*ViewAngles = 0x4CE0,*/
	AttributeManager = 0x1140,		// m_AttributeManager
	Item = 0x40,					// m_Item
	ItemDefinitionIndex = 0x1D0,	// m_iItemDefinitionIndex

};

// Static strings
static std::string Ranks[] =
{
	"Unranked",
	"Silver I",
	"Silver II",
	"Silver III",
	"Silver IV",
	"Silver Elite",
	"Silver Elite Master",
	"Gold Nova I",
	"Gold Nova II",
	"Gold Nova III",
	"Gold Nova Master",
	"Master Guardian I",
	"Master Guardian II",
	"Master Guardian Elite",
	"Distinguished Master Guardian",
	"Legendary Eagle",
	"Legendary Eagle Master",
	"Supreme Master First Class",
	"The Global Elite"
};

// Structs

struct DynOffsets
{
public:

	[swap_lines]
	DWORD entityList;
	DWORD localPlayer;
	DWORD enginePtr;
	DWORD viewAngles;
	DWORD viewMatrix;
	DWORD glowObjectBase;
	DWORD crosshairIndex;
	DWORD scoreBoard;
	DWORD gameResources;
	DWORD punchAngles;
	DWORD netvarClassesBase;
	DWORD canReload;
	DWORD jumpOffset;
	DWORD forwardOffset;
	DWORD mouseEnableOffset;
	DWORD consoleEnableOffset;
	DWORD steamOverlayOffset;
	DWORD globalVarsOffset;
	DWORD clientCMDOffset;
	DWORD mapNameOffset;
	DWORD cinputOffset;
	DWORD userCMDOffset;
	DWORD verifiedCMDOffset;
	DWORD bSendPacketOffset;
	DWORD playerInfoOffset;
	DWORD netvar_compRank;
	DWORD netvar_compWins;
	DWORD netvar_hActiveWeapon;
	DWORD netvar_iHealth;
	DWORD netvar_iTeamNum;
	DWORD netvar_fFlags;
	DWORD netvar_vecViewOffset;
	DWORD netvar_vecVelocity;
	DWORD netvar_vecOrigin;
	DWORD netvar_hOwner;
	DWORD netvar_iLifeState;
	DWORD netvar_bSpotted;
	DWORD netvar_iClip1;
	DWORD netvar_iClip2;
	DWORD netvar_bInReload;
	DWORD netvar_iObserverMode;
	DWORD netvar_iObserverTarget;
	DWORD netvar_iShotsFired;
	DWORD netvar_flFlashDuration;
	DWORD netvar_bIsDefusing;
	DWORD netvar_flFlashMaxAlpha;
	DWORD netvar_bHasHelmet;
	DWORD netvar_ArmorValue;
	DWORD netvar_bHasDefuser;
	DWORD netvar_iClass;
	DWORD netvar_fAccuracyPenalty;
	DWORD netvar_iFOVStart;
	DWORD netvar_AttributeManager;
	DWORD netvar_Item;
	DWORD netvar_iItemDefinitionIndex;
	DWORD netvar_boneMatrix;
	DWORD netvar_immuneTime;
	DWORD netvar_spottedByMask;
	DWORD netvar_bBombTicking;
	DWORD netvar_flC4Blow;
	DWORD netvar_nTickBase;
	DWORD netvar_flNextPrimaryAttack;
	DWORD netvar_szLastPlaceName;
	DWORD netvar_iMatchStats_MoneySaved;
	[/swap_lines]

};

struct Hitbox
{

public:
	[swap_lines]
	int iBone;
	CVector vMin;
	CVector vMax;
	[/swap_lines]

	void Setup(int b, CVector mi, CVector ma)
	{
		[swap_lines]
		iBone = b;
		vMin = mi;
		vMax = ma;
		[/swap_lines]
	}
};

class player_info_t
{
public:
	char			name[32];
	int				userID;
	char			guid[33];
	__int32			friendsID;
	char			friendsName[32];
	bool			fakeplayer;
	bool			ishltv;
	unsigned long	customFiles[4];
	unsigned char	filesDownloaded;
	char Pad[200];
};

struct Player
{

public:

	Player() = default;
	~Player() = default;

	DWORD			baseAddr;			// Base address

	[swap_lines]
	Matrix3x4		boneMatrix[128];
	CVector			vOrigin;			// m_vecOrigin
	CVector			vViewAngles;		// m_vecAngles
	CVector			vVelocity;			// m_vecVelocity
	CVector			vVecViewOffset;		// m_vecViewOffset
	CVector			vEyePos;
	CVector2D		vPunchAngles;		// m_vecPunchAngles
	CVector2D		vOldPunchAngles;
	char			szCallout[32];
	player_info_t	tPlayerInfo;
	int				iID;				// 
	int				iClassID;			// m_iClass
	int				iFlags;				// m_iFlags
	int				iTeam;				// m_iTeam
	int				iHealth;			// m_iHealth
	int				iArmor;				// m_iArmorValue
	int				iWeaponID;
	int				iAmmo_Primary;		// m_iClip1
	int				iAmmo_Secondary;	// m_iClip2
	int				iShotsFired;		// m_iShotsFired
	int				iSpectatorMode;		// m_iObserverMode
	int				iSpectatorTarget;	// m_iObserverTarget
	int				iOwnerEntity;		// m_hOwner
	int				iRank;				// rank from gameresources
	int				iWins;				// wins from gameresources
	int				iMoney;
	int				iSpottedByMask;
	int				iSkinOwnerHigh;		// m_OriginalOwnerXuidHigh
	int				iSkinOwnerLow;		// m_OriginalOwnerXuidLow
	int				iSkinPaint;			// m_nFallbackPaintKit
	int				iSkinSeed;			// m_nFallbackSeed
	int				iStatTrak;			// m_nFallbackStatTrak
	float			fFlashDuration;		// m_fFlashDuration
	float			fSkinWear;			// m_flFallbackWear
	float			fImmuneTime;		
	bool			bHasHelmet;			// m_bHasHelmet
	bool			bHasDefuser;		// m_bHasDefuser
	bool			bIsDefusing;		// m_bIsDefusing
	bool			bIsSpotted;			// m_bSpotted
	bool			bIsReloading;		// m_bIsReloading
	bool			bAlive;
	bool			bIsDormant;			// m_bDormant [0xE9]
	bool			bHasGunGameImmunity;
	bool			bHasBomb;
	[/swap_lines]


};

struct GlowOptions
{

public:
	[swap_lines]
	int iKey;				// VK for key to toggle
	bool bCanToggle;
	bool bActivated;
	ETargetType targetType;
	float fMaxDist;
	bool bVisibleGlow;
	bool bHealthGlow;		// Show health glow
	bool bGlowBomb;			// Glow the bomb
	bool bGlowWeapons;		// Glow weapons in hands/on ground
	bool bGlowGrenades;		// Glow grenades in hands/on ground/in air
	bool bFlashGlow;		// Glow white when flashed
	bool bDefuseGlow;		// Glow purple when defusing
	bool bChickenGlow;		// Glow chickens yellow
	bool bBombInfo;
	CVector fGlowEnemy_RGB;
	float fGlowEnemy_A;		// Alpha channel for enemies
	CVector fGlowEnemyNotVisible_RGB;
	float fGlowEnemyNotVisible_A;		// Alpha channel for enemies
	CVector fGlowTeam_RGB;
	float fGlowTeam_A;		// Alpha channel for teammates
	CVector fGlowTeamNotVisible_RGB;
	float fGlowTeamNotVisible_A;		// Alpha channel for teammates
	CVector fGlowBomb_RGB;
	float fGlowBomb_A;
	CVector fWeapons_RGB;
	float fWeapons_A;
	CVector fNades_RGB;
	float fNades_A;
	CVector fDefuse_RGB;
	float fDefuse_A;
	CVector fChickenRGB;
	float fChicken_A;
	[/swap_lines]
};

struct SubtleAimbotOptions
{
public:

	struct SubtleWeaponSettings
	{
		[swap_lines]
		EBones eBoneToAimAt;
		int iSubtleMinChance;
		int iSubtleMaxChance;
		float fSubtleRCSScale;
		[/swap_lines]
	};

	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	ETargetType targetType;
	bool bVisibleCheck;
	int iKey;				// Key to used to toggle subtle aimbot
	float fSmoothFactor;
	bool bRageMode;
	bool bIntelligentAim;
	bool bJumpCheck;
	bool bRandomPos;
	SubtleWeaponSettings tWeaponSettings_Pistol;
	SubtleWeaponSettings tWeaponSettings_Rifle;
	SubtleWeaponSettings tWeaponSettings_Sniper;
	SubtleWeaponSettings tWeaponSettings_Shotguns;
	SubtleWeaponSettings tWeaponSettings_SMGs;
	SubtleWeaponSettings tWeaponSettings_LMGs;
	bool bNewMethod;
	[/swap_lines]
};

struct ActualAimbotOptions
{
public:

	struct ActualWeaponSettings
	{
		[swap_lines]
		EBones eBoneToAimAt;
		float fSubtleRCSScale;
		[/swap_lines]
	};

	[swap_lines]
	bool bActivated;
	bool bCanToggle;
	ETargetType targetType;
	bool bVisibleCheck;
	int iToggleKey;
	int iAimKey;
	float fSmoothFactor;
	float fFOVRadius;
	EAimMethod eAimMethod;
	bool bRageMode;
	bool bSilentAim;
	bool bJumpCheck;
	bool bHumanize;
	ActualWeaponSettings tWeaponSettings_Pistol;
	ActualWeaponSettings tWeaponSettings_Rifle;
	ActualWeaponSettings tWeaponSettings_Sniper;
	ActualWeaponSettings tWeaponSettings_Shotguns;
	ActualWeaponSettings tWeaponSettings_SMGs;
	ActualWeaponSettings tWeaponSettings_LMGs;
	[/swap_lines]

};

struct BhopOptions
{
	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	int iKey;
	[/swap_lines]
};

struct ChatSpamOptions
{
	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	int iKey;
	int iChatInterval;
	bool bParseFile;
	ESpamMethod eSpamMethod;
	bool bRandomParse;
	int iUserID;
	[/swap_lines]

};

struct SpinbotOptions
{
	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	int iKey;
	SpinMethod eSpinType;
	[/swap_lines]
};

struct FakeLagOptions
{
	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	int iKey;
	int iLagInterval;
	[/swap_lines]
};

struct ESPOptions
{
	[swap_lines]
	bool bCanToggle;
	bool bActivated;
	int iKey;
	ETargetType targetType;
	EBoxType boxType;
	EHealthBarType hBarType;
	float fMaxDist;
	bool bSnapLines;
	bool bShowBox;
	bool bVisibleCheck;
	bool bFlashedCheck;
	bool bShowNames;
	bool bShowDistance;
	bool bShowHealthBar;
	bool bShowWeapon;
	bool bShowMMInfo;
	bool bShowMoney;
	bool bShowWeapons;
	bool bShowSillyWeapons;
	bool bShowGrenades;
	bool bShowAmmo;
	bool bShowBomb;
	bool bShowBombInformation;
	bool bShowChickens;
	[/swap_lines]
};

struct ThreadHandling
{
public:
	[swap_lines]
	bool bUpdateStop;
	bool bOverlayStop;
	bool bConsoleMenuStop;
	bool bGlowThreadStop;
	bool bSubtleAimbotThreadStop;
	bool bActualAimbotThreadStop;
	bool bBhopThreadStop;
	bool bChatspamThreadStop;
	bool bSpinbotThreadStop;
	bool bFakeLagThreadStop;
	[/swap_lines]
};

struct Hacks
{

public:

	void Toggle(int iBit)
	{
		[add_junk 1 5 /]
		iBitField ^= (1 << iBit);
	}

	void Set(int iBit)
	{
		iBitField |= (1 << iBit);
		[add_junk 1 5 /]
	}

	void Unset(int iBit)
	{
		iBitField &= ~(1 << iBit);
		[add_junk 1 5 /]
	}

	bool CheckBit(int iBit)
	{
		[add_junk 1 5 /]
		return (iBitField & (1 << iBit));
	}

	void UnsetAll()
	{
		iBitField = 0;
		[add_junk 1 5 /]
	}

	[swap_lines]
	unsigned long iBitField;
	std::string hacksHash;
	std::string chatHash;
	std::vector<std::string> parseLines;
	GlowOptions tGlowOptions;
	SubtleAimbotOptions tSubtleAimbotOptions;
	ActualAimbotOptions tActualAimbotOptions;
	BhopOptions tBhopOptions;
	ChatSpamOptions tChatSpamOptions;
	ThreadHandling tThreadHandling;
	SpinbotOptions tSpinbotOptions;
	FakeLagOptions tFakeLagOptions;
	ESPOptions tESPOptions;
	[/swap_lines]

};

class CSGO
{
public:
	CSGO() = default;
	~CSGO() = default;

	// Netvars
	class CRecvTable
	{
	public:

		class CRecvProp
		{
		public:
			const char* GetVarName(CSGO* c)
			{
				DWORD offset = c->m_Mem.Read<DWORD>((DWORD)this);
				[add_junk 1 5 /]
				char varName[128];
				c->m_Mem.ReadCustom(offset, varName, 128);
				return varName;
			}

			int GetOffset(CSGO* c)
			{
				[add_junk 1 5 /]
				return c->m_Mem.Read< int >((DWORD)this + 0x2C);
			}
			CRecvTable* GetDataTable(CSGO* c)
			{
				[add_junk 1 5 /]
				return c->m_Mem.Read< CRecvTable* >((DWORD) this + 0x28);
			}

		};

		const char* GetTableName(CSGO* c)
		{
			DWORD offset = c->m_Mem.Read<DWORD>((DWORD)this + 0xC);
			char tableName[128];
			[add_junk 1 5 /]
			c->m_Mem.ReadCustom(offset, tableName, 128);
			return tableName;
		}


		int GetMaxProp(CSGO* c)
		{
			[add_junk 1 5 /]
			return c->m_Mem.Read< int >((DWORD)this + 0x4);
		}

		CRecvProp* GetProperty(int iIndex, CSGO* c)
		{
			return (CRecvProp*)(c->m_Mem.Read<DWORD>((DWORD) this) + 0x3C * iIndex);
		}

	};

	class ClientClass
	{
	public:
		const char* GetNetworkName(CSGO* c)
		{
			DWORD offset = c->m_Mem.Read<DWORD>((DWORD)this + 0x8);
			[add_junk 1 5 /]
			char networkName[128];
			c->m_Mem.ReadCustom(offset, networkName, 128);
			return networkName;
		}

		ClientClass* GetNextClass(CSGO* c)
		{
			[add_junk 1 5 /]
			return c->m_Mem.Read< ClientClass* >((DWORD)this + 0x10);
		}
		CRecvTable* GetTable(CSGO* c)
		{
			[add_junk 1 5 /]
			return c->m_Mem.Read< CRecvTable* >((DWORD) this + 0xC);
		}
	};


	DWORD inline GetNetVar(const char* szClassName, const char* szNetVar)
	{
		if (!m_dynamicOffsets.netvarClassesBase || !szClassName || !szNetVar)
		{
			miscUtils->PrintLine("> Classes are fucked. Netvars can't be grabbed.");
			[add_junk 1 5 /]
		}

		ClientClass* pClass = (ClientClass*)m_dynamicOffsets.netvarClassesBase;

		if (!pClass)
		{
			return NULL;
		}

		for (; pClass; pClass = pClass->GetNextClass(this))
		{
			if (strcmp(szClassName, pClass->GetTable(this)->GetTableName(this)))
				continue;

			for (int i = 0; i < pClass->GetTable(this)->GetMaxProp(this); i++)
			{
				CRecvTable::CRecvProp* pRecvProp = pClass->GetTable(this)->GetProperty(i, this);

				[add_junk 1 5 /]

				if (isdigit(pRecvProp->GetVarName(this)[0]))
					continue;

				if (!strcmp(pRecvProp->GetVarName(this), szNetVar))
				{
					[add_junk 1 5 /]
					return pRecvProp->GetOffset(this);
				}

				if (!pRecvProp->GetDataTable(this))
					continue;

				for (int j = 0; j < pRecvProp->GetDataTable(this)->GetMaxProp(this); ++j)
				{
					[add_junk 1 5 /]

					CRecvTable::CRecvProp* pRecvProp2 = pRecvProp->GetDataTable(this)->GetProperty(j, this);

					if (isdigit(pRecvProp2->GetVarName(this)[0]))
						continue;

					if (!strcmp(pRecvProp2->GetVarName(this), szNetVar))
					{
						[add_junk 1 5 /]
						return pRecvProp2->GetOffset(this);
					}

					if (!pRecvProp2->GetDataTable(this))
						continue;

					for (int k = 0; k < pRecvProp2->GetDataTable(this)->GetMaxProp(this); ++k)
					{
						CRecvTable::CRecvProp* pRecvProp3 = pRecvProp2->GetDataTable(this)->GetProperty(k, this);

						if (isdigit(pRecvProp3->GetVarName(this)[0]))
							continue;

						if (!strcmp(pRecvProp3->GetVarName(this), szNetVar))
						{
							[add_junk 1 5 /]
							return pRecvProp3->GetOffset(this);
						}
					}
				}
			}
		}

		return NULL;
	}

	std::string inline BoolToString(bool b)
	{
		if (b)
			return "ON";

		return "OFF";
	}

	std::string inline SpinTypeToString(SpinMethod b)
	{
		switch (b)
		{
			case Actual_Spinbot:
			return "Actual Spinbot";
			case FakeDown_Jitter:
			return "Fakedown-Jitter";
			case FakeUp_Jitter:
			return "Fakeup-Jitter";

			default:
			return "Unknown Spinbot Type";
		}

		[add_junk 1 5 /]
	}

	[swap_lines]
	void DisplayControls();
	void DisplayRankInfo();
	void ScanOffsets();
	void UpdateNetvars();
	bool Attach();
	bool LoadBases();
	void UpdateInfo(Player* ply, DWORD addr);
	void ClearInfo(Player* ply);
	void UpdateEntities();
	[/swap_lines]

	int GetTeam(DWORD addr)
	{
		[add_junk 1 5 /]
		return m_Mem.Read<int>(addr + Team);
	}

	bool IsMouseEnabled()
	{
		[add_junk 1 5 /]
		return (m_Mem.Read<bool>(m_dwScaleformBase + m_dynamicOffsets.mouseEnableOffset) >= 1);
	}

	bool IsConsoleActive()
	{
		return m_Mem.Read<bool>(m_dwScaleformBase + m_dynamicOffsets.consoleEnableOffset);
	}

	bool IsSteamOverlayOn()
	{
		[add_junk 1 5 /]
		return m_Mem.Read<bool>(m_dwScaleformBase + m_dynamicOffsets.steamOverlayOffset);
	}

	bool IsSpottedBy(Player person, Player target)
	{
		[add_junk 1 5 /]
		return (person.iSpottedByMask & (1 << target.iID - 1)) != 0;
	}

	int GetEnemyTeam(int team)
	{
		if (team == Team_Terrorists)
			return Team_CounterTerrorists;
		else if (team == Team_CounterTerrorists)
			return Team_Terrorists;

		return Team_NoTeam;
	}

	CVector inline BonePosition(Player* ply, int bone)
	{
		if (bone < 0 || bone >= Bone_MAX)
			return CVector(0, 0, 0);

		[add_junk 1 5 /]

		return CVector(ply->boneMatrix[bone].m[0][3], ply->boneMatrix[bone].m[1][3], ply->boneMatrix[bone].m[2][3]);
	}

	int GetClassID(Player* ply)
	{
		[add_junk 1 5 /]
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);	// Vtable
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);	// Function
		int cls = m_Mem.Read<int>(fn + 0x1);	// Class
		[add_junk 1 5 /]
		int clsn = m_Mem.Read<int>(cls + 8);	// Class Name
		[add_junk 1 5 /]
		return m_Mem.Read<int>(cls + 20);	// ClassID
	}

	char* GetClassNameFromPlayer(Player* ply)
	{
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);
		[add_junk 1 5 /]
		int cls = m_Mem.Read<int>(fn + 0x1);
		[add_junk 1 5 /]
		int clsn = m_Mem.Read<int>(cls + 8);

		int namePointer = m_Mem.Read<int>(clsn);
		[add_junk 1 5 /]
		char* nameData = new char[32];

		for (int i = 0; i < 32; i++)
			nameData[i] = m_Mem.Read<char>(namePointer + i);

		[add_junk 1 5 /]

		return nameData;
	}

	bool IsClassIDAWeapon(int iClassID)
	{
		switch (iClassID)
		{
			case CID_CAK47:
			case CID_CDEagle:
			case CID_CWeaponAWP:
			case CID_CWeaponAug:
			case CID_CWeaponBizon:
			case CID_CWeaponElite:
			case CID_CWeaponFamas:
			case CID_CWeaponFiveSeven:
			case CID_CWeaponG3SG1:
			case CID_CWeaponGalilAR:
			case CID_CWeaponGlock:
			case CID_CWeaponHKP2000:
			case CID_CWeaponMAC10:
			case CID_CWeaponM249:
			case CID_CWeaponM4A1:
			case CID_CWeaponM3:
			case CID_CWeaponMag7:
			case CID_CWeaponMP7:
			case CID_CWeaponMP9:
			case CID_CWeaponNegev:
			case CID_CWeaponNOVA:
			case CID_CWeaponP250:
			case CID_CWeaponP90:
			case CID_CWeaponSawedoff:
			case CID_CWeaponSCAR20:
			case CID_CWeaponSG556:
			case CID_CWeaponSSG08:
			case CID_CWeaponTaser:
			case CID_CWeaponTec9:
			case CID_CWeaponUSP:
			case CID_CWeaponUMP45:
			case CID_CWeaponXM1014:


			return true;
		}

		return false;
	}

	bool IsClassIDAGrenade(int iClassID)
	{
		switch (iClassID)
		{
			case CID_CFlashbang:
			case CID_CHEGrenade:
			case CID_CDecoyGrenade:
			case CID_CIncendiaryGrenade:
			case CID_CMolotovGrenade:
			case CID_CSmokeGrenade:
			case CID_CBaseCSGrenadeProjectile:
			case CID_CSmokeGrenadeProjectile:
			case CID_CMolotovProjectile:
			case CID_CDecoyProjectile:
			return true;
		}

		return false;
	}

	EWeaponType GetWeaponType(Player& player) const
	{
		int id = player.iWeaponID;

		[add_junk 1 5 /]

		switch (id)
		{
			case WID_C4:
			return EWeaponType::WeapType_C4Explosive;

			case WID_Zeus:
			return EWeaponType::WeapType_ZeusGun;

			case WID_Negev:
			case WID_M249:
			return EWeaponType::WeapType_LMG;

			case WID_AWP:
			case WID_G3SG1_Auto:
			case WID_SCAR_Auto:
			case WID_Scout:
			return EWeaponType::WeapType_Sniper;

			case WID_XM1014:
			case WID_MAG7:
			case WID_Nova:
			case WID_SawedOff:
			return EWeaponType::WeapType_Shotgun;

			case WID_Flashbang:
			case WID_Smoke:
			case WID_Firebomb:
			case WID_HEFrag:
			case WID_Molly:
			return EWeaponType::WeapType_Grenade;

			case WID_MAC10:
			case WID_P90:
			case WID_UMP45:
			case WID_PPBizon:
			case WID_MP7:
			case WID_MP9:
			return EWeaponType::WeapType_SMG;

			case WID_Deagle:
			case WID_Dual_Berettas:
			case WID_Five_Seven:
			case WID_USP:
			case WID_Glock:
			case WID_Tec9:
			case WID_P2000:
			case WID_P250:
			case WID_CZ75:
			case WID_Revolver:
			return EWeaponType::WeapType_Pistol;

			case WID_AK47:
			case WID_AUG:
			case WID_FAMAS:
			case WID_M4A4:
			case WID_M4A1S:
			case WID_Galil:
			case WID_SG553:
			return EWeaponType::WeapType_Rifle;

			case WID_Default_Knife:
			case WID_ButterflyKnife:
			case WID_FlipKnife:
			case WID_HuntsmanKnife:
			case WID_M9BayonetKnife:
			case WID_KarambitKnife:
			case WID_FalchionKnife:
			case WID_ShadowDaggerKnife:
			case WID_BayonetKnife:
			case WID_GutKnife:
			case WID_BowieKnife:
			return EWeaponType::WeapType_KnifeType;

			default:
			return (EWeaponType)-1;
		}
	}

	void ClientCMD(const char* command)
	{
		LPVOID addr = (LPVOID)m_dynamicOffsets.clientCMDOffset;
		[add_junk 1 5 /]
		LPVOID vCommand = (LPVOID)VirtualAllocEx(m_Mem.GetHandle(), NULL, strlen(command) + 1, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
		WriteProcessMemory(m_Mem.GetHandle(), vCommand, command, strlen(command), NULL);
		[add_junk 1 5 /]
		HANDLE hThread = CreateRemoteThread(m_Mem.GetHandle(), NULL, NULL, (LPTHREAD_START_ROUTINE)addr, vCommand, NULL, NULL);
		WaitForSingleObject(hThread, INFINITE);
		[add_junk 1 5 /]
		VirtualFreeEx(m_Mem.GetHandle(), vCommand, strlen(command) + 1, MEM_RELEASE);
		CloseHandle(hThread);
	}

	[swap_lines]
	CMemory m_Mem;
	std::string m_szVersion = "\t\t\t\t3.0 PAID Edition";
	std::vector<std::thread> threadPool;
	DWORD m_dwClientBase;
	DWORD m_dwEngineBase;
	DWORD m_dwLocalBase;
	DWORD m_dwEntityBase;
	DWORD m_dwGlowObjectArrayBase;
	DWORD m_dwGameResourcesBase;
	DWORD m_dwScoreBoardBase;
	DWORD m_dwGlobalVarsBase;
	DWORD m_dwScaleformBase;
	DWORD m_dwBoneMatrix;
	DWORD m_dwAnglePointer;
	float m_ViewMatrix[16];
	Player m_Players[64];
	int m_Spectators[32];
	Hacks m_Hacks;
	RECT m_Rect;
	int m_iWindowWidth;
	int m_iWindowHeight;
	DynOffsets m_dynamicOffsets;
	[/swap_lines]

	[add_junk_datamembers 1 6 /]
};

extern CSGO* pCSGO;

#endif

[junk_disable /]
[enc_string_disable /]