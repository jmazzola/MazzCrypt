#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CSGO.h"
#include "GlowESP.h"
#include "SubtleAimbot.h"
#include "ActualAimbot.h"
#include "Bhop.h"
#include "Chatspam.h"
#include "Fakelag.h"
#include "Overlay.h"
#include "Renderer.h"
#include "Font.h"

#include "D3DMenu.h"
#include "ActualESP.h"

#include <time.h>
#include <thread>
#include <vector>

#include "Decrypt.h"

// Globals
char* programPath = "";
ActualESP* pActualESP = new ActualESP(pCSGO);

[junk_enable /]
[enc_string_enable /]

void UpdateEntitiesConstantly()
{
	while (!pCSGO->m_Hacks.tThreadHandling.bUpdateStop)
	{
		if (GetAsyncKeyState(VK_END))
			pCSGO->m_Hacks.tThreadHandling.bUpdateStop = true;

		// Check if we're in game
		int clientState = pCSGO->m_Mem.Read<int>(pCSGO->m_dwEngineBase + pCSGO->m_dynamicOffsets.enginePtr);
		[add_junk 1 4 /]
		int sos = pCSGO->m_Mem.Read<int>(clientState + SignOnState);

		if (sos == SOS_Full)
		{
			pCSGO->LoadBases();

			// Check differences in .ini and .txt
			std::string newSettingsHash = miscUtils->GetHash("settings.ini");
			[add_junk 1 4 /]
			std::string newChatHash = miscUtils->GetHash("chat.txt");

			if (strcmp(newSettingsHash.c_str(), pCSGO->m_Hacks.hacksHash.c_str()))
			{
				[add_junk 1 4 /]

				if (miscUtils->LoadINISettings("settings.ini", pCSGO))
				{
					[add_junk 1 4 /]
					miscUtils->PrintLine("> .ini file has been changed. Automatically loaded new settings!\n");
				}
				else
				{
					[add_junk 1 4 /]
					miscUtils->PrintLine("> .ini file could not be opened/changed. Failed to load new settings.\n");
				}
			}

			if (strcmp(newChatHash.c_str(), pCSGO->m_Hacks.chatHash.c_str()))
			{
				if (miscUtils->LoadCustomChat("chat.txt", pCSGO))
				{
					[add_junk 1 4 /]
					miscUtils->PrintLine("> chat.txt file has been changed. Automatically loaded new spam!\n");
				}
				else
				{
					miscUtils->PrintLine("> chat.txt file couldn't be changed. Failed to load new spam.\n");
				}
			}
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			continue;
		}

		pCSGO->UpdateEntities();

		[add_junk 1 4 /]

		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}
}

void Render()
{
	int x, y, w, h;
	pOverlay->GetCenterOfScreen(x, y);
	pOverlay->GetScreenSize(w, h);

	if (GetAsyncKeyState(VK_INSERT) & 1)
		pD3DMenu->m_bVisible = !pD3DMenu->m_bVisible;

	if (!pD3DMenu->m_bVisible)
	{
		[add_junk 1 4 /]
		pRenderer->DrawText(pD3DMenu->m_hFontWatermark, x, (y - h / 2) + 20, FONT_RENDER_CENTER_H, CVector(255, 0, 255), "smurfstomper 3.0 ~ DEV edition | [INS] To Open Menu");
	}
	else
	{
		pRenderer->DrawText(pD3DMenu->m_hFontWatermark, x, (y - h / 2) + 20, FONT_RENDER_CENTER_H, CVector(255, 0, 255), "smurfstomper 3.0 ~ DEV edition | [INS] To Close Menu");
		pD3DMenu->Render();
		[add_junk 1 4 /]
	}

	pActualESP->Render();

	[add_junk 1 4 /]

	std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

void OnFrameTick()
{
	pRenderer->PreFrame();
	{
		int clientState = pCSGO->m_Mem.Read<int>(pCSGO->m_dwEngineBase + pCSGO->m_dynamicOffsets.enginePtr);
		[add_junk 1 4 /]
		int sos = pCSGO->m_Mem.Read<int>(clientState + SignOnState);


		if (sos == SOS_Full && (GetForegroundWindow() == miscUtils->GetGameWindow()))
			Render();
		
	}
	pRenderer->PostFrame();

	[add_junk 1 4 /]

	std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

void Cleanup()
{
	[swap_lines]
	pCSGO->m_Hacks.tGlowOptions.bGlowWeapons = false;
	pCSGO->m_Hacks.tGlowOptions.bChickenGlow = false;
	pCSGO->m_Hacks.tGlowOptions.bDefuseGlow = false;
	pCSGO->m_Hacks.tGlowOptions.bFlashGlow = false;
	pCSGO->m_Hacks.tGlowOptions.bGlowGrenades = false;
	pCSGO->m_Hacks.tGlowOptions.bGlowBomb = false;
	[/swap_lines]

	[add_junk 1 4 /]

	[swap_lines]
	int objGlowArray = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwGlowObjectArrayBase);
	int objCount = pCSGO->m_Mem.Read<int>(pCSGO->m_dwGlowObjectArrayBase + 4);
	[/swap_lines]

	[add_junk 1 4 /]

	if (objGlowArray != NULL)
	{
		for (int i = 0; i < objCount; i++)
		{
			DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
			[add_junk 1 4 /]
			GlowObjectDefinition glowObj = pCSGO->m_Mem.Read<GlowObjectDefinition>(mObj);

			if (!glowObj.pEntity)
				continue;

			if (pCSGO->IsClassIDAWeapon(pCSGO->GetClassID((Player*)&glowObj.pEntity)))
			{
				[swap_lines]
				glowObj.rgb = CVector(0.f, 0.f, 0.f);
				glowObj.a = 0.0f;
				glowObj.bRenderWhenOccluded = false;
				glowObj.bRenderWhenUnoccluded = false;
				glowObj.bFullBloom = false;
				[/swap_lines]

				[add_junk 1 4 /]

				[swap_lines]
				pCSGO->m_Mem.Write<CVector>(mObj + 0x4, glowObj.rgb);
				pCSGO->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
				pCSGO->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
				pCSGO->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
				pCSGO->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
				[/swap_lines]
			}
		}
	}

	ShowWindow(GetConsoleWindow(), SW_SHOW);

	[swap_lines]
	pCSGO->m_Hacks.tThreadHandling.bFakeLagThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bChatspamThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bBhopThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bActualAimbotThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bGlowThreadStop = true;
	pCSGO->m_Hacks.tThreadHandling.bUpdateStop = true;
	pCSGO->m_Hacks.tThreadHandling.bOverlayStop = true;
	[/swap_lines]

	[add_junk 1 4 /]


	miscUtils->PrintLine(std::string("> Ending threads..."));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("> [!] If a thread doesn't end please press END [!] "));

	for (size_t i = 0; i < pCSGO->threadPool.size(); i++)
	{
		while (pCSGO->threadPool[i].joinable())
		{
			std::cout << ".";
			pCSGO->threadPool[i].join();
			Sleep(1);
			std::cout << "\nThread " << i << " ended!\n";
		}
	}


	miscUtils->PrintLine(std::string("> Detaching pCSGO.."));
	pCSGO->m_Mem.Detach();

	delete pCSGO;
	pCSGO = nullptr;
	[add_junk 1 4 /]
	delete miscUtils;
	miscUtils = nullptr;
	[add_junk 1 4 /]
	delete pD3DMenu;
	pD3DMenu = nullptr;
	[add_junk 1 4 /]
	delete pRenderer;
	pRenderer = nullptr;

	delete pOverlay;
	pOverlay = nullptr;
	[add_junk 1 4 /]
	delete pActualESP;
	pActualESP = nullptr;

	miscUtils->DeleteSelf(programPath);
}

void Init()
{
	// Create a random title and allow debugging access for this process
	miscUtils->GenerateRandomWindowTitle(20);
	miscUtils->AllowDebugging();

	miscUtils->PrintLine(std::string("                           __     _                                  "));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string(" ___ _ __ ___  _   _ _ __ / _|___| |_ ___  _ __ ___  _ __   ___ _ __ "));
	miscUtils->PrintLine(std::string("/ __| '_ ` _ \\| | | | '__| |_/ __| __/ _ \\| '_ ` _ \\| '_ \\ / _ \\ '__|"));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("\\__ \\ | | | | | |_| | |  |  _\\__ \\ || (_) | | | | | | |_) |  __/ |   "));
	miscUtils->PrintLine(std::string("|___/_| |_| |_|\\__,_|_|  |_| |___/\\__\\___/|_| |_| |_| .__/ \\___|_|   "));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("                                                    |_|              "));
	miscUtils->PrintLine(std::string("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~"));
	miscUtils->PrintLine(std::string("----------------------------------------------------------------------\n"));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now."));
	std::cout << "\b\b";

	while (!pCSGO->Attach())
	{
		std::cout << ".";
		Sleep(100);
		std::cout << "\b.";
	}

	miscUtils->PrintLine(std::string("\n> CSGO attached!"));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	miscUtils->PrintLine(std::string("> Loading INI Settings [settings.ini]..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	[add_junk 1 4 /]

	if (!miscUtils->LoadINISettings(std::string("settings.ini"), pCSGO))
	{
		pCSGO->m_Hacks.UnsetAll();
		[add_junk 1 4 /]
	}
	else
	{
		miscUtils->PrintLine(std::string("> settings.ini Loaded!..."));
		[add_junk 1 4 /]
		miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	}

	miscUtils->PrintLine(std::string("> Loading Custom Spam Table [chat.txt]..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	if (miscUtils->LoadCustomChat(std::string("chat.txt"), pCSGO))
	{
		miscUtils->PrintLine(std::string("> chat.txt Loaded!..."));
		[add_junk 1 4 /]
		miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	}

	miscUtils->PrintLine(std::string("> Waiting for game .dlls to be loaded..."));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	while (!pCSGO->m_Mem.GetModuleBase("client.dll"))
	{
		std::cout << ".";
		Sleep(100);
		std::cout << "\b.";
	}

	miscUtils->PrintLine(std::string("\n> DLLs loaded!"));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("------------------------------------------\n"));


	miscUtils->PrintLine(std::string("> Signature scanning offsets..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	[add_junk 1 4 /]
	pCSGO->ScanOffsets();

	// Load our basic information
	pCSGO->LoadBases();

	miscUtils->PrintLine(std::string("> Grabbing netvars..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	[add_junk 1 4 /]
	pCSGO->UpdateNetvars();

	miscUtils->PrintLine(std::string("\n> Netvars Grabbed!"));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	miscUtils->PrintLine(std::string("> Press INSERT whenever you're ready to 'toggle'"));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	while (!GetAsyncKeyState(VK_INSERT))
	{
		Sleep(100);
		[add_junk 1 4 /]
	}


	miscUtils->PrintLine(std::string("\n> Attaching Overlay.."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));


	pOverlay->AddCSGO(pCSGO);
	[add_junk 1 4 /]
	if (!pOverlay->AttachToHandle(miscUtils->GetGameWindow()))
		miscUtils->PrintLine(std::string("\n> Unable to attach overlay."));
	else
		miscUtils->PrintLine(std::string("\n> Overlay attached!"));

	miscUtils->PrintLine(std::string("\n> Setting up Overlay.."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	pRenderer->OnSetup(pOverlay->GetDevice());
	pD3DMenu->m_hFontWatermark = pRenderer->CreateFont("Sansation", 20, FONT_SPRITE | FONT_OUTLINED | FONT_BOLD | FONT_ANTIALIAS);
	[add_junk 1 4 /]
	pD3DMenu->m_hFontMenu = pRenderer->CreateFont("Sansation", 24, FONT_SPRITE | FONT_BOLD | FONT_ANTIALIAS);
	[add_junk 1 4 /]
	pD3DMenu->m_hFontDescription = pRenderer->CreateFont("Calibri", 18, FONT_SPRITE | FONT_NONE | FONT_ANTIALIAS);
	pOverlay->AddOnFrame(OnFrameTick);

	miscUtils->PrintLine(std::string("\n> Setting up Menu.."));
	[add_junk 1 4 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	pD3DMenu->InitMenu(CVector2D(50, 50), CVector2D(500, 500));

	miscUtils->PrintLine(std::string("> Starting cheat threads..."));

	[swap_lines]
	pCSGO->m_Hacks.tThreadHandling.bActualAimbotThreadStop = false;
	pCSGO->m_Hacks.tThreadHandling.bGlowThreadStop = false;
	pCSGO->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
	pCSGO->m_Hacks.tThreadHandling.bUpdateStop = false;
	pCSGO->m_Hacks.tThreadHandling.bOverlayStop = false;
	pCSGO->m_Hacks.tThreadHandling.bBhopThreadStop = false;
	pCSGO->m_Hacks.tThreadHandling.bChatspamThreadStop = false;
	pCSGO->m_Hacks.tThreadHandling.bFakeLagThreadStop = false;
	[/swap_lines]

	[add_junk 1 4 /]

	pCSGO->threadPool.emplace_back(UpdateEntitiesConstantly);
	pCSGO->threadPool.emplace_back(&GlowESP::Start, GlowESP(pCSGO));
	[add_junk 1 4 /]
	pCSGO->threadPool.emplace_back(&SubtleAimbot::Start, SubtleAimbot(pCSGO));
	pCSGO->threadPool.emplace_back(&ActualAimbot::Start, ActualAimbot(pCSGO));
	pCSGO->threadPool.emplace_back(&BHop::Start, BHop(pCSGO));
	[add_junk 1 4 /]
	pCSGO->threadPool.emplace_back(&ChatSpam::Start, ChatSpam(pCSGO));
	[add_junk 1 4 /]
	pCSGO->threadPool.emplace_back(&Fakelag::Start, Fakelag(pCSGO));

	pCSGO->threadPool.emplace_back(&Overlay::OnFrame, pOverlay);
	[add_junk 1 4 /]
	ShowWindow(GetConsoleWindow(), SW_HIDE);
}

void Loop()
{
	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{
		// Check if pCSGO exists
		if (!miscUtils->DoesCSGOExist())
			break;

		// Handle ESP
		if (pCSGO->m_Hacks.tESPOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tESPOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.Toggle(BIT_ESP);
			[add_junk 1 4 /]
			pCSGO->m_Hacks.tESPOptions.bActivated = pCSGO->m_Hacks.CheckBit(BIT_ESP);
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tESPOptions.bCanToggle && pCSGO->m_Hacks.tESPOptions.bActivated)
		{
			pCSGO->m_Hacks.Set(BIT_ESP);
			[add_junk 1 4 /]
			Sleep(5);
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_ESP);
			[add_junk 1 4 /]
			Sleep(5);
		}

		// Handle Fakelag
		if (pCSGO->m_Hacks.tFakeLagOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tFakeLagOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.Toggle(BIT_FAKELAG);
			[add_junk 1 4 /]
			pCSGO->m_Hacks.tFakeLagOptions.bActivated = pCSGO->m_Hacks.CheckBit(BIT_FAKELAG);
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tFakeLagOptions.bCanToggle && pCSGO->m_Hacks.tFakeLagOptions.bActivated)
		{
			pCSGO->m_Hacks.Set(BIT_FAKELAG);
			Sleep(5);
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_FAKELAG);
			[add_junk 1 4 /]
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tChatSpamOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tChatSpamOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.Toggle(BIT_CHATSPAM);
			pCSGO->m_Hacks.tChatSpamOptions.bActivated = pCSGO->m_Hacks.CheckBit(BIT_CHATSPAM);
			[add_junk 1 4 /]
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tChatSpamOptions.bCanToggle && pCSGO->m_Hacks.tChatSpamOptions.bActivated)
		{
			pCSGO->m_Hacks.Set(BIT_CHATSPAM);
			[add_junk 1 4 /]
			Sleep(5);
		}
		else
		{
			[add_junk 1 4 /]
			pCSGO->m_Hacks.Unset(BIT_CHATSPAM);
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tGlowOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tGlowOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.Toggle(BIT_GLOWESP);
			[add_junk 1 4 /]
			pCSGO->m_Hacks.tGlowOptions.bActivated = pCSGO->m_Hacks.CheckBit(BIT_GLOWESP);
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tGlowOptions.bCanToggle && pCSGO->m_Hacks.tGlowOptions.bActivated)
		{
			pCSGO->m_Hacks.Set(BIT_GLOWESP);
			Sleep(5);
			[add_junk 1 4 /]
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_GLOWESP);
			Sleep(5);
			[add_junk 1 4 /]
		}

		if (pCSGO->m_Hacks.tSubtleAimbotOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tSubtleAimbotOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.Toggle(BIT_SUBTLEAIMBOT);
			[add_junk 1 4 /]
			pCSGO->m_Hacks.tSubtleAimbotOptions.bActivated = pCSGO->m_Hacks.CheckBit(BIT_SUBTLEAIMBOT);
			Sleep(5);
		}


		if (pCSGO->m_Hacks.tSubtleAimbotOptions.bCanToggle && pCSGO->m_Hacks.tSubtleAimbotOptions.bActivated)
		{
			pCSGO->m_Hacks.Set(BIT_SUBTLEAIMBOT);
			Sleep(5);
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_SUBTLEAIMBOT);
			[add_junk 1 4 /]
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tBhopOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tBhopOptions.iKey) & 1)
		{
			pCSGO->m_Hacks.tBhopOptions.bActivated = !pCSGO->m_Hacks.tBhopOptions.bActivated;
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tBhopOptions.bCanToggle && pCSGO->m_Hacks.tBhopOptions.bActivated && GetAsyncKeyState(VK_SPACE) & 0x8000)
		{
			pCSGO->m_Hacks.Set(BIT_BHOP);
			Sleep(5);
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_BHOP);
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tActualAimbotOptions.bCanToggle && GetAsyncKeyState(pCSGO->m_Hacks.tActualAimbotOptions.iToggleKey) & 1)
		{
			pCSGO->m_Hacks.tActualAimbotOptions.bActivated = !pCSGO->m_Hacks.tActualAimbotOptions.bActivated;
			[add_junk 1 4 /]
			Sleep(5);
		}

		if (pCSGO->m_Hacks.tActualAimbotOptions.bCanToggle && pCSGO->m_Hacks.tActualAimbotOptions.bActivated && GetAsyncKeyState(pCSGO->m_Hacks.tActualAimbotOptions.iAimKey) & 0x8000)
		{
			[add_junk 1 4 /]
			pCSGO->m_Hacks.Set(BIT_AIMBOT);
			Sleep(5);
		}
		else
		{
			pCSGO->m_Hacks.Unset(BIT_AIMBOT);
			Sleep(5);
		}

		Sleep(1);
	}
}

int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	miscUtils->SetUpMinidump();
	miscUtils->DisableQuickEdit();

	if (argc > 0)
		programPath = argv[0];

	Init();

	[add_junk 1 4 /]

	Loop();

	[add_junk 1 4 /]

	Cleanup();

	return 0;
}

[junk_disable /]
[enc_string_disable /]