#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "stdafx.h"
#include <TlHelp32.h>
#include <string>

[junk_enable /]

class CMemory
{
public:
	[swap_lines]
	CMemory() = default;
	~CMemory() = default;
	bool Attach(const char* procName, DWORD rights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* modName);
	DWORD GetModuleSize(const char* modName);
	[/swap_lines]

	inline void* Allocate(DWORD dwSize, bool pageExecute) 
	{
		float flProtect;
		
		if (pageExecute)
			flProtect = PAGE_EXECUTE_READWRITE;
		else
			flProtect = PAGE_READWRITE;

		[add_junk 4 8 /]

		if (m_hProcess)
		{
			return VirtualAllocEx(m_hProcess, NULL, dwSize, MEM_COMMIT | MEM_RESERVE, flProtect);
		}
	}

	inline void Free(LPVOID lpAddress) 
	{
		[add_junk 4 8 /]
		VirtualFreeEx(m_hProcess, lpAddress, 0, MEM_RELEASE);
	}

	inline void Execute(LPVOID lpAddress, HANDLE& hThread)
	{
		hThread = CreateRemoteThread(m_hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)lpAddress, NULL, 0, NULL);
		[add_junk 4 8 /]
		WaitForSingleObject(hThread, INFINITE);
	}

	HANDLE GetHandle() const
	{
		if (!m_bAttached)
		{
			return NULL;
		}

		return m_hProcess;
	}

	template<typename T>
	T inline Read(DWORD addr)
	{
		[add_junk 1 8 /]

		T mem;
		ReadProcessMemory(m_hProcess, (LPVOID)addr, &mem, sizeof(T), NULL);
		return mem;
	}

	template<typename T>
	T inline ReadProtected(DWORD addr, T data)
	{
		T mem;
		DWORD oldProtect;
		[add_junk 1 8 /]
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		mem = Read(addr);
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), oldProtect, NULL);
		return mem;
	}

	void inline ReadCustom(DWORD addr, LPVOID buff, size_t bytesToRead)
	{
		[add_junk 1 8 /]
		ReadProcessMemory(m_hProcess, (LPCVOID)addr, buff, bytesToRead, NULL);
	}

	template<typename T>
	void inline Write(DWORD addr, T data)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, &data, sizeof(T), NULL);
	}

	template<typename T>
	void inline WriteProtected(DWORD addr, T data)
	{
		DWORD oldProtect;
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		Write(addr, data);
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), oldProtect, NULL);
	}

	void inline WriteCustom(DWORD addr, LPCVOID buff, size_t bytesToWrite)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, buff, bytesToWrite, NULL);
		[add_junk 1 8 /]
	}

	bool inline IsAttached() const
	{
		[add_junk 1 8 /]
		return m_bAttached;
	}

	bool inline DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* pszMask) 
	{
		[add_junk 1 8 /]

		for (; *pszMask; ++pszMask, ++pbData, ++pbMask)
		{
			if (*pszMask == 'c' && *pbData != *pbMask)
			{
				return false;
			}
		}

		return (*pszMask == NULL);
	}

	DWORD inline FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask) 
	{
		PBYTE data = new BYTE[dwSize];

		unsigned long bytesRead;

		[add_junk 1 8 /]

		if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead))
		{
			delete[] data;
			data = nullptr;
			return NULL;
		}

		[add_junk 1 8 /]

		for (DWORD i = 0; i < dwSize; i++) 
		{
			if (DataCompare((const BYTE*)(data + i), szSig, szMask))
			{
				delete[] data;
				data = nullptr;
				return dwStart + i;
			}
		}

		delete[] data;
		data = nullptr;
		return NULL;
	}

	DWORD inline FindPatternArr(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pattern) 
	{
		[add_junk 1 8 /]

		std::string szMask;
		szMask.resize(nCount);

		for (int i = 0; i < nCount; i++)
		{
			(pattern[i]) ? szMask[i] = 'c' : szMask[i] = '?';
		}

		[add_junk 1 8 /]

		return FindPattern(dwStart, dwSize, pattern, szMask.c_str());
	}

private:

	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers 1 8 /]
};

#endif

[junk_disable /]