#include "Memory.h"

[junk_enable /]

bool CMemory::Attach(const char* procName, DWORD rights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);

	[add_junk 1 5 /]

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)procName))
		{
			m_dwProcessID = entry.th32ProcessID;
			[add_junk 1 5 /]
			CloseHandle(handle);

			m_hProcess = OpenProcess(rights, false, m_dwProcessID);
			[add_junk 1 5 /]
			m_bAttached = true;
			
			return true;
		}
	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	return false;
}

void CMemory::Detach()
{
	m_bAttached = false;
	[add_junk 1 5 /]
	CloseHandle(m_hProcess);
}

DWORD CMemory::GetModuleBase(const char* modName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);

	[add_junk 1 5 /]

	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)modName))
		{
			CloseHandle(handle);
			[add_junk 1 5 /]
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	return NULL;
}

DWORD CMemory::GetModuleSize(const char* modName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);

	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)modName))
		{
			[add_junk 1 5 /]
			CloseHandle(handle);
			return (DWORD)entry.modBaseSize;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	[add_junk 1 5 /]

	return NULL;
}

[junk_disable /]