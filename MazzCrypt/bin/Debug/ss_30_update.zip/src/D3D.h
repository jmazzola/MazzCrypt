#ifndef _D3D_H_
#define _D3D_H_

#include <d3d9.h>
#include <d3dx9.h>

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#include <xnamath.h>
#include <windows.h>

#include <dwmapi.h>
#pragma comment(lib, "dwmapi.lib")


#endif // _D3D_H_