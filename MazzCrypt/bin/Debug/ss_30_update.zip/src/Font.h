#ifndef _FONT_H_
#define _FONT_H_

#include "D3D.h"
#include "Vector.h"
#include <string>

#undef DrawText

[junk_enable /]

enum FontFlags_t
{
	FONT_NONE = 0,
	FONT_BOLD = 1,
	FONT_ITALIC = 2,
	FONT_OUTLINED = 4,
	FONT_SPRITE = 8,
	FONT_ANTIALIAS = 16,
};

class Font
{
public:

	[swap_lines]
	Font(IDirect3DDevice9* pDevice, const std::string& fontName, int nFontSize, DWORD dwFlags);
	~Font();
	void PreFrame();
	void PostFrame();
	void OnReset();
	[/swap_lines]

	int GetFontSize() const
	{
		return m_nFontSize;
	}

	void DrawText(int x, int y, CVector color, const char* szText);
	void GetTextSize(const char* szText, int& w, int& h);

private:

	[swap_lines]
	IDirect3DDevice9* m_pDevice;
	ID3DXFont* m_pFont;
	ID3DXSprite* m_pSprite;
	std::string m_szFontName;
	int m_nFontSize;
	DWORD m_dwFlags;
	[/swap_lines]

	[add_junk_datamembers 1 6 /]
};

#endif

[junk_disable /]