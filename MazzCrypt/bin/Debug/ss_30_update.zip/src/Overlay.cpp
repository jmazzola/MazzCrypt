#include "Overlay.h"

Overlay* pOverlay = new Overlay();

[junk_enable /]

Overlay::Overlay() : m_hwnd(NULL), m_hGame(NULL), m_pDirect3D(nullptr), m_pDevice(nullptr)
{
	m_nSize[0] = m_nSize[1] = 0;
	memset(&m_PresentParams, NULL, sizeof(D3DPRESENT_PARAMETERS));

	[add_junk 1 3 /]
}

Overlay::~Overlay()
{
	[add_junk 1 3 /]
	if (m_pDevice)
	{
		m_pDevice->Release();
		m_pDevice = nullptr;
	}

	if (m_pDirect3D)
	{
		m_pDirect3D->Release();
		m_pDirect3D = nullptr;
	}

	[add_junk 1 3 /]
}

bool Overlay::AttachToHandle(HWND hwnd)
{
	m_hGame = hwnd;

	if (!m_hGame)
		return false;

	[add_junk 1 3 /]

	RECT clientRect;

	while (!m_nSize[0] || !m_nSize[1])
	{
		GetClientRect(m_hGame, &clientRect);

		m_nSize[0] = clientRect.right;
		[add_junk 1 3 /]
		m_nSize[1] = clientRect.bottom;
	}

	WNDCLASSEX wc = { NULL };
	
	static const char alphanum[] =
		"0123456789"
		"!@#$%^&*"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	std::string str;

	for (int i = 0; i < 20; i++)
	{
		str += alphanum[rand() % sizeof(alphanum) - 1];
	}

	const char* randomName = str.c_str();

	[swap_lines]
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = NULL;
	wc.hInstance = NULL;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadIcon(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = randomName;
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	[/swap_lines]

	[add_junk 1 3 /]

	if (!RegisterClassEx(&wc))
		return false;

	m_hwnd = CreateWindowEx(WS_EX_TOPMOST | WS_EX_COMPOSITED | WS_EX_TRANSPARENT | WS_EX_LAYERED, randomName, randomName, WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, m_nSize[0], m_nSize[1], NULL, NULL, NULL, NULL);

	if (!m_hwnd)
		return false;

	MARGINS margin{ -1, -1, -1, -1 };
	[add_junk 1 3 /]
	DwmExtendFrameIntoClientArea(m_hwnd, &margin);
	ShowWindow(m_hwnd, SW_SHOWDEFAULT);
	UpdateWindow(m_hwnd);

	RECT gameRect;
	GetWindowRect(m_hGame, &gameRect);

	int width = gameRect.right - gameRect.left;
	[add_junk 1 3 /]
	int height = gameRect.bottom - gameRect.top;

	LONG_PTR dwStyle = GetWindowLongPtr(m_hGame, GWL_STYLE);

	if (dwStyle & WS_BORDER)
	{
		int x = GetSystemMetrics(SM_CXBORDER);
		[add_junk 1 3 /]
		int y = GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYBORDER);

		gameRect.left += x;
		gameRect.top += y;

		[add_junk 1 3 /]

		width -= x;
		height -= y;
	}

	MoveWindow(m_hwnd, gameRect.left, gameRect.top, width, height, TRUE);

	m_nSize[0] = width;
	[add_junk 1 3 /]
	m_nSize[1] = height;

	return InitDirectX9();
}

int Overlay::OnFrame()
{
	MSG msg;

	while (!csgo->m_Hacks.tThreadHandling.bOverlayStop)
	{		
		if (GetAsyncKeyState(VK_END))
			csgo->m_Hacks.tThreadHandling.bOverlayStop = true;

		if (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			if(!m_pDevice)
				return (int)msg.wParam;

			[add_junk 1 3 /]

			m_pDevice->Clear(NULL, NULL, D3DCLEAR_TARGET, NULL, 1.0f, NULL);
			m_pDevice->BeginScene();

			if (!m_pOnFrameList.empty())
			{
				for (auto& p : m_pOnFrameList)
					p();
			}

			m_pDevice->EndScene();
			m_pDevice->Present(NULL, NULL, NULL, NULL);
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(1));

		[add_junk 1 3 /]
	}

	return (int)msg.wParam;
}

LRESULT WINAPI Overlay::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_DESTROY:
		{
			PostQuitMessage(NULL);
			break;
		}

		default:
		{
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
	}

	return NULL;
}

bool Overlay::InitDirectX9()
{
	[swap_lines]
	m_PresentParams.EnableAutoDepthStencil = TRUE;
	m_PresentParams.AutoDepthStencilFormat = D3DFMT_D16;
	m_PresentParams.Windowed = TRUE;
	m_PresentParams.BackBufferCount = 1;
	m_PresentParams.BackBufferFormat = D3DFMT_A8R8G8B8;
	m_PresentParams.BackBufferWidth = m_nSize[0];
	m_PresentParams.BackBufferHeight = m_nSize[1];
	m_PresentParams.MultiSampleType = D3DMULTISAMPLE_NONE;
	m_PresentParams.SwapEffect = D3DSWAPEFFECT_DISCARD;
	m_PresentParams.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
	m_PresentParams.hDeviceWindow = m_hwnd;
	[/swap_lines]

	[add_junk 1 3 /]

	m_pDirect3D = Direct3DCreate9(D3D_SDK_VERSION);

	if (!m_pDirect3D)
		return false;

	if (FAILED(m_pDirect3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &m_PresentParams, &m_pDevice)))
		return false;

	if (!m_pDevice)
		return false;

	[add_junk 1 3 /]

	return true;
}

[junk_disable /]