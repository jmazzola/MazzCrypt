#include "MiscUtils.h"
#include "INIReader.h"
#include "CSGO.h"
#include <Wincrypt.h>
#include <cctype>
#include <algorithm>
#include <vector>
#include <sstream>

#define BUFSIZE 1024
#define MD5LEN  16

CMiscUtils* miscUtils = new CMiscUtils();

#define clamp(val, a, b) { if(val < a) val = a; if(val > b) val = b; }

[junk_enable /]

std::string CMiscUtils::GenerateRandomString(int length)
{
	static const char alphanum[] =
		"0123456789"
		"!@#$%^&*"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	std::string str;

	[add_junk 1 3 /]

	for (int i = 0; i < length; i++)
	{
		str += alphanum[rand() % sizeof(alphanum) - 1];
		[add_junk 1 3 /]
	}

	return str;
}

void CMiscUtils::GenerateRandomWindowTitle(int stringLength)
{
	SetConsoleTitle(GenerateRandomString(stringLength).c_str());
	[add_junk 1 3 /]
}

void CMiscUtils::DeleteSelf(char* ProgramPath)
{
	// Windows keeps .exe files open during execution...
	char* batPath = new char[strlen(ProgramPath) + 5];
	strcpy_s(batPath, strlen(ProgramPath) + 5, ProgramPath);
	strcat_s(batPath, strlen(ProgramPath) + 5, ".bat");

	const char* batFormat =
		":Repeat\n"
		"del \"%s\"\n"
		"if exist \"%s\" goto Repeat\n"
		"del \"%s\"\n";

	char* batFile = new char[strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2];
	sprintf_s(batFile, strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2,
			  batFormat, ProgramPath, ProgramPath, batPath);

	FILE* f;
	fopen_s(&f, batPath, "w");
	if (f != NULL)
	{
		fwrite(batFile, strlen(batFile), 1, f);
		[add_junk 1 3 /]
		fclose(f);
	}

	STARTUPINFOA startupInfo;
	PROCESS_INFORMATION procInfo;
	[add_junk 1 3 /]
	memset(&startupInfo, 0, sizeof(startupInfo));

	startupInfo.cb = sizeof(startupInfo);

	CreateProcess(batPath, NULL, NULL, NULL, FALSE, 0, NULL, NULL,
				  &startupInfo, &procInfo);

	delete[] batFile;
	[add_junk 1 3 /]
	delete[] batPath;
}

[enc_string_enable /]
void CMiscUtils::AllowDebugging()
{
	HANDLE _HandleProcess = GetCurrentProcess();
	HANDLE _HandleToken;
	TOKEN_PRIVILEGES tkPrivileges;
	LUID _LUID;

	[add_junk 1 3 /]

	OpenProcessToken(_HandleProcess, TOKEN_ADJUST_PRIVILEGES, &_HandleToken);
	LookupPrivilegeValue(0, "seDebugPrivilege", &_LUID);

	tkPrivileges.PrivilegeCount = 1;
	tkPrivileges.Privileges[0].Luid = _LUID;
	tkPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	AdjustTokenPrivileges(_HandleToken, false, &tkPrivileges, 0, 0, 0);
	[add_junk 1 3 /]
	CloseHandle(_HandleToken);
	CloseHandle(_HandleProcess);
}

void CMiscUtils::PrintLine(std::string s)
{
	printf("%s\n", s.c_str());
	[add_junk 1 3 /]
}

int CMiscUtils::GetKeyFromString(std::string str)
{
	char data = str.c_str()[0];

	if ((data >= '0' && data <= '9') || (data >= 'A' && data <= 'Z'))
		return (int)data;

	[add_junk 1 3 /]

	if (str == "mouse1") return VK_LBUTTON;
	else if (str == "mouse2") return VK_RBUTTON;
	else if (str == "mouse3") return VK_MBUTTON;
	else if (str == "mouse4") return VK_XBUTTON1;
	else if (str == "mouse5") return VK_XBUTTON2;
	else if (str == "backspace") return VK_BACK;
	else if (str == "tab") return VK_TAB;
	else if (str == "enter") return VK_RETURN;
	else if (str == "shift") return VK_SHIFT;
	else if (str == "ctrl") return VK_CONTROL;
	else if (str == "alt") return VK_MENU;
	else if (str == "capslock") return VK_CAPITAL;
	else if (str == "escape") return VK_ESCAPE;
	else if (str == "space") return VK_SPACE;
	else if (str == "pgup") return VK_PRIOR;
	else if (str == "pgdn") return VK_NEXT;
	else if (str == "end") return VK_END;
	else if (str == "home") return VK_HOME;
	else if (str == "leftarrow") return VK_LEFT;
	else if (str == "rightarrow") return VK_RIGHT;
	else if (str == "uparrow") return VK_UP;
	else if (str == "downarrow") return VK_DOWN;
	else if (str == "ins") return VK_INSERT;
	else if (str == "del") return VK_DELETE;
	else if (str == "numpad_0") return VK_NUMPAD0;
	else if (str == "numpad_1") return VK_NUMPAD1;
	else if (str == "numpad_2") return VK_NUMPAD2;
	else if (str == "numpad_3") return VK_NUMPAD3;
	else if (str == "numpad_4") return VK_NUMPAD4;
	else if (str == "numpad_5") return VK_NUMPAD5;
	else if (str == "numpad_6") return VK_NUMPAD6;
	else if (str == "numpad_7") return VK_NUMPAD7;
	else if (str == "numpad_8") return VK_NUMPAD8;
	else if (str == "numpad_9") return VK_NUMPAD9;
	else if (str == "kp_multiply") return VK_MULTIPLY;
	else if (str == "kp_plus") return VK_ADD;
	else if (str == "kp_minus") return VK_SUBTRACT;
	else if (str == "kp_slash") return VK_DIVIDE;
	else if (str == "f1") return VK_F1;
	else if (str == "f2") return VK_F2;
	else if (str == "f3") return VK_F3;
	else if (str == "f4") return VK_F4;
	else if (str == "f5") return VK_F5;
	else if (str == "f6") return VK_F6;
	else if (str == "f7") return VK_F7;
	else if (str == "f8") return VK_F8;
	else if (str == "f9") return VK_F9;
	else if (str == "f10") return VK_F10;
	else if (str == "f11") return VK_F11;
	else if (str == "f12") return VK_F12;
	else if (str == ";") return VK_OEM_1;
	else if (str == "+") return VK_OEM_PLUS;
	else if (str == "-") return VK_OEM_MINUS;
	else if (str == ",") return VK_OEM_COMMA;
	else if (str == ".") return VK_OEM_PERIOD;
	else if (str == "/") return VK_OEM_2;
	else if (str == "~") return VK_OEM_3;
	else if (str == "[") return VK_OEM_4;
	else if (str == std::to_string(char(0x5C))) return VK_OEM_5;
	else if (str == "]") return VK_OEM_6;
	else if (str == std::to_string(char(0x22))) return VK_OEM_7;
	else return -1;

}

std::string CMiscUtils::GetStringFromKey(int key)
{
	char c[2] = { 0 };

	if ((key >= '0' && key <= '9') || (key >= 'A' && key <= 'Z'))
	{
		c[0] = (char)key;
		std::string sweg(c);
		[add_junk 1 3 /]
		std::transform(sweg.begin(), sweg.end(), sweg.begin(), ::tolower);
		return sweg;
	}

	switch (key)
	{
		case VK_LBUTTON: return std::string("mouse1");
		case VK_RBUTTON: return std::string("mouse2");
		case VK_MBUTTON: return std::string("mouse3");
		case VK_XBUTTON1: return std::string("mouse4");
		case VK_XBUTTON2: return std::string("mouse5");
		case VK_BACK: return std::string("backspace");
		case VK_TAB: return std::string("tab");
		case VK_RETURN: return std::string("enter");
		case VK_SHIFT: return std::string("shift");
		case VK_CONTROL: return std::string("ctrl");
		case VK_MENU: return std::string("alt");
		case VK_CAPITAL: return std::string("capslock");
		case VK_ESCAPE: return std::string("escape");
		case VK_SPACE: return std::string("space");
		case VK_PRIOR: return std::string("pgup");
		case VK_NEXT: return std::string("pgdn");
		case VK_END: return std::string("end");
		case VK_HOME: return std::string("home");
		case VK_LEFT: return std::string("leftarrow");
		case VK_UP: return std::string("uparrow");
		case VK_DOWN: return std::string("downarrow");
		case VK_RIGHT: return std::string("rightarrow");
		case VK_INSERT: return std::string("ins");
		case VK_DELETE: return std::string("del");
		case VK_NUMPAD0: return std::string("numpad_0");
		case VK_NUMPAD1: return std::string("numpad_1");
		case VK_NUMPAD2: return std::string("numpad_2");
		case VK_NUMPAD3: return std::string("numpad_3");
		case VK_NUMPAD4: return std::string("numpad_4");
		case VK_NUMPAD5: return std::string("numpad_5");
		case VK_NUMPAD6: return std::string("numpad_6");
		case VK_NUMPAD7: return std::string("numpad_7");
		case VK_NUMPAD8: return std::string("numpad_8");
		case VK_NUMPAD9: return std::string("numpad_9");
		case VK_MULTIPLY: return std::string("kp_multiply");
		case VK_ADD: return std::string("kp_plus");
		case VK_SUBTRACT: return std::string("kp_minus");
		case VK_DIVIDE: return std::string("kp_slash");
		case VK_F1: return std::string("f1");
		case VK_F2: return std::string("f2");
		case VK_F3: return std::string("f3");
		case VK_F4: return std::string("f4");
		case VK_F5: return std::string("f5");
		case VK_F6: return std::string("f6");
		case VK_F7: return std::string("f7");
		case VK_F8: return std::string("f8");
		case VK_F9: return std::string("f9");
		case VK_F10: return std::string("f10");
		case VK_F11: return std::string("f11");
		case VK_F12: return std::string("f12");
		case VK_OEM_1: return std::string(";");
		case VK_OEM_PLUS: return std::string("+");
		case VK_OEM_MINUS: return std::string("-");
		case VK_OEM_COMMA: return std::string(",");
		case VK_OEM_PERIOD: return std::string(".");
		case VK_OEM_2: return std::string("/");
		case VK_OEM_3: return std::string("~");
		case VK_OEM_4: return std::string("[");
		case VK_OEM_5: return std::to_string(char(0x5C));
		case VK_OEM_6: return std::string("]");
		case VK_OEM_7: return std::to_string(char(0x22));
		default: return std::string("unknown key");
	}
}

void CMiscUtils::ParseColor(std::string str, CVector& clr)
{
	LPTSTR pStop;
	int color = _tcstol(str.c_str(), &pStop, 16);
	clr.x = ((color & 0xFF0000) >> 16) / 255.0f;
	[add_junk 1 3 /]
	clr.y = ((color & 0xFF00) >> 8) / 255.0f;
	clr.z = (color & 0xFF) / 255.0f;
}

std::string CMiscUtils::GetStringFromColor(CVector color)
{
	color *= 255.0f;
	int r = (((int)color.x & 0xFF) << 16);
	int g = (((int)color.y & 0xFF) << 8);
	[add_junk 1 3 /]
	int b = (((int)color.z & 0xFF));
	std::stringstream s;
	[add_junk 1 3 /]
	s << std::hex << std::uppercase << (r | g | b);
	return s.str();
}

int GetBoneFromString(std::string bone)
{
	if (bone == "head") return Bone_Head;
	else if (bone == "neck") return Bone_Neck;
	else if (bone == "stomach") return Bone_Spine0;
	else if (bone == "chest") return Bone_Spine3;
	else return Bone_Head;
}

std::string GetStringFromBone(int bone)
{
	if (bone == Bone_Head) return "head";
	else if (bone == Bone_Neck) return "neck";
	else if (bone == Bone_Spine0) return "stomach";
	else if (bone == Bone_Spine3) return "chest";
	else return "head";
}

bool CMiscUtils::LoadINISettings(std::string fileName, CSGO* csgo)
{
	INIReader r = INIReader(fileName);

	if (r.ParseError() < 0)
	{
		std::cout << "> Unable to read .ini. Resetting settings to defaults.\n";
		return false;
	}
	csgo->m_Hacks.hacksHash = CMiscUtils::GetHash(fileName);

	csgo->m_Hacks.tESPOptions.bActivated = r.GetBoolean("esp", "defaultSetting", false);
	csgo->m_Hacks.tESPOptions.bCanToggle = r.GetBoolean("esp", "canToggle", false);
	csgo->m_Hacks.tESPOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("esp", "togglekey", "numpad_1"));
	csgo->m_Hacks.tESPOptions.bVisibleCheck = r.GetBoolean("esp", "visibleCheck", false);
	csgo->m_Hacks.tESPOptions.fMaxDist = r.GetFloat("esp", "maxdist", 50.0f);
	csgo->m_Hacks.tESPOptions.targetType.type = r.GetInteger("esp", "targettype", Target_Enemies);
	csgo->m_Hacks.tESPOptions.boxType.type = r.GetInteger("esp", "boxtype", BoxType_BoundingBox);
	csgo->m_Hacks.tESPOptions.hBarType.type = r.GetInteger("esp", "healthbartype", HealthBarType_Vertical_Left);
	csgo->m_Hacks.tESPOptions.bShowNames = r.GetBoolean("esp", "shownames", false);
	csgo->m_Hacks.tESPOptions.bShowWeapon = r.GetBoolean("esp", "showweapon", false);
	csgo->m_Hacks.tESPOptions.bShowSillyWeapons = r.GetBoolean("esp", "johnwoospecial", false);
	csgo->m_Hacks.tESPOptions.bShowBox = r.GetBoolean("esp", "showboxes", false);
	csgo->m_Hacks.tESPOptions.bSnapLines = r.GetBoolean("esp", "showsnaplines", false);
	csgo->m_Hacks.tESPOptions.bShowDistance = r.GetBoolean("esp", "showdistance", false);
	csgo->m_Hacks.tESPOptions.bShowHealthBar = r.GetBoolean("esp", "showhealthbar", false);
	csgo->m_Hacks.tESPOptions.bShowMMInfo = r.GetBoolean("esp", "showrankinfo", false);

	clamp(csgo->m_Hacks.tESPOptions.targetType.type, Target_Enemies, Target_Everyone);
	clamp(csgo->m_Hacks.tESPOptions.boxType.type, BoxType_BoundingBox, BoxType_CornerBox);
	clamp(csgo->m_Hacks.tESPOptions.hBarType.type, HealthBarType_Vertical_Left, HealthBarType_Vertical_Right);
	clamp(csgo->m_Hacks.tESPOptions.fMaxDist, 1.0f, 100.0f);


	csgo->m_Hacks.tFakeLagOptions.bCanToggle = r.GetBoolean("fakelag", "canToggle", false);
	csgo->m_Hacks.tFakeLagOptions.bActivated = r.GetBoolean("fakelag", "defaultSetting", false);
	csgo->m_Hacks.tFakeLagOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("fakelag", "togglekey", "numpad_0"));
	csgo->m_Hacks.tFakeLagOptions.iLagInterval = r.GetInteger("fakelag", "packetsToDrop", 12);

	clamp(csgo->m_Hacks.tFakeLagOptions.iLagInterval, 1, 100);

	csgo->m_Hacks.tSpinbotOptions.bCanToggle = r.GetBoolean("spinbot", "canToggle", false);
	csgo->m_Hacks.tSpinbotOptions.bActivated = r.GetBoolean("spinbot", "defaultSetting", false);
	csgo->m_Hacks.tSpinbotOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("spinbot", "togglekey", "numpad_0"));
	csgo->m_Hacks.tSpinbotOptions.eSpinType = (SpinMethod)r.GetInteger("spinbot", "spintype", SpinMethod::FakeDown_Jitter);

	csgo->m_Hacks.tChatSpamOptions.bCanToggle = r.GetBoolean("chatspam", "canToggle", false);
	csgo->m_Hacks.tChatSpamOptions.bActivated = r.GetBoolean("chatspam", "defaultSetting", false);
	csgo->m_Hacks.tChatSpamOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("chatspam", "togglekey", "kp_plus"));
	csgo->m_Hacks.tChatSpamOptions.iChatInterval = r.GetInteger("chatspam", "interval", 5);
	csgo->m_Hacks.tChatSpamOptions.bParseFile = r.GetBoolean("chatspam", "customchat", false);
	csgo->m_Hacks.tChatSpamOptions.eSpamMethod.type = r.GetInteger("chatspam", "spamtype", Advertisement);
	csgo->m_Hacks.tChatSpamOptions.iUserID = r.GetInteger("chatspam", "userid", 1);
	csgo->m_Hacks.tChatSpamOptions.bRandomParse = r.GetBoolean("chatspam", "randomparse", false);

	clamp(csgo->m_Hacks.tChatSpamOptions.iChatInterval, 1, 60);
	clamp(csgo->m_Hacks.tChatSpamOptions.eSpamMethod.type, Advertisement, ParsedFile);

	csgo->m_Hacks.tBhopOptions.bCanToggle = r.GetBoolean("bhop", "canToggle", false);
	csgo->m_Hacks.tBhopOptions.bActivated = r.GetBoolean("bhop", "defaultSetting", false);
	csgo->m_Hacks.tBhopOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("bhop", "togglekey", "numpad_2"));

	csgo->m_Hacks.tGlowOptions.bCanToggle = r.GetBoolean("glowesp", "canToggle", false);
	csgo->m_Hacks.tGlowOptions.bActivated = r.GetBoolean("glowesp", "defaultSetting", false);
	csgo->m_Hacks.tGlowOptions.fMaxDist = r.GetFloat("glowesp", "maxdist", 50.0f);
	csgo->m_Hacks.tGlowOptions.bBombInfo = r.GetBoolean("glowesp", "bombInfo", false);
	csgo->m_Hacks.tGlowOptions.targetType.type = r.GetInteger("glowesp", "targettype", Target_Enemies);
	csgo->m_Hacks.tGlowOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("glowesp", "togglekey", "mouse3"));
	csgo->m_Hacks.tGlowOptions.bVisibleGlow = r.GetBoolean("glowesp", "visibleCheck", false);
	csgo->m_Hacks.tGlowOptions.bHealthGlow = r.GetBoolean("glowesp", "health", false);
	csgo->m_Hacks.tGlowOptions.bDefuseGlow = r.GetBoolean("glowesp", "defuse", false);
	csgo->m_Hacks.tGlowOptions.bFlashGlow = r.GetBoolean("glowesp", "flash", false);
	csgo->m_Hacks.tGlowOptions.bGlowBomb = r.GetBoolean("glowesp", "bomb", false);
	csgo->m_Hacks.tGlowOptions.bGlowWeapons = r.GetBoolean("glowesp", "weapons", false);
	csgo->m_Hacks.tGlowOptions.bGlowGrenades = r.GetBoolean("glowesp", "nades", false);
	csgo->m_Hacks.tGlowOptions.bChickenGlow = r.GetBoolean("glowesp", "chicken", false);

	clamp(csgo->m_Hacks.tGlowOptions.fMaxDist, 1.0f, 100.0f);
	clamp(csgo->m_Hacks.tGlowOptions.targetType.type, Target_Enemies, Target_Everyone);

	csgo->m_Hacks.tGlowOptions.fGlowEnemy_A = r.GetFloat("glowesp", "enemy_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowEnemy_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "enemy_color", "FF0000"), csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A = r.GetFloat("glowesp", "notvisible_enemy_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "notvisible_enemy_color", "690000"), csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowTeam_A = r.GetFloat("glowesp", "teammate_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowTeam_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "teammate_color", "00FF00"), csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A = r.GetFloat("glowesp", "notvisible_teammate_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "notvisible_teammate_color", "006900"), csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB);

	csgo->m_Hacks.tGlowOptions.fWeapons_A = r.GetFloat("glowesp", "weapon_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fWeapons_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "weapon_color", "00FFFF"), csgo->m_Hacks.tGlowOptions.fWeapons_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowBomb_A = r.GetFloat("glowesp", "bomb_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowBomb_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "bomb_color", "FFBF00"), csgo->m_Hacks.tGlowOptions.fGlowBomb_RGB);

	csgo->m_Hacks.tGlowOptions.fNades_A = r.GetFloat("glowesp", "nades_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fNades_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "nades_color", "7300FF"), csgo->m_Hacks.tGlowOptions.fNades_RGB);

	csgo->m_Hacks.tGlowOptions.fDefuse_A = r.GetFloat("glowesp", "defuse_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fDefuse_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "defuse_color", "E4B5FF"), csgo->m_Hacks.tGlowOptions.fDefuse_RGB);

	csgo->m_Hacks.tGlowOptions.fChicken_A = r.GetFloat("glowesp", "chicken_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fChicken_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "chicken_color", "FFFF00"), csgo->m_Hacks.tGlowOptions.fChickenRGB);


	csgo->m_Hacks.tSubtleAimbotOptions.bCanToggle = r.GetBoolean("subtleaimbot", "canToggle", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bActivated = r.GetBoolean("subtleaimbot", "defaultSetting", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bVisibleCheck = r.GetBoolean("subtleaimbot", "visibleCheck", false);
	csgo->m_Hacks.tSubtleAimbotOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("subtleaimbot", "togglekey", "numpad_5"));
	csgo->m_Hacks.tSubtleAimbotOptions.targetType.type = r.GetInteger("subtleaimbot", "targettype", Target_Enemies);
	csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor = r.GetFloat("subtleaimbot", "smoothFactor", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.bRageMode = r.GetBoolean("subtleaimbot", "ragemode", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bJumpCheck = r.GetBoolean("subtleaimbot", "jumpcheck", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bIntelligentAim = r.GetBoolean("subtleaimbot", "intelligentaim", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bRandomPos = r.GetBoolean("subtleaimbot", "randompos", false);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.targetType.type, Target_Enemies, Target_Everyone);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor, 1.0f, 100.0f);

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_pistols", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance = r.GetInteger("subtleaimbot_pistols", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance = r.GetInteger("subtleaimbot_pistols", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale = r.GetFloat("subtleaimbot_pistols", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance, 0, 24);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance, 0, 24);

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_rifles", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance = r.GetInteger("subtleaimbot_rifles", "minChance", 2);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance = r.GetInteger("subtleaimbot_rifles", "maxChance", 10);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale = r.GetFloat("subtleaimbot_rifles", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance, 0, 35);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance, 0, 35);

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_smgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_smgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_smgs", "maxChance", 15);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale = r.GetFloat("subtleaimbot_smgs", "rcsScale", 1.5f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance, 0, 64);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance, 0, 64);

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_lmgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_lmgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_lmgs", "maxChance", 20);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale = r.GetFloat("subtleaimbot_lmgs", "rcsScale", 1.7f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance, 0, 150);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance, 0, 150);

	[add_junk 1 3 /]

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_snipers", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance = r.GetInteger("subtleaimbot_snipers", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance = r.GetInteger("subtleaimbot_snipers", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale = r.GetFloat("subtleaimbot_snipers", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance, 0, 25);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance, 0, 25);

	[add_junk 1 3 /]

	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone = GetBoneFromString(r.GetString("subtleaimbot_shotguns", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance = r.GetInteger("subtleaimbot_shotguns", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance = r.GetInteger("subtleaimbot_shotguns", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale = r.GetFloat("subtleaimbot_shotguns", "rcsScale", 0.0f);

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance, 0, 10);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance, 0, 10);


	csgo->m_Hacks.tActualAimbotOptions.bCanToggle = r.GetBoolean("aimlock", "canToggle", false);
	csgo->m_Hacks.tActualAimbotOptions.bActivated = r.GetBoolean("aimlock", "defaultSetting", false);
	csgo->m_Hacks.tActualAimbotOptions.iToggleKey = CMiscUtils::GetKeyFromString(r.GetString("aimlock", "togglekey", "numpad_8"));
	csgo->m_Hacks.tActualAimbotOptions.iAimKey = CMiscUtils::GetKeyFromString(r.GetString("aimlock", "aimkey", "mouse4"));
	csgo->m_Hacks.tActualAimbotOptions.bVisibleCheck = r.GetBoolean("aimlock", "visibleCheck", false);
	csgo->m_Hacks.tActualAimbotOptions.targetType.type = r.GetInteger("aimlock", "targettype", Target_Enemies);
	csgo->m_Hacks.tActualAimbotOptions.fFOVRadius = r.GetFloat("aimlock", "fovRadius", 25.0f);
	csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor = r.GetFloat("aimlock", "smoothFactor", 1.0f);
	csgo->m_Hacks.tActualAimbotOptions.eAimMethod.type = r.GetInteger("aimlock", "aimMethod", ClosestToCrosshair);
	csgo->m_Hacks.tActualAimbotOptions.bRageMode = r.GetBoolean("aimlock", "ragemode", false);
	csgo->m_Hacks.tActualAimbotOptions.bSilentAim = r.GetBoolean("aimlock", "silentaim", false);
	csgo->m_Hacks.tActualAimbotOptions.bJumpCheck = r.GetBoolean("aimlock", "jumpcheck", false);

	[add_junk 1 3 /]

	clamp(csgo->m_Hacks.tActualAimbotOptions.targetType.type, Target_Enemies, Target_Everyone);
	clamp(csgo->m_Hacks.tActualAimbotOptions.fFOVRadius, 0.1f, 360.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor, 1.0f, 100.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.eAimMethod.type, ClosestToCrosshair, ClosestToPlayer);

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_pistols", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale = r.GetFloat("aimlock_pistols", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale, 0.0f, 2.0f);

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_rifles", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale = r.GetFloat("aimlock_rifles", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale, 0.0f, 2.0f);

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_smgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale = r.GetFloat("aimlock_smgs", "rcsScale", 1.5f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale, 0.0f, 2.0f);


	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_lmgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale = r.GetFloat("aimlock_lmgs", "rcsScale", 1.7f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale, 0.0f, 2.0f);

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_snipers", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale = r.GetFloat("aimlock_snipers", "rcsScale", 1.0f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale, 0.0f, 2.0f);

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone = GetBoneFromString(r.GetString("aimlock_shotguns", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale = r.GetFloat("aimlock_shotguns", "rcsScale", 0.0f);

	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone, Bone_Spine0, Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale, 0.0f, 2.0f);

	std::cout << "> .ini loaded successfully!\n";
	return true;
}

[enc_string_disable /]

bool CMiscUtils::SaveINISettings(std::string fileName, CSGO* csgo)
{
	std::ofstream file(fileName.c_str());

	if (!file.good() || !file.is_open())
		return false;

	file <<
		";			                           __     _                                  \n"
		";			 ___ _ __ ___  _   _ _ __ / _|___| |_ ___  _ __ ___  _ __   ___ _ __\n"
		";			/ __| '_ ` _ " << char(0x5C) << "| | | | '__| |_/ __| __/ _ " << char(0x5C) << "| '_ ` _ " << char(0x5C) << "| '_ " << char(0x5C) << " / _ " << char(0x5C) << " '__|\n"
		";			" << char(0x5C) << "__ " << char(0x5C) << " | | | | | |_| | |  |  _" << char(0x5C) << "__ " << char(0x5C) << " || (_) | | | | | | |_) |  __/ |   \n"
		";			|___/_| |_| |_|" << char(0x5C) << "__,_|_|  |_| |___/" << char(0x5C) << "__" << char(0x5C) << "___/|_| |_| |_| .__/ " << char(0x5C) << "___|_|   \n"
		";			                                                    |_|              \n"
		";									 _____    ___  \n"
		";									|___ /   / _ " << char(0x5C) << " \n"
		";									  |_ " << char(0x5C) << "  | | | |\n"
		";									 ___) |_| |_| |\n"
		";									|____/(_)" << char(0x5C) << "___/ \n"
		";\n"
		";\n"
		";\n"
		";						            _   _   _                 \n"
		";						   ___  ___| |_| |_(_)_ __   __ _ ___ \n"
		";						  / __|/ _ " << char(0x5C) << " __| __| | '_ " << char(0x5C) << " / _` / __|\n"
		";						  " << char(0x5C) << "__ " << char(0x5C) << "  __/ |_| |_| | | | | (_| " << char(0x5C) << "__ " << char(0x5C) << " \n"
		";						  |___/" << char(0x5C) << "___|" << char(0x5C) << "__|" << char(0x5C) << "__|_|_| |_|" << char(0x5C) << "__, |___/ \n"
		";						                            |___/     \n"
		"\n"
		";						  ~ Coded and Created by ChocolatePC ~ \n"
		"\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"; 	 _                   \n"
		";	| | _____ _   _ ___  \n"
		";	| |/ / _ " << char(0x5C) << " | | / __| \n"
		";	|   <  __/ |_| " << char(0x5C) << "__ " << char(0x5C) << " \n"
		";	|_|" << char(0x5C) << "_" << char(0x5C) << "___|" << char(0x5C) << "__, |___/ \n"
		";	          |___/      \n"
		";=================================================================================\n"
		";=================================================================================\n"
		"; Use the same key names as you would in CSGO when binding something to a key.\n"
		"; There are a few exceptions down below\n"
		"\n"
		"; [!] Any keys from 'a-z' HAVE to be capitalized. [!]\n"
		"; Numpads: 'numpad_number'   (example 2 would be 'numpad_2')\n"
		"\n";

	file << "[glowesp]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tGlowOptions.iKey).c_str() << "\t\t\t; key to toggle glowesp\n\n"
		<< "[subtleaimbot]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tSubtleAimbotOptions.iKey).c_str() << "\t\t\t; key to toggle subtle aimbot\n\n"
		<< "[aimlock]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tActualAimbotOptions.iToggleKey).c_str() << "\t\t\t; key to toggle aimlock\n"
		<< "aimkey = " << GetStringFromKey(csgo->m_Hacks.tActualAimbotOptions.iAimKey).c_str() << "\t\t\t; key to hold in order to lock on\n\n"
		<< "[bhop]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tBhopOptions.iKey).c_str() << "\t\t\t; key to toggle bhop\n\n"
		<< "[chatspam]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tChatSpamOptions.iKey).c_str() << "\t\t\t; key to toggle chatspam\n\n"
		<< "[fakelag]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tFakeLagOptions.iKey).c_str() << "\t\t\t; key to toggle fakelag\n\n"
		<< "[esp]\n"
		<< "togglekey = " << GetStringFromKey(csgo->m_Hacks.tESPOptions.iKey).c_str() << "\t\t\t; key to toggle visual esp\n\n"
		<< "\n"
		<< ";=================================================================================\n"
		<< ";=================================================================================\n"
		<< "\n"
		";	 _                              _        __       \n"
		";	| |__   ___  _ __   ___  ___   (_)_ __  / _| ___  \n"
		";	| '_ " << char(0x5C) << " / _ " << char(0x5C) << "| '_ " << char(0x5C) << " / _ " << char(0x5C) << "/ __|  | | '_ " << char(0x5C) << "| |_ / _ " << char(0x5C) << " \n"
		";	| |_) | (_) | | | |  __/" << char(0x5C) << "__ " << char(0x5C) << "  | | | | |  _| (_) |\n"
		";	|_.__/ " << char(0x5C) << "___/|_| |_|" << char(0x5C) << "___||___/  |_|_| |_|_|  " << char(0x5C) << "___/ \n"
		"\n"
		"; These are the names you should use for when asked to set boneToAimAt\n"
		"\n"
		"; Head = head\n"
		"; Neck = neck\n"
		"; Chest = chest\n"
		"; Stomach = stomach\n"
		"\n"
		";=================================================================================\n"
		";=================================================================================\n"
		";	       _                              \n"
		";	  __ _| | _____      _____  ___ _ __  \n"
		";	 / _` | |/ _ " << char(0x5C) << " " << char(0x5C) << " /" << char(0x5C) << " / / _ " << char(0x5C) << "/ __| '_ " << char(0x5C) << " \n"
		";	| (_| | | (_) " << char(0x5C) << " V  V /  __/" << char(0x5C) << "__ " << char(0x5C) << " |_) |\n"
		";	 " << char(0x5C) << "__, |_|" << char(0x5C) << "___/ " << char(0x5C) << "_/" << char(0x5C) << "_/ " << char(0x5C) << "___||___/ .__/ \n"
		";	 |___/                         |_|    \n"
		";\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n"
		"[glowesp]\n"
		"canToggle = " << ((csgo->m_Hacks.tGlowOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow feature to be toggled | off = glow is unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tGlowOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on glow when loaded | off = automatically disable glow when loaded\n"
		<<
		"targettype = " << csgo->m_Hacks.tGlowOptions.targetType.type << "\t\t\t; 0 = Enemies Only | 1 = Teammates Only | 2 = Everyone\n"
		<<
		"maxdist = " << csgo->m_Hacks.tGlowOptions.fMaxDist << "\t\t\t; The max distance between you and a valid target to glow\n"
		<<
		"flash = " << ((csgo->m_Hacks.tGlowOptions.bFlashGlow) ? "on" : "off") << "\t\t\t; on = Glow white when player is flashed | off = don't\n"
		<<
		"bomb = " << ((csgo->m_Hacks.tGlowOptions.bGlowBomb) ? "on" : "off") << "\t\t\t; on = Glow the bomb | off = don't\n"
		<<
		"weapons = " << ((csgo->m_Hacks.tGlowOptions.bGlowWeapons) ? "on" : "off") << "\t\t\t; on = Glow dropped weapons | off = don't\n"
		<<
		"nades = " << ((csgo->m_Hacks.tGlowOptions.bGlowGrenades) ? "on" : "off") << "\t\t\t; on = Glow dropped / airborne grenades | off = don't\n"
		<<
		"defuse = " << ((csgo->m_Hacks.tGlowOptions.bDefuseGlow) ? "on" : "off") << "\t\t\t; on = Glow player defusing | off = don't\n"
		<<
		"chicken = " << ((csgo->m_Hacks.tGlowOptions.bChickenGlow) ? "on" : "off") << "\t\t\t; on = Glow chickens | off = don't\n"
		<<
		"health = " << ((csgo->m_Hacks.tGlowOptions.bHealthGlow) ? "on" : "off") << "\t\t\t; on = Override custom colors to show player's health | off = Use custom colors\n"
		<<
		"bombinfo = " << ((csgo->m_Hacks.tGlowOptions.bBombInfo) ? "on" : "off") << "\t\t\t; on = Override custom colors to show if bomb is able to be defused | off = Use custom colors\n"
		<<
		"visibleCheck = " << ((csgo->m_Hacks.tGlowOptions.bVisibleGlow) ? "on" : "off") << "\t\t\t ; on = Show notvisible colors when a player is invisible | off = don't\n"
		<<
		"\n"
		<<
		";=================================================================================\n"
		";=================================================================================\n"
		";\n"
		";	  ___  ___  _ __\n"
		";	 / _ " << char(0x5C) << "/ __|| '_ " << char(0x5C) << " \n"
		";	|  __/" << char(0x5C) << "__ " << char(0x5C) << "| |_) |\n"
		";	 " << char(0x5C) << "___||___/| .__/ \n"
		";	           |_|    \n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n"
		"[esp]\n"
		<<
		"canToggle = " << ((csgo->m_Hacks.tESPOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow esp to be toggled | off = esp is unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tESPOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on esp when loaded | off = automatically disable esp when loaded\n"
		<<
		"targettype = " << csgo->m_Hacks.tESPOptions.targetType.type << "\t\t\t; 0 = Enemies Only | 1 = Teammates Only | 2 = Everyone\n"
		<<
		"boxtype = " << csgo->m_Hacks.tESPOptions.boxType.type << "\t\t\t; 0 = Bounding Box | 1 = Cornered Box\n"
		<<
		"healthbartype = " << csgo->m_Hacks.tESPOptions.hBarType.type << "\t\t\t; 0 = Left Side | 1 = Right Side\n"
		<<
		"maxdist = " << csgo->m_Hacks.tESPOptions.fMaxDist << "\t\t\t; The max distance between you and a valid target to render\n"
		<<
		"visibleCheck = " << ((csgo->m_Hacks.tESPOptions.bVisibleCheck) ? "on" : "off") << "\t\t\t; on = Show notvisible colors when a player is invisible | off = don't\n"
		<<
		"showboxes = " << ((csgo->m_Hacks.tESPOptions.bShowBox) ? "on" : "off") << "\t\t\t; on = Show boxes around targets | off = Don't\n"
		<<
		"showdistance = " << ((csgo->m_Hacks.tESPOptions.bShowDistance) ? "on" : "off") << "\t\t\t; on = Show targets distance from you in meters | off = Don't\n"
		<<
		"showsnaplines = " << ((csgo->m_Hacks.tESPOptions.bSnapLines) ? "on" : "off") << "\t\t\t; on = Show snaplines from targets to you | off = Don't\n"
		<<
		"showhealthbar = " << ((csgo->m_Hacks.tESPOptions.bShowHealthBar) ? "on" : "off") << "\t\t\t; on = Show health bar | off = Don't\n"
		<<
		"shownames = " << ((csgo->m_Hacks.tESPOptions.bShowNames) ? "on" : "off") << "\t\t\t; on = Show targets name | off = Don't\n"
		<<
		"showweapon = " << ((csgo->m_Hacks.tESPOptions.bShowWeapon) ? "on" : "off") << "\t\t\t; on = Show targets weapon | off = Don't\n"
		<<
		"showrankinfo = " << ((csgo->m_Hacks.tESPOptions.bShowMMInfo) ? "on" : "off") << "\t\t\t; on = Show rank / wins information | off = Don't\n"
		<<
		"johnwoospecial = " << ((csgo->m_Hacks.tESPOptions.bShowSillyWeapons) ? "on" : "off") << "\t\t\t; on = Secret | off = You won't know the secret I suppose\n"
		<<
		";=================================================================================\n"
		";=================================================================================\n"
		";	           _                 \n"
		";	  ___ ___ | | ___  _ __ ___  \n"
		";	 / __/ _ " << char(0x5C) << "| |/ _ " << char(0x5C) << "| '__/ __| \n"
		";	| (_| (_) | | (_) | |  " << char(0x5C) << "__ " << char(0x5C) << char(0x5C) << " \n"
		";	 " << char(0x5C) << "___" << char(0x5C) << "___/|_|" << char(0x5C) << "___/|_|  |___/ \n"
		";\n"
		"; Go to colorpicker.com and copy and paste the value in the center of the page for\n"
		"; custom colors\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n"
		"[glowesp]\n"
		"; ENEMY COLOR\n"
		"enemy_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB).c_str() << "\t\t\t\t; Color for enemies' glow\n"
		<<
		"enemy_thickness = " << csgo->m_Hacks.tGlowOptions.fGlowEnemy_A << "\t\t\t; Thickness of enemies' glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"notvisible_enemy_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB).c_str() << "\t\t\t; Color for not visible enemies' glow\n"
		<<
		"notvisible_enemy_thickness = " << csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A << "\t\t\t; Thickness of not visible enemies' glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"; TEAMMATE COLOR\n"
		<<
		"teammate_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB).c_str() << "\t\t\t; Color for teammates' glow\n"
		<<
		"teammate_thickness = " << csgo->m_Hacks.tGlowOptions.fGlowTeam_A << "\t\t\t; Thickness of teammates' glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"notvisible_teammate_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB).c_str() << "\t\t\t; Color for not visible teammates' glow\n"
		<<
		"notvisible_teammate_thickness = " << csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A << "\t\t\t; Thickness of not visible teammates' glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"; BOMB COLOR\n"
		<<
		"bomb_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fGlowBomb_RGB).c_str() << "\t\t\t; Color of the bomb's glow\n"
		<<
		"bomb_thickness = " << csgo->m_Hacks.tGlowOptions.fGlowBomb_A << "\t\t\t; Thickness of the bomb's glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"; WEAPON COLOR\n"
		<<
		"weapon_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fWeapons_RGB).c_str() << "\t\t\t; Color of dropped weapons' glow\n"
		<<
		"weapon_thickness = " << csgo->m_Hacks.tGlowOptions.fWeapons_A << "\t\t\t; Thickness of dropped weapons' glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"; NADES COLOR\n"
		<<
		"nades_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fNades_RGB).c_str() << "\t\t\t; Color of dropped/airborne grenades' glow\n"
		<<
		"nades_thickness = " << csgo->m_Hacks.tGlowOptions.fNades_A << "\t\t\t;  Thickness of dropped/airborne grenades' glow ( 0.0 Non-Existent < > 1.0 Thick)\n"
		<<
		"; DEFUSER COLOR\n"
		<<
		"defuse_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fDefuse_RGB).c_str() << "\t\t\t; Color of person defusing's glow\n"
		<<
		"defuse_thickness = " << csgo->m_Hacks.tGlowOptions.fDefuse_A << "\t\t\t; Thickness of person defusing's glow ( 0.0 Non-Existent < > 1.0 Thick )\n\n"
		<<
		"; CHICKEN COLOR\n"
		<<
		"chicken_color = " << GetStringFromColor(csgo->m_Hacks.tGlowOptions.fChickenRGB).c_str() << "\t\t\t; Color of chicken's glow\n"
		<<
		"chicken_thickness = " << csgo->m_Hacks.tGlowOptions.fChicken_A << "\t\t\t; Thickness of chicken's glow ( 0.0 Non-Existent < > 1.0 Thick )\n"
		<<
		"\n;=================================================================================\n"
		";=================================================================================\n"
		";	           _     _   _              _           _           _   \n"
		";	 ___ _   _| |__ | |_| | ___    __ _(_)_ __ ___ | |__   ___ | |_ \n"
		";	/ __| | | | '_ " << char(0x5C) << "| __| |/ _ " << char(0x5C) << "  / _` | | '_ ` _ " << char(0x5C) << "| '_ " << char(0x5C) << " / _ " << char(0x5C) << "| __|\n"
		";	" << char(0x5C) << "__ " << char(0x5C) << " |_| | |_) | |_| |  __/ | (_| | | | | | | | |_) | (_) | |_ \n"
		";	|___/" << char(0x5C) << "__,_|_.__/ " << char(0x5C) << "__|_|" << char(0x5C) << "___|  " << char(0x5C) << "__,_|_|_| |_| |_|_.__/ " << char(0x5C) << "___/ " << char(0x5C) << "__|\n"
		";\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n"
		"[subtleaimbot]\n"
		"canToggle = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow esp to be toggled | off = esp is unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on esp when loaded | off = automatically disable esp when loaded\n"
		<<
		"targettype = " << csgo->m_Hacks.tSubtleAimbotOptions.targetType.type << "\t\t\t; 0 = Enemies Only | 1 = Teammates Only | 2 = Everyone\n"
		<<
		"ragemode = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bRageMode) ? "on" : "off") << "\t\t\t; 'on' - override smoothfactor / weapon minmax chances to snap to targets | 'off' - use custom smoothfactor / weapon minmax chances\n"
		<<
		"visibleCheck = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bVisibleCheck) ? "on" : "off") << "\t\t\t; 'on' = Only aimbot on visible targets | 'off' = don't care\n"
		<<
		"smoothFactor = " << csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor << "\t\t\t; float number to smooth out snapping to targets' bones | Use small steps while firing to get to bone 1.0 < > 100.0 Instantly go to bone while firing\n"
		<<
		"jumpcheck = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bJumpCheck) ? "on" : "off") << "\t\t\t; 'on' = Don't aim at players jumping | 'off' = Don't care\n"
		<<
		"intelligentaim = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bIntelligentAim) ? "on" : "off") << "\t\t\t; 'on' = Using min/max chances it will switch bones to chest/neck overtime | 'off' = Don't do that\n"
		<<
		"randompos = " << ((csgo->m_Hacks.tSubtleAimbotOptions.bRandomPos) ? "on" : "off") << "\t\t\t; 'on' = Randomize bone position with offsets to prevent 100% pinpoint accuracy | 'off' = Have 100% pinpoint accuracy\n"
		<<
		"\n\n"
		<<
		"[subtleaimbot_pistols]		; Weapons considered to be pistols: [ Deagle, P2K, Dual Berettas, USP-S, Glock, Tec9, P250, CZ-75, and R8 Revolver ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using pistols\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n[subtleaimbot_snipers]	; Weapons considered to be snipers: [ AWP, SCAR-20, Scout and G3GS1 ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using snipers\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n[subtleaimbot_rifles]	; Weapons considered to be rifles: [ AK47, M4A4, M4A1-S, Galil, AUG, FAMAS and SG553 ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using rifles\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n[subtleaimbot_smgs]		; Weapons considered to be smgs: [ MAC-10, P90, MP7, MP9, PP-Bizon and UMP45 ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using smgs\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n[subtleaimbot_lmgs]		; Weapons considered to be lmgs: [ Negev and M249 ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using lmgs\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n[subtleaimbot_shotguns]		; Weapons considered to be shotguns: [ XM1014, MAG7, Nova and Sawed-Off ]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using shotguns\n"
		<<
		"minChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance << "\t\t\t; minimum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"maxChance = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance << "\t\t\t; maximum number of shots fired until the subtle aimbot aims at the bone\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale << "\t\t\t; Scale of how perfect the RCS should be | 0.0 No Recoil Control < > 1.0 Perfect Recoil Control\n"
		<<
		"\n\n"
		<<
		";=================================================================================\n"
		";=================================================================================\n"
		";	      _           _            _    \n"
		";	 __ _(_)_ __ ___ | | ___   ___| | __ \n"
		";	/ _` | | '_ ` _ " << char(0x5C) << "| |/ _ " << char(0x5C) << " / __| |/ / \n"
		";	 (_| | | | | | | | | (_) | (__|   <  \n"
		";	" << char(0x5C) << "__,_|_|_| |_| |_|_|" << char(0x5C) << "___/ " << char(0x5C) << "___|_|" << char(0x5C) << "_" << char(0x5C) << " \n"
		"\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n[aimlock]\n"
		<<
		"canToggle = " << ((csgo->m_Hacks.tActualAimbotOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow aimlock to be toggled | off = aimlock is unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tActualAimbotOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on aimlock when loaded | off = automatically disable aimlock when loaded\n"
		<<
		"targettype = " << csgo->m_Hacks.tActualAimbotOptions.targetType.type << "\t\t\t; 0 = Enemies Only | 1 = Teammates Only | 2 = Everyone\n"
		<<
		"ragemode = " << ((csgo->m_Hacks.tActualAimbotOptions.bRageMode) ? "on" : "off") << "\t\t\t; 'on' - don't consider FOV | 'off' - do consider FOV\n"
		<<
		"aimMethod = " << csgo->m_Hacks.tActualAimbotOptions.eAimMethod.type << "\t\t\t; 0 - Aim to the closest player within your crosshair | 1 - Aim at the closest player within distance | 2 - Aim at the player with the lowest HP\n"
		<<
		"visibleCheck = " << ((csgo->m_Hacks.tActualAimbotOptions.bVisibleCheck) ? "on" : "off") << "\t\t\t; 'on' = Only aim at visible targets | 'off' = don't.\n"
		<<
		"fovRadius = " << csgo->m_Hacks.tActualAimbotOptions.fFOVRadius << "\t\t\t; the minimum FOV between you and your target to lock on | 0.1 Barely Any < > 360.0 Immediately Lock On\n"
		<<
		"jumpcheck = " << ((csgo->m_Hacks.tActualAimbotOptions.bJumpCheck) ? "on" : "off") << "\t\t\t; 'on' = Don't aim at players jumping | 'off' = Don't care\n"
		<<
		"smoothFactor = " << csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor << "\t\t\t; float number to smooth out snapping to targets' bones | 1.0 Snap To Bone < > 100.0 Smoothly/Slowly Glide to Bone\n"
		<<
		"\n[aimlock_pistols]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using pistols\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale << "\t\t\t; bone to aim at when using pistols\n"
		<<
		"\n[aimlock_snipers]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using snipers\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale << "\t\t\t; bone to aim at when using snipers\n"
		<<
		"\n[aimlock_rifles]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using rifles\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale << "\t\t\t; bone to aim at when using rifles\n"
		<<
		"\n[aimlock_smgs]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using smgs\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale << "\t\t\t; bone to aim at when using smgs\n"
		<<
		"\n[aimlock_lmgs]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using lmgs\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale << "\t\t\t; bone to aim at when using lmgs\n"
		<<
		"\n[aimlock_shotguns]\n"
		<<
		"boneToAimAt = " << GetStringFromBone(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt.bone).c_str() << "\t\t\t; bone to aim at when using shotguns\n"
		<<
		"rcsScale = " << csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale << "\t\t\t; bone to aim at when using shotguns\n"
		<<
		";=================================================================================\n"
		";=================================================================================\n"
		"\n"
		";	 _     _                 \n"
		";	| |__ | |__   ___  _ __   \n"
		";	| '_ " << char(0x5C) << "| '_ " << char(0x5C) << " / _ " << char(0x5C) << "| '_ " << char(0x5C) << "  \n"
		";	| |_) | | | | (_) | |_) | \n"
		";	|_.__/|_| |_|" << char(0x5C) << "___/| .__/  \n"
		";	                  |_|     \n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n[bhop]\n"
		<<
		"canToggle = " << ((csgo->m_Hacks.tBhopOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow bhop to be toggled | off = bhop is unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tBhopOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on bhop when loaded | off = automatically disable bhop when loaded\n"
		<<
		"\n;================================================================================="
		";=================================================================================\n"
		";																				   \n"
		";	      _           _                             							   \n"
		";	  ___| |__   __ _| |_ ___ _ __   __ _ _ __ ___  							   \n"
		";	 / __| '_ " << char(0x5C) << " / _` | __/ __| '_ " << char(0x5C) << " / _` | '_ ` _ " << char(0x5C) << " 							   \n"
		";	| (__| | | | (_| | |_" << char(0x5C) << "__ " << char(0x5C) << " |_) | (_| | | | | | |							   \n"
		";	 " << char(0x5C) << "___|_| |_|" << char(0x5C) << "__,_|" << char(0x5C) << "__|___/ .__/ " << char(0x5C) << "__,_|_| |_| |_|						  \n"
		";	                         |_|                    							   \n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n[chatspam]\n"
		<<
		"canToggle = " << ((csgo->m_Hacks.tChatSpamOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow chatspam to be toggled | off = chatspam unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tChatSpamOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on chatspam when loaded | off = automatically disable chatspam when loaded\n"
		<<
		"interval = " << csgo->m_Hacks.tChatSpamOptions.iChatInterval << "\t\t\t;  number in seconds that it'll wait to spam the chat.\n"
		<<
		"spamtype = " << csgo->m_Hacks.tChatSpamOptions.eSpamMethod.type << "\t\t\t; 0 = Advertisement | 1 = Custom Chat | 2 = Achievement Spam | 3 = Troll Information\n"
		<<
		"; [!] NOTE THE FOLLOWING WILL ONLY WORK IF SPAMTYPE IS SET TO 1 [!]\n"
		<<
		"randomparse = " << ((csgo->m_Hacks.tChatSpamOptions.bRandomParse) ? "on" : "off") << "\t\t\t; 'on' = randomly pick lines in chat.txt | 'off' = spam in order\n"
		<<
		"\n;=================================================================================\n"
		";=================================================================================\n"
		";	  __       _        _				\n"
		";	 / _| __ _| | _____| | __ _  __ _	\n"
		";	| |_ / _` | |/ / _ " << char(0x5C) << " |/ _` |/ _` |	\n"
		";	|  _| (_| |   <  __/ | (_| | (_| |	\n"
		";	|_|  " << char(0x5C) << "__,_|_|" << char(0x5C) << "_" << char(0x5C) << "___|_|" << char(0x5C) << "__,_|" << char(0x5C) << "__, |	\n"
		";	                            |___/	\n"
		";=================================================================================\n"
		";=================================================================================\n"
		"\n[fakelag]\n"
		<<
		"canToggle = " << ((csgo->m_Hacks.tFakeLagOptions.bCanToggle) ? "on" : "off") << "\t\t\t; on = allow fakelag to be toggled | off = fakelag unable to be used\n"
		<<
		"defaultSetting = " << ((csgo->m_Hacks.tFakeLagOptions.bActivated) ? "on" : "off") << "\t\t\t; on = automatically turn on fakelag when loaded | off = automatically disable fakelag when loaded\n"
		<<
		"packetsToDrop = " << csgo->m_Hacks.tFakeLagOptions.iLagInterval << "\t\t\t; number of packets to lag/drop	 | 1 Barely Any < > 100 Noticeable Rubber Banding\n";


	file.close();

	return true;
}

[enc_string_enable /]
bool CMiscUtils::LoadCustomChat(std::string fileName, CSGO* csgo)
{
	csgo->m_Hacks.parseLines.clear();

	std::ifstream parseFile;
	parseFile.open("chat.txt");
	std::string line;

	if (!parseFile.is_open() || !parseFile.good())
	{
		parseFile.close();
		[add_junk 1 3 /]
		return false;
	}

	while (std::getline(parseFile, line))
		csgo->m_Hacks.parseLines.push_back(line);

	parseFile.close();

	csgo->m_Hacks.chatHash = CMiscUtils::GetHash("chat.txt");

	return true;
}

bool CMiscUtils::IsActiveWindow()
{
	char windowTitle[256];
	char consoleTitle[256];
	HWND hwnd = GetForegroundWindow();
	GetWindowText(hwnd, windowTitle, sizeof(windowTitle));
	GetConsoleTitle(consoleTitle, sizeof(consoleTitle));

	return (!strcmp(windowTitle, consoleTitle));
}

bool CMiscUtils::IsCSGOActiveWindow()
{
	char windowTitle[256];
	HWND hwnd = GetForegroundWindow();
	GetWindowText(hwnd, windowTitle, sizeof(windowTitle));

	return(!strcmp(windowTitle, "Counter-Strike: Global Offensive"));
}

bool CMiscUtils::DoesCSGOExist()
{
	HWND hwnd = FindWindow(NULL, "Counter-Strike: Global Offensive");
	[add_junk 1 3 /]
	return (hwnd != NULL);
}

HWND CMiscUtils::GetGameWindow()
{
	[add_junk 1 3 /]
	return FindWindow(NULL, "Counter-Strike: Global Offensive");
}

void CMiscUtils::DisableQuickEdit()
{
	HANDLE hConsole = GetStdHandle(STD_INPUT_HANDLE);
	DWORD consoleMode;
	GetConsoleMode(hConsole, &consoleMode);
	consoleMode &= ~ENABLE_QUICK_EDIT_MODE;
	[add_junk 1 3 /]
	SetConsoleMode(hConsole, consoleMode);
}

[enc_string_disable /]

std::string CMiscUtils::GetHash(std::string fileName)
{
	HANDLE hFile = CreateFile(fileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	HCRYPTPROV hProv;
	HCRYPTHASH hHash;

	DWORD cbHash = MD5LEN;
	BYTE rgbHash[MD5LEN];
	CHAR rgbDigits[] = "0123456789abcdef";


[enc_string_enable /]

	if (hFile == INVALID_HANDLE_VALUE)
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error reading in .ini"));
		CloseHandle(hFile);
		[add_junk 1 3 /]
		return std::string("ERROR");
	}

	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
	}

	BOOL bResult = FALSE;
	DWORD cbRead;
	[add_junk 1 3 /]
	BYTE rgbFile[BUFSIZE];

	while (bResult = ReadFile(hFile, rgbFile, BUFSIZE, &cbRead, NULL))
	{
		if (!cbRead)
		{
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			int dwStatus = GetLastError();
			CMiscUtils::PrintLine(std::string("Error with CryptHashData"));
			CryptReleaseContext(hProv, 0);
			CryptDestroyHash(hHash);
			[add_junk 1 3 /]
			CloseHandle(hFile);
			return std::string("ERROR");
		}
	}

	if (!bResult)
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("ReadFile failed"));
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		[add_junk 1 3 /]
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			[add_junk 1 3 /]
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);
		}
	}


	CryptReleaseContext(hProv, 0);
	[add_junk 1 3 /]
	CryptDestroyHash(hHash);
	CloseHandle(hFile);

	return hashOutput;
}

void MakeMinidump(_EXCEPTION_POINTERS *e)
{
	char dumpName[MAX_PATH];

	SYSTEMTIME t;
	GetSystemTime(&t);
	[add_junk 1 3 /]
	wsprintf(dumpName, "smurfstomper_%4d%02d%02d_%02d%02d%02d.dmp", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);

	auto hFile = CreateFile(dumpName, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

	if (hFile == INVALID_HANDLE_VALUE)
		return;

	MINIDUMP_EXCEPTION_INFORMATION info;
	info.ThreadId = GetCurrentThreadId();
	[add_junk 1 3 /]
	info.ExceptionPointers = e;
	info.ClientPointers = FALSE;

	char msg[MAX_PATH];

	// Hidden minidumpwritedump somehow causes heap corruption
	if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpWithIndirectlyReferencedMemory, (e ? &info : nullptr), nullptr, nullptr))
	{
		sprintf(msg, "Crashdump created: '%s'\nPlease contact ChocolatePC with this ASAP.", dumpName);
		[add_junk 1 3 /]
		MessageBox(NULL, msg, "Crash!", MB_OK);
	}
	else
	{
		sprintf(msg, "Unable to create crashdump!\nPlease contact ChocolatePC with this:\n Error %d", GetLastError());
		MessageBox(NULL, msg, "Crash!", MB_OK);
	}

	CloseHandle(hFile);
}

LONG WINAPI unhandled_handler(_EXCEPTION_POINTERS* e)
{
	MakeMinidump(e);
	[add_junk 1 3 /]
	return EXCEPTION_CONTINUE_SEARCH;
}

void CMiscUtils::SetUpMinidump()
{
	SetUnhandledExceptionFilter(unhandled_handler);
	[add_junk 1 3 /]
}

[junk_disable /]
[enc_string_disable /]