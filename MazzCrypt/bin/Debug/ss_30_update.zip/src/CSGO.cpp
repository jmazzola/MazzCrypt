#include "CSGO.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

CSGO* pCSGO = new CSGO();

bool CSGO::Attach()
{
	[add_junk 1 6 /]
	return (m_Mem.Attach("csgo.exe"));
}

bool CSGO::LoadBases()
{
	if (!m_Mem.IsAttached())
		return false;

	m_dwClientBase = m_Mem.GetModuleBase("client.dll");

	[add_junk 1 6 /]

	if (!m_dwClientBase)
		return false;

	m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");

	if (!m_dwEngineBase)
		return false;

	m_dwScaleformBase = m_Mem.GetModuleBase("scaleformui.dll");

	if (!m_dwScaleformBase)
		return false;


	[swap_lines]
	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.localPlayer);
	m_dwEntityBase = m_dwClientBase + m_dynamicOffsets.entityList;
	m_dwGlowObjectArrayBase = m_dwClientBase + m_dynamicOffsets.glowObjectBase;
	m_dwGameResourcesBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.gameResources);
	m_dwScoreBoardBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.scoreBoard);
	m_dwGlobalVarsBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.globalVarsOffset);
	m_dwAnglePointer = m_Mem.Read <DWORD>(m_dwEngineBase + m_dynamicOffsets.enginePtr);
	[/swap_lines]

	[add_junk 1 6 /]

	for (int i = 0; i < 16; i++)
	{
		[add_junk 1 6 /]
		m_ViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + m_dynamicOffsets.viewMatrix + (4 * i));
	}

	GetClientRect(FindWindow(NULL, "Counter-Strike: Global Offensive"), &m_Rect);

	[swap_lines]
	m_iWindowWidth = (int)(m_Rect.right - m_Rect.left);
	m_iWindowHeight = (int)(m_Rect.bottom - m_Rect.top);
	[/swap_lines]

	[add_junk 1 6 /]

	return true;
}

void CSGO::ClearInfo(Player* ply)
{
	[swap_lines]
	ply->baseAddr = NULL;
	ply->iID = NULL;
	ply->iFlags = NULL;
	ply->iHealth = NULL;
	ply->iArmor = NULL;
	ply->iTeam = NULL;
	ply->iShotsFired = NULL;
	ply->iClassID = NULL;
	ply->iSpectatorMode = NULL;
	ply->iSpectatorTarget = NULL;
	ply->iOwnerEntity = NULL;
	ply->iSpottedByMask = NULL;
	ply->iRank = NULL;
	ply->iWins = NULL;
	ply->fFlashDuration = 0.0f;
	ply->bAlive = false;
	ply->bHasHelmet = false;
	ply->bHasDefuser = false;
	ply->bIsSpotted = false;
	ply->bIsReloading = false;
	ply->bIsDefusing = false;
	ply->bIsDormant = false;
	ply->iWeaponID = NULL;
	ply->iAmmo_Primary = NULL;
	ply->iAmmo_Secondary = NULL;
	ply->iSkinOwnerHigh = NULL;
	ply->iSkinOwnerLow = NULL;
	ply->iSkinPaint = NULL;
	ply->iSkinSeed = NULL;
	ply->iStatTrak = NULL;
	ply->fSkinWear = NULL;
	ply->vOrigin = CVector(0, 0, 0);
	ply->vVelocity = CVector(0, 0, 0);
	ply->vPunchAngles = CVector(0, 0, 0);
	ply->vVecViewOffset = CVector(0, 0, 0);
	ply->vEyePos = CVector(0, 0, 0);
	ply->vViewAngles = CVector(0, 0, 0);
	[/swap_lines]

	[add_junk 1 6 /]

}

unsigned int Endian_DWord_Conversion(unsigned int dword)
{
	[add_junk 1 6 /]
	return ((dword >> 24) & 0x000000FF) | ((dword >> 8) & 0x0000FF00) | ((dword << 8) & 0x00FF0000) | ((dword << 24) & 0xFF000000);
}

void CSGO::UpdateInfo(Player* ply, DWORD addr)
{
	//ClearInfo(ply);

	ply->baseAddr = addr;

	[swap_lines]
	ply->iID = m_Mem.Read<int>(addr + Id);
	ply->iFlags = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_fFlags);
	ply->iHealth = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_iHealth);
	ply->iArmor = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_ArmorValue);
	ply->iTeam = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_iTeamNum);
	ply->iShotsFired = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_iShotsFired);
	ply->iClassID = GetClassID(ply);
	ply->iSpectatorMode = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_iObserverMode);
	ply->iSpectatorTarget = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_iObserverTarget);
	ply->iOwnerEntity = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_hOwner);
	ply->iSpottedByMask = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_spottedByMask);
	[/swap_lines]

	[add_junk 1 6 /]

	int clientState = pCSGO->m_Mem.Read<int>(pCSGO->m_dwEngineBase + pCSGO->m_dynamicOffsets.enginePtr);
	int ecx = m_Mem.Read<int>(clientState + m_dynamicOffsets.playerInfoOffset);
	int edx = m_Mem.Read<int>(ecx + 0x3C);
	[add_junk 1 6 /]
	int eax = m_Mem.Read<int>(edx + 0xC);
	int info = m_Mem.Read<int>(eax + 0x20 + (ply->iID - 1)  * 0x34);
	[add_junk 1 6 /]
	m_Mem.ReadCustom(info + 0x10, ply->tPlayerInfo.name, sizeof(ply->tPlayerInfo.name));
	ply->tPlayerInfo.userID = Endian_DWord_Conversion(m_Mem.Read<int>(info + 0x90));
	m_Mem.ReadCustom(info + 0x94, ply->tPlayerInfo.guid, sizeof(ply->tPlayerInfo.guid));
	[add_junk 1 6 /]
	m_Mem.ReadCustom(addr + m_dynamicOffsets.netvar_szLastPlaceName, ply->szCallout, sizeof(ply->szCallout));

	[swap_lines]
	ply->iRank = m_Mem.Read<int>(m_dwGameResourcesBase + m_dynamicOffsets.netvar_compRank + ply->iID * 4);
	ply->iWins = m_Mem.Read<int>(m_dwGameResourcesBase + m_dynamicOffsets.netvar_compWins + ply->iID * 4);
	ply->fFlashDuration = m_Mem.Read<float>(addr + m_dynamicOffsets.netvar_flFlashDuration);
	ply->fImmuneTime = m_Mem.Read<float>(ply->baseAddr + m_dynamicOffsets.netvar_immuneTime);
	[/swap_lines]

	[add_junk 1 6 /]

	[swap_lines]
	ply->bAlive = (ply->iHealth > 0);
	ply->bHasHelmet = (m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_bHasHelmet)) ? 1 : 0;
	ply->bHasDefuser = (m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_bHasDefuser)) ? 1 : 0;
	ply->bIsSpotted = (m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_bSpotted)) ? 1 : 0;
	ply->bIsReloading = (m_Mem.Read<int>(addr + m_dynamicOffsets.canReload)) ? 1 : 0;
	ply->bIsDefusing = (m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_bIsDefusing)) ? 1 : 0;
	ply->bIsDormant = (m_Mem.Read<int>(addr + Dormant)) ? 1 : 0;
	[/swap_lines]

	[add_junk 1 6 /]

	DWORD baseCombatHandle = m_Mem.Read<DWORD>(addr + m_dynamicOffsets.netvar_hActiveWeapon);
	baseCombatHandle &= 0xFFF;
	DWORD weapBase = m_Mem.Read<DWORD>(m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);

	ply->iWeaponID = m_Mem.Read<int>(weapBase + m_dynamicOffsets.netvar_AttributeManager + m_dynamicOffsets.netvar_Item + m_dynamicOffsets.netvar_iItemDefinitionIndex);
	ply->iAmmo_Primary = m_Mem.Read<int>(weapBase + m_dynamicOffsets.netvar_iClip1);
	[add_junk 1 6 /]
	ply->iAmmo_Secondary = m_Mem.Read<int>(weapBase + m_dynamicOffsets.netvar_iClip2);

	[add_junk 1 6 /]
	ply->iSkinOwnerHigh = m_Mem.Read<int>(weapBase + SkinOwnerHigh);
	ply->iSkinOwnerLow = m_Mem.Read<int>(weapBase + SkinOwnerLow);
	ply->iSkinPaint = m_Mem.Read<int>(weapBase + SkinPaint);
	[add_junk 1 6 /]
	ply->iSkinSeed = m_Mem.Read<int>(weapBase + SkinSeed);
	ply->iStatTrak = m_Mem.Read<int>(weapBase + SkinStatTrak);
	ply->fSkinWear = m_Mem.Read<float>(weapBase + SkinWear);
	[add_junk 1 6 /]

	[swap_lines]
	ply->vOrigin = m_Mem.Read<CVector>(ply->baseAddr + m_dynamicOffsets.netvar_vecOrigin);
	ply->vPunchAngles = m_Mem.Read<CVector2D>(ply->baseAddr + m_dynamicOffsets.punchAngles);
	ply->vVecViewOffset = m_Mem.Read<CVector>(ply->baseAddr + m_dynamicOffsets.netvar_vecViewOffset);
	ply->vVelocity = m_Mem.Read<CVector>(ply->baseAddr + m_dynamicOffsets.netvar_vecVelocity);
	[/swap_lines]

	ply->vEyePos = ply->vOrigin + ply->vVecViewOffset;
	ply->vViewAngles = m_Mem.Read<CVector>(m_dwAnglePointer + m_dynamicOffsets.viewAngles);
	[add_junk 1 6 /]

	m_dwBoneMatrix = m_Mem.Read<int>(ply->baseAddr + m_dynamicOffsets.netvar_boneMatrix);

	if (m_dwBoneMatrix)
	{
		m_Mem.ReadCustom(m_dwBoneMatrix, ply->boneMatrix, sizeof(Matrix3x4[128]));
	}

	[add_junk 1 6 /]
}

void CSGO::UpdateEntities()
{
	if (!m_Mem.IsAttached())
		return;

	UpdateInfo(&m_Players[0], m_dwLocalBase);

	[add_junk 1 6 /]

	for (int i = 1; i < 64; i++)
	{
		DWORD entityBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));
		UpdateInfo(&m_Players[i], entityBase);
	}

	[add_junk 1 6 /]
}

void CSGO::DisplayControls()
{
	system("cls");

	[add_junk 1 6 /]

	miscUtils->PrintLine(std::string("                           __     _                                  "));
	miscUtils->PrintLine(std::string(" ___ _ __ ___  _   _ _ __ / _|___| |_ ___  _ __ ___  _ __   ___ _ __ "));
	[add_junk 1 6 /]
	miscUtils->PrintLine(std::string("/ __| '_ ` _ \\| | | | '__| |_/ __| __/ _ \\| '_ ` _ \\| '_ \\ / _ \\ '__|"));
	[add_junk 1 6 /]
	miscUtils->PrintLine(std::string("\\__ \\ | | | | | |_| | |  |  _\\__ \\ || (_) | | | | | | |_) |  __/ |   "));
	[add_junk 1 6 /]
	miscUtils->PrintLine(std::string("|___/_| |_| |_|\\__,_|_|  |_| |___/\\__\\___/|_| |_| |_| .__/ \\___|_|   "));
	miscUtils->PrintLine(std::string("                                                    |_|              "));
	[add_junk 1 6 /]
	miscUtils->PrintLine(m_szVersion.c_str());
	miscUtils->PrintLine(std::string("----------------------------------------------------------------------------------"));


	if (m_Hacks.tGlowOptions.bCanToggle || m_Hacks.tSubtleAimbotOptions.bCanToggle)
	{
		miscUtils->PrintLine(std::string("|\t\t\t\t  TOGGLES\t\t\t\t"));
		[add_junk 1 6 /]
		miscUtils->PrintLine(std::string("|----------------------------------------------------------------------------------"));
	}

	if (m_Hacks.tGlowOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tGlowOptions.iKey) + std::string("\t-\t");
		info += std::string("GlowESP:\t") + BoolToString(m_Hacks.tGlowOptions.bActivated);
		[add_junk 1 6 /]
		info += std::string("\t|\t") + m_Hacks.tGlowOptions.targetType.ToString();
		miscUtils->PrintLine(info);
	}

	if (m_Hacks.tSubtleAimbotOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tSubtleAimbotOptions.iKey) + std::string("\t-\t");
		info += std::string("Subtle Aimbot:\t") + BoolToString(m_Hacks.tSubtleAimbotOptions.bActivated);
		[add_junk 1 6 /]
		info += std::string("\t|\t") + m_Hacks.tSubtleAimbotOptions.targetType.ToString();
		miscUtils->PrintLine(info);
	}

	if (m_Hacks.tActualAimbotOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tActualAimbotOptions.iToggleKey) + std::string("\t-\t");
		[add_junk 1 6 /]
		info += miscUtils->GetStringFromKey(m_Hacks.tActualAimbotOptions.iAimKey) + std::string(" Aimlock:\t") + BoolToString(m_Hacks.tActualAimbotOptions.bActivated);
		info += std::string("\t|\t") + m_Hacks.tActualAimbotOptions.targetType.ToString();
		miscUtils->PrintLine(info);
	}

	if (m_Hacks.tBhopOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tBhopOptions.iKey) + std::string("\t-\t");
		info += std::string("Auto-Bhop:\t") + BoolToString(m_Hacks.tBhopOptions.bActivated);
		info += std::string("\t|\t");
		[add_junk 1 6 /]
		miscUtils->PrintLine(info);
	}

	if (m_Hacks.tChatSpamOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tChatSpamOptions.iKey) + std::string("\t-\t");
		info += std::string("Chatspam:\t") + BoolToString(m_Hacks.tChatSpamOptions.bActivated);
		info += std::string("\t|\t") + m_Hacks.tChatSpamOptions.eSpamMethod.ToString();
		[add_junk 1 6 /]
		miscUtils->PrintLine(info);
	}

	if (m_Hacks.tFakeLagOptions.bCanToggle)
	{
		std::string info = std::string("| ") + miscUtils->GetStringFromKey(m_Hacks.tFakeLagOptions.iKey) + std::string("\t-\t");
		info += std::string("FakeLag:\t") + BoolToString(m_Hacks.tFakeLagOptions.bActivated);
		[add_junk 1 6 /]
		info += std::string("\t|\t") + std::string("Lagging: ") + std::to_string(m_Hacks.tFakeLagOptions.iLagInterval) + std::string(" Packets");
		miscUtils->PrintLine(info);
	}


	miscUtils->PrintLine(std::string("|----------------------------------------------------------------------------------"));
	miscUtils->PrintLine(std::string("|\t\t\t\tMISCELLANEOUS\t\t\t\t"));
	[add_junk 1 6 /]
	miscUtils->PrintLine(std::string("|----------------------------------------------------------------------------------"));

	std::string info = std::string("| ") + std::string("pgup") + std::string("\t\t-\t");
	[add_junk 1 6 /]
	info += std::string("Print Rank Information\t|");
	miscUtils->PrintLine(info);

	info.clear();

	info = std::string("| ") + std::string("end") + std::string("\t\t-\t");
	[add_junk 1 6 /]
	info += std::string("Panic: Safely end cheat\t|");
	miscUtils->PrintLine(info);

	miscUtils->PrintLine(std::string("----------------------------------------------------------------------------------"));
}

void CSGO::ScanOffsets()

{
	DWORD clientBase = m_Mem.GetModuleBase("client.dll");
	DWORD engineBase = m_Mem.GetModuleBase("engine.dll");
	DWORD csgoBase = m_Mem.GetModuleBase("csgo.exe");

	DWORD clientModSize = m_Mem.GetModuleSize("client.dll");
	DWORD engineModSize = m_Mem.GetModuleSize("engine.dll");

	DWORD entityListBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 11, (BYTE*)"\x05\x00\x00\x00\x00\xC1\xE9\x00\x39\x48\x04");
	DWORD entityListPtr1 = m_Mem.Read<DWORD>(entityListBegin + 0x1);
	[add_junk 1 6 /]
	BYTE entityListPtr2 = m_Mem.Read<BYTE>(entityListBegin + 0x7);
	m_dynamicOffsets.entityList = (entityListPtr1 + entityListPtr2) - clientBase;
	std::cout << "> EntityList Found @ 0x" << std::hex << m_dynamicOffsets.entityList << std::endl;
	[add_junk 1 6 /]

	DWORD localPlayerBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 19, (BYTE*)"\x8D\x34\x85\x00\x00\x00\x00\x89\x15\x00\x00\x00\x00\x8B\x41\x08\x8B\x48\x00");
	DWORD localPlayerPtr1 = m_Mem.Read<DWORD>(localPlayerBegin + 0x3);
	BYTE localPlayerPtr2 = m_Mem.Read<BYTE>(localPlayerBegin + 0x12);
	[add_junk 1 6 /]
	m_dynamicOffsets.localPlayer = (localPlayerPtr1 + localPlayerPtr2) - clientBase;
	std::cout << "> LocalPlayer Found @ 0x" << std::hex << m_dynamicOffsets.localPlayer << std::endl;


	DWORD enginePtrBegin = m_Mem.FindPatternArr(engineBase, engineModSize, 37, (BYTE*)"\xF3\x0F\x5C\xC1\xF3\x0F\x10\x15\x00\x00\x00\x00\x0F\x2F\xD0\x76\x04\xF3\x0F\x58\xC1\xA1\x00\x00\x00\x00\xF3\x0F\x11\x80\x00\x00\x00\x00\xD9\x46\x04");
	m_dynamicOffsets.enginePtr = m_Mem.Read<DWORD>(enginePtrBegin + 0x16) - engineBase;
	[add_junk 1 6 /]
	m_dynamicOffsets.viewAngles = m_Mem.Read<DWORD>(enginePtrBegin + 0x1E);

	std::cout << "> EnginePtr Found @ 0x" << std::hex << m_dynamicOffsets.enginePtr << std::endl;
	std::cout << "> Viewangles Found @ 0x" << std::hex << m_dynamicOffsets.viewAngles << std::endl;

	DWORD glowBaseBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 12, (BYTE*)"\xA1\x00\x00\x00\x00\xA8\x01\x75\x4E\x0F\x57\xC0");
	DWORD dwGlowAddy = m_Mem.Read<DWORD>(glowBaseBegin + 0x1A);
	[add_junk 1 6 /]
	if (dwGlowAddy)
	{
		m_dynamicOffsets.glowObjectBase = dwGlowAddy - clientBase;
		[add_junk 1 6 /]
		std::cout << "> GlowObjectBase Found @ 0x" << std::hex << m_dynamicOffsets.glowObjectBase << std::endl;
	}


	if (!m_dynamicOffsets.localPlayer)
	{
		miscUtils->PrintLine(std::string("LocalPlayer is NULL, skipping xhair index."));
	}
	else
	{
		DWORD xhairBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 20, (BYTE*)"\x56\x57\x8B\xF9\xC7\x87\x00\x00\x00\x00\x00\x00\x00\x00\x8B\x0D\x00\x00\x00\x00");
		m_dynamicOffsets.crosshairIndex = m_Mem.Read<DWORD>(xhairBegin + 0x6);

		std::cout << "> CrosshairIndex Found @ 0x" << std::hex << m_dynamicOffsets.crosshairIndex << std::endl;
	}

	m_dynamicOffsets.viewMatrix = pCSGO->m_Mem.FindPatternArr(clientBase, clientModSize, 8, (BYTE*)"\xE8\x00\x00\x00\x00\x8D\x95\xE0") - 0x1A;
	m_dynamicOffsets.viewMatrix = (pCSGO->m_Mem.Read<DWORD>(m_dynamicOffsets.viewMatrix) + 0x90) - clientBase;

	std::cout << "> ViewMatrix Found @ 0x" << std::hex << m_dynamicOffsets.viewMatrix << std::endl;

	DWORD scoreBoardBegin = m_Mem.FindPatternArr(engineBase, engineModSize, 14, (BYTE*)"\x89\x4D\xF4\x8B\x0D\x00\x00\x00\x00\x53\x56\x57\x8B\x01");
	DWORD pointer = m_Mem.Read<DWORD>(scoreBoardBegin + 0x5);
	[add_junk 1 6 /]
	pointer -= engineBase;

	DWORD leScoreBoard = m_Mem.FindPatternArr(clientBase, clientModSize, 18, (BYTE*)"\xCC\xCC\x55\x8B\xEC\x8B\x45\x08\x8B\x44\xC1\x00\x5D\xC2\x04\x00\xCC\xCC");
	BYTE scoreBoardOffset = m_Mem.Read<BYTE>(leScoreBoard + 0xB);
	leScoreBoard = m_Mem.Read<DWORD>(engineBase + pointer);
	[add_junk 1 6 /]
	leScoreBoard += (0x46 * 8 + scoreBoardOffset);

	m_dynamicOffsets.scoreBoard = leScoreBoard - clientBase;
	std::cout << "> ScoreBoard Found @ 0x" << std::hex << m_dynamicOffsets.scoreBoard << std::endl;

	DWORD gameResourceBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 20, (BYTE*)"\x8B\x3D\x00\x00\x00\x00\x85\xFF\x0F\x84\x00\x00\x00\x00\x81\xC7\x00\x00\x00\x00");
	DWORD yush = m_Mem.Read<DWORD>(gameResourceBegin + 2);
	[add_junk 1 6 /]
	m_dynamicOffsets.gameResources = yush -= clientBase;
	std::cout << "> GameResources Found @ 0x" << std::hex << m_dynamicOffsets.gameResources << std::endl;

	DWORD punchAngleBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 14, (BYTE*)"\x66\x0F\xD6\x45\xDC\x89\x45\xE4\x81\xF9\x00\x00\x00\x00");
	m_dynamicOffsets.punchAngles = m_Mem.Read<DWORD>(punchAngleBegin - 0x20);
	[add_junk 1 6 /]
	std::cout << "> PunchAngles Found @ 0x" << std::hex << m_dynamicOffsets.punchAngles << std::endl;

	DWORD reloadBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 14, (BYTE*)"\x80\xB9\x00\x00\x00\x00\x00\x0F\x85\x00\x00\x00\x00\xA1");
	m_dynamicOffsets.canReload = m_Mem.Read<DWORD>(reloadBegin + 2);
	std::cout << "> CanReload Found @ 0x" << std::hex << m_dynamicOffsets.canReload << std::endl;

	[add_junk 1 6 /]

	DWORD dwWorld = m_Mem.FindPattern(clientBase, 0xFFFFFF, (BYTE*)"DT_TEWorldDecal", "ccccccccccccccc");
	[add_junk 1 6 /]
	m_dynamicOffsets.netvarClassesBase = m_Mem.Read<DWORD>(m_Mem.FindPattern(clientBase, 0xFFFFFF, (BYTE*)&dwWorld, "cccc") + 0x2B);
	std::cout << "> NetVar Classes Found @ 0x" << std::hex << m_dynamicOffsets.netvarClassesBase << std::endl;

	DWORD jumpBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 22, (BYTE*)"\x89\x15\x00\x00\x00\x00\x8B\x15\x00\x00\x00\x00\xF6\xC2\x03\x74\x03\x83\xCE\x08\xA8\x08");
	m_dynamicOffsets.jumpOffset = m_Mem.Read<DWORD>(jumpBegin + 2) - clientBase;
	m_dynamicOffsets.forwardOffset = m_Mem.Read<DWORD>(jumpBegin + 8) - clientBase;
	std::cout << "> Jump Found @ 0x" << std::hex << m_dynamicOffsets.jumpOffset << std::endl;
	std::cout << "> Forward Found @ 0x" << std::hex << m_dynamicOffsets.forwardOffset << std::endl;

	m_dynamicOffsets.mouseEnableOffset = 0x343F3C;
	std::cout << "> MouseEnabled Found @ 0x" << std::hex << m_dynamicOffsets.mouseEnableOffset << std::endl;

	DWORD globalVarBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 0x11, (BYTE*)"\xFF\xB0\x00\x00\x00\x00\xA1\x00\x00\x00\x00\xF3\x0F\x00\x00\x00\x00");
	m_dynamicOffsets.globalVarsOffset = m_Mem.Read<DWORD>(globalVarBegin + 7) - clientBase;
	std::cout << "> GlobalVars Found @ 0x" << std::hex << m_dynamicOffsets.globalVarsOffset << std::endl;

	m_dynamicOffsets.clientCMDOffset = m_Mem.FindPatternArr(engineBase, engineModSize, 16, (BYTE*)"\x55\x8B\xEC\xA1\x00\x00\x00\x00\x81\xEC\x00\x00\x00\x00\x80\xB8");
	std::cout << "> ClientCMD Found @ 0x" << std::hex << m_dynamicOffsets.clientCMDOffset << std::endl;

	m_dynamicOffsets.mapNameOffset = m_Mem.FindPatternArr(engineBase, engineModSize, 14, (BYTE*)"\x05\x00\x00\x00\x00\xC3\xCC\xCC\xCC\xCC\xCC\xCC\xCC\xA1") + 1;
	m_dynamicOffsets.mapNameOffset = m_Mem.Read<DWORD>(m_dynamicOffsets.mapNameOffset);
	std::cout << "> MapName Found @ 0x" << std::hex << m_dynamicOffsets.mapNameOffset << std::endl;

	[add_junk 1 6 /]

	DWORD inputBegin = m_Mem.FindPatternArr(clientBase, clientModSize, 15, (BYTE*)"\xB9\x00\x00\x00\x00\xFF\x75\x08\xE8\x00\x00\x00\x00\x8B\x06") + 1;
	m_dynamicOffsets.cinputOffset = m_Mem.Read<DWORD>(inputBegin);
	m_dynamicOffsets.userCMDOffset = m_Mem.Read<DWORD>(m_dynamicOffsets.cinputOffset + 0xEC);
	[add_junk 1 6 /]
	m_dynamicOffsets.verifiedCMDOffset = m_Mem.Read<DWORD>(m_dynamicOffsets.cinputOffset + 0xF0);
	std::cout << "> CInput Found @ 0x" << std::hex << m_dynamicOffsets.cinputOffset << std::endl;
	[add_junk 1 6 /]
	std::cout << "> UserCmd Found @ 0x" << std::hex << m_dynamicOffsets.userCMDOffset << std::endl;
	std::cout << "> VerifiedCMD Found @ 0x" << std::hex << m_dynamicOffsets.verifiedCMDOffset << std::endl;

	m_dynamicOffsets.bSendPacketOffset = m_Mem.FindPatternArr(engineBase, engineModSize, 5, (BYTE*)"\xB3\x01\x8B\x01\x8B") + 1;
	std::cout << "> bSendPacket Found @ 0x" << std::hex << m_dynamicOffsets.bSendPacketOffset << std::endl;

	[add_junk 1 6 /]

	m_dynamicOffsets.playerInfoOffset = m_Mem.FindPatternArr(engineBase, engineModSize, 15, (BYTE*)"\x8B\x88\x00\x00\x00\x00\x8B\x01\x8B\x40\x00\xFF\xD0\x8B\xF8") + 2;
	m_dynamicOffsets.playerInfoOffset = m_Mem.Read<DWORD>(m_dynamicOffsets.playerInfoOffset);
	[add_junk 1 6 /]
	std::cout << "> PlayerInfo Found @ 0x" << std::hex << m_dynamicOffsets.playerInfoOffset << std::endl;
}

void CSGO::UpdateNetvars()
{
	[swap_lines]
	m_dynamicOffsets.netvar_hOwner = GetNetVar("DT_BaseEntity", "m_hOwnerEntity");
	m_dynamicOffsets.netvar_iTeamNum = GetNetVar("DT_BaseEntity", "m_iTeamNum");
	m_dynamicOffsets.netvar_ArmorValue = GetNetVar("DT_CSPlayer", "m_ArmorValue");
	m_dynamicOffsets.netvar_vecOrigin = GetNetVar("DT_CSPlayer", "m_vecOrigin");
	m_dynamicOffsets.netvar_vecVelocity = GetNetVar("DT_CSPlayer", "m_vecVelocity[0]");
	m_dynamicOffsets.netvar_vecViewOffset = GetNetVar("DT_CSPlayer", "m_vecViewOffset[0]");
	m_dynamicOffsets.netvar_iShotsFired = GetNetVar("DT_CSPlayer", "m_iShotsFired");
	m_dynamicOffsets.netvar_bHasDefuser = GetNetVar("DT_CSPlayer", "m_bHasDefuser");
	m_dynamicOffsets.netvar_bIsDefusing = GetNetVar("DT_CSPlayer", "m_bIsDefusing");
	m_dynamicOffsets.netvar_bHasHelmet = GetNetVar("DT_CSPlayer", "m_bHasHelmet");
	m_dynamicOffsets.netvar_flFlashDuration = GetNetVar("DT_CSPlayer", "m_flFlashDuration");
	m_dynamicOffsets.netvar_flFlashMaxAlpha = GetNetVar("DT_CSPlayer", "m_flFlashMaxAlpha");
	m_dynamicOffsets.netvar_iLifeState = GetNetVar("DT_CSPlayer", "m_lifestate");
	m_dynamicOffsets.netvar_fFlags = GetNetVar("DT_CSPlayer", "m_fFlags");
	m_dynamicOffsets.netvar_iObserverMode = GetNetVar("DT_CSPlayer", "m_iObserverMode");
	m_dynamicOffsets.netvar_iObserverTarget = GetNetVar("DT_CSPlayer", "m_hObserverTarget");
	m_dynamicOffsets.netvar_iClass = GetNetVar("DT_CSPlayer", "m_iClass");
	m_dynamicOffsets.netvar_iHealth = GetNetVar("DT_CSPlayer", "m_iHealth");
	m_dynamicOffsets.netvar_iFOVStart = GetNetVar("DT_CSPlayer", "m_iFOVStart");
	m_dynamicOffsets.netvar_hActiveWeapon = GetNetVar("DT_CSPlayer", "m_hActiveWeapon");
	m_dynamicOffsets.netvar_immuneTime = GetNetVar("DT_CSPlayer", "m_fImmuneToGunGameDamageTime");
	m_dynamicOffsets.netvar_spottedByMask = GetNetVar("DT_BaseEntity", "m_bSpottedByMask");
	m_dynamicOffsets.netvar_compRank = GetNetVar("DT_CSPlayerResource", "m_iCompetitiveRanking");
	m_dynamicOffsets.netvar_compWins = GetNetVar("DT_CSPlayerResource", "m_iCompetitiveWins");
	m_dynamicOffsets.netvar_AttributeManager = GetNetVar("DT_BaseAttributableItem", "m_AttributeManager");
	m_dynamicOffsets.netvar_Item = GetNetVar("DT_BaseAttributableItem", "m_Item");
	m_dynamicOffsets.netvar_iItemDefinitionIndex = GetNetVar("DT_BaseAttributableItem", "m_iItemDefinitionIndex");
	m_dynamicOffsets.netvar_bSpotted = GetNetVar("DT_BaseAttributableItem", "m_bSpotted");
	m_dynamicOffsets.netvar_iClip1 = GetNetVar("DT_BaseCombatWeapon", "m_iClip1");
	m_dynamicOffsets.netvar_iClip2 = GetNetVar("DT_BaseCombatWeapon", "m_iClip2");
	m_dynamicOffsets.netvar_fAccuracyPenalty = GetNetVar("DT_WeaponAK47", "m_fAccuracyPenalty");
	m_dynamicOffsets.netvar_boneMatrix = GetNetVar("DT_BaseAnimating", "m_nForceBone") + 0x1C;
	m_dynamicOffsets.netvar_bBombTicking = GetNetVar("DT_PlantedC4", "m_bBombTicking");
	m_dynamicOffsets.netvar_flC4Blow = GetNetVar("DT_PlantedC4", "m_flC4Blow");
	m_dynamicOffsets.netvar_nTickBase = GetNetVar("DT_BasePlayer", "m_nTickBase");
	m_dynamicOffsets.netvar_szLastPlaceName = GetNetVar("DT_BasePlayer", "m_szLastPlaceName");
	m_dynamicOffsets.netvar_iMatchStats_MoneySaved = GetNetVar("DT_CSPlayer", "m_iMatchStats_MoneySaved");
	m_dynamicOffsets.netvar_flNextPrimaryAttack = GetNetVar("DT_BaseCombatWeapon", "m_flNextPrimaryAttack");
	[/swap_lines]

	[add_junk 1 6 /]
}

[junk_disable /]
[enc_string_disable /]