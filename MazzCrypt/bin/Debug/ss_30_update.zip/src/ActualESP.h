#ifndef _ACTUALESP_H_
#define _ACTUALESP_H_

#include "CSGO.h"
#include "Vector.h"
#include "Renderer.h"
#include <unordered_map>

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

class ActualESP
{
public:

	ActualESP() = default;
	~ActualESP() = default;
	ActualESP(CSGO* c) { csgo = c; }

	std::unordered_map<int, std::string> realweapons =
	{
		{ 0, "none" }, { 1, "deagle" }, { 2, "dual berettas" },
		{ 4, "glock"} , { 7, "ak47" }, { 8, "aug" },
		{ 9, "awp" }, { 10, "famas" }, { 11, "t auto" },
		{13, "galil"}, { 14, "m249"}, {16, "m4a4"},
		{17, "mac10"}, {19, "p90"}, {24, "ump45"},
		{25, "xm1014"}, {26, "bizon"}, {27, "mag7"},
		{28, "negev"}, {29, "sawed off"}, {30, "tec9"},
		{31, "zeus"}, {32, "p2000"}, {33, "mp7"},
		{34, "mp9"}, {35, "nova"}, {36, "p250"},
		{38, "ct auto"}, {39, "ssg553"}, {40, "scout"},
		{42, "knife"}, {43, "flashbang"}, {44, "frag"},
		{45, "smoke"}, {46, "molly"}, {47, "decoy"},
		{48, "incendiary"}, {49, "c4"}, {59, "default knife"},
		{60, "m4a1-s"}, {61, "usp"}, {63, "cz-75"},
		{64, "r8"}, {500, "bayonet"}, {505, "flip"},
		{506, "gut"}, {507, "karambit"}, {508, "m9 bayonet"},
		{509, "huntsman"}, {512, "falchion"}, {514, "bowie"},
		{515, "butterfly"}, {516, "shadow daggers"}
	};

	std::unordered_map<int, std::string> sillyweapons =
	{
		{ 0, "none" },{ 1, "juan" },{ 2, "duelies" },
		{ 4, "GLOCKS" } ,{ 7, "first bullet accuracy" },{ 8, "codgun" },
		{ 9, "pointclickandwin" },{ 10, "french rifle" },{ 11, "t salt" },
		{ 13, "haha who uses this" },{ 14, "saw the movie" },{ 16, "the better m4" },
		{ 17, "jump n shoot man" },{ 19, "pro90" },{ 24, "baby rifle" },
		{ 25, "hiko special" },{ 26, "infinite ammo" },{ 27, "magic7" },
		{ 28, "lawnmower" },{ 29, "jw special" },{ 30, "rekt9" },
		{ 31, "zeus" },{ 32, "p2000" },{ 33, "mp7" },
		{ 34, "air lawnmower" },{ 35, "csgolucky" },{ 36, "p250" },
		{ 38, "ct salt" },{ 39, "the other codgun" },{ 40, "whats jumping accuracy" },
		{ 42, "knife" },{ 43, "helen keller" },{ 44, "fag" },
		{ 45, "smoke weed erday" },{ 46, "molly" },{ 47, "the nade that never works" },
		{ 48, "incendiary" },{ 49, "train go boom" },{ 59, "default knife" },
		{ 60, "the shitty m4" },{ 61, "kqly" },{ 63, "nbk" },
		{ 64, "nice b8 m8 i r8 8/8" },{ 500, "wwii reenactment item" },{ 505, "the most expensive knife irl" },
		{ 506, "poorman knife" },{ 507, "i hide how bad I am behind skins" },{ 508, "compensator" },
		{ 509, "gut knife mk2" },{ 512, "falcon punch" },{ 514, "rip david bowie" },
		{ 515, "the spy" },{ 516, "buttplugs" }
	};

	CVector2D WorldToScreen(CVector point)
	{
		CVector returnVector(0, 0, 0);

		[add_junk 2 5 /]

		float w = csgo->m_ViewMatrix[12] * point.x + csgo->m_ViewMatrix[13] * point.y + csgo->m_ViewMatrix[14] * point.z + csgo->m_ViewMatrix[15];
		if (w >= 0.01f)
		{
			float inverseWidth = 1.0f / w;

			returnVector.x = (csgo->m_iWindowWidth / 2.0f) + (0.5f * ((csgo->m_ViewMatrix[0] * point.x + csgo->m_ViewMatrix[1] * point.y + csgo->m_ViewMatrix[2] * point.z + csgo->m_ViewMatrix[3]) * inverseWidth) * csgo->m_iWindowWidth + 0.5f);
			[add_junk 2 5 /]
			returnVector.y = (csgo->m_iWindowHeight / 2.0f) - (0.5f * ((csgo->m_ViewMatrix[4] * point.x + csgo->m_ViewMatrix[5] * point.y + csgo->m_ViewMatrix[6] * point.z + csgo->m_ViewMatrix[7]) * inverseWidth)	* csgo->m_iWindowHeight + 0.5f);
		}

		[add_junk 2 5 /]

		return returnVector; 
	}

	void Render()
	{
		if (!csgo->m_Hacks.CheckBit(BIT_ESP))
			return;

		[add_junk 2 5 /]

		for (int i = 1; i < 64; i++)
		{
			Player ply = csgo->m_Players[i];

			bool bEnemy = (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam));

			if ((csgo->m_Hacks.tESPOptions.targetType.type == Target_Enemies) && !bEnemy)
			{
				[add_junk 2 5 /]
				continue;
			}
			else if ((csgo->m_Hacks.tESPOptions.targetType.type == Target_Teammates) && bEnemy)
			{
				[add_junk 2 5 /]
				continue;
			}

			CVector targetColor = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB * 255.0f) : (csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB * 255.0f);
			[add_junk 2 5 /]
			CVector visibleColor = (bEnemy) ? (csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB * 255.0f) : (csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB * 255.0f);

			float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length()) * 0.01905f;

			if (ply.bAlive && !ply.bIsDormant && dist <= csgo->m_Hacks.tESPOptions.fMaxDist)
			{
				CVector head;
				if (ply.iFlags & FL_DUCKING)
					head = ply.vOrigin + CVector(0, 0, 52);
				else
					head = ply.vOrigin + CVector(0, 0, 72);

				[add_junk 2 5 /]

				[swap_lines]
				CVector2D headScreen = WorldToScreen(head);
				CVector2D footScreen = WorldToScreen(ply.vOrigin);
				[/swap_lines]

				[add_junk 2 5 /]

				if (headScreen == CVector2D(0, 0) || footScreen == CVector2D(0, 0))
					continue;


				float boxHeight = footScreen.y - headScreen.y;
				[add_junk 2 5 /]
				float boxWidth = (boxHeight / 4.0f);

				if (csgo->m_Hacks.tESPOptions.bShowNames)
				{
					[add_junk 2 5 /]
					pRenderer->DrawText(pD3DMenu->m_hFontDescription, headScreen.x, headScreen.y - 20, FONT_RENDER_CENTER_H, Color_White, ply.tPlayerInfo.name);
				}

				if (csgo->m_Hacks.tESPOptions.bSnapLines)
				{
					CVector2D myPos = WorldToScreen(csgo->m_Me.vOrigin);
					[add_junk 2 5 /]
					CVector2D theirPos = WorldToScreen(ply.vOrigin);

					int x, y;
					pOverlay->GetCenterOfScreen(x, y);
					[add_junk 2 5 /]
					CVector2D crosshair(x, y);

					if (theirPos != CVector2D(0, 0) && crosshair != CVector2D(0, 0))
					{
						bool isVisible = (csgo->m_Hacks.tESPOptions.bVisibleCheck && !csgo->IsSpottedBy(ply, csgo->m_Me));
						pRenderer->DrawLine(crosshair.x, crosshair.y, theirPos.x, theirPos.y, (isVisible) ? targetColor : visibleColor);
					}
				}

				if (csgo->m_Hacks.tESPOptions.bShowBox)
				{
					switch (csgo->m_Hacks.tESPOptions.boxType.type)
					{
						case BoxType_BoundingBox:
						{
							[add_junk 2 5 /]
							bool isVisible = (csgo->m_Hacks.tESPOptions.bVisibleCheck && !csgo->IsSpottedBy(ply, csgo->m_Me));
							pRenderer->DrawBorderBox(headScreen.x - boxWidth, headScreen.y, boxWidth * 2, boxHeight, 2, (isVisible) ? targetColor : visibleColor);

							break;
						}
						case BoxType_CornerBox:
						{
							int space = boxWidth / 2;
							CVector2D top(headScreen.x, headScreen.y - 20);
							[add_junk 2 5 /]
							CVector2D bottom(footScreen.x, footScreen.y + 10);
							int thickness = 3;

							bool isVisible = (csgo->m_Hacks.tESPOptions.bVisibleCheck && !csgo->IsSpottedBy(ply, csgo->m_Me));
							[add_junk 2 5 /]
							CVector color = (isVisible) ? targetColor : visibleColor;

							pRenderer->DrawRect(top.x - (space * 2), top.y + space, space, thickness, color);
							pRenderer->DrawRect(top.x - (space * 2), top.y + space, thickness , space, color);
							[add_junk 2 5 /]
							pRenderer->DrawRect(top.x + space, top.y + space, space, thickness, color);
							pRenderer->DrawRect(top.x + (space * 2), top.y + space, thickness, space, color);
							[add_junk 2 5 /]
							pRenderer->DrawRect(bottom.x - (space * 2), bottom.y + space, space, thickness, color);
							pRenderer->DrawRect(bottom.x - (space * 2), bottom.y, thickness, space, color);
							pRenderer->DrawRect(bottom.x + space, bottom.y + space, space, thickness, color);
							[add_junk 2 5 /]
							pRenderer->DrawRect(bottom.x + (space * 2), bottom.y, thickness, space, color);

							break;
						}
					}
				}

				if (csgo->m_Hacks.tESPOptions.bShowHealthBar)
				{
					int hp = ply.iHealth;

					int red = /*255 - (hp * 2.55);*/ (hp > 50.0f ? 1.0f - 2.0f * (hp - 50.0f) / 100.0f : 1.0f) * 255.0f;
					int green = /*hp * 2.55;*/ (hp > 50.0f ? 1.0f : 2.0f * hp / 100.0f) * 255.0f;
					hp = (boxHeight - ((boxHeight * hp) / 100));

					CVector healthColor(red, green, 0);

					switch (csgo->m_Hacks.tESPOptions.hBarType.type)
					{
						case HealthBarType_Vertical_Left:
						{
							[add_junk 2 5 /]
							pRenderer->DrawShadowText(DescFont, (headScreen.x - boxWidth) - 20, headScreen.y, 2, FONT_RENDER_CENTER_H, healthColor, "%d", ply.iHealth);
							pRenderer->DrawRect((headScreen.x - boxWidth) - 5, headScreen.y + hp, 5, boxHeight - hp, healthColor);
							[add_junk 2 5 /]
							pRenderer->DrawBorderBox((headScreen.x - boxWidth) - 6, headScreen.y - 1, 3, boxHeight + 2, 1, Color_Black);
							break;
						}
						case HealthBarType_Vertical_Right:
						{
							pRenderer->DrawShadowText(DescFont, (headScreen.x + boxWidth) + 20, headScreen.y, 2, FONT_RENDER_CENTER_H, healthColor, "%d", ply.iHealth);
							pRenderer->DrawRect((headScreen.x + boxWidth) + 5, headScreen.y + hp, 5, boxHeight - hp, healthColor);
							[add_junk 2 5 /]
							pRenderer->DrawBorderBox((headScreen.x + boxWidth) + 6, headScreen.y - 1, 3, boxHeight + 2, 1, Color_Black);

							break;
						}
					}
				}

				if (csgo->m_Hacks.tESPOptions.bShowDistance)
				{
					[add_junk 2 5 /]
					pRenderer->DrawText(pD3DMenu->m_hFontDescription, footScreen.x, footScreen.y + 20, FONT_RENDER_CENTER_H, Color_White, "%2.1fm", dist);
				}

				if (csgo->m_Hacks.tESPOptions.bShowWeapon)
				{
					if (csgo->m_Hacks.tESPOptions.bShowSillyWeapons)
					{
						pRenderer->DrawText(pD3DMenu->m_hFontDescription, footScreen.x, footScreen.y, FONT_RENDER_CENTER_H, Color_White, sillyweapons[ply.iWeaponID].c_str());
						[add_junk 2 5 /]
					}
					else
					{
						[add_junk 2 5 /]
						pRenderer->DrawText(pD3DMenu->m_hFontDescription, footScreen.x, footScreen.y, FONT_RENDER_CENTER_H, Color_White, realweapons[ply.iWeaponID].c_str());
					}
				}

				if (csgo->m_Hacks.tESPOptions.bShowMMInfo)
				{
					[add_junk 2 5 /]
					pRenderer->DrawText(pD3DMenu->m_hFontDescription, headScreen.x, headScreen.y - 30 , FONT_RENDER_CENTER_H, Color_White, "%s | %d Wins", Ranks[ply.iRank].c_str(), ply.iWins);
				}
			}
		}

		[add_junk 2 5 /]
	}

private:

	CSGO* csgo;

	[add_junk_datamembers 1 5 /]

};

extern ActualESP* pActualESP;
#endif 

[junk_disable /]
[enc_string_disable /]