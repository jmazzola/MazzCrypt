#ifndef _STDAFX_H_
#define _STDAFX_H

// Defines
#define WIN32_LEAN_AND_MEAN

// Includes
#include <Windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdio.h>
#include <iostream>
#include <DbgHelp.h>
#include <atlbase.h>
#include <dwmapi.h>
#include <fstream>

// Comment libs
#pragma comment(lib, "dbghelp.lib")
#pragma comment(lib, "dwmapi.lib")



#endif // _STDAFX_H_