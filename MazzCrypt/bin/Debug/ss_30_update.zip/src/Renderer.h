#ifndef _RENDERER_H_
#define _RENDERER_H_

#include "D3D.h"
#include "Font.h"
#include "Vector.h"
#include <string>
#include <vector>

#undef CreateFont

[junk_enable /]

struct Vertex_t
{
	XMFLOAT4 xyzrhw;
	D3DCOLOR color;

	enum
	{
		FVF = D3DFVF_XYZRHW | D3DFVF_DIFFUSE
	};
};

enum AlignFlags
{
	FONT_RENDER_LEFT = 0,
	FONT_RENDER_RIGHT = 1,
	FONT_RENDER_CENTER_V = 2,
	FONT_RENDER_CENTER_H = 4
};

class Renderer
{
public:

	[swap_lines]
	Renderer();
	~Renderer();
	void PreFrame();
	void PostFrame();
	void OnReset();
	unsigned long CreateFont(const std::string& szFontName, int nFontSize, DWORD dwFlags);
	void DrawRect(int x, int y, int w, int h, CVector color);
	void DrawRectOutlined(int x, int y, int w, int h, CVector fill, CVector outline);
	void DrawBorderBox(int x, int y, int w, int h, int t, CVector color);
	void DrawLine(int x0, int y0, int x1, int y1, CVector color);
	void DrawCircle(float x, float y, float r, float s, CVector color);
	void DrawText(unsigned long hFont, int x, int y, DWORD dwAlign, CVector color, const char* szText, ...);
	void DrawShadowText(unsigned long font, int x, int y, int shadowLength, DWORD align, CVector color, const char* szText, ...);
	[/swap_lines]

	void OnSetup(IDirect3DDevice9* pDevice)
	{
		m_pDevice = pDevice;
	}

	std::vector<Font*> m_pFonts;
private:

	IDirect3DDevice9* m_pDevice;

	[add_junk_datamembers 1 9 /]
};

extern Renderer* pRenderer;

inline void BuildVertex(XMFLOAT4 xyzrhw, D3DCOLOR color, Vertex_t* vertexList, int index)
{
	[add_junk 1 4 /]
	
	vertexList[index].xyzrhw = xyzrhw;
	vertexList[index].color = color;
}

#endif

[junk_disable /]