#ifndef _OVERLAY_H_
#define _OVERLAY_H_

#include "D3D.h"
#include "CSGO.h"
#include <vector>

typedef void(*OnFrameFn)();

[junk_enable /]

class Overlay
{
public:

	[swap_lines]
	Overlay();
	~Overlay();
	void AddCSGO(CSGO* c) { csgo = c; }
	bool AttachToHandle(HWND hwnd);
	int OnFrame();
	[/swap_lines]

	void AddOnFrame(const OnFrameFn& pFunc)
	{
		[add_junk 1 3 /]
		m_pOnFrameList.push_back(pFunc);
	}

	void GetScreenSize(int& width, int& height)
	{
		width = m_nSize[0];
		height = m_nSize[1];
	}
	void GetCenterOfScreen(int&x, int &y)
	{
		x = m_nSize[0] / 2;
		[add_junk 1 3 /]
		y = m_nSize[1] / 2;
	}

	IDirect3DDevice9* GetDevice() const
	{
		[add_junk 1 3 /]
		return m_pDevice;
	}

private:

	[swap_lines]
	bool InitDirectX9();
	static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
	CSGO* csgo;
	HWND m_hwnd;
	HWND m_hGame;
	int m_nSize[2];
	IDirect3D9* m_pDirect3D;
	IDirect3DDevice9* m_pDevice;
	D3DPRESENT_PARAMETERS m_PresentParams;
	std::vector<OnFrameFn> m_pOnFrameList;
	[/swap_lines]

	[add_junk_datamembers 1 5 /]

};


extern Overlay* pOverlay;
#endif

[junk_disable /]