// Config.h - Our config settings
#pragma once

#include "stdafx.h"

[junk_enable /]

struct TriggerWeaponSettings
{
	[swap_lines]
	std::vector<int> m_hitboxes;
	int m_nDelayBefore;
	int m_nDelayAfter;
	float m_fRCSScale;
	[/swap_lines]

	[add_junk_datamembers 1 4 /]
};

struct TriggerSettings
{

public:

	[swap_lines]
	bool m_bActive;
	bool m_bSniperMode;
	bool m_bMoveCheck;
	bool m_bWalkCheck;
	bool m_bSprayUntilDeadMode;
	bool m_bNewRaytraceMethod;
	bool m_bRevolverMode;
	bool m_bKnifebot;
	bool m_bAfterburst;
	bool m_bDeathmatch;
	bool m_bAntiSpectate;
	bool m_bAntiJump;
	bool m_bAntiFriendlyDamage;
	bool m_bInvertMouse;
	bool m_bAntiFlash;
	bool m_bRecoilControl;
	float m_fMinFlash;
	int m_nKey;
	int m_nToggleKey;
	int m_nOverrideKey;
	bool m_bKeyHeld;
	int m_nMethod;
	int m_nTargetType;
	int m_nDelayBefore;
	int m_nDelayAfter;
	float m_fFOV;
	float m_fMinSpeed;
	TriggerWeaponSettings m_tGlock;
	TriggerWeaponSettings m_tP2K;
	TriggerWeaponSettings m_tUSP;
	TriggerWeaponSettings m_tP250;
	TriggerWeaponSettings m_tFiveSeven;
	TriggerWeaponSettings m_tDeagle;
	TriggerWeaponSettings m_tDuelies;
	TriggerWeaponSettings m_tTec9;
	TriggerWeaponSettings m_tCZ75;
	TriggerWeaponSettings m_tRevolver;
	TriggerWeaponSettings m_tNova;
	TriggerWeaponSettings m_tXM1014;
	TriggerWeaponSettings m_tSawedOff;
	TriggerWeaponSettings m_tMag7;
	TriggerWeaponSettings m_tMAC10;
	TriggerWeaponSettings m_tMP7;
	TriggerWeaponSettings m_tMP9;
	TriggerWeaponSettings m_tUMP45;
	TriggerWeaponSettings m_tBizon;
	TriggerWeaponSettings m_tP90;
	TriggerWeaponSettings m_tGalil;
	TriggerWeaponSettings m_tAK47;
	TriggerWeaponSettings m_tM4A4;
	TriggerWeaponSettings m_tM4A1S;
	TriggerWeaponSettings m_tSG553;
	TriggerWeaponSettings m_tAUG;
	TriggerWeaponSettings m_tFAMAS;
	TriggerWeaponSettings m_tAWP;
	TriggerWeaponSettings m_tSCAR20;
	TriggerWeaponSettings m_tScout;
	TriggerWeaponSettings m_tG3SG1;
	TriggerWeaponSettings m_tM249;
	TriggerWeaponSettings m_tNegev;
	[/swap_lines]

	[add_junk_datamembers 1 4 /]

};

struct ThreadHandling
{
public:

	[swap_lines]
	bool m_bStopUpdate;
	bool m_bStopTriggerbot;
	bool m_bStopBSPHandler;
	bool m_bStopRCS;
	[/swap_lines]

	[add_junk_datamembers 1 4 /]
};

class Config
{
public:

	Config() = default;
	~Config() = default;

	[swap_lines]
	void Init(std::string szConfigName);
	std::string GetHash();
	bool LoadConfig();
	bool SaveConfig();
	int GetInt(char* section, char* option);
	float GetFloat(char* section, char* option);
	std::string GetString(char* section, char* option);
	bool GetBool(char* section, char* option);
	std::vector<int> GetCommaSeperatedInts(char* section, char* option);
	int GetKey(char* section, char* option);
	void SetInt(char* section, char* option, int nValue);
	void SetFloat(char* section, char* option, float fValue);
	void SetString(char* section, char* option, std::string szValue);
	void SetBool(char* section, char* option, bool bValue);
	void SetCommaSeperatedInts(char* section, char* option, std::vector<int> vValue);
	void SetKey(char* section, char* option, int nKey);
	[/swap_lines]



public:

	[swap_lines]
	std::string m_szHash;
	bool m_bHidden;
	TriggerSettings m_TriggerSettings;
	ThreadHandling m_ThreadSettings;
	[/swap_lines]

	[add_junk_datamembers 1 4 /]

private:

	std::string m_szConfigFile;

	[add_junk_datamembers 1 4 /]
};

[junk_disable /]