// Ray.h - Class for rays and raytracing against AABB/OBBs
#pragma once

#include "stdafx.h"
#include "Vector.h"
#include "Matrix3x4.h"

[junk_enable /]

class Ray
{
public:

	// Ctor of the ray to setup for collision detection
	// [in] - vOrigin - Set the origin
	// [in] - vDirection - Set the direction the ray is facing
	Ray(Vector vOrigin, Vector vDirection)
	{
		Init(vOrigin, vDirection);

		[add_junk 1 5 /]
	}


	void Init(Vector vOrigin, Vector vDirection)
	{
		[swap_lines]
		m_vOrigin = vOrigin;
		m_vDirection = vDirection;
		[/swap_lines]

		[swap_lines]
		m_vInverseDir.x = (1.0f / m_vDirection.x);
		m_vInverseDir.y = (1.0f / m_vDirection.y);
		m_vInverseDir.z = (1.0f / m_vDirection.z);
		[/swap_lines]
	}


	// Does this ray intersect with a bounding box?
	// [in] - vOrigin - Origin of the ray
	// [in] - vDirection - Direction of the ray
	// [in] - vAABB_Min - Minimum of the AABB to test against
	// [in] - vAABB_Max - Maximum of the AABB to test against
	bool IntersectsWithAABB(const Vector& vOrigin, const Vector& vDirection, Vector& vAABB_Min, Vector& vAABB_Max)
	{
		float txMin, txMax;
		float tyMin, tyMax;
		[add_junk 1 5 /]
		float tzMin, tzMax;

		if (vDirection.x >= 0.0f)
		{
			txMin = (vAABB_Min.x - vOrigin.x) / vDirection.x;
			[add_junk 1 5 /]
			txMax = (vAABB_Max.x - vOrigin.x) / vDirection.x;
		}
		else
		{
			[add_junk 1 5 /]
			txMin = (vAABB_Max.x - vOrigin.x) / vDirection.x;
			txMax = (vAABB_Min.x - vOrigin.x) / vDirection.x;
		}

		if (vDirection.y >= 0.0f)
		{
			tyMin = (vAABB_Min.y - vOrigin.y) / vDirection.y;
			[add_junk 1 5 /]
			tyMax = (vAABB_Max.y - vOrigin.y) / vDirection.y;
		}
		else
		{
			[add_junk 1 5 /]
			tyMin = (vAABB_Max.y - vOrigin.y) / vDirection.y;
			tyMax = (vAABB_Min.y - vOrigin.y) / vDirection.y;
			[add_junk 1 5 /]
		}

		if (txMin > tyMax || tyMin > txMax)
			return false;

		[add_junk 1 5 /]

		if (tyMin > txMin)
			txMin = tyMin;

		[add_junk 1 5 /]

		if (tyMax < txMax)
			txMax = tyMax;

		if (vDirection.z >= 0.0f)
		{
			tzMin = (vAABB_Min.z - vOrigin.z) / vDirection.z;
			[add_junk 1 5 /]
			tzMax = (vAABB_Max.z - vOrigin.z) / vDirection.z;
		}
		else
		{
			[add_junk 1 5 /]
			tzMin = (vAABB_Max.z - vOrigin.z) / vDirection.z;
			tzMax = (vAABB_Min.z - vOrigin.z) / vDirection.z;
		}

		if (txMin > tzMax || tzMin > txMax)
			return false;

		[add_junk 1 5 /]

		if (txMin < 0 || txMax < 0)
			return false;

		return true;
	}

	// Does this ray intersect with an oriented bounding box?
	// [in] - mat - Matrix to use for rotation
	// [in] - vAABB_Min - Minimum of the AABB to test against
	// [in] - vAABB_Max - Maximum of the AABB to test against
	// [out] - fDist - Distance of the intersection
	bool IntersectsWithOBB(Matrix3x4 mat, Vector vAABB_Min, Vector vAABB_Max, float& fDist)
	{
		Vector transRay, dirRay;

		Math::VectorITransform(m_vOrigin, mat, transRay);
		[add_junk 1 5 /]
		Math::VectorIRotate(m_vDirection, mat, dirRay);
		[add_junk 1 5 /]

		return IntersectsWithAABB(transRay, dirRay, vAABB_Min, vAABB_Max);
	}

	bool IntersectsWithSphere()
 	{
 		return false;
 	}

private:

	// Origin of the ray

	[swap_lines]
	Vector m_vOrigin;
	Vector m_vDirection;
	Vector m_vInverseDir;
	[/swap_lines]

	[add_junk_datamembers 2 9 /]
};

[junk_disable /]