#include "Memory.h"

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]

// Attach to the process
// [in] - szProcName - Name of the process
// [in] - dwRights = Rights flag to use for OpenProcess
bool Memory::Attach(const char* szProcName, DWORD dwRights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)szProcName))
		{
			[swap_lines]
			m_dwProcessID = entry.th32ProcessID;
			CloseHandle(handle);
			[/swap_lines]

			[add_junk 2 5 /]

			m_hProcess = OpenProcess(dwRights, false, m_dwProcessID);
			m_bAttached = true;

			return true;
		}

	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	LOGE << "Failed to attach to " << szProcName << " !";
	[add_junk 2 5 /]
	CloseHandle(handle);
	return false;
}

// Detach from the process and cleanup
void Memory::Detach()
{
	CloseHandle(m_hProcess);
	m_bAttached = false;
	[add_junk 2 5 /]
	m_dwProcessID = -1;
}

// Grab a module's base address
// [in] - szModName - Name of the module we want the base address of
DWORD Memory::GetModuleBase(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			[add_junk 2 5 /]
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	LOGE << "Failed to get the module base address of " << szModName << " !";
	[add_junk 2 5 /]
	CloseHandle(handle);
	return NULL;
}

// Grab a module's size
// [in] - szModName - The name of the module we want to get the size of
DWORD Memory::GetModuleSize(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	[add_junk 2 5 /]
	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			[add_junk 2 5 /]
			return entry.modBaseSize;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	LOGE << "Failed to get the module size of " << szModName << " !";
	[add_junk 2 5 /]
	CloseHandle(handle);
	return NULL;
}

// Return our handle we're using
HANDLE Memory::GetHandle() const
{
	if (!m_bAttached)
		return NULL;

	[add_junk 2 5 /]

	return m_hProcess;
}

// Return if we're attached to the process
bool Memory::IsAttached() const
{
	[add_junk 2 5 /]
	return m_bAttached;
}

// Return our process ID
DWORD Memory::GetProcessID() const
{
	[add_junk 2 5 /]
	return m_dwProcessID;
}

// Signature scanning - Compare bytes to a mask
// [in] - pbData - Data we're comparing
// [in] - pbMask - Mask we're comparing
// [in] - szMask - String pattern with '?' to help the comparing process
bool Memory::DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask)
{
	[add_junk 2 5 /]

	for (; *szMask; ++szMask, ++pbData, ++pbMask)
	{
		if (*szMask == CHAR_TO_MATCH && *pbData != *pbMask)
			return false;
	}

	[add_junk 2 5 /]

	return (*szMask == NULL);
}

DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask)
{
	PBYTE data = new BYTE[dwSize];

	unsigned long bytesRead;

	if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead))
	{
		delete[] data;
		data = nullptr;
		[add_junk 2 5 /]
		return NULL;
	}

	for (DWORD i = 0; i < dwSize; i++)
	{
		if (DataCompare((const BYTE*)(data + i), szSig, szMask))
		{
			delete[] data;
			[add_junk 2 5 /]
			data = nullptr;
			return dwStart + i;
		}
	}

	delete[] data;
	[add_junk 2 5 /]
	data = nullptr;
	return NULL;
}

// Signature scanning - Return the address of a signature
DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern)
{
	std::string szMask;
	[add_junk 2 5 /]
	szMask.resize(nCount);
	[add_junk 2 5 /]

	for (int i = 0; i < nCount; i++)
		(pbPattern[i]) ? szMask[i] = CHAR_TO_MATCH : szMask[i] = '?';

	[add_junk 2 5 /]

	return FindPattern(dwStart, dwSize, pbPattern, szMask.c_str());
}

[enc_string_disable /]
[junk_disable /]
