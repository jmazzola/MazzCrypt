#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Enums.h"
#include "Utils.h"
#include "Math.h"

[junk_enable /]

namespace Bhop
{
	void Start()
	{
		[add_junk 1 3 /]

		while (true)
		{
			if (pCSGO == nullptr)
			{
				LOGD << "pCSGO was nullptr! Ending thread!";
				[add_junk 1 3 /]
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopBhop)
			{
				[add_junk 1 3 /]
				LOGD << "Bhop bool was true, Ending thread!";
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopBhop = true;

			if (!pCSGO->m_Config.m_BhopOptions.m_bEnabled)
				continue;

			[add_junk 1 3 /]

			if (!Utils::IsCSGOActiveWindow())
				continue;

			if (!pCSGO->IsInGame())
				continue;

			[add_junk 1 3 /]

			if (pCSGO->m_Me.GetMoveType() == MOVETYPE_LADDER)
				continue;

			[add_junk 1 3 /]

			if (!Utils::KeyHeldDown(VK_SPACE))
				continue;

			DWORD jumpOffset = pCSGO->m_dwClientBase + pCSGO->m_Offsets.m_dwJump;
			[add_junk 1 3 /]
			if (pCSGO->m_Mem.Read<int>(pCSGO->m_Me.m_dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_fFlags) & FL_ONGROUND)
			{
				pCSGO->m_Mem.Write<DWORD>(jumpOffset, 5);
				[add_junk 1 3 /]

				if (pCSGO->m_Config.m_BhopOptions.m_bAntiSMAC)
					std::this_thread::sleep_for(std::chrono::milliseconds(Math::RAND_INT(4, 40)));
				else
					std::this_thread::sleep_for(std::chrono::milliseconds(10));

				pCSGO->m_Mem.Write<DWORD>(jumpOffset, 4);
				[add_junk 1 3 /]
			}
			else
			{
				pCSGO->m_Mem.Write<DWORD>(jumpOffset, 4);
				[add_junk 1 3 /]

				if (pCSGO->m_Config.m_BhopOptions.m_bAntiSMAC)
					std::this_thread::sleep_for(std::chrono::milliseconds(Math::RAND_INT(4, 40)));
				else
					std::this_thread::sleep_for(std::chrono::milliseconds(10));

				[add_junk 1 3 /]
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 3 /]
		}

		[add_junk 1 3 /]
	}
}

[junk_disable /]