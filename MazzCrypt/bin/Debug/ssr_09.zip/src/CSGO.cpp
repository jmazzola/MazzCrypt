#include "CSGO.h"
#include "Utils.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

std::shared_ptr<CSGO> pCSGO = std::make_shared<CSGO>();

bool CSGO::Attach()
{
	[add_junk 1 5 /]
	m_Config.Init("settings.ini");
	return (m_Mem.Attach("csgo.exe"));
}

void CSGO::Detach()
{
	m_Mem.Detach();
	[add_junk 1 5 /]
}

void CSGO::ClearBases()
{
	[swap_lines]
	m_dwLocalBase = NULL;
	m_dwEntityBase = NULL;
	m_dwAnglePointer = NULL;
	m_dwStudioHdrPointer = NULL;
	m_dwGlowObjectBase = NULL;
	m_dwGlobalVarsPointer = NULL;
	ZeroMemory(&m_flViewMatrix, sizeof(m_flViewMatrix));
	m_iWindowWidth = m_iWindowHeight = NULL;
	[/swap_lines]

	[add_junk 1 5 /]
}

void CSGO::GrabStudioHdrPtr()
{
	if (m_dwLocalBase)
	{
		[add_junk 1 5 /]
		DWORD ptr = m_Mem.Read<DWORD>(m_dwLocalBase + m_Offsets.m_dwStudioHdrPtr);
		m_dwStudioHdrPointer = m_Mem.Read<DWORD>(ptr);
	}
}

bool CSGO::LoadBases()
{
	if (!m_Mem.IsAttached())
		return false;

	[add_junk 1 5 /]

	m_dwClientBase = m_Mem.GetModuleBase("client.dll");

	if (!m_dwClientBase)
		return false;

	m_dwGlowObjectBase = m_dwClientBase + m_Offsets.m_dwGlowArray;

	[add_junk 1 5 /]

	m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");

	if (!m_dwEngineBase)
		return false;

	m_dwEntityBase = m_dwClientBase + m_Offsets.m_dwEntityList;
	[add_junk 1 5 /]
	m_dwAnglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 5 /]
	m_dwGlobalVarsPointer = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwGlobalVars);

	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwLocalPlayer);

	m_dwGameRulesProxyPointer = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwGameRulesProxyPtr);
	[add_junk 1 5 /]
	m_dwInputSystemPointer = m_Mem.Read<DWORD>(m_Offsets.m_dwInputSystemPtr);

	while (!m_dwLocalBase)
	{
		m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwLocalPlayer);
		[add_junk 1 5 /]
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}

	m_dwStudioHdrPointer = m_Mem.Read<DWORD>(m_dwLocalBase + m_Offsets.m_dwStudioHdrPtr);
	[add_junk 1 5 /]
	m_dwStudioHdrPointer = m_Mem.Read<DWORD>(m_dwStudioHdrPointer);


	for (int i = 0; i < 16; i++)
		m_flViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + m_Offsets.m_dwViewMatrix + (4 * i));

	RECT rect;
	GetClientRect(Utils::GetGameWindow(), &rect);
	m_iWindowWidth = (int)(rect.right - rect.left);
	[add_junk 1 5 /]
	m_iWindowHeight = (int)(rect.bottom - rect.top);

	[add_junk 1 5 /]
	return true;
}

void CSGO::Update()
{
	if (!m_Mem.IsAttached() || pCSGO == nullptr)
		return;

	[add_junk 1 5 /]

	m_Me.Update(m_dwLocalBase);
	
	for (int i = 1; i < 64; i++)
	{
		DWORD entBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));

		if (!entBase)
			m_Players[i].Clear();

		[add_junk 1 5 /]

		m_Players[i].Update(entBase);
	}
}

bool CSGO::IsInGame()
{
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 5 /]
	return (m_Mem.Read<int>(clientState + m_Offsets.m_dwSignOnState) == SOS_Full);
}

bool CSGO::IsClassIDAWeapon(int classID)
{
	[add_junk 1 5 /]

	switch (classID)
	{
		case CID_CAK47:
		case CID_CDEagle:
		case CID_CWeaponAWP:
		case CID_CWeaponAug:
		case CID_CWeaponBizon:
		case CID_CWeaponElite:
		case CID_CWeaponFamas:
		case CID_CWeaponFiveSeven:
		case CID_CWeaponG3SG1:
		case CID_CWeaponGalilAR:
		case CID_CWeaponGlock:
		case CID_CWeaponHKP2000:
		case CID_CWeaponMAC10:
		case CID_CWeaponM249:
		case CID_CWeaponM4A1:
		case CID_CWeaponM3:
		case CID_CWeaponMag7:
		case CID_CWeaponMP7:
		case CID_CWeaponMP9:
		case CID_CWeaponNegev:
		case CID_CWeaponNOVA:
		case CID_CWeaponP250:
		case CID_CWeaponP90:
		case CID_CWeaponSawedoff:
		case CID_CWeaponSCAR20:
		case CID_CWeaponSG556:
		case CID_CWeaponSSG08:
		case CID_CWeaponTaser:
		case CID_CWeaponTec:
		case CID_CWeaponUSP:
		case CID_CWeaponUMP45:
		case CID_CWeaponXM1014:
		return true;
	}

	[add_junk 1 5 /]

	return false;
}

bool CSGO::IsClassIDAGrenade(int classID)
{
	[add_junk 1 5 /]

	switch (classID)
	{
		case CID_CFlashbang:
		case CID_CHEGrenade:
		case CID_CDecoyGrenade:
		case CID_CIncendiaryGrenade:
		case CID_CMolotovGrenade:
		case CID_CSmokeGrenade:
		case CID_CBaseCSGrenadeProjectile:
		case CID_CSmokeGrenadeProjectile:
		case CID_CMolotovProjectile:
		case CID_CDecoyProjectile:
		return true;
	}

	[add_junk 1 5 /]

	return false;
}

int CSGO::GetEnemyTeam(int myTeam)
{
	if (myTeam == Team_CounterTerrorists)
		return Team_Terrorists;
	else if (myTeam == Team_Terrorists)
		return Team_CounterTerrorists;

	[add_junk 1 5 /]

	return Team_NoTeam;
}

std::string CSGO::GetMapName()
{
	char mapName[64];
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 5 /]
	m_Mem.Read(clientState + m_Offsets.m_dwMapName, &mapName, sizeof(mapName));

	std::string map(mapName);

	if (map.empty())
		return "Invalid Map Name";

	[add_junk 1 5 /]

	return map;
}

std::string CSGO::GetGameDirectory()
{
	char dir[255];
	[add_junk 1 5 /]
	m_Mem.Read(m_Offsets.m_dwGameDirectory, &dir, sizeof(dir));

	return std::string(dir);
}

bool CSGO::IsBombPlanted() const
{
	[add_junk 1 5 /]
	return pCSGO->m_Mem.Read<bool>(m_dwGameRulesProxyPointer + pCSGO->m_Offsets.m_dwNetvar_bBombPlanted);
}

bool CSGO::IsBombDropped() const
{
	[add_junk 1 5 /]
	return pCSGO->m_Mem.Read<bool>(m_dwGameRulesProxyPointer + pCSGO->m_Offsets.m_dwNetvar_bBombDropped);
}

void CSGO::SetAngles(Vector& vAngles)
{
	[add_junk 1 5 /]
	m_Mem.Write<Vector>(m_dwAnglePointer + m_Offsets.m_dwViewAngles, vAngles);
}

void CSGO::SendPacket(bool bPacket)
{
	[add_junk 1 5 /]
	m_Mem.WriteProtected<BYTE>(m_Offsets.m_dwSendPacket, (BYTE)bPacket);
}

void CSGO::SetFrameBuf(bool bTeleport)
{
	[add_junk 1 5 /]

	if (bTeleport)
		m_Mem.WriteProtected<BYTE>(m_Offsets.m_dwFrameBuf, 0x1);
	else
		m_Mem.WriteProtected<BYTE>(m_Offsets.m_dwFrameBuf, 0x20);
}

void CSGO::ForceFullUpdate()
{
	[add_junk 1 5 /]
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	m_Mem.Write<int>(clientState + m_Offsets.m_dwForceFullUpdate, -1);
}

void CSGO::SleepUntilInput(int ms)
{
	[add_junk 1 5 /]
	DWORD vTableAddr = pCSGO->m_Mem.Read<DWORD>(m_dwInputSystemPointer);
	[add_junk 1 5 /]
	DWORD vTableFunc = pCSGO->m_Mem.Read<DWORD>(vTableAddr + 0xB0);
	
	LPVOID addr = (LPVOID)vTableFunc;

	LPVOID param = pCSGO->m_Mem.Allocate(sizeof(ms));
	[add_junk 1 5 /]
	pCSGO->m_Mem.Write<int>((DWORD)param, ms);

	HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(addr, param);
	[add_junk 1 5 /]
	WaitForSingleObject(hThread, INFINITE);

	pCSGO->m_Mem.Free(param);

	CloseHandle(hThread);	
}

void CSGO::ClientCMD(char* cmd)
{
	LPVOID addr = (LPVOID)pCSGO->m_Offsets.m_dwClientCMD;

	LPVOID param = pCSGO->m_Mem.Allocate(strlen(cmd) + 1);
	[add_junk 1 5 /]
	pCSGO->m_Mem.Write((DWORD)param, cmd, strlen(cmd));
	[add_junk 1 5 /]

	HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(addr, param);
	WaitForSingleObject(hThread, INFINITE);
	[add_junk 1 5 /]

	pCSGO->m_Mem.Free(param, strlen(cmd) + 1);

	CloseHandle(hThread);
	[add_junk 1 5 /]
}

[junk_disable /]
[enc_string_disable /]
