// stdafx.h - The header file of all header files

#pragma once

// Defines
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

// Includes
#include <Windows.h>
#include <vector>
#include <string>
#include <thread>
#include <unordered_map>
#include <iostream>
#include <DbgHelp.h>
#include <memory>
#include <array>

// Visual Leak Detector
//#include <vld.h>

// Logging
#include <plog\Log.h>

// Libraries
#pragma comment(lib, "dbghelp.lib")