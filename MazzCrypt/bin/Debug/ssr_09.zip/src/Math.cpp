#include "Math.h"

#include "Vector.h"
#include "Matrix3x4.h"

[junk_enable /]

namespace Math
{
	int RAND_INT(int lo, int hi)
	{
		[add_junk 1 14 /]
		return (int)(rand() % (hi - lo + 1) + lo);
	}

	float RAND_FLOAT(float lo, float hi)
	{
		float random = ((float)rand()) / (float)RAND_MAX;
		[add_junk 1 14 /]
		float diff = hi - lo;
		[add_junk 1 14 /]
		float r = random * diff;
		return lo + r;
	}

	void ClampAngles(Vector& angle)
	{
		while (angle.y > 180.0f)
			angle.y -= 360.0f;

		[add_junk 1 14 /]

		while (angle.y < -180.0f)
			angle.y += 360.0f;

		[add_junk 1 14 /]

		if (angle.x > 89.0f)
			angle.x = 89.0f;

		if (angle.x < -89.0f)
			angle.x = -89.0f;

		[add_junk 1 14 /]

		if (angle.z != 0.0f)
			angle.z = 0.0f;
	}

	Vector AngleToDirection(Vector angle)
	{
		[swap_lines]
		angle.x = (float)DEG2RAD(angle.x);
		angle.y = (float)DEG2RAD(angle.y);
		[/swap_lines]

		[add_junk 1 14 /]

		float sinYaw = sin(angle.y);
		float cosYaw = cos(angle.y);

		float sinPitch = sin(angle.x);
		[add_junk 1 14 /]
		float cosPitch = cos(angle.x);

		Vector direction;
		[swap_lines]
		direction.x = cosPitch * cosYaw;
		direction.y = cosPitch * sinYaw;
		direction.z = -sinPitch;
		[/swap_lines]

		return direction;
	}

	void MakeVector(Vector angle, Vector & vector)
	{
		float pitch = float(angle.x * M_PI / 180);
		[add_junk 1 14 /]
		float yaw = float(angle.y * M_PI / 180);

		float tmp = float(cos(pitch));

		[swap_lines]
		vector.x = float(-tmp * -cos(yaw));
		vector.y = float(sin(yaw) * tmp);
		vector.z = float(-sin(pitch));
		[/swap_lines]

		[add_junk 1 14 /]
	}


	// This might be wrong. Check TGF Internal/External and VectorAngles
	Vector CalcAngle(Vector playerPos, Vector enemyPos)
	{
		Vector aimAngles;

		Vector delta = playerPos - enemyPos;

		float hyp = (float)FastSQRT(pow(delta.x, 2) + pow(delta.y, 2));

		aimAngles.x = atanf(delta.z / hyp) * M_RADPI;
		[add_junk 1 14 /]
		aimAngles.y = atanf(delta.y / delta.x) * M_RADPI;
		aimAngles.z = 0.0f;

		if (delta.x >= 0.0f)
			aimAngles.y += 180.0f;

		[add_junk 1 14 /]

		return aimAngles;
	}

	float GetFov(Vector angle, Vector src, Vector dst)
	{
		Vector ang, aim;
		ang = CalcAngle(src, dst);
		[add_junk 1 14 /]
		MakeVector(angle, aim);
		[add_junk 1 14 /]
		MakeVector(ang, ang);

		float mag = (float)FastSQRT(pow(aim.x, 2) + pow(aim.y, 2) + pow(aim.z, 2));
		[add_junk 1 14 /]
		float u_dot_v = aim.DotProduct(ang);

		return RAD2DEG(acos(u_dot_v / (pow(mag, 2))));
	}

	void AngleVectors(const Vector& angles, Vector* forward)
	{
		float sr, sp, sy, cr, cp, cy;

		SinCos(DEG2RAD(angles.x), &sy, &cy);
		[add_junk 1 14 /]
		SinCos(DEG2RAD(angles.y), &sp, &cp);
		[add_junk 1 14 /]
		SinCos(DEG2RAD(angles.z), &sr, &cr);

		if (forward)
		{
			[swap_lines]
			forward->x = cp*cy;
			forward->y = cp*sy;
			forward->z = -sp;
			[/swap_lines]
		}
	}

	void VectorITransform(Vector& in1, const Matrix3x4& in2, Vector& out)
	{
		float init[3];

		[swap_lines]
		init[0] = in1.x - in2.m[0][3];
		init[1] = in1.y - in2.m[1][3];
		init[2] = in1.z - in2.m[2][3];
		[/swap_lines]

		[add_junk 1 14 /]

		[swap_lines]
		out.x = init[0] * in2.m[0][0] + init[1] * in2.m[1][0] + init[2] * in2.m[2][0];
		out.y = init[0] * in2.m[0][1] + init[1] * in2.m[1][1] + init[2] * in2.m[2][1];
		out.z = init[0] * in2.m[0][2] + init[1] * in2.m[1][2] + init[2] * in2.m[2][2];
		[/swap_lines]
	}

	void VectorIRotate(Vector& in1, const Matrix3x4& in2, Vector& out)
	{
		out.x = in1.x * in2.m[0][0] + in1.y * in2.m[1][0] + in1.z * in2.m[2][0];
		out.y = in1.x * in2.m[0][1] + in1.y * in2.m[1][1] + in1.z * in2.m[2][1];
		[add_junk 1 14 /]
		out.z = in1.x * in2.m[0][2] + in1.y * in2.m[1][2] + in1.z * in2.m[2][2];
	}
}

[junk_disable /]