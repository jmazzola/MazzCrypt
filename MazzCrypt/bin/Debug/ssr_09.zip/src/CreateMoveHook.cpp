#include "CreateMoveHook.h"

namespace CreateMove
{
	void InitializeVirtuals()
	{
		
	}
}
