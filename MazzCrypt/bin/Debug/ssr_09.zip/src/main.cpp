#include "stdafx.h"
#include "SmurfStomper.h"
#include "Experiments.h"

#include "Decrypt.h"

#define VERSION_MAJOR 0
#define VERSION_MINOR 9

[junk_enable /]
[enc_string_enable /]

char* szProgramPath;

void ActivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopESP = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBhop = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopFakelag = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopChatspam = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopSkinChanger = false;
	[/swap_lines]
}

void DeactivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopESP = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBhop = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopFakelag = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopChatspam = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopSkinChanger = true;
	[/swap_lines]
}

// Update our entities
void UpdateTick()
{
	LOGD << "UpdateTick thread started!";
	[add_junk 1 5 /]

	while (true)
	{
		if (pCSGO == nullptr)
		{
			[add_junk 1 5 /]
			LOGD << "pCSGO was nullptr! Ending thread!";
			return;
		}
		else if (pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate)
		{
			LOGD << "Update bool was true, Ending thread!";
			[add_junk 1 5 /]
			return;
		}

		if (GetAsyncKeyState(VK_END))
		{
			pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;
			[add_junk 1 5 /]
			return;
		}

		if (!pCSGO->IsInGame())
		{
			[add_junk 1 5 /]
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			continue;
		}

		pCSGO->LoadBases();
		[add_junk 1 5 /]

		std::string newSettingsHash = pCSGO->m_Config.GetHash();
		[add_junk 1 5 /]
		std::string newChatSpamHash = pCSGO->m_Config.GetHash("chat.txt");

		if (strcmp(newSettingsHash.c_str(), pCSGO->m_Config.m_szHash.c_str()))
		{
			[add_junk 1 5 /]
			LOGD << "Hashes in settings.ini was found to be changed! Old Hash: " << pCSGO->m_Config.m_szHash.c_str() << " | New Hash: " << newSettingsHash.c_str();

			if (pCSGO->m_Config.LoadConfig())
			{
				[add_junk 1 5 /]
				LOGD << "The new settings.ini successfully loaded and changed";
				Utils::PrintLine("> .ini file has been changed. Automatically loaded new settings!\n");
			}
			else
			{
				[add_junk 1 5 /]
				LOGE << "The new settings.ini FAILED to be loaded and changed";
				Utils::PrintLine("> .ini file could not be opened/changed. Failed to load new settings.\n");
			}
		}

		// Real-Time Chat Loading
		if (strcmp(newChatSpamHash.c_str(), pCSGO->m_Config.m_ChatspamOptions.m_szHash.c_str()))
		{
			[add_junk 1 5 /]
			LOGD << "Hashes in chat.txt was found to be changed! Old Hash: " << pCSGO->m_Config.m_ChatspamOptions.m_szHash.c_str() << " | New Hash: " << newChatSpamHash.c_str();

			if (pCSGO->m_Config.m_ChatspamOptions.Load("chat.txt"))
			{
				pCSGO->m_Config.m_ChatspamOptions.m_szHash = pCSGO->m_Config.GetHash("chat.txt");
				LOGD << "The new chat.txt successfully loaded and changed";
				[add_junk 1 5 /]
				Utils::PrintLine("> chat.txt has been changed. Automatically loaded new lines!\n");
			}
			else
			{
				LOGE << "The new chat.txt FAILED to be loaded and changed";
				[add_junk 1 5 /]
				Utils::PrintLine("> chat.txt could not be opened/changed. Failed to load new lines.\n");
			}
		}

		pCSGO->Update();
		[add_junk 1 5 /]
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}
}

// Launch our cheat threads
void LaunchThreads()
{
	LOGD << "Starting threads..";
	[add_junk 1 5 /]
	std::thread threadUpdateTick(UpdateTick);
	threadUpdateTick.detach();
	[add_junk 1 5 /]
	LOGD << "Daemon thread UpdateTick launched.";

	std::thread threadRCS(&RCS::Start, RCS());
	threadRCS.detach();
	[add_junk 1 5 /]
	LOGD << "Daemon thread RCS launched.";

	std::thread threadBhop(Bhop::Start);
	[add_junk 1 5 /]
	threadBhop.detach();
	LOGD << "Daemon thread Bhop launched.";
	[add_junk 1 5 /]

	std::thread threadFL(FakeLag::Start);
	threadFL.detach();
	[add_junk 1 5 /]
	LOGD << "Daemon thread Fakelag launched.";

	std::thread threadESP(ESP::Start);
	threadESP.detach();
	[add_junk 1 5 /]
	LOGD << "Daemon thread ESP launched.";

	std::thread threadChat(&Chatspam::Start, Chatspam());
	[add_junk 1 5 /]
	threadChat.detach();
	LOGD << "Daemon thread Chatspam launched.";

	[add_junk 1 5 /]
}

void Init()
{
	plog::init(plog::debug, "log.txt");

	LOGD << "======= START =======";
	[add_junk 1 5 /]
	LOGD << "SmurfStomper: Revamped Initiated.";

	srand((unsigned int)time(NULL));
	[add_junk 1 5 /]
	rand();

	Utils::AllowDebugging();
	Utils::DisableQuickEdit();
	[add_junk 1 5 /]
	Utils::SetRandomWindowTitle();
	[add_junk 1 5 /]
	Utils::SetUpMinidump();
	[add_junk 1 5 /]
	Utils::PrintLine(std::string("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="));
	Utils::PrintLine(std::string("                           __     _                                  "));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string(" ___ _ __ ___  _   _ _ __ / _|___| |_ ___  _ __ ___  _ __   ___ _ __ "));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string("/ __| '_ ` _ \\| | | | '__| |_/ __| __/ _ \\| '_ ` _ \\| '_ \\ / _ \\ '__|"));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string("\\__ \\ | | | | | |_| | |  |  _\\__ \\ || (_) | | | | | | |_) |  __/ |   "));
	Utils::PrintLine(std::string("|___/_| |_| |_|\\__,_|_|  |_| |___/\\__\\___/|_| |_| |_| .__/ \\___|_|   "));
	Utils::PrintLine(std::string("                                                    |_|              "));
	Utils::PrintLine(std::string("                                              _ "));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string(" _ __ _____   ____ _ _ __ ___  _ __   ___  __| |"));
	Utils::PrintLine(std::string("| '__/ _ \\ \\ / / _` | '_ ` _ \\| '_ \\ / _ \\/ _` |"));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string("| | |  __/\\ V / (_| | | | | | | |_) |  __/ (_| |"));
	Utils::PrintLine(std::string("|_|  \\___| \\_/ \\__,_|_| |_| |_| .__/ \\___|\\__,_|"));
	[add_junk 1 5 /]
	Utils::PrintLine(std::string("                              |_|               "));
	Utils::PrintLine(std::string("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="));
	[add_junk 1 5 /]
	Utils::PrintLine("> Current Version: " + std::to_string(VERSION_MAJOR) + "." + std::to_string(VERSION_MINOR) + " - Build " + std::string(__DATE__) + " " + std::string(__TIME__) + "\n");

	Utils::PrintLine("> Waiting for CSGO. If you haven't started CSGO yet, please do so.");
	[add_junk 1 5 /]

	while (!pCSGO->Attach())
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

	[add_junk 1 5 /]

	LOGD << "CSGO has been loaded | ProcessID: " << pCSGO->m_Mem.GetProcessID();

	[add_junk 1 5 /]

	Utils::PrintLine("> CSGO has been loaded!\n");
	[add_junk 1 5 /]
	Utils::PrintLine("> Loading your config from settings.ini..");

	pCSGO->m_Config.Init(".\\settings.ini");

	if (pCSGO->m_Config.LoadConfig())
	{
		Utils::PrintLine("> settings.ini was successfully loaded!");
		[add_junk 1 5 /]
		LOGD << "settings.ini was successfully loaded!";
	}
	else
	{
		Utils::PrintLine("> settings.ini FAILED to load!");
		[add_junk 1 5 /]
		LOGE << "settings.ini FAILED to load!";
	}

	Utils::PrintLine("> Loading chat.txt for custom chat spamming..");
	[add_junk 1 5 /]
	if (pCSGO->m_Config.m_ChatspamOptions.Load("chat.txt"))
	{
		pCSGO->m_Config.m_ChatspamOptions.m_szHash = pCSGO->m_Config.GetHash("chat.txt");
		Utils::PrintLine("> chat.txt was successfully loaded!");
		[add_junk 1 5 /]
		LOGD << "settings.ini was successfully loaded!";
	}
	else
	{
		[add_junk 1 5 /]
		Utils::PrintLine("> chat.txt FAILED to load!");
		LOGE << "chat.txt FAILED to load!";
	}

	Utils::PrintLine("\n> Waiting until CSGO loads it's .dll's. This will only take a minute.");
	[add_junk 1 5 /]

	while (!pCSGO->m_Mem.GetModuleBase("client.dll"))
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

	[add_junk 1 5 /]
	LOGD << "client.dll was detected | Base: 0x" << std::hex << pCSGO->m_Mem.GetModuleBase("client.dll") << " Size: 0x" << pCSGO->m_Mem.GetModuleSize("client.dll");

	while (!pCSGO->m_Mem.GetModuleBase("engine.dll"))
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

	LOGD << "engine.dll was detected | Base: 0x" << std::hex << pCSGO->m_Mem.GetModuleBase("engine.dll") << " Size: 0x" << pCSGO->m_Mem.GetModuleSize("engine.dll");

	Utils::PrintLine("\n> CSGO has loaded their dlls!");
	[add_junk 1 5 /]

	Utils::PrintLine("\n> Scanning signatures and setting up netvars..\n");
	[add_junk 1 5 /]

	pCSGO->m_Offsets.Init();

	pCSGO->LoadBases();
	[add_junk 1 5 /]
	pCSGO->m_Offsets.LoadNetvars();

	LOGD << "Bases and Netvars were loaded and populated!";
	[add_junk 1 5 /]

	Utils::PrintLine("\n> Loading Cheat Threads..\n");

	ActivateAllThreads();
	[add_junk 1 5 /]
	LaunchThreads();

	Utils::PrintLine("\n> Cheat Loaded..\n");
	[add_junk 1 5 /]
	Beep(0x500, 100);
}

// Our loop for checking key presses and handling toggles
void Loop()
{
	while (!GetAsyncKeyState(VK_END))
	{
		if (!Utils::DoesCSGOExist())
		{
			[add_junk 1 5 /]
			LOGE << "CSGO doesn't exist anymore. Exiting main loop!";
			break;
		}

		if (Utils::KeyPressed(pCSGO->m_Config.m_Keys.m_nToggleBhop))
		{
			pCSGO->m_Config.m_BhopOptions.m_bEnabled = !pCSGO->m_Config.m_BhopOptions.m_bEnabled;
			LOGD << "Bunnyhop is now" << ((pCSGO->m_Config.m_BhopOptions.m_bEnabled) ? " ON" : " OFF");
		}

		if (Utils::KeyPressed(pCSGO->m_Config.m_Keys.m_nToggleFakelag))
		{
			pCSGO->m_Config.m_FakeLagOptions.m_bEnabled = !pCSGO->m_Config.m_FakeLagOptions.m_bEnabled;
			[add_junk 1 5 /]
			LOGD << "Fakelag is now" << ((pCSGO->m_Config.m_FakeLagOptions.m_bEnabled) ? " ON" : " OFF");
		}

		if (Utils::KeyPressed(pCSGO->m_Config.m_Keys.m_nToggleESP))
		{
			[add_junk 1 5 /]
			pCSGO->m_Config.m_EspOptions.m_bEnabled = !pCSGO->m_Config.m_EspOptions.m_bEnabled;
			LOGD << "ESP is now" << ((pCSGO->m_Config.m_EspOptions.m_bEnabled) ? " ON" : " OFF");
		}

		if (Utils::KeyPressed(pCSGO->m_Config.m_Keys.m_nToggleChatspam))
		{
			pCSGO->m_Config.m_ChatspamOptions.m_bEnabled = !pCSGO->m_Config.m_ChatspamOptions.m_bEnabled;
			LOGD << "Chatspam is now " << ((pCSGO->m_Config.m_EspOptions.m_bEnabled) ? "ON" : "OFF");
			[add_junk 1 5 /]
		}

		if (Utils::KeyPressed(pCSGO->m_Config.m_Keys.m_nRestartChatspam))
		{
			switch (pCSGO->m_Config.m_ChatspamOptions.m_Method)
			{
				case ChatspamMethod::SPAM_ADVERTISEMENT:
				{
					pChatSpam->adIndex = 0;
					[add_junk 1 5 /]
					LOGD << "Chatspam's advertisement index was reset";
					break;
				}
				case ChatspamMethod::SPAM_CUSTOMFILE:
				{
					pChatSpam->parseIndex = 0;
					LOGD << "Chatspam's parsed file index was reset";
					[add_junk 1 5 /]
					break;
				}
			}
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}

	LOGD << "END key detected, exiting main loop!";
	[add_junk 1 5 /]
}

void Cleanup()
{
	DeactivateAllThreads();

	LOGD << "All threads were deactivated.";
	[add_junk 1 5 /]
	Utils::PrintLine("> Ending threads...");

	pCSGO->m_Config.SaveConfig();
	[add_junk 1 5 /]
	LOGD << "settings.ini was saved";

	[add_junk 1 5 /]

	LOGD << "Self-deleting executable..";
	[add_junk 1 5 /]
	Utils::DeleteSelf(szProgramPath);

}

// Main Program
int main(int argc, char* argv[])
{
	if (argc > 0)
		szProgramPath = argv[0];

	Init();
	[add_junk 1 5 /]
	Loop();
	[add_junk 1 5 /]
	Cleanup();

	LOGD << "SmurfStomper: Revamped Ended.";
	[add_junk 1 5 /]
	LOGD << "======= END =======";

	return 0;
}

[enc_string_disable /]
[junk_disable /]