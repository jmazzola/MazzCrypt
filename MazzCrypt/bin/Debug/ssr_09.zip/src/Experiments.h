#pragma once

#include "stdafx.h"
#include "CSGO.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

namespace Experiments
{
	void SpawnConsoleWindow(std::string strTitle)
	{
		[add_junk 1 4 /]
		LPVOID allocConsole = (LPVOID)GetProcAddress(GetModuleHandle("kernel32.dll"), "AllocConsole");
		[add_junk 1 4 /]
		LPVOID setConsoleTitleA = (LPVOID)GetProcAddress(GetModuleHandle("kernel32.dll"), "SetConsoleTitleA");

		LPVOID title = pCSGO->m_Mem.Allocate(strlen(strTitle.c_str()), PAGE_READWRITE);
		[add_junk 1 4 /]
		pCSGO->m_Mem.Write((DWORD)title, strTitle.c_str(), strlen(strTitle.c_str()));

		// call AllocConsole()
		HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(allocConsole);
		WaitForSingleObject(hThread, INFINITE);

		// call SetConsoleTitleA(strTitle)
		pCSGO->m_Mem.MakeRemoteThread(setConsoleTitleA, title);
		[add_junk 1 4 /]

		pCSGO->m_Mem.Free(title, strlen(strTitle.c_str()));
		[add_junk 1 4 /]
		CloseHandle(hThread);
	}

	void FreeConsoleWindow()
	{
		LPVOID freeConsole = (LPVOID)GetProcAddress(GetModuleHandle("kernel32.dll"), "FreeConsole");

		// Call FreeConsole()
		HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(freeConsole);
		[add_junk 1 4 /]
		WaitForSingleObject(hThread, INFINITE);

		CloseHandle(hThread);
	}

	void ClientCMD_NonShellcode(std::string cmd)
	{
		LPVOID clientCMD = (LPVOID)pCSGO->m_Offsets.m_dwClientCMD;
		[add_junk 1 4 /]
		LPVOID param = pCSGO->m_Mem.Allocate(strlen(cmd.c_str()), PAGE_READWRITE);
		pCSGO->m_Mem.Write((DWORD)param, cmd.c_str(), strlen(cmd.c_str()));

		// ClientCMD(cmd)
		HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(clientCMD, param);
		[add_junk 1 4 /]
		WaitForSingleObject(hThread, INFINITE);

		pCSGO->m_Mem.Free(param, strlen(cmd.c_str()));
		CloseHandle(hThread);
	}

	// Doesn't crash but doesn't work as well.
	void ClientCMD_Shellcode(std::string cmd)
	{
		BYTE payload[] =
		{
			// int 3 - internal debugging lel
			//0xCC,
			// push ebp
			0x55,
			// mov ebp, esp
			0x8B, 0xEC,
			// push param
			0x68, 0x12, 0x34, 0x56, 0x78,
			// push ClientCMD
			0xB8, 0x12, 0x34, 0x56, 0x78,
			// add esp, 4
			0x83, 0xC4, 0x04,
			// mov esp, ebp
			0x8B, 0xE5,
			// pop ebp
			0x5D,
			// ret
			0xC3
		};

		LPVOID param = pCSGO->m_Mem.Allocate(strlen(cmd.c_str()), PAGE_READWRITE);
		[add_junk 1 4 /]
		pCSGO->m_Mem.Write((DWORD)param, cmd.c_str(), strlen(cmd.c_str()));

		*(DWORD*)&payload[0x4] = (DWORD)param;
		[add_junk 1 4 /]
		*(DWORD*)&payload[0x9] = pCSGO->m_Offsets.m_dwClientCMD;

		LPVOID lpBaseAddress = pCSGO->m_Mem.Allocate(sizeof(payload));
		[add_junk 1 4 /]
		pCSGO->m_Mem.Write((DWORD)lpBaseAddress, payload);

		HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(lpBaseAddress, nullptr, sizeof(payload));
		WaitForSingleObject(hThread, INFINITE);

		pCSGO->m_Mem.Free(param, strlen(cmd.c_str()));
		pCSGO->m_Mem.Free(lpBaseAddress, sizeof(payload));

		CloseHandle(hThread);
	}

	// look at ecco
	void ClientCMD_ThiscallShellcode(std::string cmd)
	{
		DWORD clientBase = pCSGO->m_Mem.GetModuleBase("client.dll");
		[add_junk 1 4 /]
		DWORD clientSize = pCSGO->m_Mem.GetModuleSize("client.dll");

		DWORD engine = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 0x1B, (BYTE*)"\x8B\x0D\x00\x00\x00\x00\x8B\x01\xFF\x90\x00\x00\x00\x00\xA1\x00\x00\x00\x00\xB9\x00\x00\x00\x00\xFF\x50\x14");
		engine = pCSGO->m_Mem.Read<DWORD>(engine + 2);

		BYTE payload[] =
		{
			// mov ecx, ds:0
			0x8B, 0x0D, 0x12, 0x34, 0x56, 0x78,
			// push 0x0
			0x68, 0x12, 0x34, 0x56, 0x78,
			// mov eax, [ecx]
			0x8B, 0x01,
			// mov eax, [eax + 0x1B0]
			0x8B, 0x80, 0xB0, 0x01, 0x00, 0x00,
			// call eax
			0xFF, 0xD0,
			// ret
			0xC3
		};

		LPVOID msg = pCSGO->m_Mem.Allocate(strlen(cmd.c_str()));
		[add_junk 1 4 /]
		pCSGO->m_Mem.Write((DWORD)msg, cmd.c_str(), strlen(cmd.c_str()));

		*(DWORD*)&payload[0x2] = engine;
		[add_junk 1 4 /]
		*(DWORD*)&payload[0x7] = (DWORD)msg;

		LPVOID lpBaseAddress = pCSGO->m_Mem.Allocate(sizeof(payload));
		[add_junk 1 4 /]
		pCSGO->m_Mem.Write((DWORD)lpBaseAddress, payload);

		HANDLE hThread = pCSGO->m_Mem.MakeRemoteThread(lpBaseAddress);
		[add_junk 1 4 /]
		WaitForSingleObject(hThread, INFINITE);

		pCSGO->m_Mem.Free(lpBaseAddress, sizeof(payload));
		pCSGO->m_Mem.Free(msg, strlen(cmd.c_str()));

		CloseHandle(hThread);
	}
}

[junk_disable /]
[enc_string_disable /]