// Teleport.h - The cheat thread for teleporting
#pragma once

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

namespace Teleport
{
	void Start()
	{
		while (true)
		{
			if (pCSGO == nullptr)
			{
				[add_junk 1 4 /]
				LOGD << "pCSGO was nullptr! Ending thread!";
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopTeleport)
			{
				LOGD << "Teleport bool was true, Ending thread!";
				[add_junk 1 4 /]
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopTeleport = true;

			if (!pCSGO->IsInGame())
				continue;

			[add_junk 1 4 /]

			if (pCSGO->m_Config.m_TeleportOptions.m_bEnabled)
			{
				pCSGO->SetFrameBuf(true);
				[add_junk 1 4 /]
				pCSGO->m_Config.m_TeleportOptions.m_bEnabled = !pCSGO->m_Config.m_TeleportOptions.m_bEnabled;
			}
			else
				pCSGO->SetFrameBuf(false);

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}

		[add_junk 1 4 /]
	}
}

[junk_disable /]