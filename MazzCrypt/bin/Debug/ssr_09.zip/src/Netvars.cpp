#include "Netvars.h"
#include "Utils.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

namespace Netvars
{
	DWORD GetNetVar(const char* szClassName, const char* szNetVar)
	{
		[add_junk 1 7 /]

		if (!pCSGO->m_Offsets.m_dwNetvarClasses || !szClassName || !szNetVar)
		{
			[add_junk 1 7 /]
			Utils::PrintLine("> Classes are fucked. Netvars can't be grabbed.");
		}

		ClientClass* pClass = (ClientClass*)pCSGO->m_Offsets.m_dwNetvarClasses;

		if (!pClass)
		{
			[add_junk 1 7 /]
			return NULL;
		}

		for (; pClass; pClass = pClass->GetNextClass())
		{
			[add_junk 1 7 /]

			if (strcmp(szClassName, pClass->GetTable()->GetTableName()))
				continue;

			for (int i = 0; i < pClass->GetTable()->GetMaxProp(); i++)
			{
				CRecvTable::CRecvProp* pRecvProp = pClass->GetTable()->GetProperty(i);

				[add_junk 1 7 /]

				if (isdigit(pRecvProp->GetVarName()[0]))
					continue;

				if (!strcmp(pRecvProp->GetVarName(), szNetVar))
				{
					return pRecvProp->GetOffset();
				}

				[add_junk 1 7 /]

				if (!pRecvProp->GetDataTable())
					continue;

				for (int j = 0; j < pRecvProp->GetDataTable()->GetMaxProp(); ++j)
				{
					CRecvTable::CRecvProp* pRecvProp2 = pRecvProp->GetDataTable()->GetProperty(j);

					[add_junk 1 7 /]

					if (isdigit(pRecvProp2->GetVarName()[0]))
						continue;

					if (!strcmp(pRecvProp2->GetVarName(), szNetVar))
					{
						[add_junk 1 7 /]
						return pRecvProp2->GetOffset();
					}

					if (!pRecvProp2->GetDataTable())
						continue;

					[add_junk 1 7 /]

					for (int k = 0; k < pRecvProp2->GetDataTable()->GetMaxProp(); ++k)
					{
						[add_junk 1 7 /]

						CRecvTable::CRecvProp* pRecvProp3 = pRecvProp2->GetDataTable()->GetProperty(k);

						[add_junk 1 7 /]

						if (isdigit(pRecvProp3->GetVarName()[0]))
							continue;

						if (!strcmp(pRecvProp3->GetVarName(), szNetVar))
						{
							[add_junk 1 7 /]
							return pRecvProp3->GetOffset();
						}
					}

					[add_junk 1 7 /]
				}

				[add_junk 1 7 /]
			}
		}

		return NULL;
	}
}

[junk_disable /]
[enc_string_disable /]