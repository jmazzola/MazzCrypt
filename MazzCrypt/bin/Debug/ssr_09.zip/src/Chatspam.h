// Chatspam.h - The cheat thread to handle spamming in-game chat with information and memes
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Structs.h"
#include <stdio.h>

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

class Chatspam
{
public:

	Chatspam()
	{
		[add_junk 1 5 /]
		m_vAdvertisements.clear();

		m_vAdvertisements.push_back(std::string("[!] Beginning Messages [!]"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string("SMURFSTOMPER REVAMPED | STOPPING SMURFS/SHITTIES SINCE DECEMEBER 2014 COMPLETELY UNDETECTED"));
		m_vAdvertisements.push_back(std::string("SMURFSTOMPER REVAMPED | INTRODUCING THE FIRST EVER EXTERNAL SPINBOT"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string("SMURFSTOMPER REVAMPED | CONTACT THE USER OF THIS CHEAT FOR SALES INFORMATION"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string(".: Coded by Nitsuj | ChocolatePC :."));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string(".: Shoutouts to Zerowrite.co | Diz | Wolfy | Mocha | Razor | Navi | Nitro | Golden :."));
		m_vAdvertisements.push_back(std::string("~ I hope you learned your lesson to not cheat against the best lmao. ~"));
		m_vAdvertisements.push_back(std::string("~ I will say though, it was a pretty cute attempt. ~"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string("~ If I were you, I'd abandon to refrain from further embarassment. ~"));
		m_vAdvertisements.push_back(std::string("~ I feel so sorry for that idiot you were trying to boost. ~"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string("~ You should refund that shitty copy-pasted pay2cheat and shove it up your ass. ~"));
		m_vAdvertisements.push_back(std::string("~ How are you losing to my external cheat? Too optimized 4 u. ~"));
		[add_junk 1 5 /]
		m_vAdvertisements.push_back(std::string("~ Think twice before you toggle. Have a nice day getting rekt. ~"));
		m_vAdvertisements.push_back(std::string("[!] These messages will now repeat. [!]"));
		[add_junk 1 5 /]
	}

	~Chatspam() = default;

	std::string GetInformationSpam()
	{
		CGlobalVarsBase globalVars = pCSGO->m_Mem.Read<CGlobalVarsBase>(pCSGO->m_dwGlobalVarsPointer);
		[add_junk 1 5 /]
		std::vector<Player> enemies, teammates;

		char str[255];

		for (int i = 1; i < globalVars.maxClients; i++)
		{
			Player ply = pCSGO->m_Players[i];
			[add_junk 1 5 /]

			if (!ply.Valid())
				continue;

			bool bEnemy = (pCSGO->m_Me.GetTeam() == pCSGO->GetEnemyTeam(ply.GetTeam()));

			if (bEnemy)
				enemies.push_back(ply);
			else
				teammates.push_back(ply);

			[add_junk 1 5 /]
		}

		switch (pCSGO->m_Config.m_ChatspamOptions.m_Method)
		{
			case ChatspamMethod::SPAM_INFORMATION_TEAMMATES:
			{
				[add_junk 1 5 /]

				if (teammates.empty())
					return{};

				if (teamIndex > (int)teammates.size() - 1)
					teamIndex = 0;

				[swap_lines]
				std::string name = teammates[teamIndex].GetName();
				int health = teammates[teamIndex].GetHealth();
				[/swap_lines]

				[add_junk 1 5 /]

				teamIndex++;

				sprintf_s<sizeof(str)>(str, "%s is chillin on %s with %d health, lmao.", name.c_str(), pCSGO->GetMapName().c_str(), health);
				[add_junk 1 5 /]
				return std::string(str);
				break;
			}
			case ChatspamMethod::SPAM_INFORMATION_ENEMIES:
			{
				if (enemies.empty())
					return {};

				if (enemyIndex > (int)enemies.size() - 1)
					enemyIndex = 0;

				std::string name = enemies[enemyIndex].GetName();
				[add_junk 1 5 /]
				int health = enemies[enemyIndex].GetHealth();

				enemyIndex++;

				sprintf_s<sizeof(str)>(str, "%s is chillin on %s with %d health, lmao.", name.c_str(), pCSGO->GetMapName().c_str(), health);
				[add_junk 1 5 /]
				return std::string(str);
				break;
			}
		}

		return {};
	}

	std::string GetAdvertisementSpam()
	{
		if (adIndex > (int)m_vAdvertisements.size() - 1)
			adIndex = 0;

		[add_junk 1 5 /]

		return m_vAdvertisements[adIndex++];
	}

	std::string GetTextFileSpam()
	{
		if (!pCSGO->m_Config.m_ChatspamOptions.m_bRandomParse && pCSGO->m_Config.m_ChatspamOptions.m_vParseLines.size() > 0)
		{
			if (parseIndex > (int)pCSGO->m_Config.m_ChatspamOptions.m_vParseLines.size() - 1)
				parseIndex = 0;

			[add_junk 1 5 /]

			return pCSGO->m_Config.m_ChatspamOptions.m_vParseLines[parseIndex++];
		}
		else
		{
			rand();
			[add_junk 1 5 /]
			int randomLine = rand() % pCSGO->m_Config.m_ChatspamOptions.m_vParseLines.size();

			if (randomLine >= 0 && randomLine <= (int)pCSGO->m_Config.m_ChatspamOptions.m_vParseLines.size() - 1)
				return pCSGO->m_Config.m_ChatspamOptions.m_vParseLines[randomLine];

			[add_junk 1 5 /]
		}

		return {};
	}

	void Start()
	{
		while (true)
		{
			if (pCSGO == nullptr)
			{
				LOGD << "pCSGO was nullptr! Ending thread!";
				[add_junk 1 5 /]
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopChatspam)
			{
				LOGD << "Chatspam bool was true, Ending thread!";
				[add_junk 1 5 /]
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopChatspam = true;

			[add_junk 1 5 /]

			if (!pCSGO->m_Config.m_ChatspamOptions.m_bEnabled)
				continue;

			if (!pCSGO->IsInGame())
				continue;

			char str[255];
			strcpy_s<sizeof(str)>(str, "say ");
			[add_junk 1 5 /]

			switch (pCSGO->m_Config.m_ChatspamOptions.m_Method)
			{
				case ChatspamMethod::SPAM_ADVERTISEMENT:
				{
					strcat_s<sizeof(str)>(str, GetAdvertisementSpam().c_str());
					pCSGO->ClientCMD(str);
					[add_junk 1 5 /]
					std::this_thread::sleep_for(std::chrono::seconds(pCSGO->m_Config.m_ChatspamOptions.m_nChatInterval));
					break;
				}
				case ChatspamMethod::SPAM_INFORMATION_TEAMMATES:
				case ChatspamMethod::SPAM_INFORMATION_ENEMIES:
				{
					strcat_s<sizeof(str)>(str, GetInformationSpam().c_str());
					[add_junk 1 5 /]
					pCSGO->ClientCMD(str);
					std::this_thread::sleep_for(std::chrono::seconds(pCSGO->m_Config.m_ChatspamOptions.m_nChatInterval));
					break;
				}
				case ChatspamMethod::SPAM_CUSTOMFILE:
				{
					strcat_s<sizeof(str)>(str, GetTextFileSpam().c_str());
					pCSGO->ClientCMD(str);
					[add_junk 1 5 /]
					std::this_thread::sleep_for(std::chrono::seconds(pCSGO->m_Config.m_ChatspamOptions.m_nChatInterval));
					break;
				}
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 5 /]
		}
	}

	// Our set of lines to advertise our hack
	std::vector<std::string> m_vAdvertisements;

	// Our current advertisement index
	static int adIndex;
	// Our current parsed file index
	static int parseIndex;
	// Our current teammate index
	static int teamIndex;
	// Our current enemy index
	static int enemyIndex;
};

extern std::shared_ptr<Chatspam> pChatSpam(new Chatspam);

int Chatspam::adIndex = 0;
int Chatspam::parseIndex = 0;
int Chatspam::teamIndex = 0;
int Chatspam::enemyIndex = 0;

[junk_disable /]
[enc_string_disable /]