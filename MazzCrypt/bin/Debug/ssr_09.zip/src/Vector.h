// Vector.h - Linear Algebra I. 
#pragma once

#include "stdafx.h"
#include "Math.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

class Vector
{

public:

	// Data members
	float x, y, z;

	// Ctors
	inline Vector() : x(0.0f), y(0.0f), z(0.0f)
	{
		[add_junk 1 4 /]
	}

	inline Vector(float fX, float fY, float fZ) : x(fX), y(fY), z(fZ)
	{
		[add_junk 1 4 /]
	}

	inline Vector(const Vector& v) : x(v.x), y(v.y), z(v.z)
	{
		[add_junk 1 4 /]
	}

	inline Vector(float num[3]) : x(num[0]), y(num[1]), z(num[2])
	{
		[add_junk 1 4 /]
	}

	inline void PrintInfo()
	{
		printf_s("%f | %f | %f", x, y, z);
		[add_junk 1 4 /]
	}

	inline void ZeroOut()
	{
		x = y = z = 0.0f;
		[add_junk 1 4 /]
	}

	inline float Length()
	{
		[add_junk 1 4 /]
		return (float)Math::FastSQRT(x*x + y*y + z*z);
	}

	inline float DotProduct(Vector v)
	{
		[add_junk 1 4 /]
		return (x * v.x + y * v.y + z * v.z);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();
		[add_junk 1 4 /]

		[swap_lines]
		x *= l;
		y *= l;
		z *= l;
		[/swap_lines]
	}

	inline float ToDegree(Vector to)
	{
		[add_junk 1 4 /]
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		[add_junk 1 4 /]
		return *(&x + i);
	}

	inline Vector operator+(const Vector& v)
	{
		[add_junk 1 4 /]
		return Vector(x + v.x, y + v.y, z + v.z);
	}

	inline void operator+= (const Vector& v)
	{
		[swap_lines]
		x += v.x;
		y += v.y;
		z += v.z;
		[/swap_lines]

		[add_junk 1 4 /]
	}

	inline Vector operator+= (const float f)
	{
		[add_junk 1 4 /]
		return Vector(x += f, y += f, z += f);
	}


	inline Vector operator-(const Vector& v)
	{
		[add_junk 1 4 /]
		return Vector(x - v.x, y - v.y, z - v.z);
	}

	inline void operator-=(const Vector& v)
	{
		[add_junk 1 4 /]
		x -= v.x;
		y -= v.y;
		[add_junk 1 4 /]
		z -= v.z;
	}

	inline Vector operator-=(const float f)
	{
		[add_junk 1 4 /]
		return Vector(x -= f, y -= f, z -= f);
	}

	inline Vector operator*(const float f)
	{
		[add_junk 1 4 /]
		return Vector(x * f, y * f, z * f);
	}

	inline void operator*=(const float f)
	{
		[swap_lines]
		x *= f;
		y *= f;
		[/swap_lines]

		[add_junk 1 4 /]
		z *= f;
	}

	inline Vector operator/(const float f)
	{
		[add_junk 1 4 /]
		return Vector(x / f, y / f, z / f);
	}

	inline void operator/=(const float f)
	{
		x /= f;
		[add_junk 1 4 /]

		[swap_lines]
		y /= f;
		z /= f;
		[/swap_lines]
	}

	inline void operator=(const float* f)
	{
		[swap_lines]
		x = f[0];
		y = f[1];
		z = f[2];
		[/swap_lines]

		[add_junk 1 4 /]
	}

	inline void operator=(const float& f)
	{
		x = y = z = f;
		[add_junk 1 4 /]
	}

	inline bool operator==(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x == v.x && y == v.y && z == v.z);
	}

	inline bool operator!=(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x != v.x && y != v.y && z != v.z);
	}

	inline bool operator<=(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x <= v.x && y <= v.y && z <= v.z);
	}

	inline bool operator>=(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x >= v.x && y >= v.y && z >= v.z);
	}

	inline bool operator>(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x > v.x && y > v.y && z > v.z);
	}

	inline bool operator<(const Vector& v)
	{
		[add_junk 1 4 /]
		return (x < v.x && y < v.y && z < v.z);
	}
};

class Vector2D
{

public:

	// Data members
	float x, y;

	// Ctors
	inline Vector2D() : x(0.0f), y(0.0f)
	{
		[add_junk 1 4 /]
	}

	inline Vector2D(float fX, float fY) : x(fX), y(fY)
	{
		[add_junk 1 4 /]
	}

	inline Vector2D(const Vector2D& v) : x(v.x), y(v.y)
	{
		[add_junk 1 4 /]
	}

	inline Vector2D(float num[2]) : x(num[0]), y(num[1])
	{
		[add_junk 1 4 /]
	}

	inline void PrintInfo()
	{
		printf_s("%f | %f", x, y);
		[add_junk 1 4 /]
	}

	inline void ZeroOut()
	{
		x = y = 0.0f;
		[add_junk 1 4 /]
	}

	inline float Length()
	{
		[add_junk 1 4 /]
		return (float)Math::FastSQRT(x*x + y*y);
	}

	inline float DotProduct(Vector2D v)
	{
		return (x * v.x + y * v.y);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();
		x *= l;
		[add_junk 1 4 /]
		y *= l;
	}

	inline float ToDegree(Vector2D to)
	{
		[add_junk 1 4 /]
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		[add_junk 1 4 /]
		return *(&x + i);
	}

	inline Vector2D operator+(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return Vector2D(x + v.x, y + v.y);
	}

	inline void operator+= (const Vector2D& v)
	{
		x += v.x;
		[add_junk 1 4 /]
		y += v.y;
	}

	inline Vector2D operator-(const Vector2D& v)
	{
		return Vector2D(x - v.x, y - v.y);
	}

	inline void operator-=(const Vector2D& v)
	{
		[swap_lines]
		x -= v.x;
		y -= v.y;
		[/swap_lines]

		[add_junk 1 4 /]
	}

	inline Vector2D operator*(const float f)
	{
		[add_junk 1 4 /]
		return Vector2D(x * f, y * f);
	}

	inline void operator*=(const float f)
	{
		x *= f;
		y *= f;
		[add_junk 1 4 /]
	}

	inline Vector2D operator/(const float f)
	{
		return Vector2D(x / f, y / f);
	}

	inline void operator/=(const float f)
	{
		x /= f;
		[add_junk 1 4 /]
		y /= f;
	}

	inline void operator=(const float* f)
	{
		x = f[0];
		[add_junk 1 4 /]
		y = f[1];
	}

	inline void operator=(const float& f)
	{
		x = y = f;
		[add_junk 1 4 /]
	}

	inline bool operator==(const Vector2D& v)
	{
		return (x == v.x && y == v.y);
	}

	inline bool operator!=(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return (x != v.x && y != v.y);
	}

	inline bool operator<=(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return (x <= v.x && y <= v.y);
	}

	inline bool operator>=(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return (x >= v.x && y >= v.y);
	}

	inline bool operator>(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return (x > v.x && y > v.y);
	}

	inline bool operator<(const Vector2D& v)
	{
		[add_junk 1 4 /]
		return (x < v.x && y < v.y);
	}
};

[junk_disable /]
[enc_string_disable /]