// RCS.h - RCS (Recoil Control System) cheat thread
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

[junk_enable /]

class RCS
{
public:

	RCS() = default;
	~RCS() = default;

	// Thread routine
	void Start()
	{
		Vector2D oldPunch(0, 0);

		while (true)
		{
			[add_junk 1 7 /]
			if (pCSGO == nullptr)
			{
				LOGD << "pCSGO was nullptr! Ending thread!";
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopRCS)
			{
				LOGD << "RCS bool was true, Ending thread!";
				[add_junk 1 7 /]
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = true;

			[add_junk 1 7 /]

			if (!pCSGO->IsInGame())
				continue;

			if (!m_bActive)
				continue;

			Vector2D punch = pCSGO->m_Mem.Read<Vector2D>(pCSGO->m_Me.m_dwBaseAddr + pCSGO->m_Offsets.m_dwPunchAngles);
			Vector newAngles;
			[add_junk 1 7 /]

			if (pCSGO->m_Me.IsShooting() && pCSGO->m_Me.GetShotsFired() > 1)
			{
				Vector curAngles = pCSGO->m_Mem.Read<Vector>(pCSGO->m_dwAnglePointer + pCSGO->m_Offsets.m_dwViewAngles);

				newAngles.x = ((curAngles.x + oldPunch.x) - (punch.x * 2.0f * m_fRCSScale));
				[add_junk 1 7 /]
				newAngles.y = ((curAngles.y + oldPunch.y) - (punch.y * 2.0f * m_fRCSScale));

				Math::ClampAngles(newAngles);

				[swap_lines]
				oldPunch.x = punch.x * 2.0f * m_fRCSScale;
				oldPunch.y = punch.y * 2.0f * m_fRCSScale;
				[/swap_lines]

				[add_junk 1 7 /]

				pCSGO->SetAngles(newAngles);

				Sleep(1);
			}
			else
			{
				oldPunch = Vector2D(0, 0);
				[add_junk 1 7 /]
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 7 /]
		}
	}

	static float m_fRCSScale;
	static bool m_bActive;
};

// extern
extern std::shared_ptr<RCS> pRCS(new RCS);

// Statics
float RCS::m_fRCSScale = 1.0f;
bool RCS::m_bActive = true;

[junk_disable /]