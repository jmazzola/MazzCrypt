// Memory.h - Handle all memory accessing/writing and keep a process for neatness to the game's core
#pragma once

#include "stdafx.h"
#include <TlHelp32.h>

#define BYTE_TO_CHECK 's'

[junk_enable /]

class Memory
{
public:

	Memory() = default;
	~Memory() = default;

	// Attach to the process
	bool Attach(const char* szProcName, DWORD dwRights = PROCESS_ALL_ACCESS);

	// Detach from the process and cleanup
	void Detach();

	// Grab a module's base address
	DWORD GetModuleBase(const char* szModName);

	// Grab a module's size
	DWORD GetModuleSize(const char* szModName);

	// Return our handle we're using
	HANDLE GetHandle() const;

	// Return if we're attached to the process
	bool IsAttached() const;

	// Return our process ID
	DWORD GetProcessID() const;

	// Read Memory
	// [in] - dwAddr - The address we're reading
	template<typename T>
	T Read(DWORD dwAddr)
	{
		T mem;
		[add_junk 1 3 /]
		ReadProcessMemory(m_hProcess, (LPVOID)dwAddr, &mem, sizeof(T), NULL);

		return mem;
	}

	// Read Custom Memory
	// [in] - dwAddr - The address we're reading
	// [out] - buff - The data we want
	// [in] - bytesToRead - how many bytes to read
	void inline Read(DWORD dwAddr, LPVOID buff, size_t bytesToRead)
	{
		[add_junk 1 3 /]
		ReadProcessMemory(m_hProcess, (LPCVOID)dwAddr, buff, bytesToRead, NULL);
	}

	// Read Protected Memory
	// [in] - dwAddr - The address we're reading
	template<typename T>
	T inline ReadProtected(DWORD addr)
	{
		T mem;
		DWORD oldProtect;
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		[add_junk 1 3 /]
		mem = Read(addr);
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), oldProtect, NULL);
		[add_junk 1 3 /]
		return mem;
	}

	// Write Memory
	// [in] - dwAddr - The address we're writing to
	// [in] - data - The data we're writing
	template<typename T>
	void inline Write(DWORD dwAddr, T data)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)dwAddr, &data, sizeof(T), NULL);
		[add_junk 1 3 /]
	}

	// Write Protected Memory
	// [in] - dwAddr - The address we're writing to
	// [in] - data - The data we're writing
	template<typename T>
	void inline WriteProtected(DWORD dwAddr, T data)
	{
		DWORD oldProtect;
		VirtualProtectEx(m_hProcess, (LPVOID)dwAddr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		Write(dwAddr, data);
		[add_junk 1 3 /]
		VirtualProtectEx(m_hProcess, (LPVOID)dwAddr, sizeof(T), oldProtect, NULL);
	}

	// Write Custom Memory
	// [in] - dwAddr - The address we're writing to
	// [in] - buff - The data we're sending
	// [in] - bytesToWrite - How many bytes to write
	void inline Write(DWORD addr, LPCVOID buff, size_t bytesToWrite)
	{
		[add_junk 1 3 /]
		WriteProcessMemory(m_hProcess, (LPVOID)addr, buff, bytesToWrite, NULL);
	}

	// Write String (for shellcode)
	// [in] - addr - The address at where we're writing
	// [in] - str - The string we're writing to
	void inline WriteString(LPVOID addr, LPCSTR str)
	{
		WriteProcessMemory(m_hProcess, addr, str, strlen(str) + 1, NULL);
		[add_junk 1 3 /]
	}

	// Virtually Allocate Memory
	// [in] - dwSize - The amount of memory to allocate
	// [in] - dwFlags - Flags to pass in
	LPVOID inline Allocate(DWORD dwSize, DWORD dwFlags = PAGE_EXECUTE_READWRITE)
	{
		[add_junk 1 3 /]
		return VirtualAllocEx(m_hProcess, NULL, dwSize, MEM_RESERVE | MEM_COMMIT, dwFlags);
	}

	// Virtually Free Memory
	// [in] - lpAddr - The address to free
	// [in] - dwSize - The amount of memory to free
	void inline Free(LPVOID lpAddr, DWORD dwSize = NULL)
	{
		VirtualFreeEx(m_hProcess, lpAddr, dwSize, MEM_RELEASE);
		[add_junk 1 3 /]
	}

	// Create a Remote Thread
	// [in] - lpAddr - The address to use for the thread
	// [in] - param - The parameter
	HANDLE inline MakeRemoteThread(LPVOID lpAddr, LPVOID param = nullptr, int dwSize = NULL)
	{
		[add_junk 1 3 /]
		return CreateRemoteThread(m_hProcess, NULL, dwSize, (LPTHREAD_START_ROUTINE)lpAddr, param, NULL, NULL);
	}

	// Signature scanning - Compare bytes to a mask
	bool DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask);

	// Signature scanning - Return the address of a signature
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask);
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern);


private:
	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

};

[junk_disable /]