#pragma once

#include "stdafx.h"
#include "Config.h"
#include "Offsets.h"
#include "Memory.h"
#include "Player.h"

[junk_enable /]

#define m_Me m_Players[0]

class CSGO
{
public:

	CSGO() = default;
	~CSGO() = default;

	// Attach to CSGO
	bool Attach();

	// Detach from CSGO
	void Detach();

	void GrabStudioHdrPtr();

	// Load the base offsets
	bool LoadBases();

	void ClearBases();

	// Update Tick
	void Update();

	// Are we in game?
	bool IsInGame();

	// Is this class ID a weapon?
	bool IsClassIDAWeapon(int classID);
	
	// Is this class ID a grenade?
	bool IsClassIDAGrenade(int classID);

	// Is this class ID a knife?
	bool IsClassIDAKnife(int classID);

	int GetEnemyTeam(int myTeam);

	// What map are we currently on?
	std::string GetMapName();

	// Get our game directory path
	std::string GetGameDirectory();

	// Is the bomb planted on the map?
	bool IsBombPlanted() const;

	// Is the bomb dropped on the map?
	bool IsBombDropped() const;

	// Set our viewangles
	void SetAngles(Vector& vAngles);

	// Send packets
	void SendPacket(bool bPacket);

	// Set frameBuf
	void SetFrameBuf(bool bTeleport);

	// Force Full Update
	void ForceFullUpdate();

	// call InputSystem SleepUntilInput
	void SleepUntilInput(int ms);

	// call IVEngineClient->ClientCMD
	void ClientCMD(char* cmd);

public:

	[swap_lines]
	Memory m_Mem;
	Config m_Config;
	std::array<Player, 64> m_Players;
	std::array<float, 16> m_flViewMatrix;
	DWORD m_dwClientBase;
	DWORD m_dwEngineBase;
	DWORD m_dwLocalBase;
	DWORD m_dwEntityBase;
	DWORD m_dwBoneMatrix;
	DWORD m_dwAnglePointer;
	DWORD m_dwStudioHdrPointer;
	DWORD m_dwGlowObjectBase;
	DWORD m_dwGlobalVarsPointer;
	DWORD m_dwGameRulesProxyPointer;
	DWORD m_dwInputSystemPointer;
	Offsets m_Offsets;
	int m_iWindowWidth;
	int m_iWindowHeight;
	[/swap_lines]

	[add_junk_datamembers 1 6 /]
};

extern std::shared_ptr<CSGO> pCSGO;

[junk_disable /]