#include "Hitboxes.h"
#include "CSGO.h"

[junk_enable /]

std::unique_ptr<Hitboxes> pHitboxes(new Hitboxes);

#define NUM_HITBOXES 20

mstudiobbox_t::mstudiobbox_t()
{
	[swap_lines]
	m_iBone = m_iGroup = 0;
	m_vecBBMax = m_vecBBMin = Vector(0, 0, 0);
	m_iHitboxNameIndex = -1;
	m_flRadius = -1.0f;
	[/swap_lines]
}

bool Hitboxes::LoadModelHitboxes(const std::string & strModelName, DWORD pStudioHdr)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	[add_junk 1 4 /]

	if (strModelName.empty() || !pStudioHdr)
		return false;

	[add_junk 1 4 /]

	for (auto& map_data : m_mapModelHitboxes)
	{
		if (!strModelName.compare(map_data.first))
			return true;
	}

	DWORD iHitBoxSetIndex = pCSGO->m_Mem.Read<DWORD>(pStudioHdr + 0xB0);
	[add_junk 1 4 /]
	DWORD pStudioHitboxSet = pStudioHdr + iHitBoxSetIndex;
	[add_junk 1 4 /]
	DWORD iNumHitboxes = pCSGO->m_Mem.Read<DWORD>(pStudioHitboxSet + 0x4);

	if (iNumHitboxes != NUM_HITBOXES)
	{
		[add_junk 1 4 /]
		return false;
	}

	DWORD iHitboxIdx = pCSGO->m_Mem.Read<DWORD>(pStudioHitboxSet + 0x8);

	std::vector<mstudiobbox_t> vStudioHitboxes;
	vStudioHitboxes.reserve(iNumHitboxes);
	[add_junk 1 4 /]

	for (DWORD i = 0; i < iNumHitboxes; i++)
	{
		mstudiobbox_t studioHitbox;
		[add_junk 1 4 /]
		studioHitbox = pCSGO->m_Mem.Read<mstudiobbox_t>(sizeof(mstudiobbox_t) * i + iHitboxIdx + pStudioHitboxSet);

		if (studioHitbox.m_flRadius != -1.0f)
		{
			[swap_lines]
			studioHitbox.m_vecBBMin -= studioHitbox.m_flRadius;
			studioHitbox.m_vecBBMax += studioHitbox.m_flRadius;
			[/swap_lines]
		}

		vStudioHitboxes.push_back(studioHitbox);
		[add_junk 1 4 /]
	}

	if (vStudioHitboxes.empty())
		return false;

	m_mapModelHitboxes.insert(std::pair< std::string, std::vector< mstudiobbox_t > >(strModelName, vStudioHitboxes));
	[add_junk 1 4 /]

	return true;
}

std::vector<mstudiobbox_t> Hitboxes::GetModelHitboxes(const std::string & strModelName) const
{
	std::lock_guard< std::mutex > lock(m_mutex);

	if (strModelName.empty())
		return {};

	[add_junk 1 4 /]

	for (auto& map_data : m_mapModelHitboxes)
	{
		[add_junk 1 4 /]
		
		if (!strModelName.compare(map_data.first))
			return map_data.second;
	}

	return {};
}

[junk_disable /]