// CreateMoveHook.h - Experiment of CreateMove hooking externally
#pragma once

#include "stdafx.h"
#include "CSGO.h"

namespace CreateMove
{
	void InitializeVirtuals();

}