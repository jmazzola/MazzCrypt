#include "Memory.h"

[junk_enable /]

bool Memory::Attach(const char* szProcName, DWORD dwRights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	[add_junk 1 9 /]
	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)szProcName))
		{
			m_dwProcessID = entry.th32ProcessID;
			[add_junk 1 9 /]
			CloseHandle(handle);

			[swap_lines]
			m_hProcess = OpenProcess(dwRights, false, m_dwProcessID);
			m_bAttached = true;
			[/swap_lines]

			[add_junk 1 9 /]

			return true;
		}

	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	CloseHandle(handle);
	[add_junk 1 9 /]
	LOGE << "Failed to attach to " << szProcName << " !";
	return false;
}

void Memory::Detach()
{
	[swap_lines]
	CloseHandle(m_hProcess);
	m_bAttached = false;
	m_dwProcessID = -1;
	[/swap_lines]

	[add_junk 1 9 /]
}

DWORD Memory::GetModuleBase(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	MODULEENTRY32 entry;
	[add_junk 1 9 /]
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			[add_junk 1 9 /]
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	CloseHandle(handle);
	LOGE << "Failed to get the module base address of " << szModName << " !";
	[add_junk 1 9 /]
	return NULL;
}

DWORD Memory::GetModuleSize(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	[add_junk 1 9 /]
	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			[add_junk 1 9 /]
			return entry.modBaseSize;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	[add_junk 1 9 /]
	CloseHandle(handle);
	LOGE << "Failed to get the module size of " << szModName << " !";
	return NULL;
}

HANDLE Memory::GetHandle() const
{
	[add_junk 1 9 /]

	if (!m_bAttached)
		return NULL;

	return m_hProcess;
}


bool Memory::IsAttached() const
{
	[add_junk 1 9 /]
	return m_bAttached;
}


DWORD Memory::GetProcessID() const
{
	[add_junk 1 9 /]
	return m_dwProcessID;
}

bool Memory::DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask)
{
	[add_junk 1 9 /]
	for (; *szMask; ++szMask, ++pbData, ++pbMask)
	{
		[add_junk 1 9 /]

		if (*szMask == BYTE_TO_CHECK && *pbData != *pbMask)
			return false;
	}

	return (*szMask == NULL);
}

DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask)
{
	PBYTE data = new BYTE[dwSize];

	unsigned long bytesRead;
	[add_junk 1 9 /]
	if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead))
	{
		delete[] data;
		[add_junk 1 9 /]
		data = nullptr;
		return NULL;
	}

	for (DWORD i = 0; i < dwSize; i++)
	{
		if (DataCompare((const BYTE*)(data + i), szSig, szMask))
		{
			delete[] data;
			[add_junk 1 9 /]
			data = nullptr;
			return dwStart + i;
		}
	}

	delete[] data;
	data = nullptr;
	[add_junk 1 9 /]
	return NULL;
}

DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern)
{
	std::string szMask;
	[add_junk 1 9 /]
	szMask.resize(nCount);

	for (int i = 0; i < nCount; i++)
		(pbPattern[i]) ? szMask[i] = BYTE_TO_CHECK : szMask[i] = '?';

	return FindPattern(dwStart, dwSize, pbPattern, szMask.c_str());
}

[junk_disable /]