// Fakelag.h - Cheat thread for fake lag
#pragma once

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

namespace FakeLag
{
	void Start()
	{
		while (true)
		{
			if (pCSGO == nullptr)
			{
				[add_junk 1 4 /]
				LOGD << "pCSGO was nullptr! Ending thread!";
				pCSGO->SendPacket(true);
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopFakelag)
			{
				LOGD << "Fakelag bool was true, Ending thread!";
				[add_junk 1 4 /]
				pCSGO->SendPacket(true);
				return;
			}

			if (GetAsyncKeyState(VK_END))
			{
				pCSGO->m_Config.m_ThreadSettings.m_bStopFakelag = true;
				pCSGO->SendPacket(true);
				[add_junk 1 4 /]
			}

			// If we're disabled, we're disabled.
			if (!pCSGO->m_Config.m_FakeLagOptions.m_bEnabled)
				continue;

			// If we're not in game, don't fuck with shit.
			if (!pCSGO->IsInGame())
			{
				pCSGO->SendPacket(true);
				[add_junk 1 4 /]
				continue;
			}

			pCSGO->SendPacket(false);
			[add_junk 1 4 /]
			std::this_thread::sleep_for(std::chrono::milliseconds(pCSGO->m_Config.m_FakeLagOptions.m_nPacketsDropped / 6));
			[add_junk 1 4 /]
			pCSGO->SendPacket(true);

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}
}

[junk_disable /]