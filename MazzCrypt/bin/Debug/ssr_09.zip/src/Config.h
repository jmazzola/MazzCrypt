// Config.h - Our config settings
#pragma once

#include "Structs.h"
#include <fstream>
#include <sstream>

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

// Enums
enum class TargetType
{
	TARGET_ENEMIES,
	TARGET_TEAMMATES,
	TARGET_EVERYONE
};

enum class GlowType
{
	GLOW_VISIBILITY,
	GLOW_VULNERABILITY,
	GLOW_HEALTH,
};

enum class AimMethod
{
	AIM_CLOSESTTOCROSSHAIR,
	AIM_CLOSESTTOPLAYER,
	AIM_LOWESTHP,
	AIM_RAGE
};

enum class ChatspamMethod
{
	SPAM_ADVERTISEMENT,
	SPAM_CUSTOMFILE,
	SPAM_INFORMATION_TEAMMATES,
	SPAM_INFORMATION_ENEMIES,
};

enum class ESPBoxType
{
	ESP_BOXNONE,
	ESP_BOXBOUNDINGSTATIC,
	ESP_BOXBOUNDINGDYNAMIC,
	ESP_BOXCORNER,
	ESP_BOXEDGE,
	ESP_BOX3DOUTLINE,
	ESP_BOX3DFILLED,
};

enum class ESPHealthbarType
{
	ESP_HEALTHBAR_NONE,
	ESP_HEALTHBAR_VLEFT,
	ESP_HEALTHBAR_VRIGHT,
	ESP_HEALTHBAR_INTERWEBZ,
};

enum class AntiAimType_X
{
	AA_X_NONE,
	AA_X_EMOTION,
	AA_X_FAKEDOWN,
	AA_X_UP,
	AA_X_JITTER,
	AA_X_FAKEJITTER,
	AA_X_LISP,
};

enum class AntiAimType_Y
{
	AA_Y_NONE,
	AA_Y_BACKWARDS,
	AA_Y_RIGHT,
	AA_Y_FORWARD,
	AA_Y_LEFT,
	AA_Y_GOLDENRATIOSPIN,
	AA_Y_JITTER,
	AA_Y_LISP,
};

struct ThreadHandling
{
public:
	[swap_lines]
	bool m_bStopUpdate;
	bool m_bStopESP;
	bool m_bStopBhop;
	bool m_bStopRCS;
	bool m_bStopFakelag;
	bool m_bStopTeleport;
	bool m_bStopSkinChanger;
	bool m_bStopAimbot;
	bool m_bStopTriggerbot;
	bool m_bStopChatspam;
	[/swap_lines]
};

struct SkinChangerOptions
{
public:

	struct SkinOptions
	{
	public:

		[swap_lines]
		int m_nPaintKit;
		int m_nStatTrak;
		float m_fWear;
		int m_nSeed;
		char m_szName[32];
		[/swap_lines]
	};

	[swap_lines]
	int m_nRefreshKey;
	SkinOptions m_Glock;
	SkinOptions m_P2000;
	SkinOptions m_USP;
	SkinOptions m_P250;
	SkinOptions m_FiveSeven;
	SkinOptions m_Deagle;
	SkinOptions m_Duelies;
	SkinOptions m_Tec9;
	SkinOptions m_CZ75;
	SkinOptions m_Revolver;
	SkinOptions m_Nova;
	SkinOptions m_XM1014;
	SkinOptions m_SawedOff;
	SkinOptions m_MAG7;
	SkinOptions m_MAC10;
	SkinOptions m_MP7;
	SkinOptions m_MP9;
	SkinOptions m_UMP45;
	SkinOptions m_Bizon;
	SkinOptions m_P90;
	SkinOptions m_Galil;
	SkinOptions m_AK47;
	SkinOptions m_M4A4;
	SkinOptions m_M4A1S;
	SkinOptions m_SG553;
	SkinOptions m_AUG;
	SkinOptions m_FAMAS;
	SkinOptions m_AWP;
	SkinOptions m_SCAR20;
	SkinOptions m_Scout;
	SkinOptions m_GSG31;
	SkinOptions m_M249;
	SkinOptions m_Negev;
	SkinOptions m_Knife;
	SkinOptions m_C4;
	[/swap_lines]
};

struct BhopOptions
{

public:

	[swap_lines]
	bool m_bEnabled;
	bool m_bAntiSMAC;
	[/swap_lines]
};

struct GlowOptions
{

public:

	[swap_lines]
	TargetType m_TargetType;
	GlowType m_GlowType;
	float m_fMaxDist;
	bool m_bBombs;
	bool m_bDroppedWeapons;
	bool m_bThrownProjs;
	bool m_bFlashed;
	bool m_bBombInteraction;
	bool m_bBombHint;
	bool m_bBombCarrier;
	Color m_clrEnemies;
	Color m_clrTeammates;
	Color m_clrEnemiesNotVisible;
	Color m_clrTeammatesNotVisible;
	Color m_clrBomb;
	Color m_clrDroppedWeapons;
	Color m_clrThrownProjs;
	Color m_clrBombInteraction;
	Color m_clrBombCarrier;
	[/swap_lines]

};

struct ESPOptions
{

public:
	[swap_lines]
	bool m_bEnabled;
	bool m_bGlow;
	GlowOptions m_tGlowOptions;
	[/swap_lines]
};

struct FakelagOptions
{

public:

	[swap_lines]
	bool m_bEnabled;
	int m_nPacketsDropped;
	[/swap_lines]
};

struct TeleportOptions
{

public:

	bool m_bEnabled;
};

struct AimbotOptions
{
public:
	struct WeaponSettings
	{
		[swap_lines]
		int m_nHitbox;
		float m_fRCSScale;
		[/swap_lines]
	};

	[swap_lines]
	bool m_bEnabled;
	TargetType m_TargetType;
	float m_fFOV;
	AimMethod m_Method;
	[/swap_lines]

};

struct TriggerbotOptions
{

};

struct ChatspamOptions
{

public:

	bool Load(std::string fileName)
	{
		m_vParseLines.clear();

		[add_junk 1 5 /]

		std::ifstream parseFile;
		parseFile.open("chat.txt");

		std::string curLine;

		if (!parseFile.is_open() || !parseFile.good())
		{
			parseFile.close();
			[add_junk 1 5 /]
			LOGE << "Loading chat.txt failed with error: " << GetLastError();
			return false;
		}

		while (std::getline(parseFile, curLine))
			m_vParseLines.push_back(curLine);

		parseFile.close();
		[add_junk 1 5 /]

		return true;
	}
	
	[swap_lines]
	bool m_bEnabled;
	bool m_bRandomParse;
	ChatspamMethod m_Method;
	int m_nChatInterval;
	std::vector<std::string> m_vParseLines;
	std::string m_szHash;
	[/swap_lines]
};

struct Hotkeys
{
	[swap_lines]
	int m_nToggleBhop;
	int m_nToggleFakelag;
	int m_nToggleESP;
	int m_nToggleChatspam;
	int m_nRestartChatspam;
	int m_nToggleAimbot;
	int m_nHoldAimbot;
	int m_nToggleTrig;
	int m_nHoldTrig;
	[/swap_lines]
};

class Config
{
public:

	Config() = default;
	~Config() = default;

	void Init(std::string szConfigName);

	std::string GetHash(std::string szFile = "");

	bool LoadConfig();

	bool SaveConfig();

	int GetInt(char* section, char* option);
	float GetFloat(char* section, char* option);
	std::string GetString(char* section, char* option);
	bool GetBool(char* section, char* option);
	std::vector<int> GetCommaSeperatedInts(char* section, char* option);
	int GetKey(char* section, char* option);
	Color GetColor(char* section, char* option);

	void SetInt(char* section, char* option, int nValue);
	void SetFloat(char* section, char* option, float fValue);
	void SetString(char* section, char* option, std::string szValue);
	void SetBool(char* section, char* option, bool bValue);
	void SetCommaSeperatedInts(char* section, char* option, std::vector<int> vValue);
	void SetKey(char* section, char* option, int nKey);
	void SetColor(char* section, char* option, Color color);

public:

	[swap_lines]
	std::string m_szHash;
	Hotkeys m_Keys;
	ThreadHandling m_ThreadSettings;
	BhopOptions m_BhopOptions;
	FakelagOptions m_FakeLagOptions;
	TeleportOptions m_TeleportOptions;
	ESPOptions m_EspOptions;
	SkinChangerOptions m_SkinChangerOptions;
	ChatspamOptions m_ChatspamOptions;
	[/swap_lines]

private:

	std::string m_szConfigFile;
	[add_junk_datamembers 1 10 /]
};

[junk_disable /]
[enc_string_disable /]