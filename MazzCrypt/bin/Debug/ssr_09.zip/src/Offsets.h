#pragma once

#include "stdafx.h"

[junk_enable /]

class Offsets
{
public:

	Offsets() = default;
	~Offsets() = default;

	// Load and scan the offsets
	void Init();

	// Load and grab our netvars
	void LoadNetvars();


public:
	[swap_lines]
	DWORD m_dwEntityList;
	DWORD m_dwLocalPlayer;
	DWORD m_dwEnginePtr;
	DWORD m_dwViewAngles;
	DWORD m_dwViewMatrix;
	DWORD m_dwCrosshairIndex;
	DWORD m_dwPunchAngles;
	DWORD m_dwNetvarClasses;
	DWORD m_dwCanReload;
	DWORD m_dwPlayerInfo;
	DWORD m_dwAttack;
	DWORD m_dwJump;
	DWORD m_dwMoveType;
	DWORD m_dwStudioHdrPtr;
	DWORD m_dwMapName;
	DWORD m_dwGameDirectory;
	DWORD m_dwSendPacket;
	DWORD m_dwFrameBuf;
	DWORD m_dwClientCMD;
	DWORD m_dwGlowArray;
	DWORD m_dwGlobalVars;
	DWORD m_dwGameResources;
	DWORD m_dwFlashBangTime;
	DWORD m_dwGameRulesProxyPtr;
	DWORD m_dwInputSystemPtr;
	DWORD m_dwSignOnState = 0x100;
	DWORD m_dwEntIndex = 0x64;
	DWORD m_dwDormant = 0xE9;
	DWORD m_dwModel = 0x6C;
	DWORD m_dwForceFullUpdate = 0x16C;
	DWORD m_dwNetvar_iHealth;
	DWORD m_dwNetvar_iTeamNum;
	DWORD m_dwNetvar_fFlags;
	DWORD m_dwNetvar_vecViewOffset;
	DWORD m_dwNetvar_vecVelocity;
	DWORD m_dwNetvar_vecOrigin;
	DWORD m_dwNetvar_iClip1;
	DWORD m_dwNetvar_bInReload;
	DWORD m_dwNetvar_iObserverMode;
	DWORD m_dwNetvar_iObserverTarget;
	DWORD m_dwNetvar_iShotsFired;
	DWORD m_dwNetvar_hActiveWeapon;
	DWORD m_dwNetvar_AttributeManager;
	DWORD m_dwNetvar_Item;
	DWORD m_dwNetvar_iItemDefinitionIndex;
	DWORD m_dwNetvar_boneMatrix;
	DWORD m_dwNetvar_immuneTime;
	DWORD m_dwNetvar_bIsScoped;
	DWORD m_dwNetvar_flFlashDuration;
	DWORD m_dwNetvar_iItemIDLow;
	DWORD m_dwNetvar_OriginalOwnerXuidLow;
	DWORD m_dwNetvar_OriginalOwnerXuidHigh;
	DWORD m_dwNetvar_iAccountID;
	DWORD m_dwNetvar_nFallbackStatTrak;
	DWORD m_dwNetvar_nFallbackSeed;
	DWORD m_dwNetvar_nFallbackPaintKit;
	DWORD m_dwNetvar_flFallbackWear;
	DWORD m_dwNetvar_szCustomName;
	DWORD m_dwNetvar_bBombTicking;
	DWORD m_dwNetvar_flC4Blow;
	DWORD m_dwNetvar_nTickBase;
	DWORD m_dwNetvar_iCompetitiveRanking;
	DWORD m_dwNetvar_iCompetitiveWins;
	DWORD m_dwNetvar_iPlayerC4;
	DWORD m_dwNetvar_flNextAttack;
	DWORD m_dwNetvar_bDuckOverride;
	DWORD m_dwNetvar_bIsDefusing;
	DWORD m_dwNetvar_bInBombZone;
	DWORD m_dwNetvar_hOwnerEntity;
	DWORD m_dwNetvar_bBombPlanted;
	DWORD m_dwNetvar_bBombDropped;
	[/swap_lines]

	[add_junk_datamembers 1 10 /]
};

[junk_disable /]