#include "Config.h"
#include "Utils.h"
#include "Enums.h"
#include <Wincrypt.h>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <tchar.h>

#include "Decrypt.h"

[junk_enable /]

// Set the config file
void Config::Init(std::string szConfigName)
{
	[add_junk 1 5 /]
	m_szConfigFile = szConfigName;
}

// Get hash of the file
std::string Config::GetHash(std::string szFile)
{
	if (szFile == "")
		szFile = m_szConfigFile;

	[add_junk 1 5 /]

	HANDLE hFile = CreateFile(szFile.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	[swap_lines]
	HCRYPTPROV hProv;
	HCRYPTHASH hHash;
	DWORD cbHash = 16;
	BYTE rgbHash[16];
	CHAR rgbDigits[] = "0123456789abcdef";
	[/swap_lines]

	if (hFile == INVALID_HANDLE_VALUE)
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		[add_junk 1 5 /]
		Utils::PrintLine(std::string("Error reading in .ini"));
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		[add_junk 1 5 /]

		[enc_string_enable /]
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
		[add_junk 1 5 /]
		[enc_string_disable /]
	}

	[swap_lines]
	BOOL bResult = FALSE;
	DWORD cbRead;
	BYTE rgbFile[1024];
	[/swap_lines]

	[add_junk 1 5 /]

	while (bResult = ReadFile(hFile, rgbFile, 1024, &cbRead, NULL))
	{
		if (!cbRead)
		{
			[add_junk 1 5 /]
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			[enc_string_enable /]
			int dwStatus = GetLastError();
			Utils::PrintLine(std::string("Error with CryptHashData"));
			CryptReleaseContext(hProv, 0);
			CryptDestroyHash(hHash);
			[add_junk 1 5 /]
			CloseHandle(hFile);
			return std::string("ERROR");
			[enc_string_disable /]
		}
	}

	if (!bResult)
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("ReadFile failed"));
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		[add_junk 1 5 /]
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			[add_junk 1 5 /]
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);
		}
	}

	CryptReleaseContext(hProv, 0);
	CryptDestroyHash(hHash);
	[add_junk 1 5 /]
	CloseHandle(hFile);

	return hashOutput;
}

[enc_string_enable /]

bool Config::LoadConfig()
{
	[add_junk 1 5 /]

	[swap_lines]
	m_szHash = GetHash();

	m_Keys.m_nToggleBhop = GetKey("bhop", "togglekey");
	m_Keys.m_nToggleFakelag = GetKey("fakelag", "togglekey");
	m_Keys.m_nToggleESP = GetKey("esp", "togglekey");
	m_Keys.m_nToggleChatspam = GetKey("chatspam", "togglekey");
	m_Keys.m_nRestartChatspam = GetKey("chatspam", "restartkey");

	m_BhopOptions.m_bEnabled = GetBool("bhop", "activated");
	m_BhopOptions.m_bAntiSMAC = GetBool("bhop", "anti_smac");

	m_FakeLagOptions.m_bEnabled = GetBool("fakelag", "activated");
	m_FakeLagOptions.m_nPacketsDropped = GetInt("fakelag", "num_packets_dropped");

	m_SkinChangerOptions.m_AK47.m_nPaintKit = 456;
	m_SkinChangerOptions.m_Glock.m_nPaintKit = 607;
	m_SkinChangerOptions.m_AWP.m_nPaintKit = 344;

	m_EspOptions.m_bEnabled = GetBool("esp", "activated");
	m_EspOptions.m_bGlow = GetBool("esp", "glow");

	m_EspOptions.m_tGlowOptions.m_TargetType = (TargetType)GetInt("glow", "targettype");
	m_EspOptions.m_tGlowOptions.m_GlowType = (GlowType)GetInt("glow", "glowtype");
	m_EspOptions.m_tGlowOptions.m_clrTeammates = GetColor("glow", "teamColor");
	m_EspOptions.m_tGlowOptions.m_clrEnemies = GetColor("glow", "enemyColor");
	m_EspOptions.m_tGlowOptions.m_clrTeammatesNotVisible = GetColor("glow", "nonvisTeamColor");
	m_EspOptions.m_tGlowOptions.m_clrEnemiesNotVisible = GetColor("glow", "nonvisEnemyColor");
	m_EspOptions.m_tGlowOptions.m_fMaxDist = GetFloat("glow", "maxdist");
	m_EspOptions.m_tGlowOptions.m_bBombs = GetBool("glow", "bombs");
	m_EspOptions.m_tGlowOptions.m_clrBomb = GetColor("glow", "bombColor");
	m_EspOptions.m_tGlowOptions.m_bBombHint = GetBool("glow", "bombHint");
	m_EspOptions.m_tGlowOptions.m_bDroppedWeapons = GetBool("glow", "droppedweaps");
	m_EspOptions.m_tGlowOptions.m_clrDroppedWeapons = GetColor("glow", "weapColor");
	m_EspOptions.m_tGlowOptions.m_bThrownProjs = GetBool("glow", "thrownprojs");
	m_EspOptions.m_tGlowOptions.m_clrThrownProjs = GetColor("glow", "thrownprojColor");
	m_EspOptions.m_tGlowOptions.m_bBombInteraction = GetBool("glow", "bombInteraction");
	m_EspOptions.m_tGlowOptions.m_clrBombInteraction = GetColor("glow", "bombInteractionColor");
	m_EspOptions.m_tGlowOptions.m_bBombCarrier = GetBool("glow", "bombCarrier");
	m_EspOptions.m_tGlowOptions.m_clrBombCarrier = GetColor("glow", "bombCarrierColor");
	m_EspOptions.m_tGlowOptions.m_bFlashed = GetBool("glow", "flashed");

	m_ChatspamOptions.m_bEnabled = GetBool("chatspam", "activated");
	m_ChatspamOptions.m_bRandomParse = GetBool("chatspam", "random");
	m_ChatspamOptions.m_Method = (ChatspamMethod)GetInt("chatspam", "spamtype");
	m_ChatspamOptions.m_nChatInterval = GetInt("chatspam", "interval");

	[/swap_lines]

	return true;
}

bool Config::SaveConfig()
{
	[swap_lines]
	SetKey("bhop", "togglekey", m_Keys.m_nToggleBhop);
	SetKey("fakelag", "togglekey", m_Keys.m_nToggleFakelag);
	SetKey("esp", "togglekey", m_Keys.m_nToggleESP);
	SetKey("chatspam", "togglekey", m_Keys.m_nToggleChatspam);
	SetKey("chatspam", "restartkey", m_Keys.m_nRestartChatspam);

	SetBool("bhop", "activated", m_BhopOptions.m_bEnabled);
	SetBool("bhop", "anti_smac", m_BhopOptions.m_bAntiSMAC);

	SetBool("fakelag", "activated", m_FakeLagOptions.m_bEnabled);
	SetInt("fakelag", "num_packets_dropped", m_FakeLagOptions.m_nPacketsDropped);

	SetBool("esp", "activated", m_EspOptions.m_bEnabled);
	SetBool("esp", "glow", m_EspOptions.m_bGlow);
	SetInt("glow", "targettype", (int)m_EspOptions.m_tGlowOptions.m_TargetType);
	SetInt("glow", "glowtype", (int)m_EspOptions.m_tGlowOptions.m_GlowType);
	SetColor("glow", "teamColor", m_EspOptions.m_tGlowOptions.m_clrTeammates);
	SetColor("glow", "enemyColor", m_EspOptions.m_tGlowOptions.m_clrEnemies);
	SetColor("glow", "nonvisTeamColor", m_EspOptions.m_tGlowOptions.m_clrTeammatesNotVisible);
	SetColor("glow", "nonvisEnemyColor", m_EspOptions.m_tGlowOptions.m_clrEnemiesNotVisible);
	SetFloat("glow", "maxdist", m_EspOptions.m_tGlowOptions.m_fMaxDist);
	SetBool("glow", "bombs", m_EspOptions.m_tGlowOptions.m_bBombs);
	SetColor("glow", "bombColor", m_EspOptions.m_tGlowOptions.m_clrBomb);
	SetBool("glow", "bombHint", m_EspOptions.m_tGlowOptions.m_bBombHint);
	SetBool("glow", "droppedweaps", m_EspOptions.m_tGlowOptions.m_bDroppedWeapons);
	SetColor("glow", "weapColor", m_EspOptions.m_tGlowOptions.m_clrDroppedWeapons);
	SetBool("glow", "thrownprojs", m_EspOptions.m_tGlowOptions.m_bThrownProjs);
	SetColor("glow", "thrownprojColor", m_EspOptions.m_tGlowOptions.m_clrThrownProjs);
	SetBool("glow", "bombInteraction", m_EspOptions.m_tGlowOptions.m_bBombInteraction);
	SetColor("glow", "bombInteractionColor", m_EspOptions.m_tGlowOptions.m_clrBombInteraction);
	SetBool("glow", "bombCarrier", m_EspOptions.m_tGlowOptions.m_bBombCarrier);
	SetColor("glow", "bombCarrierColor", m_EspOptions.m_tGlowOptions.m_clrBombCarrier);
	SetBool("glow", "flashed", m_EspOptions.m_tGlowOptions.m_bFlashed);

	SetBool("chatspam", "activated", m_ChatspamOptions.m_bEnabled);
	SetBool("chatspam", "random", m_ChatspamOptions.m_bRandomParse);
	SetInt("chatspam", "spamtype", (int)m_ChatspamOptions.m_Method);
	SetInt("chatspam", "interval", m_ChatspamOptions.m_nChatInterval);
	[/swap_lines]


	[add_junk 1 5 /]
	return true;
}

int Config::GetInt(char* section, char* option)
{
	[add_junk 1 5 /]
	return GetPrivateProfileIntA(section, option, NULL, m_szConfigFile.c_str());
}

float Config::GetFloat(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	[add_junk 1 5 /]
	return (float)atof(val);
}

std::string Config::GetString(char* section, char* option)
{
	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return std::string(val);
}

bool Config::GetBool(char* section, char* option)
{
	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return (!_stricmp(val, "on"));
}

std::vector<int> Config::GetCommaSeperatedInts(char * section, char * option)
{
	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	std::string str(val);

	std::vector<int> vec;
	[add_junk 1 5 /]
	std::stringstream ss(str);
	int i;

	while (ss >> i)
	{
		vec.push_back(i);

		[add_junk 1 5 /]

		if (ss.peek() == ',' || ss.peek() == ' ')
			ss.ignore();
	}

	return vec;
}

int Config::GetKey(char * section, char * option)
{
	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	std::string str(val);

	char data = str.c_str()[0];

	[add_junk 1 5 /]

	if ((data >= '0' && data <= '9') || (data >= 'A' && data <= 'Z'))
		return (int)data;

	[add_junk 1 5 /]

	if (str == "mouse1") return VK_LBUTTON;
	else if (str == "mouse2") return VK_RBUTTON;
	else if (str == "mouse3") return VK_MBUTTON;
	else if (str == "mouse4") return VK_XBUTTON1;
	else if (str == "mouse5") return VK_XBUTTON2;
	else if (str == "backspace") return VK_BACK;
	else if (str == "tab") return VK_TAB;
	else if (str == "enter") return VK_RETURN;
	else if (str == "shift") return VK_SHIFT;
	else if (str == "ctrl") return VK_CONTROL;
	else if (str == "alt") return VK_MENU;
	else if (str == "capslock") return VK_CAPITAL;
	else if (str == "escape") return VK_ESCAPE;
	else if (str == "space") return VK_SPACE;
	else if (str == "pgup") return VK_PRIOR;
	else if (str == "pgdn") return VK_NEXT;
	else if (str == "end") return VK_END;
	else if (str == "home") return VK_HOME;
	else if (str == "leftarrow") return VK_LEFT;
	else if (str == "rightarrow") return VK_RIGHT;
	else if (str == "uparrow") return VK_UP;
	else if (str == "downarrow") return VK_DOWN;
	else if (str == "ins") return VK_INSERT;
	else if (str == "del") return VK_DELETE;
	else if (str == "numpad_0") return VK_NUMPAD0;
	else if (str == "numpad_1") return VK_NUMPAD1;
	else if (str == "numpad_2") return VK_NUMPAD2;
	else if (str == "numpad_3") return VK_NUMPAD3;
	else if (str == "numpad_4") return VK_NUMPAD4;
	else if (str == "numpad_5") return VK_NUMPAD5;
	else if (str == "numpad_6") return VK_NUMPAD6;
	else if (str == "numpad_7") return VK_NUMPAD7;
	else if (str == "numpad_8") return VK_NUMPAD8;
	else if (str == "numpad_9") return VK_NUMPAD9;
	else if (str == "kp_multiply") return VK_MULTIPLY;
	else if (str == "kp_plus") return VK_ADD;
	else if (str == "kp_minus") return VK_SUBTRACT;
	else if (str == "kp_slash") return VK_DIVIDE;
	else if (str == "numpad_.") return VK_DECIMAL;
	else if (str == "f1") return VK_F1;
	else if (str == "f2") return VK_F2;
	else if (str == "f3") return VK_F3;
	else if (str == "f4") return VK_F4;
	else if (str == "f5") return VK_F5;
	else if (str == "f6") return VK_F6;
	else if (str == "f7") return VK_F7;
	else if (str == "f8") return VK_F8;
	else if (str == "f9") return VK_F9;
	else if (str == "f10") return VK_F10;
	else if (str == "f11") return VK_F11;
	else if (str == "f12") return VK_F12;
	else if (str == ";") return VK_OEM_1;
	else if (str == "+") return VK_OEM_PLUS;
	else if (str == "-") return VK_OEM_MINUS;
	else if (str == ",") return VK_OEM_COMMA;
	else if (str == ".") return VK_OEM_PERIOD;
	else if (str == "/") return VK_OEM_2;
	else if (str == "~") return VK_OEM_3;
	else if (str == "[") return VK_OEM_4;
	else if (str == std::to_string(char(0x5C))) return VK_OEM_5;
	else if (str == "]") return VK_OEM_6;
	else if (str == std::to_string(char(0x22))) return VK_OEM_7;

	return -1;
}

Color Config::GetColor(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	Color clr;

	[add_junk 1 5 /]

	LPTSTR pStop;
	int parsedColor = _tcstol(val, &pStop, 16);
	clr.rgb.x = ((parsedColor & 0xFF0000) >> 16) / 255.0f;
	clr.rgb.y = ((parsedColor & 0xFF00) >> 8) / 255.0f;
	clr.rgb.z = (parsedColor & 0xFF) / 255.0f;
	clr.a = 0.6f;

	return clr;
}

void Config::SetInt(char* section, char* option, int nValue)
{
	char val[255];
	[add_junk 1 5 /]
	sprintf_s(val, " %d", nValue);
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetFloat(char* section, char* option, float fValue)
{
	char val[255];
	sprintf_s(val, " %2.1f", fValue);
	[add_junk 1 5 /]
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetString(char* section, char* option, std::string szValue)
{
	WritePrivateProfileStringA(section, option, szValue.c_str(), m_szConfigFile.c_str());
	[add_junk 1 5 /]
}

void Config::SetBool(char* section, char* option, bool bValue)
{
	char val[255];
	sprintf_s(val, "%s", bValue ? " on" : " off");
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
	[add_junk 1 5 /]
}

void Config::SetCommaSeperatedInts(char * section, char * option, std::vector<int> vValue)
{
	std::string input = " ";

	for (size_t i = 0; i < vValue.size(); i++)
	{
		if (i == vValue.size() - 1)
			input += std::to_string(i);
		else
			input += std::to_string(i) + ",";

		[add_junk 1 5 /]
	}

	WritePrivateProfileStringA(section, option, input.c_str(), m_szConfigFile.c_str());
	[add_junk 1 5 /]
}

void Config::SetKey(char * section, char * option, int nKey)
{
	char c[2] = { 0 };

	[add_junk 1 5 /]

	if ((nKey >= '0' && nKey <= '9') || (nKey >= 'A' && nKey <= 'Z'))
	{
		c[0] = (char)nKey;
		std::string sweg(c);
		[add_junk 1 5 /]
		std::transform(sweg.begin(), sweg.end(), sweg.begin(), ::tolower);
		WritePrivateProfileStringA(section, option, sweg.c_str(), m_szConfigFile.c_str());
		return;
	}

	std::string retStr = " ";

	[add_junk 1 5 /]

	switch (nKey)
	{
		case VK_LBUTTON: retStr += "mouse1"; break;
		case VK_RBUTTON: retStr += "mouse2"; break;
		case VK_MBUTTON: retStr += "mouse3"; break;
		case VK_XBUTTON1: retStr += "mouse4"; break;
		case VK_XBUTTON2: retStr += "mouse5"; break;
		case VK_BACK: retStr += "backspace"; break;
		case VK_TAB: retStr += "tab"; break;
		case VK_RETURN: retStr += "enter"; break;
		case VK_SHIFT: retStr += "shift"; break;
		case VK_CONTROL: retStr += "ctrl"; break;
		case VK_MENU: retStr += "alt"; break;
		case VK_CAPITAL: retStr += "capslock"; break;
		case VK_ESCAPE: retStr += "escape"; break;
		case VK_SPACE: retStr += "space"; break;
		case VK_PRIOR: retStr += "pgup"; break;
		case VK_NEXT: retStr += "pgdn"; break;
		case VK_END: retStr += "end"; break;
		case VK_HOME: retStr += "home"; break;
		case VK_LEFT: retStr += "leftarrow"; break;
		case VK_UP: retStr += "uparrow"; break;
		case VK_DOWN: retStr += "downarrow"; break;
		case VK_RIGHT: retStr += "rightarrow"; break;
		case VK_INSERT: retStr += "ins"; break;
		case VK_DELETE: retStr += "del"; break;
		case VK_NUMPAD0: retStr += "numpad_0"; break;
		case VK_NUMPAD1: retStr += "numpad_1"; break;
		case VK_NUMPAD2: retStr += "numpad_2"; break;
		case VK_NUMPAD3: retStr += "numpad_3"; break;
		case VK_NUMPAD4: retStr += "numpad_4"; break;
		case VK_NUMPAD5: retStr += "numpad_5"; break;
		case VK_NUMPAD6: retStr += "numpad_6"; break;
		case VK_NUMPAD7: retStr += "numpad_7"; break;
		case VK_NUMPAD8: retStr += "numpad_8"; break;
		case VK_NUMPAD9: retStr += "numpad_9"; break;
		case VK_MULTIPLY: retStr += "kp_multiply"; break;
		case VK_ADD: retStr += "kp_plus"; break;
		case VK_SUBTRACT: retStr += "kp_minus"; break;
		case VK_DIVIDE: retStr += "kp_slash"; break;
		case VK_DECIMAL: retStr += "numpad_."; break;
		case VK_F1: retStr += "f1"; break;
		case VK_F2: retStr += "f2"; break;
		case VK_F3: retStr += "f3"; break;
		case VK_F4: retStr += "f4"; break;
		case VK_F5: retStr += "f5"; break;
		case VK_F6: retStr += "f6"; break;
		case VK_F7: retStr += "f7"; break;
		case VK_F8: retStr += "f8"; break;
		case VK_F9: retStr += "f9"; break;
		case VK_F10: retStr += "f10"; break;
		case VK_F11: retStr += "f11"; break;
		case VK_F12: retStr += "f12"; break;
		case VK_OEM_1: retStr += ";"; break;
		case VK_OEM_PLUS: retStr += "+"; break;
		case VK_OEM_MINUS: retStr += "-"; break;
		case VK_OEM_COMMA: retStr += ","; break;
		case VK_OEM_PERIOD: retStr += "."; break;
		case VK_OEM_2: retStr += "/"; break;
		case VK_OEM_3: retStr += "~"; break;
		case VK_OEM_4: retStr += "["; break;
		case VK_OEM_5: retStr += std::to_string(char(0x5C)); break;
		case VK_OEM_6: retStr += "]"; break;
		case VK_OEM_7: retStr += std::to_string(char(0x22)); break;
		default: retStr += "unknown key"; break;
	}

	[add_junk 1 5 /]

	if (!retStr.empty())
		WritePrivateProfileStringA(section, option, retStr.c_str(), m_szConfigFile.c_str());
	else
		WritePrivateProfileStringA(section, option, " error", m_szConfigFile.c_str());
}

void Config::SetColor(char* section, char* option, Color color)
{
	color.rgb *= 255.0f;
	int r = (((int)color.rgb[0] & 0xFF) << 16);
	[add_junk 1 5 /]
	int g = (((int)color.rgb[1] & 0xFF) << 8);
	[add_junk 1 5 /]
	int b = (((int)color.rgb[2] & 0xFF));
	std::stringstream s;
	s << std::hex << std::uppercase << " " <<  (r | g | b);

	WritePrivateProfileStringA(section, option, s.str().c_str(), m_szConfigFile.c_str());
	[add_junk 1 5 /]
}

[junk_disable /]
[enc_string_disable /]