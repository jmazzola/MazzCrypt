// Structs.h - All the structs/classes for CSGO
#pragma once

#include "stdafx.h"
#include "Vector.h"

#include "Decrypt.h"

[enc_string_enable /]

static std::string Ranks[] =
{
	"Unranked",
	"Silver I",
	"Silver II",
	"Silver III",
	"Silver IV",
	"Silver Elite",
	"Silver Elite Master",
	"Gold Nova I",
	"Gold Nova II",
	"Gold Nova III",
	"Gold Nova Master",
	"Master Guardian I",
	"Master Guardian II",
	"Master Guardian Elite",
	"Distinguished Master Guardian",
	"Legendary Eagle",
	"Legendary Eagle Master",
	"Supreme Master First Class",
	"The Global Elite"
};

[enc_string_disable /]

struct Color
{
public:
	Color() : rgb(0, 0, 0), a(0.6f)
	{
	}

	Color(Vector v, float alpha) : rgb(v), a(alpha)
	{
	}

	Vector rgb;
	float a;
};

struct GlowObjectDefinition
{
	DWORD	m_pEntity;
	Color	m_Color;
	char    unk1[4];
	float   flUnk;
	float   m_flBloomAmount;
	float   localplayeriszeropoint3;
	bool    m_bRenderWhenOccluded;
	bool    m_bRenderWhenUnoccluded;
	bool    m_bFullBloomRender;
	char    unk2[1];
	int     m_nFullBloomStencilTestValue; 
	int     iUnk; 
	int     m_nSplitScreenSlot;
	int     m_nNextFreeSlot;
};

struct CGlobalVarsBase
{
public:
	float		realtime;
	int			framecount;
	float		absoluteframetime;
	float		frametime;
	float		curtime;
	float		interval_per_tick;
	int			maxClients;
	int			tickcount;
	float		interpolation_amount;
	float		unknown;
	int			simTicksThisFrame;
	int			network_protocol;
	void*		pSaveData;
	bool		m_bClient;
	int			nTimestampNetworkingBase;
	int			nTimestampRandomizeWindow;
};

class player_info_t
{
public:

	char			name[32];
	int				userID;
	char			guid[33];
	__int32			friendsID;
	char			friendsName[32];
	bool			fakeplayer;
	bool			ishltv;
	unsigned long	customFiles[4];
	unsigned char	filesDownloaded;
	char			Pad[200];
};
