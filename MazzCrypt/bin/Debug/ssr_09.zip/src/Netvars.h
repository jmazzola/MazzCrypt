// Netvars.h - Class to hold netvars and scanning netvars
#pragma once

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

namespace Netvars
{
	class CRecvTable
	{
	public:

		class CRecvProp
		{
		public:
			const char* GetVarName()
			{
				[add_junk 1 6 /]

				DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this);
				char varName[128];
				pCSGO->m_Mem.Read(offset, varName, 128);

				[add_junk 1 6 /]

				return varName;
			}

			int GetOffset()
			{
				[add_junk 1 6 /]
				return pCSGO->m_Mem.Read<int>((DWORD)this + 0x2C);
			}
			CRecvTable* GetDataTable()
			{
				[add_junk 1 6 /]
				return pCSGO->m_Mem.Read<CRecvTable*>((DWORD)this + 0x28);
			}

		};

		const char* GetTableName()
		{
			DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this + 0xC);
			[add_junk 1 6 /]
			char tableName[128];
			[add_junk 1 6 /]
			pCSGO->m_Mem.Read(offset, tableName, 128);
			return tableName;
		}


		int GetMaxProp()
		{
			[add_junk 1 6 /]
			return pCSGO->m_Mem.Read< int >((DWORD)this + 0x4);
		}

		CRecvProp* GetProperty(int iIndex)
		{
			[add_junk 1 6 /]
			return (CRecvProp*)(pCSGO->m_Mem.Read<DWORD>((DWORD)this) + 0x3C * iIndex);
		}

	};

	class ClientClass
	{
	public:
		const char* GetNetworkName()
		{
			DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this + 0x8);
			[add_junk 1 6 /]
			char networkName[128];
			[add_junk 1 6 /]
			pCSGO->m_Mem.Read(offset, networkName, 128);
			return networkName;
		}

		ClientClass* GetNextClass()
		{
			[add_junk 1 6 /]
			return pCSGO->m_Mem.Read< ClientClass* >((DWORD)this + 0x10);
		}
		CRecvTable* GetTable()
		{
			[add_junk 1 6 /]
			return pCSGO->m_Mem.Read< CRecvTable* >((DWORD)this + 0xC);
		}
	};

	DWORD GetNetVar(const char* szClassName, const char* szNetVar);
}

[junk_disable /]