// Skinchanger.h - Cheat thread to change skins on the clientside of the player
#pragma once

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

namespace Skinchanger
{
	void GetWeaponSettings(SkinChangerOptions::SkinOptions& tSkin)
	{
		switch (pCSGO->m_Me.GetWeaponID())
		{
			case WID_Glock:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Glock;
				break;
			}

			case WID_P2000:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_P2000;
				[add_junk 1 7 /]
				break;
			}

			case WID_USP:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_USP;
				break;
			}

			case WID_P250:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_P250;
				break;
			}

			case WID_Five_Seven:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_FiveSeven;
				[add_junk 1 7 /]
				break;
			}

			case WID_Deagle:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Deagle;
				break;
			}

			case WID_Dual_Berettas:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Duelies;
				break;
			}

			case WID_Tec9:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Tec9;
				break;
			}

			case WID_CZ75:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_CZ75;
				[add_junk 1 7 /]
				break;
			}

			case WID_Revolver:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Revolver;
				[add_junk 1 7 /]
				break;
			}

			case WID_Galil:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Galil;
				[add_junk 1 7 /]
				break;
			}

			case WID_AK47:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_AK47;
				break;
			}

			case WID_M4A4:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_M4A4;
				break;
			}

			case WID_M4A1S:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_M4A1S;
				break;
			}

			case WID_SG553:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_SG553;
				break;
			}

			case WID_AUG:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_AUG;
				break;
			}

			case WID_FAMAS:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_FAMAS;
				break;
			}

			case WID_MAC10:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_MAC10;
				break;
			}

			case WID_MP7:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_MP7;
				[add_junk 1 7 /]
				break;
			}

			case WID_MP9:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_MP9;
				break;
			}

			case WID_UMP45:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_UMP45;
				break;
			}

			case WID_PPBizon:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Bizon;
				break;
			}

			case WID_P90:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_P90;
				[add_junk 1 7 /]
				break;
			}

			case WID_M249:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_M249;
				break;
			}

			case WID_Negev:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Negev;
				[add_junk 1 7 /]
				break;
			}

			case WID_AWP:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_AWP;
				[add_junk 1 7 /]
				break;
			}

			case WID_SCAR_Auto:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_SCAR20;
				break;
			}

			case WID_G3SG1_Auto:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_GSG31;
				break;
			}

			case WID_Scout:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Scout;
				break;
			}

			case WID_Nova:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_Nova;
				break;
			}

			case WID_XM1014:
			{
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_XM1014;
				break;
			}

			case WID_SawedOff:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_SawedOff;
				break;
			}

			case WID_MAG7:
			{
				[add_junk 1 7 /]
				tSkin = pCSGO->m_Config.m_SkinChangerOptions.m_MAG7;
				break;
			}

			default:
			break;
		}
	}

	void WriteAndApplySkinData(SkinChangerOptions::SkinOptions& skin)
	{
		DWORD baseCombatHandle = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_Me.m_dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_hActiveWeapon);
		[add_junk 1 7 /]
		baseCombatHandle &= 0xFFF;

		DWORD weapBase = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);

		if (weapBase)
		{
			pCSGO->m_Mem.Write<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_OriginalOwnerXuidLow, 0);
			[add_junk 1 7 /]
			pCSGO->m_Mem.Write<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_OriginalOwnerXuidHigh, 0);

			[swap_lines]
			pCSGO->m_Mem.Write<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_nFallbackPaintKit, skin.m_nPaintKit);
			pCSGO->m_Mem.Write<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_nFallbackStatTrak, skin.m_nStatTrak);
			pCSGO->m_Mem.Write<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_nFallbackSeed, skin.m_nSeed);
			pCSGO->m_Mem.Write<float>(weapBase + pCSGO->m_Offsets.m_dwNetvar_flFallbackWear, skin.m_fWear);
			[/swap_lines]

			[add_junk 1 7 /]

			//char name[101] = "We dem boys";
			//pCSGO->m_Mem.Write(weapBase + pCSGO->m_Offsets.m_dwNetvar_AttributeManager + pCSGO->m_Offsets.m_dwNetvar_Item + pCSGO->m_Offsets.m_dwNetvar_szCustomName, name, sizeof(name));

			pCSGO->ForceFullUpdate();
			[add_junk 1 7 /]
		}
	}

	void Start()
	{
		DWORD tempWeapon = 0;
		[add_junk 1 7 /]
		SkinChangerOptions::SkinOptions skin;

		while (true)
		{
			if (pCSGO == nullptr)
			{
				LOGD << "pCSGO was nullptr! Ending thread!";
				[add_junk 1 7 /]
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopSkinChanger)
			{
				[add_junk 1 7 /]
				LOGD << "Skinchanger bool was true, Ending thread!";
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopSkinChanger = true;

			if (!pCSGO->IsInGame())
				continue;

			[add_junk 1 7 /]
			
			GetWeaponSettings(skin);

			// Check when we swap weapons
			if (tempWeapon != pCSGO->m_Me.GetWeaponID())
			{
				[add_junk 1 7 /]
				tempWeapon = pCSGO->m_Me.GetWeaponID();
				WriteAndApplySkinData(skin);
			}

			if (GetAsyncKeyState('K') & 1)
				WriteAndApplySkinData(skin);

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 7 /]
		}
	}
}

[junk_disable /]