// ESP.h - ESP Cheat thread (both overlay as well as Glow ESP)
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Enums.h"
#include "Utils.h"
#include "Math.h"
#include "Structs.h"
#include <algorithm>

[junk_enable /]

namespace ESP
{
	void WriteGlowStruct(DWORD& mObj, GlowObjectDefinition& glowObj)
	{
		[swap_lines]
		pCSGO->m_Mem.Write<Color>(mObj + 0x4, glowObj.m_Color);
		pCSGO->m_Mem.Write<bool>(mObj + 0x24, glowObj.m_bRenderWhenOccluded);
		pCSGO->m_Mem.Write<bool>(mObj + 0x25, glowObj.m_bRenderWhenUnoccluded);
		pCSGO->m_Mem.Write<bool>(mObj + 0x26, glowObj.m_bFullBloomRender);
		[/swap_lines]

		[add_junk 1 4 /]
	}

	void DoGlow()
	{
		[swap_lines]
		static DWORD objGlowArray = 0;
		static int objCount = 0;
		static int bombCarrier = -1;
		[/swap_lines]

		[add_junk 1 4 /]

		objGlowArray = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwGlowObjectBase);
		[add_junk 1 4 /]
		objCount = pCSGO->m_Mem.Read<int>(pCSGO->m_dwGlowObjectBase + 4);

		if (objGlowArray == NULL)
			return;

		for (int i = 0; i < objCount; i++)
		{
			DWORD obj = objGlowArray + i * sizeof(GlowObjectDefinition);
			[add_junk 1 4 /]
			GlowObjectDefinition glowObj = pCSGO->m_Mem.Read<GlowObjectDefinition>(obj);

			if (!glowObj.m_pEntity)
				continue;

			Player* ply = (Player*)&glowObj.m_pEntity;
			[add_junk 1 4 /]
			int classID = ply->GetClassID();

			if (pCSGO->IsBombPlanted() || pCSGO->IsBombDropped())
				bombCarrier = -1;

			#pragma region Bomb Check
			if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bBombs)
			{
				if (classID == CID_CC4 || classID == CID_CPlantedC4)
				{
					[add_junk 1 4 /]
					if (classID == CID_CC4 && pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bBombCarrier)
					{
						DWORD handleOwner = pCSGO->m_Mem.Read<DWORD>(glowObj.m_pEntity + pCSGO->m_Offsets.m_dwNetvar_hOwnerEntity);
						[add_junk 1 4 /]
						handleOwner &= 0xFFF;

						for (int i = 0; i < 64; i++)
						{
							[add_junk 1 4 /]
							if (handleOwner == pCSGO->m_Players[i].m_nID)
							{
								bombCarrier = handleOwner;
								break;
							}
						}
					}

					[swap_lines]
					glowObj.m_bRenderWhenOccluded = true;
					glowObj.m_bRenderWhenUnoccluded = false;
					glowObj.m_bFullBloomRender = false;
					glowObj.m_Color = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrBomb;
					[/swap_lines]

					WriteGlowStruct(obj, glowObj);
				}
			}
#pragma endregion

			#pragma region Bomb Info
			if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bBombHint)
			{
				if (classID == CID_CPlantedC4 && (pCSGO->m_Mem.Read<bool>(glowObj.m_pEntity + pCSGO->m_Offsets.m_dwNetvar_bBombTicking)) )
				{
					CGlobalVarsBase globalVars = pCSGO->m_Mem.Read<CGlobalVarsBase>(pCSGO->m_dwGlobalVarsPointer);
					[add_junk 1 4 /]
					float bombTime = pCSGO->m_Mem.Read<float>(glowObj.m_pEntity + pCSGO->m_Offsets.m_dwNetvar_flC4Blow) - globalVars.curtime;
					Color color;

					color.a = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrBomb.a;
					[add_junk 1 4 /]

					if (bombTime >= 10.0f)
						color.rgb = Vector(0.0f, 1.0f, 0.0f);
					else if (bombTime >= 5.0f)
						color.rgb = Vector(0.0f, 0.0f, 1.0f);
					else
						color.rgb = Vector(1.0f, 0.0f, 0.0f);

					[swap_lines]
					glowObj.m_Color = color;
					glowObj.m_bRenderWhenOccluded = true;
					glowObj.m_bRenderWhenUnoccluded = false;
					glowObj.m_bFullBloomRender = false;
					[/swap_lines]
					[add_junk 1 4 /]

					WriteGlowStruct(obj, glowObj);
				}
			}
#pragma endregion

			#pragma region Thrown Projectiles
			if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bThrownProjs)
			{
				if (pCSGO->IsClassIDAGrenade(classID))
				{
					[add_junk 1 4 /]

					[swap_lines]
					glowObj.m_bRenderWhenOccluded = true;
					glowObj.m_bRenderWhenUnoccluded = false;
					glowObj.m_bFullBloomRender = false;
					glowObj.m_Color = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrThrownProjs;
					[/swap_lines]

					WriteGlowStruct(obj, glowObj);
				}
			}
#pragma endregion

			#pragma region Dropped Weapons
			if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bDroppedWeapons)
			{
				[add_junk 1 4 /]
				if (pCSGO->IsClassIDAWeapon(classID))
				{
					[swap_lines]
					glowObj.m_bRenderWhenOccluded = true;
					glowObj.m_bRenderWhenUnoccluded = false;
					glowObj.m_bFullBloomRender = false;
					glowObj.m_Color = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrDroppedWeapons;
					[/swap_lines]

					WriteGlowStruct(obj, glowObj);
				}
			}
#pragma endregion

			#pragma region Players
			if (classID != CID_CCSPlayer)
				continue;

			[add_junk 1 4 /]

			CGlobalVarsBase globalVars = pCSGO->m_Mem.Read<CGlobalVarsBase>(pCSGO->m_dwGlobalVarsPointer);

			for (int i = 1; i < globalVars.maxClients; i++)
			{
				Player ply = pCSGO->m_Players[i];
				[add_junk 1 4 /]

				if (ply.m_dwBaseAddr != glowObj.m_pEntity)
					continue;

				bool bEnemy = (pCSGO->m_Me.GetTeam() == pCSGO->GetEnemyTeam(ply.GetTeam()));

				if ((pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_TargetType == TargetType::TARGET_ENEMIES) && !bEnemy)
					continue;
				else if ((pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_TargetType == TargetType::TARGET_TEAMMATES) && bEnemy)
					continue;

				[swap_lines]
				Color visibleColor = (bEnemy) ? pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrEnemies : pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrTeammates;
				Color invisibleColor = (bEnemy) ? pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrEnemiesNotVisible : pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrTeammatesNotVisible;
				[/swap_lines]

				glowObj.m_Color = visibleColor;
				[add_junk 1 4 /]

				#pragma region Glow Types
				switch (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_GlowType)
				{
					case GlowType::GLOW_HEALTH:
					{
						int health = std::max(0, std::min(ply.GetHealth(), 100));

						Color color;
						[swap_lines]
						color.rgb.x = std::min((2.0f * (100 - health)) / 100.0f, 1.0f);
						color.rgb.y = std::min((2.0f * health) / 100.0f, 1.0f);
						color.rgb.z = 0.0f;
						color.a = 0.6f;
						[/swap_lines]

						[add_junk 1 4 /]

						glowObj.m_Color = color;
						break;
					}

					case GlowType::GLOW_VISIBILITY:
					{
						[add_junk 1 4 /]
						break;
					}

					case GlowType::GLOW_VULNERABILITY:
					{
						if (ply.GetWeaponType() == WeapType_Grenade || ply.GetWeaponType() == WeapType_KnifeType || ply.IsReloading())
						{
							[add_junk 1 4 /]
							glowObj.m_Color = Color(Vector(0.0f, 255.0f, 242.0f), 0.6f);
						}

						break;
					}
				}
#pragma endregion

				#pragma region Bomb Carrier
				if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bBombCarrier)
				{
					[add_junk 1 4 /]
					if (!pCSGO->IsBombDropped() && bombCarrier != 1 && ply.GetID() == bombCarrier)
					{
						[add_junk 1 4 /]
						glowObj.m_Color = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrBombCarrier;
					}
				}
#pragma endregion

				#pragma region Defusing/Planting
				if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bBombInteraction)
				{
					if (ply.IsDefusing() || ply.IsPlanting())
					{
						[add_junk 1 4 /]
						glowObj.m_Color = pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_clrBombInteraction;
					}
				}
#pragma endregion 

				#pragma region Flashed
				if (pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_bFlashed)
				{
					[add_junk 1 4 /]
					if (ply.IsFlashed())
					{
						glowObj.m_Color = Color(Vector(255, 255, 255), 0.6f);
						[add_junk 1 4 /]
					}
				}
#pragma endregion

				if (ply.IsDormant() || ply.GetDistanceFromMe() >= pCSGO->m_Config.m_EspOptions.m_tGlowOptions.m_fMaxDist)
					glowObj.m_Color.a = 0.0f;

				[swap_lines]
				glowObj.m_bRenderWhenOccluded = true;
				glowObj.m_bRenderWhenUnoccluded = false;
				glowObj.m_bFullBloomRender = false;
				[/swap_lines]

				[add_junk 1 4 /]

				WriteGlowStruct(obj, glowObj);

			}
#pragma endregion

		}
	}

	void DoOverlayESP()
	{
		[add_junk 1 4 /]
		return;
	}

	void Start()
	{
		while (true)
		{
			[add_junk 1 4 /]
			if (pCSGO == nullptr)
			{
				LOGD << "pCSGO was nullptr! Ending thread!";
				[add_junk 1 4 /]
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopESP)
			{
				[add_junk 1 4 /]
				LOGD << "Bhop bool was true, Ending thread!";
				return;
			}

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopESP = true;

			if (!pCSGO->m_Config.m_EspOptions.m_bEnabled)
				continue;

			if (!pCSGO->IsInGame())
				continue;

			if (pCSGO->m_Config.m_EspOptions.m_bGlow)
				DoGlow();

			DoOverlayESP();
			[add_junk 1 4 /]

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}

		[add_junk 1 4 /]
	}
}

[junk_disable /]