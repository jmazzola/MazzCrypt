#include "Memory.h"

[junk_enable /]

bool CMemory::Attach(const char* procName, DWORD rights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

	[add_junk /]

	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)procName))
		{
			m_dwProcessID = entry.th32ProcessID;
			CloseHandle(handle);

			[add_junk /]

			m_hProcess = OpenProcess(rights, false, m_dwProcessID);
			m_bAttached = true;

			[add_junk /]
			
			return true;
		}
	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	return false;
}

void CMemory::Detach()
{
	m_bAttached = false;
	[add_junk /]
	CloseHandle(m_hProcess);
}

DWORD CMemory::GetModuleBase(const char* modName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);

	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	[add_junk /]

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)modName))
		{
			CloseHandle(handle);
			[add_junk /]
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	return NULL;
	
}
