#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "stdafx.h"
#include <TlHelp32.h>
#include <string>

[junk_enable /]

class CMemory
{
public:
	CMemory() = default;
	~CMemory() = default;

	bool Attach(const char* procName, DWORD rights = PROCESS_ALL_ACCESS);

	void Detach();

	DWORD GetModuleBase(const char* modName);

	HANDLE GetHandle() const
	{
		if (m_bAttached)
		{
			return NULL;
		}

		return m_hProcess;
	}

	template<typename T>
	T inline Read(DWORD addr)
	{
		T mem;
		ReadProcessMemory(m_hProcess, (LPVOID)addr, &mem, sizeof(T), NULL);
		return mem;
	}

	template<typename T>
	void inline Write(DWORD addr, T data)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, &data, sizeof(T), NULL);
	}

	BOOL inline DataCompare(BYTE* pData, BYTE* pMask, char* szMask)
	{
		for (; *szMask; ++szMask, ++pData, ++pMask)
		{
			if (*szMask == 'c' && *pData != *pMask)
			{
				return FALSE;
			}
		}

		return (*szMask == NULL);
	}

	DWORD inline FindPattern(DWORD addr, DWORD len, BYTE* pMask, char* szMask)
	{
		for (DWORD i = 0; i < len; i++)
		{
			if (DataCompare((BYTE*)(addr + i), pMask, szMask))
			{
				return (DWORD)(addr + i);
			}
		}

		return NULL;
	}

	bool inline IsAttached() const
	{
		return m_bAttached;
	}

private:

	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers /]
};

#endif // _MEMORY_H_
