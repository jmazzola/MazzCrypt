#ifndef _GLOWESP_H_
#define _GLOWESP_H_

#include "stdafx.h"
#include "CSGO.h"

struct GlowObjectDefinition
{
	DWORD			pEntity;
	float			r; // 0x04
	float			g; // 0x08
	float			b; // 0xC
	float			a; // 0x10
	unsigned char	unk1[16];
	bool			bRenderWhenOccluded; // 0x24
	bool			bRenderWhenUnoccluded; // 0x25
	bool			bFullBloom; // 0x26
	unsigned char	unk2[10];

};

class GlowESP
{
public:

	void Start()
	{
		static DWORD objGlowArray = 0;
		int objCount = 0;
		while (!csgo->m_Hacks.tThreadHandling.bGlowThreadStop)
		{
			if (csgo->m_Hacks.CheckBit(BIT_ESP))
			{
				[swap_lines]
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);
				[/swap_lines]

				if (objGlowArray != NULL)
				{
					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						[add_junk /]

						if (!glowObj.pEntity)
							continue;

						#pragma region Bomb Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowBomb)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_C4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_PlantedC4)
							{

								[swap_lines]
								glowObj.r = 1.0f;
								glowObj.g = 0.4f;
								glowObj.b = 0.03f;
								glowObj.a = 1.0f;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[swap_lines]
								csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
								csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
								csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
								csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
								csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
								[/swap_lines]

							}
						}
						#pragma endregion


						#pragma region Grenade Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowGrenades)
						{
							if (csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{
								[swap_lines]
								glowObj.r = 0.5f;
								glowObj.g = 0.02f;
								glowObj.b = 1.0f;
								glowObj.a = 1.0f;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[swap_lines]
								csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
								csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
								csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
								csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
								csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
								[/swap_lines]
							}
						}

						#pragma endregion


						#pragma region Weapon Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowWeapons)
						{
							if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{

								[swap_lines]
								glowObj.r = 0.0f;
								glowObj.g = 1.0f;
								glowObj.b = 1.0f;
								glowObj.a = 1.0f;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[swap_lines]
								csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
								csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
								csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
								csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
								csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
								[/swap_lines]
							}
#pragma endregion

						}

						if (!csgo->m_Hacks.tGlowOptions.bEnemyOnly)
						{
							#pragma region Friendly Check
							for (int player = 0; player < 32; player++)
							{
								Player friendly = csgo->GetFriendly(player);

								if ((friendly.baseAddr == glowObj.pEntity) && (csgo->GetTeam(glowObj.pEntity) == csgo->m_Me.iTeam) && !friendly.bIsDormant && csgo->GetClassID(&friendly) == CID_CSPlayer)
								{
									[swap_lines]
									glowObj.r = csgo->m_Hacks.tGlowOptions.fGlowTeam_R;
									glowObj.g = csgo->m_Hacks.tGlowOptions.fGlowTeam_G;
									glowObj.b = csgo->m_Hacks.tGlowOptions.fGlowTeam_B;
									glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowTeam_A;
									[/swap_lines]

									if (csgo->m_Hacks.tGlowOptions.bFlashGlow)
									{
										if (friendly.fFlashDuration > 0.001f)
										{
											[swap_lines]
											glowObj.r = 1.0f;
											glowObj.g = 1.0f;
											glowObj.b = 1.0f;
											glowObj.a = 1.0f;
											[/swap_lines]
										}

										[swap_lines]
										glowObj.bRenderWhenOccluded = true;
										glowObj.bRenderWhenUnoccluded = false;
										glowObj.bFullBloom = false;
										[/swap_lines]
									}

									[swap_lines]
									csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
									csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
									csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
									csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
									csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
									csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
									csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
									[/swap_lines]
								}
							}

							#pragma endregion
						}

						#pragma region Enemy Check
						for (int player = 0; player < 32; player++)
						{
							Player enemy = csgo->GetEnemy(player);

							if ((enemy.baseAddr == glowObj.pEntity) && csgo->GetTeam(glowObj.pEntity) == csgo->GetEnemyTeam(csgo->m_Me.iTeam) && !enemy.bIsDormant && csgo->GetClassID(&enemy) == CID_CSPlayer)
							{
								if (!csgo->m_Hacks.tGlowOptions.bHealthGlow)
								{
									[swap_lines]
									glowObj.r = csgo->m_Hacks.tGlowOptions.fGlowEnemy_R;
									glowObj.g = csgo->m_Hacks.tGlowOptions.fGlowEnemy_G;
									glowObj.b = csgo->m_Hacks.tGlowOptions.fGlowEnemy_B;
									glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowEnemy_A;
									[/swap_lines]

									if (csgo->m_Hacks.tGlowOptions.bFlashGlow)
									{
										if (enemy.fFlashDuration > 0.001f)
										{
											[swap_lines]
											glowObj.r = 1.0f;
											glowObj.g = 1.0f;
											glowObj.b = 1.0f;
											glowObj.a = 1.0f;
											[/swap_lines]
										}
									}

									[swap_lines]
									glowObj.bRenderWhenOccluded = true;
									glowObj.bRenderWhenUnoccluded = false;
									glowObj.bFullBloom = false;
									[/swap_lines]
								}
								else
								{
									float r = 0.0f, g = 0.0f, b = 0.0f, a = 1.0f;
									DWORD health = enemy.iHealth;

									if (health >= 1 && health <= 30)
									{
										r = 1.0f; g = 0.0f; b = 0.0f;
									}
									else if (health > 30 && health <= 69)
									{
										r = 1.0f; g = 1.0f; b = 0.0f;
									}
									else if (health > 69 && health <= 100)
									{
										r = 0.0f; g = 1.0f; b = 0.0f;
									}

									glowObj.r = r; glowObj.g = g; glowObj.b = b; glowObj.a = a;

									if (csgo->m_Hacks.tGlowOptions.bFlashGlow)
									{
										if (enemy.fFlashDuration > 0.001f)
										{
											[swap_lines]
											glowObj.r = 1.0f;
											glowObj.g = 1.0f;
											glowObj.b = 1.0f;
											glowObj.a = 1.0f;
											[/swap_lines]
										}
									}

									[swap_lines]
									glowObj.bRenderWhenOccluded = true;
									glowObj.bRenderWhenUnoccluded = true;
									glowObj.bFullBloom = false;
									[/swap_lines]
								}

								[swap_lines]
								csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
								csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
								csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
								csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
								csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
								csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
								[/swap_lines]
							}
						}

#pragma endregion
					}
				}
			}
			else
			{
				[swap_lines]
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);
				[/swap_lines]

				if (objGlowArray != NULL)
				{
					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)) || csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity)) 
							|| csgo->GetClassID((Player*)&glowObj.pEntity) == CID_C4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_PlantedC4)
						{

							[swap_lines]
							glowObj.r = 0.0f;
							glowObj.g = 0.0f;
							glowObj.b = 0.0f;
							[add_junk /]
							glowObj.a = 0.0f;
							glowObj.bRenderWhenOccluded = true;
							glowObj.bRenderWhenUnoccluded = false;
							glowObj.bFullBloom = false;
							[/swap_lines]

							[swap_lines]
							csgo->m_Mem.Write<float>(mObj + 0x4, glowObj.r);
							csgo->m_Mem.Write<float>(mObj + 0x8, glowObj.g);
							csgo->m_Mem.Write<float>(mObj + 0xC, glowObj.b);
							csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
							csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
							csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
							csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
							[/swap_lines]
						}

					}
					
				}
			}
		}

		Sleep(1);
	}

	GlowESP(CSGO* c)
	{
		csgo = c;
		[add_junk /]
	}

	~GlowESP() = default;


private:

	CSGO* csgo;

	[add_junk_datamembers 6 10 /]
};

#endif // _GLOWESP_H_
