#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CSGO.h"
#include "GlowESP.h"

#include <time.h>
#include <thread>

// Memory Leak Detection
//#include <vld.h>

// Globals
[swap_lines]
char* programPath = "";
CMemory memTest;
CSGO csgo;
[/swap_lines]

[junk_enable /]

void UpdateEntitiesConstantly(CSGO* csgo)
{
	while (!csgo->m_Hacks.tThreadHandling.bUpdateStop)
	{
		csgo->UpdateEntities();
		Sleep(1);
	}
}


int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	// Set up minidumper in case we have a crash
	SetUnhandledExceptionFilter(CMiscUtils::MinidumpHelper);

	if (argc > 0)
	{
		programPath = argv[0];

		[add_junk /]
	}

	// Create a random title and allow debugging access for this process
	CMiscUtils::GenerateRandomWindowTitle(20);
	CMiscUtils::AllowDebugging();

	CMiscUtils::PrintLine("~ SmurfStomper [CSGO] : Completely recoded and redone ~");
	CMiscUtils::PrintLine("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~");
	CMiscUtils::PrintLine("-----------------------------\n");

	CMiscUtils::PrintLine("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now.");
	std::cout << "\b\b";

	while (!csgo.Attach())
	{
		std::cout << "_";
		Sleep(100);\
		[add_junk /]
		std::cout << "\b_";
	}

	CMiscUtils::PrintLine("> CSGO attached!");
	CMiscUtils::PrintLine("-----------------------------\n");

	CMiscUtils::PrintLine("> Loading INI Settings...");
	CMiscUtils::PrintLine("-----------------------------------------\n");

	if (!CMiscUtils::LoadINISettings("settings.ini", &csgo))
	{
		csgo.m_Hacks.Unset(BIT_AIMBOT | BIT_TRIGGERBOT | BIT_BHOP | BIT_RCS | BIT_ESP);

		[add_junk /]
	}

	CMiscUtils::PrintLine("> Press INSERT whenever your ready to 'toggle'");
	CMiscUtils::PrintLine("-----------------------------\n");

	while (!GetAsyncKeyState(VK_INSERT))
	{
		[add_junk /]
		
		Sleep(100);
	}

	CMiscUtils::PrintLine("> Starting cheat threads..");

	// Start the threads
	std::thread threadUpdateEnts(UpdateEntitiesConstantly, &csgo);
	std::thread threadGlowESP(&GlowESP::Start, GlowESP(&csgo));

	CMiscUtils::PrintLine("> Cheat running! Press END at any time to stop.");


	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{
		// Handle triggerbot
		if (GetAsyncKeyState(csgo.m_Hacks.tTriggerOptions.iKey) < 0)
		{
			csgo.m_Hacks.Set(BIT_TRIGGERBOT);
			[add_junk /]
			Sleep(50);
		}
		else
		{
			[add_junk /]
			csgo.m_Hacks.Unset(BIT_TRIGGERBOT);
			Sleep(50);
		}

		if (GetAsyncKeyState(csgo.m_Hacks.tGlowOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_ESP);
			[add_junk /]
			Sleep(50);
		}
		
		//CMiscUtils::PrintLine(std::to_string((int)csgo.m_Hacks.tGlowOptions.bGlowBomb));
		//CMiscUtils::PrintLine("");
		//CMiscUtils::PrintLine(std::to_string((int)csgo.m_Hacks.tGlowOptions.bGlowWeapons));
		//Sleep(10);
	}

	[add_junk /]

	memTest.Detach();
	CMiscUtils::DeleteSelf(programPath);

	exit(0);
}