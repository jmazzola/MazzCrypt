#ifndef _INIREADER_H_
#define _INIREADER_H_

#include <unordered_map>
#include <string>

class INIReader
{
public:

	INIReader(std::string filename);

	~INIReader();

	int ParseError();

	std::string GetString(std::string section, std::string name, std::string defaultVal);

	long GetInteger(std::string section, std::string name, long defaultVal);

	float GetFloat(std::string section, std::string name, float defaultVal);

	bool GetBoolean(std::string section, std::string name, bool defaultVal);

private:

	int m_iError;

	std::unordered_map<std::string, std::string> m_mValues;

	static std::string MakeKey(std::string section, std::string name);

	static int ValHandler(void* user, const char* section, const char* name, const char* val);

};

#endif // _INIREADER_H_
