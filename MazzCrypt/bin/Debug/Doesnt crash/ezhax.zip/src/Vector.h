#ifndef _VECTOR_H_
#define _VECTOR_H_

#include "stdafx.h"
#include <xmmintrin.h>
#include <math.h>
#include <cmath>
#include <float.h>

#define X_INDEX 0
#define Y_INDEX 1
#define Z_INDEX 2

class CVector
{

public:

	// Data members
	float x, y, z;

	[add_junk_datamembers /]

	// Ctors
	inline CVector() : x(0.0f), y(0.0f), z(0.0f)
	{
	}

	inline CVector(float fX, float fY, float fZ) : x(fX), y(fY), z(fZ)
	{
	}

	inline CVector(const CVector& v) : x(v.x), y(v.y), z(v.z)
	{
	}

	inline CVector(float num[3]) : x(num[X_INDEX]), y(num[Y_INDEX]), z(num[Z_INDEX])
	{
	}

	inline void PrintInfo()
	{
		printf_s("%f | %f | %f", x, y, z);
	}

	inline void ZeroOut()
	{
		x = y = z = 0.0f;
	}

	inline float FastSQRT(float f)
	{
		__m128 root = _mm_sqrt_ss(_mm_load_ss(&f));
		return *(reinterpret_cast<float *>(&root));
	}

	inline float Length() 
	{ 
		return FastSQRT(x*x + y*y + z*z);
	}

	inline float DotProduct(CVector v)
	{
		return (x * v.x + y * v.y + z * v.z);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();

		[swap_lines]
		x *= l;
		y *= l;
		z *= l;
		[/swap_lines]
	}

	inline float ToDegree(CVector to)
	{
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		return *(&x + i);
	}

	inline CVector operator+(const CVector& v)
	{
		return CVector(x + v.x, y + v.y, z + v.z);
	}
	
	inline void operator+= (const CVector& v)
	{
		[swap_lines]
		x += v.x;
		y += v.y;
		z += v.z;
		[/swap_lines]
	}

	inline CVector operator-(const CVector& v)
	{
		return CVector(x - v.x, y - v.y, z - v.z);
	}

	inline void operator-=(const CVector& v)
	{
		[swap_lines]
		x -= v.x;
		y -= v.y;
		z -= v.z;
		[/swap_lines]
	}

	inline CVector operator*(const float f)
	{
		return CVector(x * f, y * f, z * f);
	}

	inline void operator*=(const float f)
	{
		[swap_lines]
		x *= f;
		y *= f;
		z *= f;
		[/swap_lines]
	}

	inline CVector operator/(const float f)
	{
		return CVector(x / f, y / f, z / f);
	}

	inline void operator/=(const float f)
	{
		[swap_lines]
		x /= f;
		y /= f;
		z /= f;
		[/swap_lines]
	}
	
	inline void operator=(const float* f)
	{
		[swap_lines]
		x = f[0];
		y = f[1];
		z = f[2];
		[/swap_lines]
	}

	inline void operator=(const float& f)
	{
		x = y = z = f;
	}

	inline bool operator==(const CVector& v)
	{
		return (x == v.x && y == v.y && z == v.z);
	}

	inline bool operator!=(const CVector& v)
	{
		return (x != v.x && y != v.y && z != v.z);
	}

	inline bool operator<=(const CVector& v)
	{
		return (x <= v.x && y <= v.y && z <= v.z);
	}

	inline bool operator>=(const CVector& v)
	{
		return (x >= v.x && y >= v.y && z >= v.z);
	}

	inline bool operator>(const CVector& v)
	{
		return (x > v.x && y > v.y && z > v.z);
	}

	inline bool operator<(const CVector& v)
	{
		return (x < v.x && y < v.y && z < v.z);
	}
};

class CVector2D
{

public:

	// Data members
	float x, y;

	[add_junk_datamembers /]

	// Ctors
	inline CVector2D() : x(0.0f), y(0.0f)
	{
	}

	inline CVector2D(float fX, float fY) : x(fX), y(fY)
	{
	}

	inline CVector2D(const CVector& v) : x(v.x), y(v.y)
	{
	}

	inline CVector2D(float num[2]) : x(num[X_INDEX]), y(num[Y_INDEX])
	{
	}

	inline void PrintInfo()
	{
		printf_s("%f | %f", x, y);
	}

	inline void ZeroOut()
	{
		x = y = 0.0f;
	}

	inline float FastSQRT(float f)
	{
		__m128 root = _mm_sqrt_ss(_mm_load_ss(&f));
		return *(reinterpret_cast<float *>(&root));
	}

	inline float Length()
	{
		return FastSQRT(x*x + y*y);
	}

	inline float DotProduct(CVector2D v)
	{
		return (x * v.x + y * v.y);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();

		[swap_lines]
		x *= l;
		y *= l;
		[/swap_lines]
	}

	inline float ToDegree(CVector2D to)
	{
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		return *(&x + i);
	}

	inline CVector2D operator+(const CVector2D& v)
	{
		return CVector2D(x + v.x, y + v.y);
	}

	inline void operator+= (const CVector2D& v)
	{
		[swap_lines]
		x += v.x;
		y += v.y;
		[/swap_lines]
	}

	inline CVector2D operator-(const CVector2D& v)
	{
		return CVector2D(x - v.x, y - v.y);
	}

	inline void operator-=(const CVector2D& v)
	{
		[swap_lines]
		x -= v.x;
		y -= v.y;
		[/swap_lines]
	}

	inline CVector2D operator*(const float f)
	{
		return CVector2D(x * f, y * f);
	}

	inline void operator*=(const float f)
	{
		[swap_lines]
		x *= f;
		y *= f;
		[/swap_lines]
	}

	inline CVector2D operator/(const float f)
	{
		return CVector2D(x / f, y / f);
	}

	inline void operator/=(const float f)
	{
		[swap_lines]
		x /= f;
		y /= f;
		[/swap_lines]
	}

	inline void operator=(const float* f)
	{
		[swap_lines]
		x = f[0];
		y = f[1];
		[/swap_lines]
	}

	inline void operator=(const float& f)
	{
		x = y = f;
	}

	inline bool operator==(const CVector2D& v)
	{
		return (x == v.x && y == v.y);
	}

	inline bool operator!=(const CVector2D& v)
	{
		return (x != v.x && y != v.y);
	}

	inline bool operator<=(const CVector2D& v)
	{
		return (x <= v.x && y <= v.y);
	}

	inline bool operator>=(const CVector2D& v)
	{
		return (x >= v.x && y >= v.y);
	}

	inline bool operator>(const CVector2D& v)
	{
		return (x > v.x && y > v.y);
	}

	inline bool operator<(const CVector2D& v)
	{
		return (x < v.x && y < v.y);
	}
};

#endif