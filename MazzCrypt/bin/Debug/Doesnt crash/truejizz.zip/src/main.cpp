#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CSGO.h"
#include "GlowESP.h"
#include "SubtleAimbot.h"

#include <time.h>
#include <thread>

#include "Decrypt.h"

// Memory Leak Detection
//#include <vld.h>

// Globals

char* programPath = "";
CSGO csgo;

[enc_string_enable /]

void UpdateEntitiesConstantly(CSGO* csgo)
{
	while (!csgo->m_Hacks.tThreadHandling.bUpdateStop)
	{
		csgo->UpdateEntities();
		Sleep(1);
	}
}


int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	// Set up minidumper in case we have a crash
	SetUnhandledExceptionFilter(CMiscUtils::MinidumpHelper);

	if (argc > 0)
	{
		programPath = argv[0];
	}

	// Create a random title and allow debugging access for this process
	CMiscUtils::GenerateRandomWindowTitle(20);
	CMiscUtils::AllowDebugging();

	CMiscUtils::PrintLine(std::string("~ SmurfStomper [CSGO] : Completely recoded and redone ~"));
	CMiscUtils::PrintLine(std::string("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	CMiscUtils::PrintLine(std::string("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now."));
	std::cout << "\b\b";

	while (!csgo.Attach())
	{
		std::cout << "_";
		Sleep(100);\
		std::cout << "\b_";
	}

	CMiscUtils::PrintLine(std::string("\n> CSGO attached!"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	CMiscUtils::PrintLine(std::string("> Loading INI Settings..."));
	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));

	if (!CMiscUtils::LoadINISettings(std::string("settings.ini"), &csgo))
	{
		csgo.m_Hacks.Unset(BIT_SUBTLEAIMBOT | BIT_TRIGGERBOT | BIT_BHOP | BIT_RCS | BIT_ESP);
	}

	CMiscUtils::PrintLine(std::string("> Press INSERT whenever your ready to 'toggle'"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	while (!GetAsyncKeyState(VK_INSERT))
	{
		Sleep(100);
	}

	CMiscUtils::PrintLine(std::string("> Starting cheat threads.."));

	// Start the threads
	std::thread threadUpdateEnts(UpdateEntitiesConstantly, &csgo);

	std::thread threadGlowESP(&GlowESP::Start, GlowESP(&csgo));
	std::thread threadAimbot(&SubtleAimbot::Start, SubtleAimbot(&csgo));


	CMiscUtils::PrintLine(std::string("> Cheat running! Press END at any time to stop."));

	CMiscUtils::PrintLine(std::string(">	!!! ~ CONTROLS ~ !!!"));
	CMiscUtils::PrintLine(std::string(""));
	CMiscUtils::PrintLine(std::string(">	INSERT - ReAttach & Refresh Values"));
	CMiscUtils::PrintLine(std::string(">	HOME - Reload INI"));
	CMiscUtils::PrintLine(std::string(">	Middle Mouse - GlowESP"));
	CMiscUtils::PrintLine(std::string(">	C - Subtle Aimbot"));
	CMiscUtils::PrintLine(std::string(""));


	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{

		if (GetAsyncKeyState(VK_HOME) & 1)
		{
			CMiscUtils::PrintLine(std::string("> Loading INI Settings..."));
			CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
			CMiscUtils::LoadINISettings(std::string("settings.ini"), &csgo);
		}

		// Handle reattaching (every map change)
		if (GetAsyncKeyState(VK_INSERT) & 1)
		{
			CMiscUtils::PrintLine(std::string("> Loading INI Settings..."));
			CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
			CMiscUtils::LoadINISettings(std::string("settings.ini"), &csgo);

			CMiscUtils::PrintLine(std::string("> Refreshing..."));
			CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
			csgo.LoadBases();

			system("cls");

			CMiscUtils::PrintLine(std::string(">	!!! ~ CONTROLS ~ !!!"));
			CMiscUtils::PrintLine(std::string("-----------------------------------------"));
			CMiscUtils::PrintLine(std::string(">	INSERT - ReAttach & Refresh Values"));
			CMiscUtils::PrintLine(std::string(">	HOME - Reload INI"));
			CMiscUtils::PrintLine(std::string(">	Middle Mouse - GlowESP"));
			CMiscUtils::PrintLine(std::string(">	C - Subtle Aimbot"));
			CMiscUtils::PrintLine(std::string("-----------------------------------------"));
		}

[enc_string_disable /]

		// Handle triggerbot
		if (GetAsyncKeyState(csgo.m_Hacks.tTriggerOptions.iKey) < 0)
		{
			csgo.m_Hacks.Set(BIT_TRIGGERBOT);
			Sleep(50);
		}
		else
		{
			csgo.m_Hacks.Unset(BIT_TRIGGERBOT);
			Sleep(50);
		}

		// Handle Glowing
		if (GetAsyncKeyState(csgo.m_Hacks.tGlowOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_ESP);
			Sleep(50);
		}

		// Handle Subtle Aimbot
		if (GetAsyncKeyState(csgo.m_Hacks.tSubtleAimbotOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_SUBTLEAIMBOT);
			Sleep(50);
		}
	}

	csgo.m_Mem.Detach();
	CMiscUtils::DeleteSelf(programPath);


	exit(0);

}