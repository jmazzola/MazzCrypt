#include "INIReader.h"
#include "ini.h"
#include <algorithm>
using std::string;

[junk_enable /]


INIReader::INIReader(string filename)
{
	[add_junk 3 4 /]
	m_iError = ini_parse(filename.c_str(), ValHandler, this);
}

INIReader::~INIReader()
{
}

int INIReader::ParseError()
{
	[add_junk 3 4 /]
	return m_iError;
}

string INIReader::GetString(string section, string name, string defVal = "Error")
{
	string key = MakeKey(section, name);
	[add_junk 3 4 /]
	return m_mValues.count(key) ? m_mValues[key] : defVal;
}

long INIReader::GetInteger(string section, string name, long defVal = -1)
{
	string valstr = GetString(section, name);
	char* end;

	[add_junk 3 4 /]

	long n = strtol(valstr.c_str(), &end, 0);
	return (end > valstr.c_str()) ? n : defVal;

}

float INIReader::GetFloat(string section, string name, float defVal)
{
	string valstr = GetString(section, name);
	char* end;

	[add_junk 3 4 /]

	float n = strtof(valstr.c_str(), &end);
	return (end > valstr.c_str()) ? n : defVal;
}

bool INIReader::GetBoolean(string section, string name, bool defVal)
{
	string valstr = GetString(section, name);
	char* end;

	[add_junk 2 4 /]

	if (!_stricmp(valstr.c_str(), "on") || !_stricmp(valstr.c_str(), "yes") || !_stricmp(valstr.c_str(), "1") || !_stricmp(valstr.c_str(), "true"))
		return true;
	else if (!_stricmp(valstr.c_str(), "off") || !_stricmp(valstr.c_str(), "no") || !_stricmp(valstr.c_str(), "0") || !_stricmp(valstr.c_str(), "false"))
		return false;
	else
		return defVal;
}

string INIReader::MakeKey(string section, string name)
{
	string key = section + "." + name;
	// Convert to lower case to make section/name lookups case-insensitive
	std::transform(key.begin(), key.end(), key.begin(), ::tolower);
	[add_junk 3 4 /]
	return key;
}

int INIReader::ValHandler(void* user, const char* section, const char* name, const char* value)
{
	INIReader* reader = (INIReader*)user;
	[add_junk 3 4 /]
	string key = MakeKey(section, name);

	[add_junk 5 7 /]

	if (reader->m_mValues[key].size() > 0)
		reader->m_mValues[key] += "\n";

	reader->m_mValues[key] += value;

	return 1;
}
