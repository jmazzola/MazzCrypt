#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CSGO.h"
#include "GlowESP.h"
#include "SubtleAimbot.h"
#include "ConsoleMenu.h"

#include <time.h>
#include <thread>

#include "Decrypt.h"

// Memory Leak Detection
//#include <vld.h>

// Globals

char* programPath = "";
CSGO csgo;

[enc_string_enable /]
[junk_enable /]

void UpdateEntitiesConstantly(CSGO* csgo)
{
	while (!csgo->m_Hacks.tThreadHandling.bUpdateStop)
	{
		// Check if we're in game
		int clientState = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + EnginePtr);
		int sos = csgo->m_Mem.Read<int>(clientState + SignOnState);

		[add_junk 1 5 /]

		if (sos == SOS_Full)
		{
			csgo->LoadBases();
			
			[add_junk 1 5 /]

			[swap_lines]
			csgo->m_Hacks.tThreadHandling.bGlowThreadStop = false;
			csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
			[/swap_lines]

			std::string newHash = CMiscUtils::GetHash(std::string("settings.ini"));

			if (strcmp(newHash.c_str(), csgo->m_Hacks.hacksHash.c_str()))
			{
				CMiscUtils::PrintLine(std::string(".ini file has been changed. Automatically loading new settings!\n"));
				[add_junk 4 10 /]
				CMiscUtils::LoadINISettings(std::string("settings.ini"), csgo);
			}

			[add_junk 3 5 /]
		}
		else
		{
			[swap_lines]
			csgo->m_Hacks.tThreadHandling.bGlowThreadStop = true;
			csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = true;
			[/swap_lines]
			continue;
		}

		csgo->UpdateEntities();
		Sleep(1);
	}
}


void DisplayControls()
{
	system("cls");

	CMiscUtils::PrintLine(std::string(">	~ SmurfStomper Ghetto CONTROLS ~ "));
	CMiscUtils::PrintLine(std::string("-----------------------------------------"));
	//CMiscUtils::PrintLine(std::string(">	INSERT - ReAttach & Refresh Values"));
	//CMiscUtils::PrintLine(std::string(">	HOME - Reload INI"));
	CMiscUtils::PrintLine(std::string(">	Middle Mouse - GlowESP: ") + std::string(BoolToString(csgo.m_Hacks.CheckBit(BIT_ESP))));
	CMiscUtils::PrintLine(std::string(">	C - Subtle Aimbot: ") + std::string(BoolToString(csgo.m_Hacks.CheckBit(BIT_SUBTLEAIMBOT))));
	CMiscUtils::PrintLine(std::string("-----------------------------------------"));
}


int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	// Set up minidumper in case we have a crash
	SetUnhandledExceptionFilter(CMiscUtils::MinidumpHelper);

	if (argc > 0)
	{
		programPath = argv[0];
	}

	// Create a random title and allow debugging access for this process
	CMiscUtils::GenerateRandomWindowTitle(20);
	CMiscUtils::AllowDebugging();

	CMiscUtils::PrintLine(std::string("~ SmurfStomper [CSGO] : Completely recoded and redone ~"));
	CMiscUtils::PrintLine(std::string("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	CMiscUtils::PrintLine(std::string("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now."));
	std::cout << "\b\b";

	while (!csgo.Attach())
	{
		std::cout << "_";
		Sleep(100);\
		std::cout << "\b_";
	}

	CMiscUtils::PrintLine(std::string("\n> CSGO attached!"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	CMiscUtils::PrintLine(std::string("> Loading INI Settings..."));
	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));

	if (!CMiscUtils::LoadINISettings(std::string("settings.ini"), &csgo))
	{
		csgo.m_Hacks.Unset(BIT_SUBTLEAIMBOT | BIT_TRIGGERBOT | BIT_BHOP | BIT_RCS | BIT_ESP);
	}

	CMiscUtils::PrintLine(std::string("> Press INSERT whenever your ready to 'toggle'"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	while (!GetAsyncKeyState(VK_INSERT))
	{
		Sleep(100);
	}

	CMiscUtils::PrintLine(std::string("> Starting cheat threads.."));

	// Load our basic information
	csgo.LoadBases();

	// Start the threads
	std::thread threadUpdateEnts(UpdateEntitiesConstantly, &csgo);
	std::thread threadGlowESP(&GlowESP::Start, GlowESP(&csgo));
	std::thread threadAimbot(&SubtleAimbot::Start, SubtleAimbot(&csgo));

	
	DisplayControls();


	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{
		// Handle triggerbot
		if (GetAsyncKeyState(csgo.m_Hacks.tTriggerOptions.iKey) < 0)
		{
			csgo.m_Hacks.Set(BIT_TRIGGERBOT);
			Sleep(50);
		}
		else
		{
			csgo.m_Hacks.Unset(BIT_TRIGGERBOT);
			Sleep(50);
		}

		// Handle GlowESP
		if (GetAsyncKeyState(csgo.m_Hacks.tGlowOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_ESP);
			Sleep(50);

			DisplayControls();

		}

		// Handle Subtle Aimbot
		if (GetAsyncKeyState(csgo.m_Hacks.tSubtleAimbotOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_SUBTLEAIMBOT);
			Sleep(50);

			DisplayControls();
		}
	}

	csgo.m_Mem.Detach();
	CMiscUtils::DeleteSelf(programPath);


	exit(0);

}