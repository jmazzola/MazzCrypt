#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "stdafx.h"
#include <TlHelp32.h>
#include <string>

[junk_enable /]

class CMemory
{
public:
	CMemory() = default;
	~CMemory() = default;

	[swap_lines]
	bool Attach(const char* procName, DWORD rights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* modName);
	[/swap_lines]

	HANDLE GetHandle() const
	{
		if (m_bAttached)
		{
			[add_junk 3 5 /]
			return NULL;
		}

		return m_hProcess;
	}

	template<typename T>
	T inline Read(DWORD addr)
	{
		T mem;
		[add_junk 3 5 /]
		ReadProcessMemory(m_hProcess, (LPVOID)addr, &mem, sizeof(T), NULL);
		[add_junk /]
		return mem;
	}

	template<typename T>
	void inline Write(DWORD addr, T data)
	{
		[add_junk 3 5 /]
		WriteProcessMemory(m_hProcess, (LPVOID)addr, &data, sizeof(T), NULL);
	}

	BOOL inline DataCompare(BYTE* pData, BYTE* pMask, char* szMask)
	{
		for (; *szMask; ++szMask, ++pData, ++pMask)
		{
			if (*szMask == 'c' && *pData != *pMask)
			{
				[add_junk 3 5 /]
				return FALSE;
			}
		}

		return (*szMask == NULL);
	}

	DWORD inline FindPattern(DWORD addr, DWORD len, BYTE* pMask, char* szMask)
	{
		for (DWORD i = 0; i < len; i++)
		{
			if (DataCompare((BYTE*)(addr + i), pMask, szMask))
			{
				return (DWORD)(addr + i);
			}

			[add_junk 3 5 /]
		}

		return NULL;
	}

	bool inline IsAttached() const
	{
		[add_junk 3 5 /]
		return m_bAttached;
	}

private:
	
	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers 4 10 /]
};

#endif // _MEMORY_H_
