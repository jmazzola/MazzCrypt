#ifndef _CSGO_H_
#define _CSGO_H_

#include "Vector.h"
#include "Memory.h"

#define BIT_TRIGGERBOT 0x1
#define BIT_SUBTLEAIMBOT 0x2
#define BIT_ESP 0x4
#define BIT_RCS 0x8
#define BIT_BHOP 0x10

[junk_enable /]

// Enums
enum EWeaponType
{
	[swap_lines]
	WeapType_Pistol = 0,
	WeapType_Rifle = 1,
	WeapType_SMG = 2,
	WeapType_Sniper = 3,
	WeapType_KnifeType = 4,
	WeapType_Grenade = 5,
	WeapType_LMG = 6,
	WeapType_Shotgun = 7,
	WeapType_ZeusGun = 8,
	WeapType_C4Explosive = 9,
	[/swap_lines]
};

enum ESpectatorView
{
	[swap_lines]
	SV_NotSpectating = 0,
	SV_DeathCam = 1,
	SV_FreezeCam = 2,
	SV_Fixed = 3,
	SV_FirstPerson = 4,
	SV_ThirdPerson = 5,
	SV_Free = 6,
	[/swap_lines]
};

enum EWeaponIDs
{
	[swap_lines]
	WID_None = 0,
	WID_Deagle = 1,
	WID_Dual_Berettas = 2,
	WID_Five_Seven = 3,
	WID_Glock = 4,
	WID_AK47 = 7,
	WID_AUG = 8,
	WID_AWP = 9,
	WID_FAMAS = 10,
	WID_G3SG1_Auto = 11,
	WID_Galil = 13,
	WID_M249 = 14,
	WID_M4A4 = 16,
	WID_MAC10 = 17,
	WID_P90 = 19,
	WID_UMP45 = 24,
	WID_XM1014 = 25,
	WID_PPBizon = 26,
	WID_MAG7 = 27,
	WID_Negev = 28,
	WID_SawedOff = 29,
	WID_Tec9 = 30,
	WID_Zeus = 31,
	WID_P2000 = 32,
	WID_MP7 = 33,
	WID_MP9 = 34,
	WID_Nova = 35,
	WID_P250 = 36,
	WID_SCAR_Auto = 38,
	WID_SG553 = 39,
	WID_Scout = 40,
	WID_Knife = 42,
	WID_Flashbang = 43,
	WID_HEFrag = 44,
	WID_Smoke = 45,
	WID_Molly = 46,
	WID_Decoy = 47,
	WID_Firebomb = 48,
	WID_C4 = 49,
	WID_MusicKit = 58,
	WID_Default_Knife = 59,
	WID_M4A1S = 60,
	WID_USP = 61,
	WID_TradeUpContract = 62,
	WID_CZ75 = 63,
	WID_BayonetKnife = 500,
	WID_FlipKnife = 505,
	WID_GutKnife = 506,
	WID_KarambitKnife = 507,
	WID_M9BayonetKnife = 508,
	WID_HuntsmanKnife = 509,
	WID_FalchionKnife = 512,
	WID_ButterflyKnife = 515,
	[/swap_lines]
};

enum EClassIDs
{
	[swap_lines]
	CID_AK47 = 1,
	CID_BaseAnimating = 2,
	CID_BaseCSGrenadeProjectile = 9,
	CID_BaseDoor = 10,
	CID_BaseEntity = 11,
	CID_BaseTrigger = 20,
	CID_C4 = 28,
	CID_CascadeLight = 29,
	CID_Chicken = 30,
	CID_ColorCorrection = 31,
	CID_CSGameRulesProxy = 33,
	CID_CSPlayer = 34,
	CID_CSPlayerResource = 35,
	CID_CSRagdoll = 36,
	CID_CSTeam = 37,
	CID_DEagle = 38,
	CID_DecoyGrenade = 40,
	CID_DynamicProp = 42,
	CID_EnvDetailController = 50,
	CID_EnvTonemapController = 57,
	CID_EnvWind = 58,
	CID_Grenade59 = 59,
	CID_Grenade60 = 60,
	CID_Grenade61 = 61,
	CID_Grenade62 = 62,
	CID_Flashbang = 63,
	CID_FogController = 64,
	CID_Func_Dust = 66,
	CID_FuncBrush = 69,
	CID_FuncOccluder = 74,
	CID_FuncRotating = 76,
	CID_Grenade77 = 77,
	CID_Grenade78 = 78,
	CID_Grenade79 = 79,
	CID_MolotovGrenade,
	CID_HEGrenade = 81,
	CID_Hostage = 82,
	CID_HostageCarriableProp = 83,
	CID_Grenade84 = 84,
	CID_Inferno = 85,
	CID_Grenade86 = 86,
	CID_Grenade87 = 87,
	CID_Knife = 88,
	CID_LightGlow = 90,
	CID_Grenade91 = 91,
	CID_Grenade92 = 92,
	CID_IncendiaryGrenade = 93,
	CID_Grenade94 = 94,
	CID_Grenade95 = 95,
	CID_Grenade96 = 96,
	CID_ParticleSystem = 97,
	CID_Grenade98 = 98,
	CID_Grenade99 = 99,
	CID_PhysicsProp = 100,
	CID_PhysicsPropMultiplayer = 101,
	CID_Grenade102 = 102,
	CID_PlantedC4 = 103,
	CID_Grenade104 = 104,
	CID_Grenade105 = 105,
	CID_Grenade106 = 106,
	CID_Grenade107 = 107,
	CID_Grenade108 = 108,
	CID_PostProcessController = 109,
	CID_Grenade110 = 110,
	CID_Grenade111 = 111,
	CID_PredictedViewModel = 112,
	CID_PropDoorRotating = 114,
	CID_Grenade115 = 115,
	CID_Grenade116 = 116,
	CID_Grenade117 = 117,
	CID_Grenade118 = 118,
	CID_Grenade119 = 119,
	CID_RopeKeyframe = 120,
	CID_ShadowControl = 123,
	CID_Grenade124 = 124,
	CID_Grenade125 = 125,
	CID_SmokeGrenade = 126,
	CID_Sprite = 129,
	CID_Sun = 134,
	CID_VGuiScreen = 190,
	CID_VoteController = 191,
	CID_Weapon192 = 192,
	CID_Weapon193 = 193,
	CID_Weapon194 = 194,
	CID_WeaponAUG = 195,
	CID_WeaponAWP = 196,
	CID_WeaponBizon = 197,
	CID_Weapon198 = 198,
	CID_Weapon199 = 199,
	CID_Weapon200 = 200,
	CID_WeaponElite = 201,
	CID_WeaponFAMAS = 202,
	CID_WeaponFiveSeven = 203,
	CID_WeaponG3SG1 = 204,
	CID_Weapon205 = 205,
	CID_WeaponGalilAR = 206,
	CID_WeaponGlock = 207,
	CID_WeaponHKP2000 = 208,
	CID_WeaponM249 = 209,
	CID_WeaponM4A1 = 210,
	CID_WeaponM4A4 = 211,
	CID_Weapon212 = 212,
	CID_WeaponMag7 = 213,
	CID_Weapon214 = 214,
	CID_WeaponMP7 = 215,
	CID_WeaponMP9 = 216,
	CID_WeaponNegev = 217,
	CID_WeaponNOVA = 218,
	CID_Weapon219 = 219,
	CID_WeaponP250 = 220,
	CID_WeaponP90 = 221,
	CID_WeaponSawedOff = 222,
	CID_WeaponScar20 = 223,
	CID_Weapon224 = 224,
	CID_Weapon225 = 225,
	CID_WeaponSG556 = 226,
	CID_WeaponSSG08 = 227,
	CID_Weapon228 = 228,
	CID_WeaponTaser = 229,
	CID_WeaponTec9 = 230,
	CID_WeaponUMP45 = 232,
	CID_Weapon233 = 233,
	CID_WeaponXM1014 = 234,
	CID_World = 235,
	CID_Weapon = 48879,
	CID_Unknown = 57005,
	[/swap_lines]
};

enum EBones : int
{
	[swap_lines]
	Bone_Pelvis = 0,
	Bone_Spine1 = 1,
	Bone_Spine2 = 2,
	Bone_Spine3 = 3,
	Bone_Spine4 = 4,
	Bone_Neck = 5,
	Bone_LeftClavicle = 6,
	Bone_LeftUpperarm = 7,
	Bone_LeftForearm = 8,
	Bone_LeftHand = 9,
	Bone_Head = 10,
	Bone_Forward = 11,
	Bone_RightClavicle = 12,
	Bone_RightUpperarm = 13,
	Bone_RightForearm = 14,
	Bone_RightHand = 15,
	Bone_Weapon = 16,
	Bone_WeaponSlide = 17,
	Bone_WeaponRightHand = 18,
	Bone_WeaponLeftHand = 19,
	Bone_WeaponClip1 = 20,
	Bone_WeaponClip2 = 21,
	Bone_Silencer = 22,
	Bone_RightThigh = 23,
	Bone_RightCalf = 24,
	Bone_RightFoot = 25,
	Bone_LeftThigh = 26,
	Bone_LeftCalf = 27,
	Bone_LeftFoot = 28,
	Bone_LeftWeaponHand = 29,
	Bone_RightWeaponHand = 30,
	Bone_LeftForeTwist = 31,
	Bone_LeftCalfTwist = 32,
	Bone_RightCalfTwist = 33,
	Bone_LeftThighTwist = 34,
	Bone_RightThighTwist = 35,
	Bone_LeftUpArmTwist = 36,
	Bone_RightUpArmTwist = 37,
	Bone_RightForeTwist = 38,
	Bone_RightToe = 39,
	Bone_LeftToe = 40,
	Bone_RightFinger01 = 41,
	Bone_RightFinger02 = 42,
	Bone_RightFinger03 = 43,
	Bone_RightFinger04 = 44,
	Bone_RightFinger05 = 45,
	Bone_RightFinger06 = 46,
	Bone_RightFinger07 = 47,
	Bone_RightFinger08 = 48,
	Bone_RightFinger09 = 49,
	Bone_RightFinger10 = 50,
	Bone_RightFinger11 = 51,
	Bone_RightFinger12 = 52,
	Bone_RightFinger13 = 53,
	Bone_RightFinger14 = 54,
	Bone_LeftFinger01 = 55,
	Bone_LeftFinger02 = 56,
	Bone_LeftFinger03 = 57,
	Bone_LeftFinger04 = 58,
	Bone_LeftFinger05 = 59,
	Bone_LeftFinger06 = 60,
	Bone_LeftFinger07 = 61,
	Bone_LeftFinger08 = 62,
	Bone_LeftFinger09 = 63,
	Bone_LeftFinger10 = 64,
	Bone_LeftFinger11 = 65,
	Bone_LeftFinger12 = 66,
	Bone_LeftFinger13 = 67,
	Bone_LeftFinger14 = 68,
	Bone_LeftFinger15 = 69,
	Bone_RightFinger15 = 70,
	Bone_MAX = 71,
	[/swap_lines]
};

enum EHitboxes
{
	[swap_lines]
	HB_Pelvis = 0,
	HB_LeftThigh = 1,
	HB_LeftCalf = 2,
	HB_LeftFoot = 3,
	HB_RightThigh = 4,
	HB_RightCalf = 5,
	HB_RightFoot = 6,
	HB_Spine1 = 7,
	HB_Spine2 = 8,
	HB_Spine3 = 9,
	HB_Neck = 10,
	HB_Head = 11,
	HB_LeftUpperArm = 12,
	HB_LeftForearm = 13,
	HB_LeftHand = 14,
	HB_RightUpperArm = 15,
	HB_RightForearm = 16,
	HB_RightHand = 17,
	HB_LeftClavicle = 18,
	HB_RightClavicle = 19,
	HB_Helmet = 20,
	HB_Spine4 = 21,
	[/swap_lines]
};

enum ETeams : int
{
	[swap_lines]
	Team_NoTeam = 0,
	Team_Spectator = 1,
	Team_Terrorists = 2,
	Team_CounterTerrorists = 3,
	[/swap_lines]
};

enum ESignOnState : int
{
	SOS_None = 0,
	SOS_Challenge = 1,
	SOS_Connected = 2,
	SOS_New = 3,
	SOS_Prespawn = 4,
	SOS_Spawn = 5,
	SOS_Full = 6,
	SOS_ChangeLevel = 7,
};

// TODO: make this sigscan, kthx.
enum EOffsets
{
	[swap_lines]
	LocalPlayer = 0xA77D2C,
	EntityBase = 0x4A19D84,
	EnginePtr = 0x5D2284,
	Jump = 0x4AAAAF8,
	ViewMatrix = 0x4A0F314,
	GlowObject = 0x4B2CD44,
	RadarBase = 0x4A4EA2C,
	GameResources = 0x2E8945C,
	CompetitiveRank = 0x1A3C,
	CompetitiveWins = 0x1B40,
	ActiveWeapon = 0x12C0,		//m_hActiveWeapon
	ActiveWeapID = 0x1C,
	Id = 0x64,
	SignOnState = 0xE8,
	Dormant = 0xE9,				//m_bDormant
	Health = 0xFC,				//m_iHealth
	Team = 0xF0,				//m_iTeamNum 
	Flags = 0x100,				//m_fFlags
	VecViewOffset = 0x104,		//m_vecViewOffset[0]
	VecVelocity = 0x110,		//m_vecVelocity[0]
	Origin = 0x134,				//m_vecOrigin -> CS_BasePlayer
	OwnerEntity = 0x148,		//m_hOwner
	LifeState = 0x25B,			//m_lifeState
	Spotted = 0x935,			//m_bSpotted
	BoneMatrix = 0xA78,
	PunchVector = 0x13E8,		// F3 0F 7E 82 E8 13 ?? ?? 8B 82 F0 13 ?? ?? [xmm0, qword ptr [edx+PunchVector] ]
	PrimaryAmmo = 0x15C0,		//m_iClip1
	SecondaryAmmo = 0x15C4,		//m_iClip2
	IsReloading = 0x1601,		//m_bInReload
	SpectatorView = 0x1728,		//m_iObserverMode 
	SpectatorTarget = 0x173C,	//m_hObserverTarget
	ShotsFired = 0x1D6C,		//m_iShotsFired
	FlashDuration = 0x1DB4,		//m_flFlashDuration
	IsDefusing = 0x1C08,		//m_bIsDefusing
	HasImmunity = 0x1C14,		//m_bGunGameImmunity
	FlashMaxAlpha = 0x1DB0,		//m_flFlashMaxAlpha
	HasHelmet = 0x23A8,			//m_bHasHelmet
	Armor = 0x23B0,				//m_ArmorValue 
	HasDefuseKit = 0x23C0,		//m_bHasDefuser
	Class = 0x23AC,				//m_iClass
	CrosshairID = 0x2410,		//m_iCrosshairID
	AccuracyPenalty = 0x1670,	//m_fAccuracyPenalty
	FOVStart = 0x159C,			//m_iFOVStart
	ViewAngles = 0x4CE0,
	[/swap_lines]

};

// Static strings
static std::string Ranks[] =
{
	"Unranked",
	"Silver I",
	"Silver II",
	"Silver III",
	"Silver IV",
	"Silver Elite",
	"Silver Elite Master",
	"Gold Nova I",
	"Gold Nova II",
	"Gold Nova III",
	"Gold Nova Master",
	"Master Guardian I",
	"Master Guardian II",
	"Master Guardian Elite",
	"Distinguished Master Guardian",
	"Legendary Eagle",
	"Legendary Eagle Master",
	"Supreme Master First Class",
	"The Global Elite"
};

// Structs
struct Hitbox
{

	public:
		[swap_lines]
		int iBone;
		CVector vMin;
		CVector vMax;
		[/swap_lines]

	void Setup(int b, CVector mi, CVector ma)
	{
		[swap_lines]
		iBone = b;
		vMin = mi;
		vMax = ma;
		[/swap_lines]
	}
};

struct Player
{

	public:
		DWORD baseAddr;				// Base address

		[swap_lines]
		CVector bones[30];			// bones
		CVector vOrigin;			// m_vecOrigin
		CVector vViewAngles;		// m_vecAngles
		CVector vVelocity;			// m_vecVelocity
		CVector vVecViewOffset;		// m_vecViewOffset
		CVector vEyePos;
		CVector2D vPunchAngles;		// m_vecPunchAngles
		CVector2D vOldPunchAngles;
		int		iID;				// 
		int		iClassID;			// m_iClass
		int		iFlags;				// m_iFlags
		int		iTeam;				// m_iTeam
		int		iHealth;			// m_iHealth
		int		iArmor;				// m_iArmorValue
		int		iWeaponID;			
		int		iAmmo_Primary;		// m_iClip1
		int		iAmmo_Secondary;	// m_iClip2
		int		iShotsFired;		// m_iShotsFired
		int		iSpectatorMode;		// m_iObserverMode
		int		iSpectatorTarget;	// m_iObserverTarget
		int		iOwnerEntity;		// m_hOwner
		int		iRank;			// rank from gameresources
		int		iWins;			// wins from gameresources
		float	fFlashDuration;		// m_fFlashDuration
		bool	bHasHelmet;			// m_bHasHelmet
		bool	bHasDefuser;		// m_bHasDefuser
		bool	bIsDefusing;		// m_bIsDefusing
		bool	bIsSpotted;			// m_bSpotted
		bool	bIsReloading;		// m_bIsReloading
		bool	bAlive;				
		bool	bIsDormant;			// m_bDormant [0xE9]
		bool	bHasBomb = false;
		[/swap_lines]


}; 

struct TriggerOptions
{

	public:
		[swap_lines]
		int iDelay;				// Delay in MS for sleep
		int iKey;				// VK for the key to toggle
		bool bStopOnSpectate;	// Stop when being spectated
		[/swap_lines]
};

struct GlowOptions
{

	public:
		[swap_lines]
		int iKey;				// VK for key to toggle
		bool bEnemyOnly;		// Only show enemy information
		bool bHealthGlow;		// Show health glow
		bool bGlowBomb;			// Glow the bomb
		bool bGlowWeapons;		// Glow weapons in hands/on ground
		bool bGlowGrenades;		// Glow grenades in hands/on ground/in air
		bool bDefuseGlow;		// Glow black when defusing
		bool bFlashGlow;		// Glow white when flashed
		float fGlowEnemy_R;		// Red channel for enemies
		float fGlowEnemy_G;		// Green channel for enemies
		float fGlowEnemy_B;		// Blue channel for enemies
		float fGlowEnemy_A;		// Alpha channel for enemies
		float fGlowTeam_R;		// Red channel for teammates
		float fGlowTeam_G;		// Green channel for teammates
		float fGlowTeam_B;		// Blue channel for teammates
		float fGlowTeam_A;		// Alpha channel for teammates
		[/swap_lines]
};

struct SubtleAimbotOptions
{
	public:

		struct SubtleWeaponSettings
		{
			[swap_lines]
			EBones eBoneToAimAt;
			int iSubtleMinChance;
			int iSubtleMaxChance;
			float fSubtleRCSScale;
			[/swap_lines]
		};

		[swap_lines]
		int iKey;
		float fSmoothFactor;
		SubtleWeaponSettings tWeaponSettings_Pistol;
		SubtleWeaponSettings tWeaponSettings_Rifle;
		SubtleWeaponSettings tWeaponSettings_Sniper;
		SubtleWeaponSettings tWeaponSettings_Shotguns;
		SubtleWeaponSettings tWeaponSettings_SMGs;
		SubtleWeaponSettings tWeaponSettings_LMGs;
		bool bNewMethod;
		[/swap_lines]
};

struct ThreadHandling
{
	public:
		[swap_lines]
		bool bUpdateStop;
		bool bGlowThreadStop;
		bool bTrigThreadStop;
		bool bSubtleAimbotThreadStop;
		bool bConsoleMenuStop;
		[/swap_lines]
};

struct Hacks
{
	// BitField & 0x1 = Triggerbot
	// BitField & 0x2 = Aimbot
	// BitField & 0x4 = ESP
	// BitField & 0x8 = RCS
	// BitField & 0x10 = Bhop

public:

	void Toggle(int iBit)
	{
		iBitField ^= iBit;
		[add_junk 1 3 /]
	}

	void Set(int iBit)
	{
		iBitField |= iBit;
		[add_junk 1 3 /]
	}

	void Unset(int iBit)
	{
		[add_junk 1 3 /]
		iBitField &= ~iBit;
	}

	bool CheckBit(int iBit)
	{
		[add_junk 1 3 /]

		if (iBitField & iBit)
			return true;

		return false;
	}

	[swap_lines]
	unsigned int iBitField;
	std::string hacksHash;
	TriggerOptions tTriggerOptions;
	GlowOptions tGlowOptions;
	SubtleAimbotOptions tSubtleAimbotOptions;
	ThreadHandling tThreadHandling;
	[/swap_lines]
};


class CSGO
{
public:
	CSGO() = default;
	~CSGO() = default;

	[swap_lines]
	bool Attach();
	void UpdateInfo(Player* ply, DWORD addr);
	bool LoadBases();
	void UpdateEntities();
	[/swap_lines]

	Player GetFriendly(DWORD id)
	{
		[add_junk 1 5 /]
		return m_Friendlies[id];
	}

	Player GetEnemy(DWORD id)
	{
		[add_junk 1 5 /]
		return m_Enemies[id];
	}

	int GetTeam(DWORD addr)
	{
		[add_junk 1 5 /]
		return m_Mem.Read<int>(addr + Team);
	}

	int GetEnemyTeam(int team)
	{
		[add_junk 1 5 /]

		if (team == Team_Terrorists)
			return Team_CounterTerrorists;
		else if (team == Team_CounterTerrorists)
			return Team_Terrorists;

		return Team_NoTeam;
	}

	CVector inline BonePosition(DWORD addr, int bone)
	{
		if (bone < 0 || bone >= EBones::Bone_MAX)
			return CVector(0, 0, 0);

		DWORD boneMatrix = m_Mem.Read<int>(addr + BoneMatrix);

		[add_junk 1 5 /]

		[swap_lines]
		float boneX = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0xC);
		float boneY = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0x1C);
		float boneZ = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0x2C);
		[/swap_lines]

		return CVector(boneX, boneY, boneZ);
	}

	int GetClassID(Player* ply)
	{
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);	// Vtable
		[add_junk 1 5 /]
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);	// Function
		[add_junk 1 5 /]
		int cls = m_Mem.Read<int>(fn + 0x1);	// Class
		int clsn = m_Mem.Read<int>(cls + 8);	// Class Name
		return m_Mem.Read<int>(cls + 20);	// ClassID
	}

	char* GetClassNameFromPlayer(Player* ply)
	{
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);
		int cls = m_Mem.Read<int>(fn + 0x1);
		[add_junk 1 5 /]
		int clsn = m_Mem.Read<int>(cls + 8);

		int namePointer = m_Mem.Read<int>(clsn);
		char* nameData = new char[32];

		for (int i = 0; i < 32; i++)
			nameData[i] = m_Mem.Read<char>(namePointer + i);

		[add_junk 1 5 /]

		return nameData;
	}

	bool IsClassIDAWeapon(int iClassID)
	{
		switch (iClassID)
		{
			[swap_lines]
			case CID_AK47:
			case CID_DEagle:
			case CID_WeaponAWP:
			case CID_WeaponAUG:
			case CID_WeaponBizon:
			case CID_WeaponElite:
			case CID_WeaponFAMAS:
			case CID_WeaponFiveSeven:
			case CID_WeaponG3SG1:
			case CID_WeaponGalilAR:
			case CID_WeaponGlock:
			case CID_WeaponHKP2000:
			case CID_WeaponM249:
			case CID_WeaponM4A1:
			case CID_WeaponM4A4:
			case CID_WeaponMag7:
			case CID_WeaponMP7:
			case CID_WeaponMP9:
			case CID_WeaponNegev:
			case CID_WeaponNOVA:
			case CID_WeaponP250:
			case CID_WeaponP90:
			case CID_WeaponSawedOff:
			case CID_WeaponScar20:
			case CID_WeaponSG556:
			case CID_WeaponSSG08:
			case CID_WeaponTaser:
			case CID_WeaponTec9:
			case CID_WeaponUMP45:
			case CID_WeaponXM1014:
			[/swap_lines]
			//case CID_Weapon192:
			//case CID_Weapon193:
			//case CID_Weapon194:
			//case CID_Weapon198:
			//case CID_Weapon199:
			//case CID_Weapon200:
			////case CID_Weapon212:
			////case CID_Weapon214:
			////case CID_Weapon219:
			////case CID_Weapon224:
			////case CID_Weapon225:
			////case CID_Weapon228:
			////case CID_Weapon233:


			return true;
		}

		return false;
	}

	bool IsClassIDAGrenade(int iClassID)
	{
		switch (iClassID)
		{
			[swap_lines]
			case CID_Flashbang:
			case CID_HEGrenade:
			case CID_DecoyGrenade:
			case CID_IncendiaryGrenade:
			case CID_MolotovGrenade:
			case CID_SmokeGrenade:
			case CID_BaseCSGrenadeProjectile:
			[/swap_lines]
			return true;
		}

		return false;
	}

	EWeaponType GetWeaponType(Player& player) const
	{
		int id = player.iWeaponID;

		[add_junk 1 5 /]

		if (id == WID_Deagle || id == WID_Dual_Berettas || id == WID_Five_Seven || id == WID_USP || id == WID_Glock || id == WID_Tec9 || id == WID_P2000 || id == WID_P250 || id == WID_CZ75)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Pistol;
		}
		else if (id == WID_AK47 || id == WID_AUG || id == WID_FAMAS || id == WID_M4A4 || id == WID_M4A1S || id == WID_Galil || id == WID_SG553)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Rifle;
		}
		else if (id == WID_AWP || id == WID_G3SG1_Auto || id == WID_SCAR_Auto || id == WID_Scout)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Sniper;
		}
		else if (id == WID_MAC10 || id == WID_P90 || id == WID_UMP45 || id == WID_PPBizon || id == WID_MP7 || id == WID_MP9)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_SMG;
		}
		else if (id == WID_Negev || id == WID_M249)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_LMG;
		}
		else if (id == WID_XM1014 || id == WID_MAG7 || id == WID_Nova || id == WID_SawedOff)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Shotgun;
		}
		else if (id == WID_Flashbang || id == WID_Smoke || id == WID_Firebomb || id == WID_HEFrag || id == WID_Molly)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Grenade;
		}
		else if (id == WID_C4)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_C4Explosive;
		}
		else if (id == WID_Default_Knife || id == WID_ButterflyKnife || id == WID_HuntsmanKnife || id == WID_M9BayonetKnife || id == WID_FlipKnife || id == WID_KarambitKnife || id == WID_GutKnife || id == WID_BayonetKnife || id == WID_FalchionKnife)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_KnifeType;
		}
		else if (id == WID_Zeus)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_ZeusGun;
		}
		else
		{
			return (EWeaponType)-1;
		}
	}

	[swap_lines]
	CMemory m_Mem;
	DWORD m_dwClientBase;
	DWORD m_dwEngineBase;
	DWORD m_dwLocalBase;
	DWORD m_dwEntityBase;
	DWORD m_dwGlowObjectArrayBase;
	DWORD m_dwGameResourcesBase;
	float m_ViewMatrix[16];
	Player m_Me;
	Player m_Friendlies[32];
	Player m_Enemies[32];
	int m_iEnemiesDetected;
	int m_iFriendliesDetected;
	Hitbox m_Hitboxes[21];
	int m_Spectators[32];
	Hacks m_Hacks;
	int m_iWindowWidth;
	int m_iWindowHeight;
	[/swap_lines]
};

#endif // _CSGO_H_

