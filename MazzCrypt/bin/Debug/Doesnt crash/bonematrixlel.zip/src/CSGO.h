#ifndef _CSGO_H_
#define _CSGO_H_

#include "Vector.h"
#include "Memory.h"

#define BIT_TRIGGERBOT 0x1
#define BIT_SUBTLEAIMBOT 0x2
#define BIT_ESP 0x4
#define BIT_RCS 0x8
#define BIT_BHOP 0x10
#define BIT_AIMBOT 0x20

[junk_enable /]

// Enums
enum EWeaponType
{
	[swap_lines]
	WeapType_Pistol = 0,
	WeapType_Rifle = 1,
	WeapType_SMG = 2,
	WeapType_Sniper = 3,
	WeapType_KnifeType = 4,
	WeapType_Grenade = 5,
	WeapType_LMG = 6,
	WeapType_Shotgun = 7,
	WeapType_ZeusGun = 8,
	WeapType_C4Explosive = 9,
	[/swap_lines]
};

enum ESpectatorView
{
	[swap_lines]
	SV_NotSpectating = 0,
	SV_DeathCam = 1,
	SV_FreezeCam = 2,
	SV_Fixed = 3,
	SV_FirstPerson = 4,
	SV_ThirdPerson = 5,
	SV_Free = 6,
	[/swap_lines]
};

enum EWeaponIDs
{
	[swap_lines]
	WID_None = 0,
	WID_Deagle = 1,
	WID_Dual_Berettas = 2,
	WID_Five_Seven = 3,
	WID_Glock = 4,
	WID_AK47 = 7,
	WID_AUG = 8,
	WID_AWP = 9,
	WID_FAMAS = 10,
	WID_G3SG1_Auto = 11,
	WID_Galil = 13,
	WID_M249 = 14,
	WID_M4A4 = 16,
	WID_MAC10 = 17,
	WID_P90 = 19,
	WID_UMP45 = 24,
	WID_XM1014 = 25,
	WID_PPBizon = 26,
	WID_MAG7 = 27,
	WID_Negev = 28,
	WID_SawedOff = 29,
	WID_Tec9 = 30,
	WID_Zeus = 31,
	WID_P2000 = 32,
	WID_MP7 = 33,
	WID_MP9 = 34,
	WID_Nova = 35,
	WID_P250 = 36,
	WID_SCAR_Auto = 38,
	WID_SG553 = 39,
	WID_Scout = 40,
	WID_Knife = 42,
	WID_Flashbang = 43,
	WID_HEFrag = 44,
	WID_Smoke = 45,
	WID_Molly = 46,
	WID_Decoy = 47,
	WID_Firebomb = 48,
	WID_C4 = 49,
	WID_MusicKit = 58,
	WID_Default_Knife = 59,
	WID_M4A1S = 60,
	WID_USP = 61,
	WID_TradeUpContract = 62,
	WID_CZ75 = 63,
	WID_BayonetKnife = 500,
	WID_FlipKnife = 505,
	WID_GutKnife = 506,
	WID_KarambitKnife = 507,
	WID_M9BayonetKnife = 508,
	WID_HuntsmanKnife = 509,
	WID_FalchionKnife = 512,
	WID_ButterflyKnife = 515,
	[/swap_lines]
};

enum EClassIDs
{
	[swap_lines]
	CAI_BaseNPC = 0,
	CID_CAK47 = 1,
	CID_CBaseAnimating = 2,
	CID_CBaseAnimatingOverlay = 3,
	CID_CBaseAttributableItem = 4,
	CID_CBaseButton = 5,
	CID_CBaseCombatCharacter = 6,
	CID_CBaseCombatWeapon = 7,
	CID_CBaseCSGrenade = 8,
	CID_CBaseCSGrenadeProjectile = 9,
	CID_CBaseDoor = 10,
	CID_CBaseEntity = 11,
	CID_CBaseFlex = 12,
	CID_CBaseGrenade = 13,
	CID_CBaseParticleEntity = 14,
	CID_CBasePlayer = 15,
	CID_CBasePropDoor = 16,
	CID_CBaseTeamObjectiveResource = 17,
	CID_CBaseTempEntity = 18,
	CID_CBaseToggle = 19,
	CID_CBaseTrigger = 20,
	CID_CBaseViewModel = 21,
	CID_CBaseVPhysicsTrigger = 22,
	CID_CBaseWeaponWorldModel = 23,
	CID_CBeam = 24,
	CID_CBeamSpotlight = 25,
	CID_CBoneFollower = 26,
	CID_CBreakableProp = 27,
	CID_CBreakableSurface = 28,
	CID_CC4 = 29,
	CID_CCascadeLight = 30,
	CID_CChicken = 31,
	CID_CColorCorrection = 32,
	CID_CColorCorrectionVolume = 33,
	CID_CCSGameRulesProxy = 34,
	CID_CCSPlayer = 35,
	CID_CCSPlayerResource = 36,
	CID_CCSRagdoll = 37,
	CID_CCSTeam = 38,
	CID_CDEagle = 39,
	CID_CDecoyGrenade = 40,
	CID_CDecoyProjectile = 41,
	CID_CDynamicLight = 42,
	CID_CDynamicProp = 43,
	CID_CEconEntity = 44,
	CID_CEmbers = 45,
	CID_CEntityDissolve = 46,
	CID_CEntityFlame = 47,
	CID_CEntityFreezing = 48,
	CID_CEntityParticleTrail = 49,
	CID_CEnvAmbientLight = 50,
	CID_CEnvDetailController = 51,
	CID_CEnvDOFController = 52,
	CID_CEnvParticleScript = 53,
	CID_CEnvProjectedTexture = 54,
	CID_CEnvQuadraticBeam = 55,
	CID_CEnvScreenEffect = 56,
	CID_CEnvScreenOverlay = 57,
	CID_CEnvTonemapController = 58,
	CID_CEnvWind = 59,
	CID_CFireCrackerBlast = 60,
	CID_CFireSmoke = 61,
	CID_CFireTrail = 62,
	CID_CFish = 63,
	CID_CFlashbang = 64,
	CID_CFogController = 65,
	CID_CFootstepControl = 66,
	CID_CFunc_Dust = 67,
	CID_CFunc_LOD = 68,
	CID_CFuncAreaPortalWindow = 69,
	CID_CFuncBrush = 70,
	CID_CFuncConveyor = 71,
	CID_CFuncLadder = 72,
	CID_CFuncMonitor = 73,
	CID_CFuncMoveLinear = 74,
	CID_CFuncOccluder = 75,
	CID_CFuncReflectiveGlass = 76,
	CID_CFuncRotating = 77,
	CID_CFuncSmokeVolume = 78,
	CID_CFuncTrackTrain = 79,
	CID_CGameRulesProxy = 80,
	CID_CHandleTest = 81,
	CID_CHEGrenade = 82,
	CID_CHostage = 83,
	CID_CHostageCarriableProp = 84,
	CID_CIncendiaryGrenade = 85,
	CID_CInferno = 86,
	CID_CInfoLadderDismount = 87,
	CID_CInfoOverlayAccessor = 88,
	CID_CKnife = 89,
	CID_CKnifeGG = 90,
	CID_CLightGlow = 91,
	CID_CMaterialModifyControl = 92,
	CID_CMolotovGrenade = 93,
	CID_CMolotovProjectile = 94,
	CID_CMovieDisplay = 95,
	CID_CParticleFire = 96,
	CID_CParticlePerformanceMonitor = 97,
	CID_CParticleSystem = 98,
	CID_CPhysBox = 99,
	CID_CPhysBoxMultiplayer = 100,
	CID_CPhysicsProp = 101,
	CID_CPhysicsPropMultiplayer = 102,
	CID_CPhysMagnet = 103,
	CID_CPlantedC4 = 104,
	CID_CPlasma = 105,
	CID_CPlayerResource = 106,
	CID_CPointCamera = 107,
	CID_CPointCommentaryNode = 108,
	CID_CPoseController = 109,
	CID_CPostProcessController = 110,
	CID_CPrecipitation = 111,
	CID_CPrecipitationBlocker = 112,
	CID_CPredictedViewModel = 113,
	CID_CProp_Hallucination = 114,
	CID_CPropDoorRotating = 115,
	CID_CPropJeep = 116,
	CID_CPropVehicleDriveable = 117,
	CID_CRagdollManager = 118,
	CID_CRagdollProp = 119,
	CID_CRagdollPropAttached = 120,
	CID_CRopeKeyframe = 121,
	CID_CSCAR17 = 122,
	CID_CSceneEntity = 123,
	CID_CShadowControl = 124,
	CID_CSlideshowDisplay = 125,
	CID_CSmokeGrenade = 126,
	CID_CSmokeGrenadeProjectile = 127,
	CID_CSmokeStack = 128,
	CID_CSpatialEntity = 129,
	CID_CSpotlightEnd = 130,
	CID_CSprite = 131,
	CID_CSpriteOriented = 132,
	CID_CSpriteTrail = 133,
	CID_CStatueProp = 134,
	CID_CSteamJet = 135,
	CID_CSun = 136,
	CID_CSunlightShadowControl = 137,
	CID_CTeam = 138,
	CID_CTeamplayRoundBasedRulesProxy = 139,
	CID_CTEArmorRicochet = 140,
	CID_CTEBaseBeam = 141,
	CID_CTEBeamEntPoint = 142,
	CID_CTEBeamEnts = 143,
	CID_CTEBeamFollow = 144,
	CID_CTEBeamLaser = 145,
	CID_CTEBeamPoints = 146,
	CID_CTEBeamRing = 147,
	CID_CTEBeamRingPoint = 148,
	CID_CTEBeamSpline = 149,
	CID_CTEBloodSprite = 150,
	CID_CTEBloodStream = 151,
	CID_CTEBreakModel = 152,
	CID_CTEBSPDecal = 153,
	CID_CTEBubbles = 154,
	CID_CTEBubbleTrail = 155,
	CID_CTEClientProjectile = 156,
	CID_CTEDecal = 157,
	CID_CTEDust = 158,
	CID_CTEDynamicLight = 159,
	CID_CTEEffectDispatch = 160,
	CID_CTEEnergySplash = 161,
	CID_CTEExplosion = 162,
	CID_CTEFireBullets = 163,
	CID_CTEFizz = 164,
	CID_CTEFootprintDecal = 165,
	CID_CTEFoundryHelpers = 166,
	CID_CTEGaussExplosion = 167,
	CID_CTEGlowSprite = 168,
	CID_CTEImpact = 169,
	CID_CTEKillPlayerAttachments = 170,
	CID_CTELargeFunnel = 171,
	CID_CTEMetalSparks = 172,
	CID_CTEMuzzleFlash = 173,
	CID_CTEParticleSystem = 174,
	CID_CTEPhysicsProp = 175,
	CID_CTEPlantBomb = 176,
	CID_CTEPlayerAnimEvent = 177,
	CID_CTEPlayerDecal = 178,
	CID_CTEProjectedDecal = 179,
	CID_CTERadioIcon = 180,
	CID_CTEShatterSurface = 181,
	CID_CTEShowLine = 182,
	CID_CTesla = 183,
	CID_CTESmoke = 184,
	CID_CTESparks = 185,
	CID_CTESprite = 186,
	CID_CTESpriteSpray = 187,
	CID_CTest_ProxyToggle_Networkable = 188,
	CID_CTestTraceline = 189,
	CID_CTEWorldDecal = 190,
	CID_CTriggerPlayerMovement = 191,
	CID_CTriggerSoundOperator = 192,
	CID_CVGuiScreen = 193,
	CID_CVoteController = 194,
	CID_CWaterBullet = 195,
	CID_CWaterLODControl = 196,
	CID_CWeaponAug = 197,
	CID_CWeaponAWP = 198,
	CID_CWeaponBizon = 199,
	CID_CWeaponCSBase = 200,
	CID_CWeaponCSBaseGun = 201,
	CID_CWeaponCycler = 202,
	CID_CWeaponElite = 203,
	CID_CWeaponFamas = 204,
	CID_CWeaponFiveSeven = 205,
	CID_CWeaponG3SG1 = 206,
	CID_CWeaponGalil = 207,
	CID_CWeaponGalilAR = 208,
	CID_CWeaponGlock = 209,
	CID_CWeaponHKP2000 = 210,
	CID_CWeaponM249 = 211,
	CID_CWeaponM3 = 212,
	CID_CWeaponM4A1 = 213,
	CID_CWeaponMAC10 = 214,
	CID_CWeaponMag7 = 215,
	CID_CWeaponMP5Navy = 216,
	CID_CWeaponMP7 = 217,
	CID_CWeaponMP9 = 218,
	CID_CWeaponNegev = 219,
	CID_CWeaponNOVA = 220,
	CID_CWeaponP228 = 221,
	CID_CWeaponP250 = 222,
	CID_CWeaponP90 = 223,
	CID_CWeaponSawedoff = 224,
	CID_CWeaponSCAR20 = 225,
	CID_CWeaponScout = 226,
	CID_CWeaponSG550 = 227,
	CID_CWeaponSG552 = 228,
	CID_CWeaponSG556 = 229,
	CID_CWeaponSSG08 = 230,
	CID_CWeaponTaser = 231,
	CID_CWeaponTec9 = 232,
	CID_CWeaponTMP = 233,
	CID_CWeaponUMP45 = 234,
	CID_CWeaponUSP = 235,
	CID_CWeaponXM1014 = 236,
	CID_CWorld = 237,
	CID_DustTrail = 238,
	CID_MovieExplosion = 239,
	CID_ParticleSmokeGrenade = 240,
	CID_RocketTrail = 241,
	CID_SmokeTrail = 242,
	CID_SporeExplosion = 243,
	CID_SporeTrail = 244,
	[/swap_lines]
};

enum EBones : int
{
	// Updated bones
	[swap_lines]
	Bone_Spine0 = 1,
	Bone_Spine1 = 2,
	Bone_Spine2 = 3,
	Bone_Spine3 = 4,
	Bone_Neck = 5,
	Bone_Head = 6,
	Bone_LeftClavicle = 7,
	Bone_LeftUpperarm = 8,
	Bone_LeftLowerarm = 9,
	Bone_LeftHand = 10,
	Bone_RightClavicle = 11,
	Bone_RightUpperarm = 12,
	Bone_RightLowerarm = 13,
	Bone_RightHand = 14,
	Bone_LeftUpperleg = 15,
	Bone_LeftLowerleg = 16,
	Bone_LeftAnkle = 17,
	Bone_RightUpperleg = 18,
	Bone_RightLowerleg = 19,
	Bone_RightAnkle = 20,
	Bone_MAX = 21,
	[/swap_lines]
};

enum EHitboxes
{
	[swap_lines]
	HB_Pelvis = 0,
	HB_LeftThigh = 1,
	HB_LeftCalf = 2,
	HB_LeftFoot = 3,
	HB_RightThigh = 4,
	HB_RightCalf = 5,
	HB_RightFoot = 6,
	HB_Spine1 = 7,
	HB_Spine2 = 8,
	HB_Spine3 = 9,
	HB_Neck = 10,
	HB_Head = 11,
	HB_LeftUpperArm = 12,
	HB_LeftForearm = 13,
	HB_LeftHand = 14,
	HB_RightUpperArm = 15,
	HB_RightForearm = 16,
	HB_RightHand = 17,
	HB_LeftClavicle = 18,
	HB_RightClavicle = 19,
	HB_Helmet = 20,
	HB_Spine4 = 21,
	[/swap_lines]
};

enum ETeams : int
{
	[swap_lines]
	Team_NoTeam = 0,
	Team_Spectator = 1,
	Team_Terrorists = 2,
	Team_CounterTerrorists = 3,
	[/swap_lines]
};

enum ESignOnState : int
{
	SOS_None = 0,
	SOS_Challenge = 1,
	SOS_Connected = 2,
	SOS_New = 3,
	SOS_Prespawn = 4,
	SOS_Spawn = 5,
	SOS_Full = 6,
	SOS_ChangeLevel = 7,
};

// TODO: make this sigscan, kthx.
enum EOffsets
{
	[swap_lines]
	/*LocalPlayer = 0xA77D2C,*/
	/*EntityBase = 0x4A19D84,*/
	/*EnginePtr = 0x5D2284,*/
	Jump = 0x4AAAAF8,
	/*ViewMatrix = 0x4A0F314,*/
	/*GlowObject = 0x4B2CD34,*/
	RadarBase = 0x4A4EA2C,
	/*ScoreBoard = 0x4A39FDC,*/
	GameResources = 0x2E91C6C,

	Names = 0x9D0,
	ClanTag = 0x4110,

	CompetitiveRank = 0x1A3C,
	CompetitiveWins = 0x1B40,

	ActiveWeapon = 0x12B8,		//m_hActiveWeapon
	ActiveWeapID = 0x1C,
	Id = 0x64,
	SignOnState = 0xE8,
	Dormant = 0xE9,				//m_bDormant
	Health = 0xFC,				//m_iHealth
	Team = 0xF0,				//m_iTeamNum 
	Flags = 0x100,				//m_fFlags
	VecViewOffset = 0x104,		//m_vecViewOffset[0]
	VecVelocity = 0x110,		//m_vecVelocity[0]
	Origin = 0x134,				//m_vecOrigin -> CS_BasePlayer
	OwnerEntity = 0x148,		//m_hOwner
	LifeState = 0x25B,			//m_lifeState
	Spotted = 0x935,			//m_bSpotted
	BoneMatrix = 0xA74,
	PunchVector = 0x13FC,		// 13E8 | F3 0F 7E 82 E8 13 ?? ?? 8B 82 F0 13 ?? ?? [xmm0, qword ptr [edx+PunchVector] ]
	SkinOwnerLow = 0x14F0,
	SkinOwnerHigh = 0x14F4,
	SkinPaint = 0x14F8,
	SkinSeed = 0x14FC,
	SkinWear = 0x1500,
	SkinStatTrak = 0x1504,
	PrimaryAmmo = 0x15B8,		//m_iClip1
	SecondaryAmmo = 0x15BC,		//m_iClip2
	IsReloading = 0x15F9,		//m_bInReload
	SpectatorView = 0x173C,		//m_iObserverMode 
	SpectatorTarget = 0x1750,	//m_hObserverTarget
	ShotsFired = 0x8660,		//m_iShotsFired
	FlashDuration = 0x86A8,		//m_flFlashDuration
	IsDefusing = 0x1C4C,		//m_bIsDefusing
	HasImmunity = 0x1C58,		//m_bGunGameImmunity
	FlashMaxAlpha = 0x86A4,		//m_flFlashMaxAlpha
	HasHelmet = 0x8C9C,			//m_bHasHelmet
	Armor = 0x8CA4,				//m_ArmorValue 
	HasDefuseKit = 0x8CB4,		//m_bHasDefuser
	Class = 0x8CA0,				//m_iClass
	//CrosshairID = 0x2410,		//m_iCrosshairID
	AccuracyPenalty = 0x1668,	//m_fAccuracyPenalty
	FOVStart = 0x15B0,			//m_iFOVStart
	/*ViewAngles = 0x4CE0,*/
	[/swap_lines]

};

// Static strings
static std::string Ranks[] =
{
	"Unranked",
	"Silver I",
	"Silver II",
	"Silver III",
	"Silver IV",
	"Silver Elite",
	"Silver Elite Master",
	"Gold Nova I",
	"Gold Nova II",
	"Gold Nova III",
	"Gold Nova Master",
	"Master Guardian I",
	"Master Guardian II",
	"Master Guardian Elite",
	"Distinguished Master Guardian",
	"Legendary Eagle",
	"Legendary Eagle Master",
	"Supreme Master First Class",
	"The Global Elite"
};

// Structs

struct DynOffsets
{
	public:

		[swap_lines]
		DWORD entityList;
		DWORD localPlayer;
		DWORD enginePtr;
		DWORD viewAngles;
		DWORD viewMatrix;
		DWORD glowObjectBase;
		DWORD crosshairIndex;
		DWORD scoreBoard;
		DWORD gameResources;
		DWORD punchAngles;
		DWORD netvarClassesBase;
		DWORD netvar_compRank;
		DWORD netvar_compWins;
		DWORD netvar_hActiveWeapon;
		DWORD netvar_iHealth;
		DWORD netvar_iTeamNum;
		DWORD netvar_fFlags;
		DWORD netvar_vecViewOffset;
		DWORD netvar_vecVelocity;
		DWORD netvar_vecOrigin;
		DWORD netvar_hOwner;
		DWORD netvar_iLifeState;
		DWORD netvar_bSpotted;
		DWORD netvar_iClip1;
		DWORD netvar_iClip2;
		DWORD netvar_bInReload;
		DWORD netvar_iObserverMode;
		DWORD netvar_iObserverTarget;
		DWORD netvar_iShotsFired;
		DWORD netvar_flFlashDuration;
		DWORD netvar_bIsDefusing;
		DWORD netvar_bGunGameImmunity;
		DWORD netvar_flFlashMaxAlpha;
		DWORD netvar_bHasHelmet;
		DWORD netvar_ArmorValue;
		DWORD netvar_bHasDefuser;
		DWORD netvar_iClass;
		DWORD netvar_fAccuracyPenalty;
		DWORD netvar_iFOVStart;
		DWORD netvar_AttributeManager;
		DWORD netvar_Item;
		DWORD netvar_iItemDefinitionIndex;
		DWORD netvar_boneMatrix;
		[/swap_lines]
};

struct Hitbox
{

	public:
		[swap_lines]
		int iBone;
		CVector vMin;
		CVector vMax;
		[/swap_lines]

	void Setup(int b, CVector mi, CVector ma)
	{
		[swap_lines]
		iBone = b;
		vMin = mi;
		vMax = ma;
		[/swap_lines]
	}
};

struct Player
{

	public:
		DWORD baseAddr;				// Base address

		[swap_lines]
		CVector bones[30];			// bones
		CVector vOrigin;			// m_vecOrigin
		CVector vViewAngles;		// m_vecAngles
		CVector vVelocity;			// m_vecVelocity
		CVector vVecViewOffset;		// m_vecViewOffset
		CVector vEyePos;
		CVector2D vPunchAngles;		// m_vecPunchAngles
		CVector2D vOldPunchAngles;
		char* 	szName = new char[32];
		int		iID;				// 
		int		iClassID;			// m_iClass
		int		iFlags;				// m_iFlags
		int		iTeam;				// m_iTeam
		int		iHealth;			// m_iHealth
		int		iArmor;				// m_iArmorValue
		int		iWeaponID;			
		int		iAmmo_Primary;		// m_iClip1
		int		iAmmo_Secondary;	// m_iClip2
		int		iShotsFired;		// m_iShotsFired
		int		iSpectatorMode;		// m_iObserverMode
		int		iSpectatorTarget;	// m_iObserverTarget
		int		iOwnerEntity;		// m_hOwner
		int		iRank;				// rank from gameresources
		int		iWins;				// wins from gameresources
		float	fFlashDuration;		// m_fFlashDuration
		bool	bHasHelmet;			// m_bHasHelmet
		bool	bHasDefuser;		// m_bHasDefuser
		bool	bIsDefusing;		// m_bIsDefusing
		bool	bIsSpotted;			// m_bSpotted
		bool	bIsReloading;		// m_bIsReloading
		bool	bAlive;				
		bool	bIsDormant;			// m_bDormant [0xE9]
		bool	bHasBomb = false;
		[/swap_lines]


}; 

struct TriggerOptions
{

	public:
		[swap_lines]
		int iDelay;				// Delay in MS for sleep
		int iKey;				// VK for the key to toggle
		bool bStopOnSpectate;	// Stop when being spectated
		[/swap_lines]
};

struct GlowOptions
{

	public:
		[swap_lines]
		int iKey;				// VK for key to toggle
		bool bEnemyOnly;		// Only show enemy information
		bool bHealthGlow;		// Show health glow
		bool bGlowBomb;			// Glow the bomb
		bool bGlowWeapons;		// Glow weapons in hands/on ground
		bool bGlowGrenades;		// Glow grenades in hands/on ground/in air
		bool bDefuseGlow;		// Glow black when defusing
		bool bFlashGlow;		// Glow white when flashed
		float fGlowEnemy_R;		// Red channel for enemies
		float fGlowEnemy_G;		// Green channel for enemies
		float fGlowEnemy_B;		// Blue channel for enemies
		float fGlowEnemy_A;		// Alpha channel for enemies
		float fGlowTeam_R;		// Red channel for teammates
		float fGlowTeam_G;		// Green channel for teammates
		float fGlowTeam_B;		// Blue channel for teammates
		float fGlowTeam_A;		// Alpha channel for teammates
		[/swap_lines]
};

struct SubtleAimbotOptions
{
	public:

		struct SubtleWeaponSettings
		{
			[swap_lines]
			EBones eBoneToAimAt;
			int iSubtleMinChance;
			int iSubtleMaxChance;
			float fSubtleRCSScale;
			[/swap_lines]
		};

		[swap_lines]
		int iKey;
		float fSmoothFactor;
		SubtleWeaponSettings tWeaponSettings_Pistol;
		SubtleWeaponSettings tWeaponSettings_Rifle;
		SubtleWeaponSettings tWeaponSettings_Sniper;
		SubtleWeaponSettings tWeaponSettings_Shotguns;
		SubtleWeaponSettings tWeaponSettings_SMGs;
		SubtleWeaponSettings tWeaponSettings_LMGs;
		bool bNewMethod;
		[/swap_lines]
};

struct ActualAimbotOptions
{
	public:

	struct ActualWeaponSettings
	{
		[swap_lines]
		EBones eBoneToAimAt;
		float fSubtleRCSScale;
		[/swap_lines]
	};

	enum EAimMethod
	{
		[swap_lines]
		ClosestToCrosshair = 0,
		ClosestToPlayer = 1,
		LowestHP = 2,
		FullRage = 3,
		[/swap_lines]
	};

	[swap_lines]
	int iKey;				// Key to used to toggle subtle aimbot
	float fSmoothFactor;
	float fFOVRadius;
	EAimMethod eAimMethod;
	ActualWeaponSettings tWeaponSettings_Pistol;
	ActualWeaponSettings tWeaponSettings_Rifle;
	ActualWeaponSettings tWeaponSettings_Sniper;
	ActualWeaponSettings tWeaponSettings_Shotguns;
	ActualWeaponSettings tWeaponSettings_SMGs;
	ActualWeaponSettings tWeaponSettings_LMGs;
	[/swap_lines]

};

struct ThreadHandling
{
	public:
		[swap_lines]
		bool bUpdateStop;
		bool bGlowThreadStop;
		bool bTrigThreadStop;
		bool bSubtleAimbotThreadStop;
		bool bActualAimbotThreadStop;
		bool bConsoleMenuStop;
		[/swap_lines]
};

struct Hacks
{
	// BitField & 0x1 = Triggerbot
	// BitField & 0x2 = Aimbot
	// BitField & 0x4 = ESP
	// BitField & 0x8 = RCS
	// BitField & 0x10 = Bhop

public:

	void Toggle(int iBit)
	{
		iBitField ^= iBit;
		[add_junk 1 3 /]
	}

	void Set(int iBit)
	{
		iBitField |= iBit;
		[add_junk 1 3 /]
	}

	void Unset(int iBit)
	{
		[add_junk 1 3 /]
		iBitField &= ~iBit;
	}

	bool CheckBit(int iBit)
	{
		[add_junk 1 3 /]

		if (iBitField & iBit)
			return true;

		return false;
	}

	[swap_lines]
	unsigned int iBitField;
	std::string hacksHash;
	TriggerOptions tTriggerOptions;
	GlowOptions tGlowOptions;
	SubtleAimbotOptions tSubtleAimbotOptions;
	ActualAimbotOptions tActualAimbotOptions;
	ThreadHandling tThreadHandling;
	[/swap_lines]
};


class CSGO
{
public:
	CSGO() = default;
	~CSGO() = default;

	[swap_lines]
	bool Attach();
	void UpdateInfo(Player* ply, DWORD addr);
	bool LoadBases();
	void UpdateEntities();
	[/swap_lines]

	Player GetFriendly(DWORD id)
	{
		[add_junk 1 5 /]
		return m_Friendlies[id];
	}

	Player GetEnemy(DWORD id)
	{
		[add_junk 1 5 /]
		return m_Enemies[id];
	}

	int GetTeam(DWORD addr)
	{
		[add_junk 1 5 /]
		return m_Mem.Read<int>(addr + Team);
	}

	int GetEnemyTeam(int team)
	{
		[add_junk 1 5 /]

		if (team == Team_Terrorists)
			return Team_CounterTerrorists;
		else if (team == Team_CounterTerrorists)
			return Team_Terrorists;

		return Team_NoTeam;
	}

	CVector inline BonePosition(DWORD addr, int bone)
	{
		if (bone < 0 || bone >= EBones::Bone_MAX)
			return CVector(0, 0, 0);

		DWORD boneMatrix = m_Mem.Read<int>(addr + m_dynamicOffsets.netvar_boneMatrix);

		[add_junk 1 5 /]

		[swap_lines]
		float boneX = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0xC);
		float boneY = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0x1C);
		float boneZ = m_Mem.Read<float>(boneMatrix + (0x30 * bone) + 0x2C);
		[/swap_lines]

		return CVector(boneX, boneY, boneZ);
	}

	int GetClassID(Player* ply)
	{
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);	// Vtable
		[add_junk 1 5 /]
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);	// Function
		[add_junk 1 5 /]
		int cls = m_Mem.Read<int>(fn + 0x1);	// Class
		int clsn = m_Mem.Read<int>(cls + 8);	// Class Name
		return m_Mem.Read<int>(cls + 20);	// ClassID
	}

	char* GetClassNameFromPlayer(Player* ply)
	{
		int vt = m_Mem.Read<int>(ply->baseAddr + 0x8);
		int fn = m_Mem.Read<int>(vt + 2 * 0x4);
		int cls = m_Mem.Read<int>(fn + 0x1);
		[add_junk 1 5 /]
		int clsn = m_Mem.Read<int>(cls + 8);

		int namePointer = m_Mem.Read<int>(clsn);
		char* nameData = new char[32];

		for (int i = 0; i < 32; i++)
			nameData[i] = m_Mem.Read<char>(namePointer + i);

		[add_junk 1 5 /]

		return nameData;
	}

	bool IsClassIDAWeapon(int iClassID)
	{
		switch (iClassID)
		{
			[swap_lines]
			case CID_CAK47:
			case CID_CDEagle:
			case CID_CWeaponAWP:
			case CID_CWeaponAug:
			case CID_CWeaponBizon:
			case CID_CWeaponElite:
			case CID_CWeaponFamas:
			case CID_CWeaponFiveSeven:
			case CID_CWeaponG3SG1:
			case CID_CWeaponGalilAR:
			case CID_CWeaponGlock:
			case CID_CWeaponHKP2000:
			case CID_CWeaponMAC10:
			case CID_CWeaponM249:
			case CID_CWeaponM4A1:
			case CID_CWeaponM3:
			case CID_CWeaponMag7:
			case CID_CWeaponMP7:
			case CID_CWeaponMP9:
			case CID_CWeaponNegev:
			case CID_CWeaponNOVA:
			case CID_CWeaponP250:
			case CID_CWeaponP90:
			case CID_CWeaponSawedoff:
			case CID_CWeaponSCAR20:
			case CID_CWeaponSG556:
			case CID_CWeaponSSG08:
			case CID_CWeaponTaser:
			case CID_CWeaponTec9:
			case CID_CWeaponUSP:
			case CID_CWeaponUMP45:
			case CID_CWeaponXM1014:
			[/swap_lines]

			return true;
		}

		return false;
	}

	bool IsClassIDAGrenade(int iClassID)
	{
		switch (iClassID)
		{
			[swap_lines]
			case CID_CFlashbang:
			case CID_CHEGrenade:
			case CID_CDecoyGrenade:
			case CID_CIncendiaryGrenade:
			case CID_CMolotovGrenade:
			case CID_CSmokeGrenade:
			case CID_CBaseCSGrenadeProjectile:
			case CID_CSmokeGrenadeProjectile:
			case CID_CMolotovProjectile:
			case CID_CDecoyProjectile:
			[/swap_lines]
			return true;
		}

		return false;
	}

	EWeaponType GetWeaponType(Player& player) const
	{
		int id = player.iWeaponID;

		[add_junk 1 5 /]

		if (id == WID_Deagle || id == WID_Dual_Berettas || id == WID_Five_Seven || id == WID_USP || id == WID_Glock || id == WID_Tec9 || id == WID_P2000 || id == WID_P250 || id == WID_CZ75)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Pistol;
		}
		else if (id == WID_AK47 || id == WID_AUG || id == WID_FAMAS || id == WID_M4A4 || id == WID_M4A1S || id == WID_Galil || id == WID_SG553)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Rifle;
		}
		else if (id == WID_AWP || id == WID_G3SG1_Auto || id == WID_SCAR_Auto || id == WID_Scout)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Sniper;
		}
		else if (id == WID_MAC10 || id == WID_P90 || id == WID_UMP45 || id == WID_PPBizon || id == WID_MP7 || id == WID_MP9)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_SMG;
		}
		else if (id == WID_Negev || id == WID_M249)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_LMG;
		}
		else if (id == WID_XM1014 || id == WID_MAG7 || id == WID_Nova || id == WID_SawedOff)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Shotgun;
		}
		else if (id == WID_Flashbang || id == WID_Smoke || id == WID_Firebomb || id == WID_HEFrag || id == WID_Molly)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_Grenade;
		}
		else if (id == WID_C4)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_C4Explosive;
		}
		else if (id == WID_Default_Knife || id == WID_ButterflyKnife || id == WID_HuntsmanKnife || id == WID_M9BayonetKnife || id == WID_FlipKnife || id == WID_KarambitKnife || id == WID_GutKnife || id == WID_BayonetKnife || id == WID_FalchionKnife)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_KnifeType;
		}
		else if (id == WID_Zeus)
		{
			[add_junk 1 5 /]
			return EWeaponType::WeapType_ZeusGun;
		}
		else
		{
			return (EWeaponType)-1;
		}
	}

	[swap_lines]
	CMemory m_Mem;
	DWORD m_dwClientBase;
	DWORD m_dwEngineBase;
	DWORD m_dwLocalBase;
	DWORD m_dwEntityBase;
	DWORD m_dwGlowObjectArrayBase;
	DWORD m_dwScoreBoardBase;
	DWORD m_dwGameResourcesBase;
	float m_ViewMatrix[16];
	Player m_Me;
	Player m_Friendlies[32];
	Player m_Enemies[32];
	int m_iEnemiesDetected;
	int m_iFriendliesDetected;
	Hitbox m_Hitboxes[21];
	int m_Spectators[32];
	Hacks m_Hacks;
	int m_iWindowWidth;
	int m_iWindowHeight;
	DynOffsets m_dynamicOffsets;
	[/swap_lines]
};

#endif // _CSGO_H_

