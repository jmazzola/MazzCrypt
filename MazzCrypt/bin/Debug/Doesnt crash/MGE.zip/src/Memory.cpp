#include "Memory.h"

bool CMemory::Attach(const char* procName, DWORD rights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	PROCESSENTRY32 entry;
	[add_junk 3 5 /]
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)procName))
		{
			m_dwProcessID = entry.th32ProcessID;
			CloseHandle(handle);

			[add_junk 3 5 /]

			m_hProcess = OpenProcess(rights, false, m_dwProcessID);
			m_bAttached = true;

			[add_junk 3 5 /]
			
			return true;
		}
	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	return false;
}

void CMemory::Detach()
{
	m_bAttached = false;
	[add_junk 3 5 /]
	CloseHandle(m_hProcess);
}

DWORD CMemory::GetModuleBase(const char* modName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);

	[add_junk 3 5 /]

	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)modName))
		{
			[add_junk 3 5 /]
			CloseHandle(handle);
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	[add_junk 3 5 /]

	return NULL;
	
}

DWORD CMemory::GetModuleSize(const char* modName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);

	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		[add_junk 3 5 /]

		if (!strcmp(entry.szModule, (LPSTR)modName))
		{
			CloseHandle(handle);
			return (DWORD)entry.modBaseSize;
		}

		[add_junk 3 5 /]

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	[add_junk 2 6 /]

	return NULL;
}
