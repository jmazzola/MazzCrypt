#ifndef _AIMBOT_H_
#define _AIMBOT_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

#include <random>

#define RAND_INT(a, b) (a - b + 1) + b


[junk_enable /]

class SubtleAimbot
{
public:

	void Start()
	{
		while (true)
		{
			if(!csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop)
			{
			[add_junk 2 3 /]

			if (csgo->m_Hacks.CheckBit(BIT_SUBTLEAIMBOT))
			{
				[swap_lines]
				int randomShotTime = 0;
				int boneToAimAt = 0;
				float rcsScale = 0.0f;
				[/swap_lines]

				[add_junk 3 5 /]

					switch (csgo->GetWeaponType(csgo->m_Me))
					{
						case EWeaponType::WeapType_Pistol:
						{
							[add_junk 3 5 /]

							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale;
							[/swap_lines]

							break;
						}

						case EWeaponType::WeapType_Sniper:
						{
							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale;
							[/swap_lines]

							[add_junk 3 5 /]

							break;
						}

						case EWeaponType::WeapType_Rifle:
						{
							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale;
							[/swap_lines]

							[add_junk 3 5 /]

							break;
						}

						case EWeaponType::WeapType_SMG:
						{
							[add_junk 3 5 /]

							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale;
							[/swap_lines]

							break;
						}

						case EWeaponType::WeapType_LMG:
						{
							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale;
							[/swap_lines]

							[add_junk 3 5 /]

							break;
						}
						case EWeaponType::WeapType_Shotgun:
						{
							[add_junk 3 5 /]
							[swap_lines]
							randomShotTime = rand() % RAND_INT(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance, csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance);
							boneToAimAt = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale;
							[/swap_lines]

							break;
						}

						default:
						{
							continue;
						}

					}
				if (csgo->m_Me.iShotsFired > randomShotTime && !csgo->m_Me.bIsReloading && csgo->m_Me.iAmmo_Primary)
				{
					Player* enemy = PlayerInCross();

					if (!enemy || !enemy->bAlive || enemy->bIsDormant)
						continue;

					// Better method
					CVector enemyPos = BetterVelocityComp(enemy->bones[boneToAimAt], enemy->vVelocity);
					[add_junk 2 4 /]
					CVector aimAngle = CalcAngle(csgo->m_Me.vEyePos, enemyPos);

					[add_junk 1 5/]
					CVector punchAngle(csgo->m_Me.vPunchAngles.x, csgo->m_Me.vPunchAngles.y, 0.0f);
					aimAngle -= punchAngle * (2.0f * rcsScale);

					//DWORD anglePointer = csgo->m_Mem.Read<DWORD>(csgo->m_dwEngineBase + EnginePtr);
					DWORD anglePointer = csgo->m_Mem.Read<DWORD>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr);
					[add_junk /]
					//CVector currentAngle = csgo->m_Mem.Read<CVector>(anglePointer + ViewAngles);
					CVector currentAngle = csgo->m_Mem.Read<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles);

					[add_junk 3 5 /]
					SetAimbotAngles(aimAngle, currentAngle);
				}
			}
		}

			Sleep(1);
		}
	}

	Player* PlayerInCross()
	{

		int tempPlayer = csgo->m_Mem.Read<int>(csgo->m_dwLocalBase + csgo->m_dynamicOffsets.crosshairIndex);

		if (tempPlayer != 0)
		{
			[add_junk 3 6 /]

			for (int i = 0; i < csgo->m_iEnemiesDetected; i++)
			{
				if (csgo->GetEnemy(i).iID == tempPlayer)
					return &csgo->GetEnemy(i);
			}
		}

		return NULL;
	}

	void ClampAngles(CVector& angle)
	{
		if (angle.x > 89.0f && angle.x <= 180.0f)
		{
			angle.x = 89.0f;
			[add_junk 1 1 /]
		}

		if (angle.x > 180.f)
		{
			[add_junk 1 1 /]
			angle.x -= 360.f;
		}

		if (angle.x < -89.0f)
		{
			[add_junk 3 6 /]
			angle.x = -89.0f;
		}

		[add_junk 3 9 /]

		if (angle.y > 180.f)
			angle.y -= 360.f;

		[add_junk 2 3 /]

		if (angle.y < -180.f)
			angle.y += 360.f;

		if (angle.z != 0.0f)
		{
			angle.z = 0.0f;
			[add_junk /]
		}
	}

	CVector VelocityCompensate(CVector& myVel, CVector& enemyVel)
	{
		float smoothAmount = csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor;

		[add_junk /]

		CVector output;

		[swap_lines]
		output.x = output.x + (enemyVel.x / 100.0f) * (40.0f / smoothAmount);
		output.y = output.y + (enemyVel.y / 100.0f) * (40.0f / smoothAmount);
		output.z = output.z + (enemyVel.z / 100.f) * (40.0f / smoothAmount);
		[/swap_lines]

		output.x = output.x - (myVel.x / 100.0f) * (40.0f / smoothAmount);
		output.y = output.y - (myVel.y / 100.0f) * (40.0f / smoothAmount);
		[add_junk 2 5 /]
		output.z = output.z - (myVel.z / 100.0f) * (40.0f / smoothAmount);

		return output;
	}

	CVector BetterVelocityComp(CVector enemyPos, CVector enemyVel)
	{
		[add_junk /]

		CVector distVec = csgo->m_Me.vOrigin - enemyPos;
		float dist = enemyPos.FastSQRT((distVec.x * distVec.x) + (distVec.y * distVec.y) + (distVec.z * distVec.z));


		[swap_lines]
		enemyPos.x += (enemyVel.x) / dist;
		enemyPos.y += (enemyVel.y) / dist;
		enemyPos.z += (enemyVel.z) / dist;
		[/swap_lines]

		[add_junk /]

		enemyPos.x -= (csgo->m_Me.vVelocity.x) / dist;
		enemyPos.y -= (csgo->m_Me.vVelocity.y) / dist;
		enemyPos.z -= (csgo->m_Me.vVelocity.z) / dist;
		return enemyPos;
	}

	CVector CalcAngle(CVector& src, CVector& dst)
	{
		[swap_lines]
		CVector ret;
		CVector vDelta = src - dst;
		[/swap_lines]

		[add_junk /]

		float fHyp = vDelta.FastSQRT((vDelta.x * vDelta.x) + (vDelta.y * vDelta.y));

		[swap_lines]
		ret.x = (atan(vDelta.z / fHyp) * (float)(180.0f / 3.14159));
		ret.y = (atan(vDelta.y / vDelta.x) * (float)(180.0f / 3.14159));
		[/swap_lines]

		if (vDelta.x >= 0.0f)
		{
			ret.y += 180.0f;
			[add_junk 1 3 /]
		}

		return ret;
	}

	CVector CalcAnglesForAimAssist(CVector src, CVector dst)
	{
		/*std::random_device Random;
		std::mt19937 RandomGen(Random());
		std::uniform_real<float> RandomXdistrib(csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMinRCS_X, csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMaxRCS_X);
		std::uniform_real<float> RandomYdistrib(csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMinRCS_Y, csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMaxRCS_Y);

		CVector2D MyPunch = csgo->m_Mem.Read<CVector2D>(csgo->m_Me.baseAddr + PunchVector);
		CVector vecOrigin = csgo->m_Mem.Read<CVector>(csgo->m_Me.baseAddr + VecViewOffset);

		float pitchreduction = RandomXdistrib(RandomGen);
		float yawreduction = RandomYdistrib(RandomGen);
		float delta[3] = { (src[0] - dst[0]), (src[1] - dst[1]), ((src[2] + vecOrigin[2]) - dst[2]) };
		float hyp = sqrt(delta[0] * delta[0] + delta[1] * delta[1]);

		CVector angles;

		[swap_lines]
		angles.x = atanf(delta[2] / hyp) * 57.295779513082f - MyPunch.x * pitchreduction;
		angles.y = atanf(delta[1] / delta[0]) * 57.295779513082f - MyPunch.y * yawreduction;
		angles.z = 0.0f;
		[/swap_lines]

		if (delta[0] >= 0.0)
		{
			angles.y += 180.0f;
			[add_junk /]
		}

		return angles;*/
	}

	void SetAimbotAngles(CVector& dest, CVector& orig)
	{
		CVector smoothAngles;
		float smoothAmount = csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor;

		[add_junk /]

		[swap_lines]
		smoothAngles.x = dest.x - orig.x;
		smoothAngles.y = dest.y - orig.y;
		smoothAngles.z = 0.0f;
		[/swap_lines]

		ClampAngles(smoothAngles);

		[swap_lines]
		smoothAngles.x = orig.x + smoothAngles.x / 100.0f * smoothAmount;
		smoothAngles.y = orig.y + smoothAngles.y / 100.0f * smoothAmount;
		smoothAngles.z = 0.0f;
		[/swap_lines]

		ClampAngles(smoothAngles);

		//DWORD anglePointer = csgo->m_Mem.Read<DWORD>(csgo->m_dwEngineBase + EnginePtr);
		DWORD anglePointer = csgo->m_Mem.Read<DWORD>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr);
		//csgo->m_Mem.Write<CVector>(anglePointer + ViewAngles, smoothAngles);
		csgo->m_Mem.Write<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles, smoothAngles);

		[add_junk 2 5 /]

	}

	SubtleAimbot(CSGO* c)
	{
		csgo = c;
		[add_junk 2 4 /]
	}

	~SubtleAimbot() = default;

private:

	CSGO* csgo;

};

#endif // _AIMBOT_H_