#ifndef _CONSOLEMENU_H_
#define _CONSOLEMENU_H_

#include "CSGO.h"
#include "MiscUtils.h"
#include <vector>

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

enum EGameState
{
	[swap_lines]
	MAIN_MENU,
	GLOW_OPTIONS,
	SUBTLEAIMBOT_OPTIONS,
	EXIT_MENU,
	[/swap_lines]
};

struct Option
{
	[swap_lines]
	bool m_bIsToggleable;
	bool m_bTheToggle;
	char* m_szText;
	void(*m_fpFunction)();
	[/swap_lines]

	Option(bool isTogg, bool theTog, char* text, void(*func)() = nullptr)
	{
		if (isTogg)
		{
			[swap_lines]
			m_bIsToggleable = isTogg;
			m_bTheToggle = theTog;
			[/swap_lines]
		}

		[swap_lines]
		m_szText = text;
		m_fpFunction = func;
		[/swap_lines]
	}
};

char* BoolToString(bool b)
{
	[add_junk 2 6 /]

	if (b)
		return "ON";
	
	return "OFF";
}

class ConsoleMenu
{

public:

	void QuitMenu()
	{
		csgo->m_Hacks.tThreadHandling.bConsoleMenuStop = false;
	}

	void Start()
	{
		[add_junk 3 4 /]

		while (!csgo->m_Hacks.tThreadHandling.bConsoleMenuStop)
		{
			if (CMiscUtils::IsActiveWindow())
			{
				if (GetAsyncKeyState(VK_UP) & 1)
				{
					switch (m_eGameState)
					{
						case MAIN_MENU:
						{
							--m_iCursor;

							[add_junk 3 4 /]

							if (m_iCursor < 0)
								m_iCursor = mainMenuOptions.size() - 1;

							break;
						}
					}
				}

				if (GetAsyncKeyState(VK_DOWN) & 1)
				{
					switch (m_eGameState)
					{
						case MAIN_MENU:
						{
							[add_junk 3 4 /]

							++m_iCursor;

							if (m_iCursor >= (int)mainMenuOptions.size())
								m_iCursor = 0;

							break;
						}
					}
				}

				if (GetAsyncKeyState(VK_RETURN) & 1)
				{
					[add_junk 3 4 /]
				}
			}

			switch (m_eGameState)
			{
				case MAIN_MENU:
				{
					std::cout << "SmurfStomper's Ghetto Console Menu" << std::endl;
					[add_junk 3 4 /]
					std::cout << "------------------------------------" << std::endl;

					for (int i = 0; i < (int)mainMenuOptions.size(); i++)
					{
						if (i == m_iCursor)
						{
							if (mainMenuOptions[i].m_bIsToggleable)
							{
								[add_junk 3 4 /]
								std::cout << "[x] " << mainMenuOptions[i].m_szText << BoolToString(mainMenuOptions[i].m_bTheToggle) << std::endl;
							}
							else
							{
								std::cout << "[x] " << mainMenuOptions[i].m_szText << std::endl;
							}
						}
						else
						{
							if (i == mainMenuOptions.size() - 1)
							{
								if (mainMenuOptions[i].m_bIsToggleable)
								{
									[add_junk 3 4 /]
									std::cout << "[ ] " << mainMenuOptions[i].m_szText << BoolToString(mainMenuOptions[i].m_bTheToggle) << std::endl;
								}
								else
								{
									std::cout << "[ ] " << mainMenuOptions[i].m_szText << std::endl;
								}
							}
							else
							{
								if (mainMenuOptions[i].m_bIsToggleable)
								{
									[add_junk 3 4 /]
									std::cout << "[ ] " << mainMenuOptions[i].m_szText << BoolToString(mainMenuOptions[i].m_bTheToggle);
								}
								else
								{
									[add_junk 3 4 /]
									std::cout << "[ ] " << mainMenuOptions[i].m_szText;
								}
							}
						}
					}

					break;
				}
			}


			system("cls");

			[add_junk 3 4 /]

			Sleep(1);
		}
	}

	ConsoleMenu(CSGO* c)
	{
		csgo = c;

		[swap_lines]
		m_eGameState = MAIN_MENU;
		m_iCursor = 0;
		m_hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
		[/swap_lines]

		mainMenuOptions.push_back(Option(true, csgo->m_Hacks.CheckBit(BIT_ESP), "Toggle GlowESP: "));
		[add_junk 3 4 /]
		mainMenuOptions.push_back(Option(true, csgo->m_Hacks.CheckBit(BIT_SUBTLEAIMBOT), "Toggle Subtle Aimbot: "));
		[add_junk 3 4 /]
		mainMenuOptions.push_back(Option(false, false, "Glow Options", nullptr));
		mainMenuOptions.push_back(Option(false, false, "Subtle Aimbot Options", nullptr));
		[add_junk 3 4 /]
		mainMenuOptions.push_back(Option(false, false, "Exit Menu"));



	}

	~ConsoleMenu()
	{

	}


private:

	[swap_lines]
	CSGO* csgo;
	EGameState m_eGameState;
	HANDLE m_hConsole;
	int m_iCursor;
	std::vector<Option> mainMenuOptions;
	[/swap_lines]
};

[enc_string_disable /]


#endif // _CONSOLEMENU_H_