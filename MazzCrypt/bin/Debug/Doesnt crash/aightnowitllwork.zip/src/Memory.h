#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "stdafx.h"
#include <TlHelp32.h>
#include <string>

[junk_enable /]

class CMemory
{
public:
	CMemory() = default;
	~CMemory() = default;

	[swap_lines]
	bool Attach(const char* procName, DWORD rights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* modName);
	DWORD GetModuleSize(const char* modName);
	[/swap_lines]

	HANDLE GetHandle() const
	{
		if (m_bAttached)
		{
			[add_junk 3 5 /]
			return NULL;
		}

		return m_hProcess;
	}

	template<typename T>
	T inline Read(DWORD addr)
	{
		T mem;
		[add_junk 3 5 /]
		ReadProcessMemory(m_hProcess, (LPVOID)addr, &mem, sizeof(T), NULL);
		[add_junk /]
		return mem;
	}

	void inline ReadCustom(DWORD addr, LPVOID buff, size_t bytesToRead)
	{
		[add_junk 3 10 /]
		ReadProcessMemory(m_hProcess, (LPCVOID)addr, buff, bytesToRead, NULL);
	}

	template<typename T>
	void inline Write(DWORD addr, T data)
	{
		[add_junk 3 5 /]
		WriteProcessMemory(m_hProcess, (LPVOID)addr, &data, sizeof(T), NULL);
	}

	void inline WriteCustom(DWORD addr, LPCVOID buff, size_t bytesToWrite)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, buff, bytesToWrite, NULL);
		[add_junk 3 10 /]
	}

	bool inline DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* pszMask) 
	{
		for (; *pszMask; ++pszMask, ++pbData, ++pbMask)
		{
			if (*pszMask == 'c' && *pbData != *pbMask)
			{
				[add_junk 3 5 /]
				return false;
			}
		}

		return (*pszMask == NULL);
	}

	DWORD inline FindPattern(DWORD dwStart, DWORD dwSize, const char* szSig, const char* szMask) 
	{
		PBYTE data = new BYTE[dwSize];

		[add_junk 3 5 /]

		unsigned long bytesRead;

		if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead)) 
		{
			[add_junk 3 5 /]
			return NULL;
		}

		for (DWORD i = 0; i < dwSize; i++) 
		{
			if (DataCompare((const BYTE*)(data + i), (const BYTE*)szSig, szMask))
			{
				[add_junk 3 5 /]
				return dwStart + i;
			}
		}

		[add_junk 10 20 /]

		return NULL;
	}

	DWORD inline FindPatternArr(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pattern) 
	{

		char* sig = new char[nCount + 1];

		[add_junk 1 9 /]

		for (int i = 0; i < nCount; i++)
		{
			sig[i] = pattern[i];
		}

		sig[nCount] = '\0';

		[add_junk 1 9 /]

		std::string szMask;
		szMask.resize(nCount);

		for (int i = 0; i < nCount; i++)
		{
			(pattern[i]) ? szMask[i] = 'c' : szMask[i] = '?';
		}

		[add_junk 2 5 /]


		return FindPattern(dwStart, dwSize, sig, szMask.c_str());
	}

	bool inline IsAttached() const
	{
		[add_junk 3 5 /]
		return m_bAttached;
	}

private:
	
	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers 4 10 /]
};

#endif // _MEMORY_H_
