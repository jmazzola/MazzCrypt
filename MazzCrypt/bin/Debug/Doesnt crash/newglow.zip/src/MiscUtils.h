#ifndef _MISCUTILS_H_
#define _MISCUTILS_H_

#include "stdafx.h"
#include <string>

class CSGO;

[junk_enable /]

class CMiscUtils
{
public:

	CMiscUtils() = default;
	~CMiscUtils() = default;

	[swap_lines]
	static void GenerateRandomWindowTitle(int length = 15);
	static void DeleteSelf(char* szProgramPath);
	static void AllowDebugging();
	static void PrintLine(std::string szStr);
	static bool LoadINISettings(std::string fileName, CSGO* csgo);
	static bool IsActiveWindow();
	static std::string GetHash(std::string fileName);
	static LONG WINAPI MinidumpHelper(_EXCEPTION_POINTERS *pExceptionInfo);
	[/swap_lines]

private:

	[add_junk_datamembers 4 9 /]

};
#endif // _MISCUTILS_H_

