#include "CSGO.h"

bool CSGO::Attach()
{
	if (m_Mem.Attach("csgo.exe"))
	{
		return LoadBases();
	}

	return false;
}

bool CSGO::LoadBases()
{
	if (!m_Mem.IsAttached())
		return false;

	m_dwClientBase = m_Mem.GetModuleBase("client.dll");

	if (!m_dwClientBase)
		return false;

	m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");

	if (!m_dwEngineBase)
		return false;

	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + LocalPlayer);
	m_dwEntityBase = m_dwClientBase + EntityBase;
	m_dwGlowObjectArrayBase = m_dwClientBase + GlowObject;

	for (int i = 0; i < 16; i++)
	{
		m_ViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + ViewMatrix + (4 * i));
	}

	RECT m_Rect;
	GetClientRect(FindWindow(NULL, "Counter-Strike: Global Offensive"), &m_Rect);

	m_iWindowWidth = (int)(m_Rect.right - m_Rect.left);
	m_iWindowHeight = (int)(m_Rect.bottom - m_Rect.top);
}

void CSGO::UpdateInfo(Player* ply, DWORD addr)
{
	ply->baseAddr = addr;
	ply->iID = m_Mem.Read<int>(addr + Id);
	ply->iFlags = m_Mem.Read<int>(addr + Flags);
	ply->iHealth = m_Mem.Read<int>(addr + Health);
	ply->iArmor = m_Mem.Read<int>(addr + Armor);
	ply->iTeam = m_Mem.Read<int>(addr + Team);
	ply->iShotsFired = m_Mem.Read<int>(addr + ShotsFired);
	ply->iClassID = GetClassID(ply);
	ply->iSpectatorMode = m_Mem.Read<int>(addr + SpectatorView);
	ply->iSpectatorTarget= m_Mem.Read<int>(addr + SpectatorTarget);
	ply->iOwnerEntity = m_Mem.Read<int>(addr + OwnerEntity);

	ply->fFlashDuration = m_Mem.Read<float>(addr + FlashDuration);

	ply->bAlive = (ply->iHealth > 0);
	ply->bHasHelmet = (m_Mem.Read<int>(addr + HasHelmet)) ? 1 : 0;
	ply->bHasDefuser = (m_Mem.Read<int>(addr + HasDefuseKit)) ? 1 : 0;
	ply->bIsSpotted = (m_Mem.Read<int>(addr + Spotted)) ? 1 : 0;
	ply->bIsReloading = (m_Mem.Read<int>(addr + IsReloading)) ? 1 : 0;
	ply->bIsDefusing = (m_Mem.Read<int>(addr + IsDefusing)) ? 1 : 0;
	ply->bIsDormant = (m_Mem.Read<int>(addr + Dormant)) ? 1 : 0;

	DWORD baseCombatHandle = m_Mem.Read<DWORD>(addr + ActiveWeapon);
	baseCombatHandle &= 0xFFF;

	DWORD weapBase = m_Mem.Read<DWORD>(m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);
	//ply->iWeaponID = m_Mem.Read<int>(weapBase + AccuracyPenalty + ActiveWeapID);
	ply->iWeaponID = m_Mem.Read<int>(weapBase + 0x1148 + 0x40 + 0x194); // weaponBase + m_AttributeManager + m_Item + m_iItemDefinitionIndex
	ply->iAmmo_Primary = m_Mem.Read<int>(weapBase + PrimaryAmmo);
	ply->iAmmo_Secondary = m_Mem.Read<int>(weapBase + SecondaryAmmo);

	ply->vOrigin = m_Mem.Read<CVector>(ply->baseAddr + Origin);
	ply->vVelocity = m_Mem.Read<CVector>(ply->baseAddr + VecVelocity);
	ply->vPunchAngles = m_Mem.Read<CVector2D>(ply->baseAddr + PunchVector);
	ply->vVecViewOffset = m_Mem.Read<CVector>(ply->baseAddr + VecViewOffset);

	ply->vEyePos = ply->vOrigin + ply->vVecViewOffset;

	DWORD anglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + EnginePtr);
	ply->vViewAngles = m_Mem.Read<CVector>(anglePointer + ViewAngles);

	for (int i = 0; i < 30; i++)
	{
		ply->bones[i] = BonePosition(ply->baseAddr, i);
	}
}

void CSGO::UpdateEntities()
{
	if (!m_Mem.IsAttached())
		return;

	UpdateInfo(&m_Me, m_dwLocalBase);

	int friendIndex, enemyIndex;
	enemyIndex = friendIndex = 0;

	for (int i = 1; i < 64; i++)
	{
		DWORD entityBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));

		if (!entityBase)
			continue;

		if (GetTeam(entityBase) == GetEnemyTeam(m_Me.iTeam))
		{
			UpdateInfo(&m_Enemies[enemyIndex], entityBase);
			enemyIndex++;
		}
		else if (GetTeam(entityBase) == m_Me.iTeam)
		{
			UpdateInfo(&m_Friendlies[friendIndex], entityBase);
			friendIndex++;
		}
	}

	m_iEnemiesDetected = enemyIndex;
}