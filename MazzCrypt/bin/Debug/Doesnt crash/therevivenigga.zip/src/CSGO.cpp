#include "CSGO.h"

#include "Decrypt.h"

[junk_enable /]
[enc_string_enable /]

bool CSGO::Attach()
{
	if (m_Mem.Attach("csgo.exe"))
	{
		[add_junk 3 5 /]
		return LoadBases();
	}

	return false;
}

bool CSGO::LoadBases()
{
	if (!m_Mem.IsAttached())
		return false;

	[add_junk 3 5 /]

	m_dwClientBase = m_Mem.GetModuleBase("client.dll");

	if (!m_dwClientBase)
		return false;

	m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");

	if (!m_dwEngineBase)
		return false;

	//m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + LocalPlayer);
	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.localPlayer);
	//m_dwEntityBase = m_dwClientBase + EntityBase;
	m_dwEntityBase = m_dwClientBase + m_dynamicOffsets.entityList;
	[add_junk 3 5 /]

	[swap_lines]
	//m_dwGlowObjectArrayBase = m_dwClientBase + GlowObject;
	m_dwGlowObjectArrayBase = m_dwClientBase + m_dynamicOffsets.glowObjectBase;
	//m_dwGameResourcesBase = m_dwClientBase + GameResources;
	m_dwGameResourcesBase = m_Mem.Read<DWORD>(m_dwClientBase + GameResources);
	//m_dwScoreBoardBase = m_Mem.Read<DWORD>(m_dwClientBase + ScoreBoard);
	m_dwScoreBoardBase = m_Mem.Read<DWORD>(m_dwClientBase + m_dynamicOffsets.scoreBoard);
	[/swap_lines]

	for (int i = 0; i < 16; i++)
	{
		//m_ViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + ViewMatrix + (4 * i));
		m_ViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + m_dynamicOffsets.viewMatrix + (4 * i));
	}

	RECT m_Rect;
	GetClientRect(FindWindow(NULL, "Counter-Strike: Global Offensive"), &m_Rect);

	m_iWindowWidth = (int)(m_Rect.right - m_Rect.left);
	[add_junk 3 5 /]
	m_iWindowHeight = (int)(m_Rect.bottom - m_Rect.top);
}

[enc_string_disable /]

void CSGO::UpdateInfo(Player* ply, DWORD addr)
{
	ply->baseAddr = addr;

	[swap_lines]
	ply->iID = m_Mem.Read<int>(addr + Id);
	ply->iFlags = m_Mem.Read<int>(addr + Flags);
	ply->iHealth = m_Mem.Read<int>(addr + Health);
	ply->iArmor = m_Mem.Read<int>(addr + Armor);
	ply->iTeam = m_Mem.Read<int>(addr + Team);
	ply->iShotsFired = m_Mem.Read<int>(addr + ShotsFired);
	ply->iClassID = GetClassID(ply);
	ply->iSpectatorMode = m_Mem.Read<int>(addr + SpectatorView);
	ply->iSpectatorTarget= m_Mem.Read<int>(addr + SpectatorTarget);
	ply->iOwnerEntity = m_Mem.Read<int>(addr + OwnerEntity);
	[/swap_lines]

	int namePtr = m_Mem.Read<int>(m_dwScoreBoardBase + Names + ply->iID * 4);
	[add_junk 4 6 /]
	m_Mem.ReadCustom(namePtr, &ply->szName[0], 32);

	[swap_lines]
	ply->iRank = m_Mem.Read<int>(m_dwGameResourcesBase + CompetitiveRank + ply->iID * 4);
	ply->iWins = m_Mem.Read<int>(m_dwGameResourcesBase + CompetitiveWins + ply->iID * 4);
	[/swap_lines]

	[swap_lines]
	ply->fFlashDuration = m_Mem.Read<float>(addr + FlashDuration);
	ply->bAlive = (ply->iHealth > 0);
	ply->bHasHelmet = (m_Mem.Read<int>(addr + HasHelmet)) ? 1 : 0;
	ply->bHasDefuser = (m_Mem.Read<int>(addr + HasDefuseKit)) ? 1 : 0;
	ply->bIsSpotted = (m_Mem.Read<int>(addr + Spotted)) ? 1 : 0;
	ply->bIsReloading = (m_Mem.Read<int>(addr + IsReloading)) ? 1 : 0;
	ply->bIsDefusing = (m_Mem.Read<int>(addr + IsDefusing)) ? 1 : 0;
	ply->bIsDormant = (m_Mem.Read<int>(addr + Dormant)) ? 1 : 0;
	[/swap_lines]

	DWORD baseCombatHandle = m_Mem.Read<DWORD>(addr + ActiveWeapon);
	baseCombatHandle &= 0xFFF;

	DWORD weapBase = m_Mem.Read<DWORD>(m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);
	//ply->iWeaponID = m_Mem.Read<int>(weapBase + AccuracyPenalty + ActiveWeapID);
	[swap_lines]
	ply->iWeaponID = m_Mem.Read<int>(weapBase + 0x1148 + 0x40 + 0x194); // weaponBase + m_AttributeManager + m_Item + m_iItemDefinitionIndex
	ply->iAmmo_Primary = m_Mem.Read<int>(weapBase + PrimaryAmmo);
	ply->iAmmo_Secondary = m_Mem.Read<int>(weapBase + SecondaryAmmo);
	ply->vOrigin = m_Mem.Read<CVector>(ply->baseAddr + Origin);
	ply->vVelocity = m_Mem.Read<CVector>(ply->baseAddr + VecVelocity);
	ply->vPunchAngles = m_Mem.Read<CVector2D>(ply->baseAddr + PunchVector);
	ply->vVecViewOffset = m_Mem.Read<CVector>(ply->baseAddr + VecViewOffset);
	[/swap_lines]
	
	ply->vEyePos = ply->vOrigin + ply->vVecViewOffset;

	//DWORD anglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + EnginePtr);
	DWORD anglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + m_dynamicOffsets.enginePtr);
	//ply->vViewAngles = m_Mem.Read<CVector>(anglePointer + ViewAngles);
	ply->vViewAngles = m_Mem.Read<CVector>(anglePointer + m_dynamicOffsets.viewAngles);

	for (int i = 0; i < 30; i++)
	{
		ply->bones[i] = BonePosition(ply->baseAddr, i);
	}
}

void CSGO::UpdateEntities()
{
	if (!m_Mem.IsAttached())
		return;

	UpdateInfo(&m_Me, m_dwLocalBase);

	[add_junk 3 5 /]

	int friendIndex, enemyIndex;
	enemyIndex = friendIndex = 0;

	for (int i = 1; i < 64; i++)
	{
		DWORD entityBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));

		if (!entityBase)
			continue;

		if (GetTeam(entityBase) == GetEnemyTeam(m_Me.iTeam))
		{
			UpdateInfo(&m_Enemies[enemyIndex], entityBase);
			[add_junk 3 5 /]
			enemyIndex++;
		}
		else if (GetTeam(entityBase) == m_Me.iTeam)
		{
			UpdateInfo(&m_Friendlies[friendIndex], entityBase);
			friendIndex++;
			[add_junk 3 5 /]
		}
	}

	[add_junk 3 5 /]

	[swap_lines]
	m_iEnemiesDetected = enemyIndex;
	m_iFriendliesDetected = friendIndex;
	[/swap_lines]
}