#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CSGO.h"
#include "GlowESP.h"
#include "SubtleAimbot.h"
#include "ActualAimbot.h"
#include "ConsoleMenu.h"

#include <time.h>
#include <thread>

#include "Decrypt.h"

// Memory Leak Detection
//#include <vld.h>

// Globals

char* programPath = "";
CSGO csgo;

[enc_string_enable /]
[junk_enable /]

void UpdateEntitiesConstantly(CSGO* csgo)
{
	while (!csgo->m_Hacks.tThreadHandling.bUpdateStop)
	{
		// Check if we're in game
		//int clientState = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + EnginePtr);
		int clientState = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr);
		int sos = csgo->m_Mem.Read<int>(clientState + SignOnState);

		[add_junk 1 5 /]

		if (sos == SOS_Full)
		{
			csgo->LoadBases();
			
			[add_junk 1 5 /]

			[swap_lines]
			csgo->m_Hacks.tThreadHandling.bGlowThreadStop = false;
			csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
			[/swap_lines]

			std::string newHash = CMiscUtils::GetHash(std::string("settings.ini"));

			if (strcmp(newHash.c_str(), csgo->m_Hacks.hacksHash.c_str()))
			{
				CMiscUtils::PrintLine(std::string(".ini file has been changed. Automatically loading new settings!\n"));
				[add_junk 4 10 /]
				CMiscUtils::LoadINISettings(std::string("settings.ini"), csgo);
			}

			[add_junk 3 5 /]
		}
		else
		{
			[swap_lines]
			csgo->m_Hacks.tThreadHandling.bGlowThreadStop = true;
			csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = true;
			[/swap_lines]
			continue;
		}

		csgo->UpdateEntities();
		Sleep(1);
	}
}


void DisplayControls()
{
	system("cls");

	[add_junk 4 6 /]

	CMiscUtils::PrintLine(std::string(">	~ SmurfStomper Ghetto CONTROLS ~ "));
	CMiscUtils::PrintLine(std::string("-----------------------------------------"));
	CMiscUtils::PrintLine(std::string(">	Middle Mouse - GlowESP: ") + std::string(BoolToString(csgo.m_Hacks.CheckBit(BIT_ESP))));
	CMiscUtils::PrintLine(std::string(">	NumPad 5 - Subtle Aimbot: ") + std::string(BoolToString(csgo.m_Hacks.CheckBit(BIT_SUBTLEAIMBOT))));
	CMiscUtils::PrintLine(std::string(">	V - Aimbot Key: ") + std::string(BoolToString(csgo.m_Hacks.CheckBit(BIT_AIMBOT))));
	CMiscUtils::PrintLine(std::string(">	Pg Up - Dump Ranks & Wins: "));
	CMiscUtils::PrintLine(std::string("-----------------------------------------"));
}

void DisplayRankInfo()
{
	if (csgo.m_Me.iRank >= ARRAYSIZE(Ranks))
	{
		[add_junk 3 4 /]
		CMiscUtils::PrintLine(std::string("> Rank Information has been corrupted. Perhaps an outdated offset?"));
		return;
	}

	CMiscUtils::PrintLine(std::string("> Loading Ranks & Wins"));
	[add_junk 3 4 /]
	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));

	CMiscUtils::PrintLine(std::string(csgo.m_Me.szName) + "[You]");
	CMiscUtils::PrintLine(std::string("-----------------------------------------"));

	[add_junk 3 4 /]

	CMiscUtils::PrintLine(std::string("Rank: ") + Ranks[csgo.m_Me.iRank]);
	CMiscUtils::PrintLine(std::string("Wins: ") + std::to_string(csgo.m_Me.iWins));

	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
	CMiscUtils::PrintLine(std::string("Friendlies:\n"));

	for (int i = 0; i < csgo.m_iFriendliesDetected; i++)
	{
		CMiscUtils::PrintLine(std::string(csgo.m_Friendlies[i].szName));
		CMiscUtils::PrintLine(std::string("-----------------------------------------"));
		CMiscUtils::PrintLine(std::string("Rank: ") + Ranks[csgo.m_Friendlies[i].iRank]);
		[add_junk 3 4 /]
		CMiscUtils::PrintLine(std::string("Wins: ") + std::to_string(csgo.m_Friendlies[i].iWins));
		CMiscUtils::PrintLine(std::string("-----------------------------------------"));
	}

	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
	CMiscUtils::PrintLine(std::string("Enemies:\n"));
	[add_junk 3 4 /]

	for (int i = 0; i < csgo.m_iEnemiesDetected; i++)
	{
		CMiscUtils::PrintLine(std::string(csgo.m_Enemies[i].szName));
		[add_junk 3 4 /]
		CMiscUtils::PrintLine(std::string("-----------------------------------------"));
		CMiscUtils::PrintLine(std::string("Rank: ") + Ranks[csgo.m_Enemies[i].iRank]);
		[add_junk 3 4 /]
		CMiscUtils::PrintLine(std::string("Wins: ") + std::to_string(csgo.m_Enemies[i].iWins));
		CMiscUtils::PrintLine(std::string("-----------------------------------------"));
	}

	[add_junk 3 4 /]

	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
}

void ScanOffsets()
{
	[swap_lines]
	DWORD clientBase = csgo.m_Mem.GetModuleBase("client.dll");
	DWORD engineBase = csgo.m_Mem.GetModuleBase("engine.dll");
	DWORD clientModSize = csgo.m_Mem.GetModuleSize("client.dll");
	DWORD engineModSize = csgo.m_Mem.GetModuleSize("engine.dll");
	[/swap_lines]

#pragma region Scan for Entity List
	BYTE entListPattern[11] =
	{
		0x05, 0x00, 0x00, 0x00, 0x00,			// add eax, client.dll+xxxx
		0xC1, 0xE9, 0x00,						// shr ecx, x
		0x39, 0x48, 0x04						// cmp [eax+04], ecx
	};

	DWORD entityListBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(entListPattern), entListPattern);
	[add_junk 5 10 /]
	DWORD entityListPtr1 = csgo.m_Mem.Read<DWORD>(entityListBegin + 0x1);
	BYTE entityListPtr2 = csgo.m_Mem.Read<BYTE>(entityListBegin + 0x7);
	[add_junk 5 10 /]
	csgo.m_dynamicOffsets.entityList = (entityListPtr1 + entityListPtr2) - clientBase;
	std::cout << "> EntityList Found @ 0x" << std::hex << csgo.m_dynamicOffsets.entityList << std::endl;
	[add_junk 3 5 /]
#pragma endregion			// works

	[add_junk 3 5 /]

#pragma region Scan for Local Player

	BYTE localPlayerPattern[19] =
	{
		0x8D, 0x34, 0x85, 0x00, 0x00, 0x00, 0x00,       // lea esi, [eax*4+client.dll+xxxx]
		0x89, 0x15, 0x00, 0x00, 0x00, 0x00,             // mov [client.dll+xxxx],edx
		0x8B, 0x41, 0x08,                               // mov eax,[ecx+08]
		0x8B, 0x48, 0x00                                // mov ecx,[eax+04]
	};

	DWORD localPlayerBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(localPlayerPattern), localPlayerPattern);
	[add_junk 3 5 /]
	DWORD localPlayerPtr1 = csgo.m_Mem.Read<DWORD>(localPlayerBegin + 0x3);
	BYTE localPlayerPtr2 = csgo.m_Mem.Read<BYTE>(localPlayerBegin + 0x12);
	[add_junk 3 5 /]
	csgo.m_dynamicOffsets.localPlayer = (localPlayerPtr1 + localPlayerPtr2) - clientBase;
	std::cout << "> LocalPlayer Found @ 0x" << std::hex << csgo.m_dynamicOffsets.localPlayer << std::endl;
	[add_junk 3 5 /]

#pragma endregion			// works

	[add_junk 6 8 /]

#pragma region Scan for EnginePtr

	BYTE enginePtrPattern[37] =
	{
		0xF3, 0x0F, 0x5C, 0xC1,							// subss   xmm0, xmm1
		0xF3, 0x0F, 0x10, 0x15, 0x0, 0x0, 0x0, 0x0,		// movss   xmm2, ds:xxxx
		0x0F, 0x2F, 0xD0,								// comiss  xmm2, xmm0
		0x76, 0x04,										// jbe     short x
		0xF3, 0x0F, 0x58, 0xC1,							// addss   xmm0, xmm1
		0xA1, 0x0, 0x0, 0x0, 0x0,						// mov     eax, xxxx	
		0xF3, 0x0F, 0x11, 0x80, 0x0, 0x0, 0x0, 0x0,		// movss   dword ptr [eax+4CE0h], xmm0  (4ce0 = viewangles)
		0xD9, 0x46, 0x04								// fld     dword ptr [esi+4]
	};

	DWORD enginePtrBegin = csgo.m_Mem.FindPatternArr(engineBase, engineModSize, ARRAYSIZE(enginePtrPattern), enginePtrPattern);
	[add_junk 1 5 /]
	csgo.m_dynamicOffsets.enginePtr = csgo.m_Mem.Read<DWORD>(enginePtrBegin + 0x16) - engineBase;
	[add_junk 1 5 /]
	csgo.m_dynamicOffsets.viewAngles = csgo.m_Mem.Read<DWORD>(enginePtrBegin + 0x1E);
	std::cout << "> EnginePtr Found @ 0x" << std::hex << csgo.m_dynamicOffsets.enginePtr << std::endl;
	[add_junk 1 5 /]
	std::cout << "> Viewangles Found @ 0x" << std::hex << csgo.m_dynamicOffsets.viewAngles << std::endl;
#pragma endregion				// works

	[add_junk 1 5 /]

#pragma region Scan for GlowObjectBase

	BYTE glowObjectBase[26] =
	{
		0x8D, 0x8F, 0x00, 0x00, 0x00, 0x00,
		0xA1, 0x00, 0x00, 0x00, 0x00,
		0xC7, 0x04, 0x02, 0x00, 0x00, 0x00, 0x00,
		0x89, 0x35, 0x00, 0x00, 0x00, 0x00,
		0x8B, 0x51
	};

	DWORD glowBaseBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(glowObjectBase), glowObjectBase);
	DWORD dwGlowAddy = csgo.m_Mem.Read<DWORD>(glowBaseBegin + 0x7);
	[add_junk 1 5 /]
	if (dwGlowAddy)
	{
		[add_junk 1 5 /]
		csgo.m_dynamicOffsets.glowObjectBase = dwGlowAddy - clientBase;
		std::cout << "> GlowObjectBase Found @ 0x" << std::hex << csgo.m_dynamicOffsets.glowObjectBase << std::endl;
		[add_junk 1 5 /]
	}

	[add_junk 1 5 /]

#pragma endregion			// works

#pragma region Scan for Crosshair Index
if (!csgo.m_dynamicOffsets.localPlayer)
{
	CMiscUtils::PrintLine(std::string("LocalPlayer is NULL, skipping xhair index."));
	[add_junk 4 10 /]
}
else
{
	BYTE xhairIndexPattern[20] =
	{
		0x56,                           //push esi
		0x57,                           //push edi
		0x8B, 0xF9,                     //mov edi,ecx
		0xC7, 0x87, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  //mov [edi+xhair]
		0x8B, 0x0D, 0x00, 0x00, 0x00, 0x00
	};

	DWORD xhairBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(xhairIndexPattern), xhairIndexPattern);
	[add_junk 1 10 /]
	csgo.m_dynamicOffsets.crosshairIndex = csgo.m_Mem.Read<DWORD>(xhairBegin + 0x6);
	std::cout << "> CrosshairIndex Found @ 0x" << std::hex << csgo.m_dynamicOffsets.crosshairIndex << std::endl;
	[add_junk 1 10 /]
}
#pragma endregion		// works

#pragma region Scan for Viewmatrix
BYTE viewMatrixPattern[33] =
{
	0x53, 0x8B, 0xDC, 0x83, 0xEC, 0x08, 0x83, 0xE4,
	0xF0, 0x83, 0xC4, 0x04, 0x55, 0x8B, 0x6B, 0x04,
	0x89, 0x6C, 0x24, 0x04, 0x8B, 0xEC, 0xA1, 0x00,
	0x00, 0x00, 0x00, 0x81, 0xEC, 0x98, 0x03, 0x00,
	0x00
};

DWORD viewMatrixBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(viewMatrixPattern), viewMatrixPattern);
csgo.m_dynamicOffsets.viewMatrix  = csgo.m_Mem.Read<DWORD>(viewMatrixBegin + 0x4EE);
[add_junk 1 10 /]
csgo.m_dynamicOffsets.viewMatrix  -= clientBase;
csgo.m_dynamicOffsets.viewMatrix  += 0x80;
[add_junk 1 10 /]
std::cout << "> ViewMatrix Found @ 0x" << std::hex << csgo.m_dynamicOffsets.viewMatrix  << std::endl;
#pragma endregion				// works

#pragma region Scan for Scoreboard
BYTE scoreBoardPattern[14] =
{
	0x89, 0x4D, 0xF4,						//mov [ebp-0C],ecx
	0x8B, 0x0D, 0x00, 0x00, 0x00, 0x00,		//mov ecx,[engine.dll+xxxx]
	0x53,									//push ebx
	0x56,									//push esi
	0x57,									//push edi
	0x8B, 0x01								//moveax,[ecx]
};

[add_junk 1 10 /]

BYTE scoreBoardPattern2[18] =
{
	0xCC,                               //int 3
	0xCC,                               //int 3
	0x55,                               //push ebp
	0x8B, 0xEC,                         //mov ebp,esp
	0x8B, 0x45, 0x08,                   //mov eax,[ebp+08]
	0x8B, 0x44, 0xC1, 0x00,             //mov eax,[acx+eax*8+xx]
	0x5D,                               //pop ebp
	0xC2, 0x04, 0x00,					//ret 4
	0xCC,                               //int 3
	0xCC                                //int 3
};

DWORD scoreBoardBegin = csgo.m_Mem.FindPatternArr(engineBase, engineModSize, ARRAYSIZE(scoreBoardPattern), scoreBoardPattern);
DWORD pointer = csgo.m_Mem.Read<DWORD>(scoreBoardBegin + 0x5);
[add_junk 5 7/]
pointer -= engineBase;

DWORD leScoreBoard = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(scoreBoardPattern2), scoreBoardPattern2);
BYTE scoreBoardOffset = csgo.m_Mem.Read<BYTE>(leScoreBoard + 0xB);
[add_junk 5 7/]
leScoreBoard = csgo.m_Mem.Read<DWORD>(engineBase + pointer);
leScoreBoard += (0x46 * 8 + scoreBoardOffset);

csgo.m_dynamicOffsets.scoreBoard = leScoreBoard - clientBase;
std::cout << "> ScoreBoard Found @ 0x" << std::hex << csgo.m_dynamicOffsets.scoreBoard << std::endl;
#pragma endregion				// works

[add_junk 5 7/]

#pragma region Scan for GameResources
	BYTE gameResourcePattern[20] =
	{
		0x8B, 0x3D, 0x00, 0x00, 0x00, 0x00, // mov	edi, gameResourcePtr
		0x85, 0xFF,							// test edi, edi
		0x0F, 0x84, 0x00, 0x00, 0x00, 0x00, // jz	xxxx
		0x81, 0xC7, 0x00, 0x00, 0x00, 0x00, // add	edi, xxxx
	};

	DWORD gameResourceBegin = csgo.m_Mem.FindPatternArr(clientBase, clientModSize, ARRAYSIZE(gameResourcePattern), gameResourcePattern);
	[add_junk 5 7/]
	DWORD yush = csgo.m_Mem.Read<DWORD>(gameResourceBegin + 2);
	[add_junk 5 7/]
	csgo.m_dynamicOffsets.gameResources = yush -= clientBase;
	std::cout << "> GameResources Found @ 0x" << std::hex << csgo.m_dynamicOffsets.gameResources << std::endl;
#pragma endregion			// works

	[add_junk 5 7/]

}


int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	// Set up minidumper in case we have a crash
	SetUnhandledExceptionFilter(CMiscUtils::MinidumpHelper);

	if (argc > 0)
	{
		programPath = argv[0];
	}

	// Create a random title and allow debugging access for this process
	CMiscUtils::GenerateRandomWindowTitle(20);
	[add_junk 5 7/]
	CMiscUtils::AllowDebugging();

	CMiscUtils::PrintLine(std::string("~ SmurfStomper [CSGO] : Completely recoded and redone ~"));
	[add_junk 5 7/]
	CMiscUtils::PrintLine(std::string("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	CMiscUtils::PrintLine(std::string("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now."));
	std::cout << "\b\b";

	while (!csgo.Attach())
	{
		std::cout << "_";
		Sleep(100);\
		std::cout << "\b_";
	}

	CMiscUtils::PrintLine(std::string("\n> CSGO attached!"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	[add_junk 5 7/]

	CMiscUtils::PrintLine(std::string("> Loading INI Settings..."));
	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));

	if (!CMiscUtils::LoadINISettings(std::string("settings.ini"), &csgo))
	{
		csgo.m_Hacks.Unset(BIT_SUBTLEAIMBOT | BIT_TRIGGERBOT | BIT_BHOP | BIT_RCS | BIT_ESP | BIT_AIMBOT);
	}

	CMiscUtils::PrintLine(std::string("> Signature scanning offsets..."));
	CMiscUtils::PrintLine(std::string("-----------------------------------------\n"));
	[add_junk 5 7/]
	ScanOffsets();

	CMiscUtils::PrintLine(std::string("> Press INSERT whenever your ready to 'toggle'"));
	CMiscUtils::PrintLine(std::string("-----------------------------\n"));

	while (!GetAsyncKeyState(VK_INSERT))
	{
		Sleep(100);
	}

	CMiscUtils::PrintLine(std::string("> Starting cheat threads.."));

	[add_junk 5 7/]

	// Load our basic information
	csgo.LoadBases();

	// Start the threads
	std::thread threadUpdateEnts(UpdateEntitiesConstantly, &csgo);
	std::thread threadGlowESP(&GlowESP::Start, GlowESP(&csgo));
	[add_junk 5 7/]
	std::thread threadSubtleAimbot(&SubtleAimbot::Start, SubtleAimbot(&csgo));
	std::thread threadActualAimbot(&ActualAimbot::Start, ActualAimbot(&csgo));

	[add_junk 5 7/]

	
	DisplayControls();

	[add_junk 5 7/]


	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{

		if (GetAsyncKeyState(VK_PRIOR) & 1)
		{
			DisplayRankInfo();
		}

		// Handle triggerbot
		if (GetAsyncKeyState(csgo.m_Hacks.tTriggerOptions.iKey) < 0)
		{
			csgo.m_Hacks.Set(BIT_TRIGGERBOT);
			[add_junk 1 2 /]
			Sleep(50);
		}
		else
		{
			csgo.m_Hacks.Unset(BIT_TRIGGERBOT);
			Sleep(50);
		}

		// Handle GlowESP
		if (GetAsyncKeyState(csgo.m_Hacks.tGlowOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_ESP);
			Sleep(50);

			[add_junk 1 2 /]

			DisplayControls();

		}

		// Handle Subtle Aimbot
		if (GetAsyncKeyState(csgo.m_Hacks.tSubtleAimbotOptions.iKey) & 1)
		{
			csgo.m_Hacks.Toggle(BIT_SUBTLEAIMBOT);
			[add_junk 1 2 /]
			Sleep(50);

			DisplayControls();
		}

		// Handle Actual Aimbot
		if (GetAsyncKeyState(csgo.m_Hacks.tActualAimbotOptions.iKey) < 0)
		{
			csgo.m_Hacks.Set(BIT_AIMBOT);
			Sleep(50);

			[add_junk 1 2 /]


			DisplayControls();
		}
		else
		{
			csgo.m_Hacks.Unset(BIT_AIMBOT);

			[add_junk 1 2 /]
			
			Sleep(50);
		}
	}

	csgo.m_Mem.Detach();
	CMiscUtils::DeleteSelf(programPath);


	exit(0);

}