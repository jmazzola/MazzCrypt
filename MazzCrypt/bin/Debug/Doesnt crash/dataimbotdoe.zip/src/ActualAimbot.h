#ifndef _ACTUALAIMBOT_H_
#define _ACTUALAIMBOT_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

#include <random>

#define M_PI       3.14159265358979323846


[junk_enable /]

class ActualAimbot
{
public:

	ActualAimbot(CSGO* c)
	{
		csgo = c;
		[add_junk 2 4 /]
	}

	~ActualAimbot() = default;

	bool PointInCircle(CVector2D point, CVector2D circleCenter, float radius)
	{
		[add_junk 2 3 /]

		return sqrtf(((circleCenter.x - point.x) * (circleCenter.x - point.x)) + ((circleCenter.y - point.y) * (circleCenter.y - point.y))) < radius;
	}

	void ClampAngles(CVector& angle)
	{
		if (angle.x > 89.0f && angle.x <= 180.0f)
		{
			[add_junk 2 3 /]
			angle.x = 89.0f;
		}

		[add_junk 2 3 /]

		if (angle.x > 180.f)
			angle.x -= 360.f;

		[add_junk 2 3 /]

		if (angle.x < -89.0f)
		{
			angle.x = -89.0f;
			[add_junk 2 3 /]
		}

		[add_junk 2 3 /]

		if (angle.y > 180.f)
			angle.y -= 360.f;

		[add_junk 2 3 /]

		if (angle.y < -180.f)
			angle.y += 360.f;

		[add_junk 2 3 /]

		if (angle.z != 0.0f)
			angle.z = 0.0f;
	}

	CVector2D WorldToScreen(CVector point)
	{
		CVector returnVector(0, 0, 0);

		float w = csgo->m_ViewMatrix[12] * point.x + csgo->m_ViewMatrix[13] * point.y + csgo->m_ViewMatrix[14] * point.z + csgo->m_ViewMatrix[15];
		if (w >= 0.01f)
		{
			[add_junk 2 3 /]

			float inverseWidth = 1.0f / w;

			[swap_lines]
			returnVector.x = (csgo->m_iWindowWidth / 2.0f) + (0.5f * ((csgo->m_ViewMatrix[0] * point.x + csgo->m_ViewMatrix[1] * point.y + csgo->m_ViewMatrix[2] * point.z + csgo->m_ViewMatrix[3]) * inverseWidth) * csgo->m_iWindowWidth + 0.5f);
			returnVector.y = (csgo->m_iWindowHeight / 2.0f) - (0.5f * ((csgo->m_ViewMatrix[4] * point.x + csgo->m_ViewMatrix[5] * point.y + csgo->m_ViewMatrix[6] * point.z + csgo->m_ViewMatrix[7]) * inverseWidth)	* csgo->m_iWindowHeight + 0.5f);
			[/swap_lines]

			[add_junk 2 3 /]
		}

		return returnVector;
	}

	Player* GetPlayerClosestToCrosshair()
	{
		CVector2D least = CVector2D(0, 0);
		[add_junk 2 3 /]
		int index = -1;
		float leastDist = FLT_MAX;

		CVector2D screenM(csgo->m_iWindowWidth / 2.0f, csgo->m_iWindowHeight / 2.0f);

		for (int i = 0; i < csgo->m_iEnemiesDetected; i++)
		{
			[add_junk 2 3 /]

			CVector2D boneLocationOnScreenLoc = WorldToScreen(csgo->m_Enemies[i].bones[(int)csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt]);

			if (!PointInCircle(boneLocationOnScreenLoc, screenM, csgo->m_Hacks.tActualAimbotOptions.fFOVRadius))
				continue;

			[add_junk 2 3 /]

			float dist = (float)abs((boneLocationOnScreenLoc - screenM).Length());

			if (dist < leastDist)
			{
				[add_junk 2 3 /]
				least = boneLocationOnScreenLoc;
				[add_junk 2 3 /]
				leastDist = dist;
				index = i;
			}
		}

		[add_junk 2 3 /]

		if (index != -1)
			return &csgo->m_Enemies[index];
		else
			return NULL;
	}

	CVector CalcAngle(CVector src, CVector dst)
	{
		CVector ret;
		CVector vDelta = src - dst;
		[add_junk 2 3 /]
		float fHyp = sqrtf((vDelta.x * vDelta.x) + (vDelta.y * vDelta.y));

		[swap_lines]
		ret.x = (atanf(vDelta.z / fHyp)) * (180.0f / (float)M_PI);
		ret.y = (atanf(vDelta.y / vDelta.x)) * (180.0f / (float)M_PI);
		[/swap_lines]

		if (vDelta.x >= 0.0f)
			ret.y += 180.0f;

		[add_junk 2 3 /]

		return ret;
	}

	void Start()
	{
		while (true)
		{
			if (!csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop)
			{
				[add_junk 2 3 /]

				if (csgo->m_Hacks.CheckBit(BIT_AIMBOT))
				{
					int boneToAimAt = 0;
					[add_junk 3 5 /]
					float rcsScale = 0.0f;

					switch (csgo->GetWeaponType(csgo->m_Me))
					{
						case EWeaponType::WeapType_Pistol:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale;
							[/swap_lines]
							break;
						}

						case EWeaponType::WeapType_Sniper:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale;
							[/swap_lines]
							break;
						}

						case EWeaponType::WeapType_Rifle:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale;
							[/swap_lines]
							break;
						}

						case EWeaponType::WeapType_SMG:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale;
							[/swap_lines]
							break;
						}

						case EWeaponType::WeapType_LMG:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale;
							[/swap_lines]
							break;
						}
						case EWeaponType::WeapType_Shotgun:
						{
							[swap_lines]
							boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt;
							rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale;
							[/swap_lines]
							break;
						}

						default:
						{
							continue;
						}

					}

					if (csgo->m_Me.bIsReloading)
						continue;

					Player* enemy = NULL;

					[add_junk 3 5 /]

					switch (csgo->m_Hacks.tActualAimbotOptions.eAimMethod)
					{
						case 0:
						case 1:
						case 2:
						case 3:
						{
							enemy = GetPlayerClosestToCrosshair();
							[add_junk 3 5 /]
							break;
						}
					}

					if (!enemy || !enemy->bAlive || enemy->bIsDormant)
						continue;

					[add_junk 3 5 /]

					DWORD anglePointer = csgo->m_Mem.Read<DWORD>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr);
					[add_junk 3 5 /]
					CVector viewAngles = csgo->m_Mem.Read<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles);

					CVector position = csgo->m_Me.vOrigin + csgo->m_Me.vVecViewOffset;
					viewAngles = CalcAngle(position, enemy->bones[csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt]);

					[add_junk 3 5 /]

					// RCS 
					CVector punchAngle(csgo->m_Me.vPunchAngles.x, csgo->m_Me.vPunchAngles.y, 0.0f);
					[add_junk 3 5 /]
					viewAngles -= punchAngle * (2.0f);

					// Smooth Angles
					CVector smoothed = viewAngles - csgo->m_Mem.Read<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles);
					[add_junk 3 5 /]
					smoothed *= csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor / 100.0f;
					if (abs(smoothed.y) < 45.0f)
					{
						viewAngles = csgo->m_Mem.Read<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles) + smoothed;
						[add_junk 3 5 /]
					}

					viewAngles.z = 0;

					[add_junk 3 5 /]

					ClampAngles(viewAngles);

					csgo->m_Mem.Write<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles, viewAngles);
				}
			}
		}
	}

private:

	CSGO* csgo;
};

#endif //_ACTUALAIMBOT_H_
