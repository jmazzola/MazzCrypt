#include "MiscUtils.h"
#include "INIReader.h"
#include "CSGO.h"

#include "Decrypt.h"

#include <Wincrypt.h>


#define BUFSIZE 1024
#define MD5LEN  16

[junk_enable /]

/*static*/ void CMiscUtils::GenerateRandomWindowTitle(int stringLength)
{
	// Generate random window title
	static const char alphanum[] =
		"0123456789"
		"!@#$%^&*"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	[add_junk 4 6 /]

	std::string str;

	for (int i = 0; i < stringLength; i++)
	{
		str += alphanum[rand() % sizeof(alphanum) - 1];
	}

	[add_junk 4 6 /]

	SetConsoleTitleA(str.c_str());
}



/*static*/ void CMiscUtils::DeleteSelf(char* ProgramPath)
{
	// Windows keeps .exe files open during execution...
	char* batPath = new char[strlen(ProgramPath) + 5];
	strcpy_s(batPath, strlen(ProgramPath) + 5, ProgramPath);
	strcat_s(batPath, strlen(ProgramPath) + 5, ".bat");

	[add_junk 4 6 /]

	const char* batFormat =
		":Repeat\n"
		"del \"%s\"\n"
		"if exist \"%s\" goto Repeat\n"
		"del \"%s\"\n";

	char* batFile = new char[strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2];
	sprintf_s(batFile, strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2,
			  batFormat, ProgramPath, ProgramPath, batPath);

	FILE* f;
	fopen_s(&f, batPath, "w");
	if (f != NULL)
	{
		fwrite(batFile, strlen(batFile), 1, f);
		fclose(f);
	}

	STARTUPINFOA startupInfo;
	PROCESS_INFORMATION procInfo;
	memset(&startupInfo, 0, sizeof(startupInfo));

	startupInfo.cb = sizeof(startupInfo);

	CreateProcessA(batPath, NULL, NULL, NULL, FALSE, 0, NULL, NULL,
				   &startupInfo, &procInfo);

	delete[] batFile;
	delete[] batPath;
}

[enc_string_enable /]

/*static*/ void CMiscUtils::AllowDebugging()
{
	HANDLE _HandleProcess = GetCurrentProcess();
	HANDLE _HandleToken;
	TOKEN_PRIVILEGES tkPrivileges;
	[add_junk 4 6 /]
	LUID _LUID;

	OpenProcessToken(_HandleProcess, TOKEN_ADJUST_PRIVILEGES, &_HandleToken);
	[add_junk 4 6 /]
	LookupPrivilegeValue(0, "seDebugPrivilege", &_LUID);

	tkPrivileges.PrivilegeCount = 1;
	[add_junk 4 6 /]
	tkPrivileges.Privileges[0].Luid = _LUID;
	tkPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	AdjustTokenPrivileges(_HandleToken, false, &tkPrivileges, 0, 0, 0);

	CloseHandle(_HandleToken);

	[add_junk 4 6 /]

	CloseHandle(_HandleProcess);
}

/*static*/ void CMiscUtils::PrintLine(std::string s)
{
	std::cout << s.c_str() << std::endl;
	[add_junk 4 6 /]
}

/*static*/ bool CMiscUtils::LoadINISettings(std::string fileName, CSGO* csgo)
{
	INIReader r = INIReader(fileName);

	if (r.ParseError() < 0)
	{
		[add_junk 2 6 /]
		std::cout << "> Unable to read .ini. Resetting settings to defaults.\n";
		return false;
	}

	csgo->m_Hacks.hacksHash = CMiscUtils::GetHash(fileName);

	(r.GetBoolean("tbot", "trig", "off")) ? csgo->m_Hacks.Set(BIT_TRIGGERBOT) : csgo->m_Hacks.Unset(BIT_TRIGGERBOT);
	/*csgo->m_Hacks.triggerHead = r.GetBoolean("tbot", "trig_head", "off");
	csgo->m_Hacks.triggerNeck = r.GetBoolean("tbot", "trig_neck", "off");
	csgo->m_Hacks.triggerSniper = r.GetBoolean("tbot", "trig_sniper", "off");
	csgo->m_Hacks.triggerPistolRound = r.GetBoolean("tbot", "trig_pistolround", "off");*/

	[swap_lines]
	csgo->m_Hacks.tTriggerOptions.iDelay = r.GetInteger("tbot", "trig_delay", 120);
	csgo->m_Hacks.tTriggerOptions.iKey = r.GetInteger("tbot", "trig_vKey", VK_XBUTTON1);
	csgo->m_Hacks.tTriggerOptions.bStopOnSpectate = r.GetBoolean("tbot", "trig_stopOnSpectate", "on");
	[/swap_lines]

	/*csgo->m_Hacks.radarEnabled = r.GetBoolean("radar", "radar", "off");
	csgo->m_Hacks.radarVKey = r.GetInteger("radar", "radar_vKey", VK_MENU);*/

	(r.GetBoolean("bhop", "bhop_enabled", "off")) ? csgo->m_Hacks.Set(BIT_BHOP) : csgo->m_Hacks.Unset(BIT_BHOP);

	/*csgo->m_Hacks.rcsEnabled = r.GetBoolean("rcs", "rcs", "off");
	csgo->m_Hacks.rcsVKey = r.GetInteger("rcs", "rcs_vKey", 'V');*/

	[add_junk 2 10 /]

	[swap_lines]
	(r.GetBoolean("glowesp", "glow", "off")) ? csgo->m_Hacks.Set(BIT_ESP) : csgo->m_Hacks.Unset(BIT_ESP);
	csgo->m_Hacks.tGlowOptions.bEnemyOnly = r.GetBoolean("glowesp", "glow_enemyOnly", "off");
	csgo->m_Hacks.tGlowOptions.iKey = r.GetInteger("glowesp", "glow_vKey", VK_MBUTTON);
	csgo->m_Hacks.tGlowOptions.bHealthGlow = r.GetBoolean("glowesp", "glow_health", "off");
	csgo->m_Hacks.tGlowOptions.bFlashGlow = r.GetBoolean("glowesp", "glow_flash", "off");
	csgo->m_Hacks.tGlowOptions.bDefuseGlow = r.GetBoolean("glowesp", "glow_defuse", "off");
	csgo->m_Hacks.tGlowOptions.bGlowBomb = r.GetBoolean("glowesp", "glow_bomb", "off");
	csgo->m_Hacks.tGlowOptions.bGlowWeapons = r.GetBoolean("glowesp", "glow_weapons", "off");
	csgo->m_Hacks.tGlowOptions.bGlowGrenades = r.GetBoolean("glowesp", "glow_grenades", "off");
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_R = r.GetFloat("glowesp", "glow_enemy_R", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_G = r.GetFloat("glowesp", "glow_enemy_G", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_B = r.GetFloat("glowesp", "glow_enemy_B", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_A = r.GetFloat("glowesp", "glow_enemy_A", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_R = r.GetFloat("glowesp", "glow_team_R", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_G = r.GetFloat("glowesp", "glow_team_G", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_B = r.GetFloat("glowesp", "glow_team_B", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_A = r.GetFloat("glowesp", "glow_team_A", 1.0f);
	(r.GetBoolean("subtleaimbot", "subtleaimbot", "off")) ? csgo->m_Hacks.Set(BIT_SUBTLEAIMBOT) : csgo->m_Hacks.Unset(BIT_SUBTLEAIMBOT);
	csgo->m_Hacks.tSubtleAimbotOptions.iKey = r.GetInteger("subtleaimbot", "subtleaimbot_key", 'C');;
	csgo->m_Hacks.tSubtleAimbotOptions.bNewMethod = r.GetBoolean("subtleaimbot", "newMethod", false);
	csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor = r.GetFloat("subtleaimbot", "smoothFactor", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_pistols", "boneToAimAt", EBones::Bone_Head));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance = r.GetInteger("subtleaimbot_pistols", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance = r.GetInteger("subtleaimbot_pistols", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale =  r.GetFloat("subtleaimbot_pistols", "rcsScale", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_rifles", "boneToAimAt", EBones::Bone_Head));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance = r.GetInteger("subtleaimbot_rifles", "minChance", 2);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance = r.GetInteger("subtleaimbot_rifles", "maxChance", 10);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale =  r.GetFloat("subtleaimbot_rifles", "rcsScale", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_smgs", "boneToAimAt", EBones::Bone_Head));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_smgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_smgs", "maxChance", 15);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale =  r.GetFloat("subtleaimbot_smgs", "rcsScale", 1.5f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_lmgs", "boneToAimAt", EBones::Bone_Head));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_lmgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_lmgs", "maxChance", 20);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale =  r.GetFloat("subtleaimbot_lmgs", "rcsScale", 1.7f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_snipers", "boneToAimAt", EBones::Bone_Spine3));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance = r.GetInteger("subtleaimbot_snipers", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance = r.GetInteger("subtleaimbot_snipers", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale =  r.GetFloat("subtleaimbot_snipers", "rcsScale", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt = (EBones)(r.GetInteger("subtleaimbot_shotguns", "boneToAimAt", EBones::Bone_Spine3));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance = r.GetInteger("subtleaimbot_shotguns", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance = r.GetInteger("subtleaimbot_shotguns", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale =  r.GetFloat("subtleaimbot_shotguns", "rcsScale", 0.0f);
	csgo->m_Hacks.tThreadHandling.bGlowThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bTrigThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bUpdateStop = false;
	csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
	[/swap_lines]

	[add_junk 4 6 /]

	std::cout << "> .ini loaded successfully!\n";
	return true;
}

/*static*/ bool CMiscUtils::IsActiveWindow()
{
	[swap_lines]
	char windowTitle[256];
	char consoleTitle[256];
	HWND hwnd = GetForegroundWindow();
	[/swap_lines]

	[add_junk 3 5 /]

	[swap_lines]
	GetWindowText(hwnd, windowTitle, sizeof(windowTitle));
	GetConsoleTitle(consoleTitle, sizeof(consoleTitle));
	[/swap_lines]

	[add_junk 5 8 /]

	return (!strcmp(windowTitle, consoleTitle));
}

/*static*/ std::string CMiscUtils::GetHash(std::string fileName)
{
	[enc_string_disable /]

	[swap_lines]
	HANDLE hFile = CreateFile(fileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	HCRYPTPROV hProv;
	HCRYPTHASH hHash;
	DWORD cbHash = MD5LEN;
	BYTE rgbHash[MD5LEN];
	CHAR rgbDigits[] = "0123456789abcdef";
	[/swap_lines]

	[add_junk 4 10 /]

	if (hFile == INVALID_HANDLE_VALUE)
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error reading in .ini"));
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]

	}

	// Get handle to the crypto provider
	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	[add_junk 3 10 /]

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	BOOL bResult = FALSE;
	DWORD cbRead;
	BYTE rgbFile[BUFSIZE];

	while (bResult = ReadFile(hFile, rgbFile, BUFSIZE, &cbRead, NULL))
	{
		if (!cbRead)
		{
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			[enc_string_enable /]
			int dwStatus = GetLastError();
			CMiscUtils::PrintLine(std::string("Error with CryptHashData"));
			CryptReleaseContext(hProv, 0);
			CryptDestroyHash(hHash);
			CloseHandle(hFile);
			return std::string("ERROR");
			[enc_string_disable /]
		}
	}

	if (!bResult)
	{
		[enc_string_enable /]
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("ReadFile failed"));
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		CloseHandle(hFile);
		return std::string("ERROR");
		[enc_string_disable /]
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		//printf("MD5 hash of file %s is: ", fileName.c_str());

		[add_junk 3 5 /]

		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);

			//printf("%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
		}
		//printf("\n");
	}

	[add_junk 4 9 /]

	CryptReleaseContext(hProv, 0);
	CryptDestroyHash(hHash);
	CloseHandle(hFile);

	return hashOutput;
}

/*static*/ LONG WINAPI CMiscUtils::MinidumpHelper(_EXCEPTION_POINTERS *pExceptionInfo)
{
	std::string filename = "DC_CrashReport_";
	SYSTEMTIME sysTime;

	GetLocalTime(&sysTime);
	filename += std::to_string(sysTime.wMonth);
	filename += '-';
	filename += std::to_string(sysTime.wDay);
	filename += '-';
	[add_junk 4 6 /]
	filename += std::to_string(sysTime.wYear);
	filename += '_';
	filename += std::to_string(sysTime.wHour);
	filename += '-';
	filename += std::to_string(sysTime.wMinute);
	[add_junk 4 6 /]
	filename += '-';
	filename += std::to_string(sysTime.wSecond);
	filename += ".mdmp";

	[add_junk 4 6 /]

	HANDLE hFile = CreateFileA(filename.c_str(), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		_MINIDUMP_EXCEPTION_INFORMATION ExInfo;

		ExInfo.ThreadId = GetCurrentThreadId();
		ExInfo.ExceptionPointers = pExceptionInfo;

		[add_junk 4 6 /]

		ExInfo.ClientPointers = NULL;
		MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpNormal, &ExInfo, NULL, NULL);
		filename = "Dump File Saved - " + filename;
		MessageBox(NULL, filename.c_str(), "Crash! D:", MB_OK);
		CloseHandle(hFile);

		[add_junk 4 6 /]
	}

	return 0;
}

[enc_string_disable /]