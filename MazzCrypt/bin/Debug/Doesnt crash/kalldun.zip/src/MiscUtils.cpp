#include "MiscUtils.h"
#include "INIReader.h"
#include "CSGO.h"

#include "Decrypt.h"

[junk_enable /]

/*static*/ void CMiscUtils::GenerateRandomWindowTitle(int stringLength)
{
	// Generate random window title
	static const char alphanum[] =
		"0123456789"
		"!@#$%^&*"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	[add_junk 4 6 /]

	std::string str;

	for (int i = 0; i < stringLength; i++)
	{
		str += alphanum[rand() % sizeof(alphanum) - 1];
	}

	[add_junk 4 6 /]

	SetConsoleTitleA(str.c_str());
}



/*static*/ void CMiscUtils::DeleteSelf(char* ProgramPath)
{
	// Windows keeps .exe files open during execution...
	char* batPath = new char[strlen(ProgramPath) + 5];
	strcpy_s(batPath, strlen(ProgramPath) + 5, ProgramPath);
	strcat_s(batPath, strlen(ProgramPath) + 5, ".bat");

	[add_junk 4 6 /]

	const char* batFormat =
		":Repeat\n"
		"del \"%s\"\n"
		"if exist \"%s\" goto Repeat\n"
		"del \"%s\"\n";

	char* batFile = new char[strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2];
	sprintf_s(batFile, strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2,
			  batFormat, ProgramPath, ProgramPath, batPath);

	FILE* f;
	fopen_s(&f, batPath, "w");
	if (f != NULL)
	{
		fwrite(batFile, strlen(batFile), 1, f);
		fclose(f);
	}

	STARTUPINFOA startupInfo;
	PROCESS_INFORMATION procInfo;
	memset(&startupInfo, 0, sizeof(startupInfo));

	startupInfo.cb = sizeof(startupInfo);

	CreateProcessA(batPath, NULL, NULL, NULL, FALSE, 0, NULL, NULL,
				   &startupInfo, &procInfo);

	delete[] batFile;
	delete[] batPath;
}

[enc_string_enable /]

/*static*/ void CMiscUtils::AllowDebugging()
{
	HANDLE _HandleProcess = GetCurrentProcess();
	HANDLE _HandleToken;
	TOKEN_PRIVILEGES tkPrivileges;
	[add_junk 4 6 /]
	LUID _LUID;

	OpenProcessToken(_HandleProcess, TOKEN_ADJUST_PRIVILEGES, &_HandleToken);
	[add_junk 4 6 /]
	LookupPrivilegeValue(0, "seDebugPrivilege", &_LUID);

	tkPrivileges.PrivilegeCount = 1;
	[add_junk 4 6 /]
	tkPrivileges.Privileges[0].Luid = _LUID;
	tkPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	AdjustTokenPrivileges(_HandleToken, false, &tkPrivileges, 0, 0, 0);

	CloseHandle(_HandleToken);

	[add_junk 4 6 /]

	CloseHandle(_HandleProcess);
}

/*static*/ void CMiscUtils::PrintLine(std::string s)
{
	std::cout << s.c_str() << std::endl;
	[add_junk 4 6 /]
}

/*static*/ bool CMiscUtils::LoadINISettings(std::string fileName, CSGO* csgo)
{
	INIReader r = INIReader(fileName);

	if (r.ParseError() < 0)
	{
		[add_junk 2 6 /]
		std::cout << "> Unable to read .ini. Resetting settings to defaults.\n";
		return false;
	}

	(r.GetBoolean("tbot", "trig", "off")) ? csgo->m_Hacks.Set(BIT_TRIGGERBOT) : csgo->m_Hacks.Unset(BIT_TRIGGERBOT);
	/*csgo->m_Hacks.triggerHead = r.GetBoolean("tbot", "trig_head", "off");
	csgo->m_Hacks.triggerNeck = r.GetBoolean("tbot", "trig_neck", "off");
	csgo->m_Hacks.triggerSniper = r.GetBoolean("tbot", "trig_sniper", "off");
	csgo->m_Hacks.triggerPistolRound = r.GetBoolean("tbot", "trig_pistolround", "off");*/

	[swap_lines]
	csgo->m_Hacks.tTriggerOptions.iDelay = r.GetInteger("tbot", "trig_delay", 120);
	csgo->m_Hacks.tTriggerOptions.iKey = r.GetInteger("tbot", "trig_vKey", VK_XBUTTON1);
	csgo->m_Hacks.tTriggerOptions.bStopOnSpectate = r.GetBoolean("tbot", "trig_stopOnSpectate", "on");
	[/swap_lines]

	/*csgo->m_Hacks.radarEnabled = r.GetBoolean("radar", "radar", "off");
	csgo->m_Hacks.radarVKey = r.GetInteger("radar", "radar_vKey", VK_MENU);*/

	(r.GetBoolean("bhop", "bhop_enabled", "off")) ? csgo->m_Hacks.Set(BIT_BHOP) : csgo->m_Hacks.Unset(BIT_BHOP);

	/*csgo->m_Hacks.rcsEnabled = r.GetBoolean("rcs", "rcs", "off");
	csgo->m_Hacks.rcsVKey = r.GetInteger("rcs", "rcs_vKey", 'V');*/

	[add_junk 2 10 /]

	[swap_lines]
	(r.GetBoolean("glowesp", "glow", "off")) ? csgo->m_Hacks.Set(BIT_ESP) : csgo->m_Hacks.Unset(BIT_ESP);
	csgo->m_Hacks.tGlowOptions.bEnemyOnly = r.GetBoolean("glowesp", "glow_enemyOnly", "off");
	csgo->m_Hacks.tGlowOptions.iKey = r.GetInteger("glowesp", "glow_vKey", VK_MBUTTON);
	csgo->m_Hacks.tGlowOptions.bHealthGlow = r.GetBoolean("glowesp", "glow_health", "off");
	csgo->m_Hacks.tGlowOptions.bFlashGlow = r.GetBoolean("glowesp", "glow_flash", "off");
	csgo->m_Hacks.tGlowOptions.bGlowBomb = r.GetBoolean("glowesp", "glow_bomb", "off");
	csgo->m_Hacks.tGlowOptions.bGlowWeapons = r.GetBoolean("glowesp", "glow_weapons", "off");
	csgo->m_Hacks.tGlowOptions.bGlowGrenades = r.GetBoolean("glowesp", "glow_grenades", "off");
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_R = r.GetFloat("glowesp", "glow_enemy_R", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_G = r.GetFloat("glowesp", "glow_enemy_G", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_B = r.GetFloat("glowesp", "glow_enemy_B", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_A = r.GetFloat("glowesp", "glow_enemy_A", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_R = r.GetFloat("glowesp", "glow_team_R", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_G = r.GetFloat("glowesp", "glow_team_G", 1.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_B = r.GetFloat("glowesp", "glow_team_B", 0.0f);
	csgo->m_Hacks.tGlowOptions.fGlowTeam_A = r.GetFloat("glowesp", "glow_team_A", 1.0f);
	(r.GetBoolean("subtleaimbot", "subtleaimbot", "off")) ? csgo->m_Hacks.Set(BIT_SUBTLEAIMBOT) : csgo->m_Hacks.Unset(BIT_SUBTLEAIMBOT);
	csgo->m_Hacks.tSubtleAimbotOptions.bPistolAimbot = r.GetBoolean("subtleaimbot", "pistols", "off");
	csgo->m_Hacks.tSubtleAimbotOptions.iKey = r.GetInteger("subtleaimbot", "subtleaimbot_key", 'C');
	csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor = r.GetFloat("subtleaimbot", "smooth_factor", 20.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.iSubtleMinChance = r.GetInteger("subtleaimbot", "minChance", 3);
	csgo->m_Hacks.tSubtleAimbotOptions.iSubtleMaxChance = r.GetInteger("subtleaimbot", "maxChance", 15);
	csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMinRCS_X = r.GetFloat("subtleaimbot", "minRCS_x", 2.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMaxRCS_X = r.GetFloat("subtleaimbot", "maxRCS_x", 2.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMinRCS_Y = r.GetFloat("subtleaimbot", "minRCS_y", 2.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.fSubtleMaxRCS_Y = r.GetFloat("subtleaimbot", "maxRCS_y", 2.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.eBoneToAimAt = (EBones)r.GetInteger("subtleaimbot", "boneToAimFor", EBones::Bone_Head);
	csgo->m_Hacks.tThreadHandling.bGlowThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bTrigThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bUpdateStop = false;
	csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
	[/swap_lines]

	[add_junk 4 6 /]

	std::cout << "> .ini loaded successfully!\n";
	return true;
}

/*static*/ LONG WINAPI CMiscUtils::MinidumpHelper(_EXCEPTION_POINTERS *pExceptionInfo)
{
	std::string filename = "DC_CrashReport_";
	SYSTEMTIME sysTime;

	GetLocalTime(&sysTime);
	filename += std::to_string(sysTime.wMonth);
	filename += '-';
	filename += std::to_string(sysTime.wDay);
	filename += '-';
	[add_junk 4 6 /]
	filename += std::to_string(sysTime.wYear);
	filename += '_';
	filename += std::to_string(sysTime.wHour);
	filename += '-';
	filename += std::to_string(sysTime.wMinute);
	[add_junk 4 6 /]
	filename += '-';
	filename += std::to_string(sysTime.wSecond);
	filename += ".mdmp";

	[add_junk 4 6 /]

	HANDLE hFile = CreateFileA(filename.c_str(), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		_MINIDUMP_EXCEPTION_INFORMATION ExInfo;

		ExInfo.ThreadId = GetCurrentThreadId();
		ExInfo.ExceptionPointers = pExceptionInfo;

		[add_junk 4 6 /]

		ExInfo.ClientPointers = NULL;
		MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpNormal, &ExInfo, NULL, NULL);
		filename = "Dump File Saved - " + filename;
		MessageBox(NULL, filename.c_str(), "Crash! D:", MB_OK);
		CloseHandle(hFile);

		[add_junk 4 6 /]
	}

	return 0;
}

[enc_string_disable /]