#include "CSGO.h"
#include "Utils.h"

CSGO* pCSGO = new CSGO();

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]


// Attach to CSGO
bool CSGO::Attach()
{
	m_Config.Init("settings.ini");
	[add_junk 1 3 /]
	return (m_Mem.Attach("csgo.exe"));
}

// Detach from CSGO
void CSGO::Detach()
{
	m_Mem.Detach();
	[add_junk 1 3 /]
}

void CSGO::ClearBases()
{
	[swap_lines]
	m_dwLocalBase = NULL;
	m_dwGlobalVarsBase = NULL;
	m_dwEntityBase = NULL;
	m_dwAnglePointer = NULL;
	m_dwStudioHdrPointer = NULL;
	ZeroMemory(&m_flViewMatrix, sizeof(m_flViewMatrix));
	m_iWindowWidth = m_iWindowHeight = NULL;
	[/swap_lines]

	[add_junk 1 5 /]
}

void CSGO::GrabStudioHdrPtr()
{
	[add_junk 2 5 /]
	if (m_dwLocalBase)
	{
		[add_junk 2 5 /]
		DWORD ptr = m_Mem.Read<DWORD>(m_dwLocalBase + m_Offsets.m_dwStudioHdrPtr);
		m_dwStudioHdrPointer = m_Mem.Read<DWORD>(ptr);
	}
	[add_junk 2 5 /]
}

// Load the base offsets
bool CSGO::LoadBases(bool bGetDLLs)
{
	if (!m_Mem.IsAttached())
		return false;

	if (bGetDLLs)
	{
		[add_junk 2 4 /]
		m_dwClientBase = m_Mem.GetModuleBase("client.dll");
		[add_junk 2 4 /]
		if (!m_dwClientBase)
			return false;
		[add_junk 2 4 /]
		m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");
		[add_junk 2 4 /]
		if (!m_dwEngineBase)
			return false;

	}

	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwLocalPlayer);
	[add_junk 2 5 /]
	GrabStudioHdrPtr();
	[add_junk 2 5 /]
	if (!m_dwGlobalVarsBase)
		m_dwGlobalVarsBase = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwGlobalVarOffset);
	[add_junk 2 5 /]
	if(!m_dwEntityBase)
		m_dwEntityBase = m_dwClientBase + m_Offsets.m_dwEntityList;
	[add_junk 2 5 /]
	if(!m_dwAnglePointer)
		m_dwAnglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 2 5 /]
	for (int i = 0; i < 16; i++)
		m_flViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + m_Offsets.m_dwViewMatrix + (4 * i));

	RECT rect;
	[add_junk 2 5 /]
	GetClientRect(Utils::GetGameWindow(), &rect);
	[swap_lines]
	m_iWindowWidth = (int)(rect.right - rect.left);
	m_iWindowHeight = (int)(rect.bottom - rect.top);
	[/swap_lines]

	return true;
}

// Update Tick
void CSGO::Update()
{
	if (!m_Mem.IsAttached())
		return;
	
	m_Me.Update(m_dwLocalBase);

	for (int i = 1; i < 64; i++)
	{
		[add_junk 1 3 /]

		DWORD entBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));

		if(!entBase)
			m_Players[i].Clear();

		[add_junk 2 5 /]

		m_Players[i].Update(entBase);
	}
}

// Are we in game?
bool CSGO::IsInGame()
{
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 3 /]
	return (m_Mem.Read<int>(clientState + m_Offsets.m_dwSignOnState) == SOS_Full);
}

bool CSGO::IsChangingLevel()
{
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 3 /]
	return (m_Mem.Read<int>(clientState + m_Offsets.m_dwSignOnState) == SOS_New);
}

bool CSGO::IsPrespawned()
{
	[add_junk 1 3 /]
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	return (m_Mem.Read<int>(clientState + m_Offsets.m_dwSignOnState) == SOS_Prespawn);
}

// What map are we currently on?
std::string CSGO::GetMapName()
{
	char mapName[64];
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	[add_junk 1 3 /]
	m_Mem.Read(clientState + m_Offsets.m_dwMapName, &mapName, sizeof(mapName));

	std::string map(mapName);

	[add_junk 1 3 /]

	if (map.empty())
		return "Invalid Map Name";
	
	return map;
}

// Get our game directory path
std::string CSGO::GetGameDirectory()
{
	char dir[255];
	[add_junk 1 3 /]
	m_Mem.Read(m_Offsets.m_dwGameDirectory, &dir, sizeof(dir));

	return std::string(dir);
}

[enc_string_disable /]
[junk_disable /]