// Main.cpp - The base of the project

#include "stdafx.h"

#include "Utils.h"
#include "Memory.h"
#include "CSGO.h"

#include "Triggerbot.h"
#include "RCS.h"

#include "Hitboxes.h"

#include "BSP.h"
#include "BSPHandler.h"

#include <time.h>
// Memory Leak Detection
#if _DEBUG
#include <vld.h>
#endif

#include "Decrypt.h"

// Defines
#define VERSION_MAJOR 2
#define VERSION_MINOR 5
char* programPath;
std::string currentMap;

[enc_string_enable /]
[junk_enable /]

// Prototypes
void ActivateAllThreads();
void DeactivateAllThreads();
void LaunchThreads();
void UpdateTick();
void Init();
void Loop();
void Cleanup();


// Activate all our threads
void ActivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = false;
	[/swap_lines]
}

// Deactivate all our threads
void DeactivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = true;
	[/swap_lines]

	[add_junk 1 5 /]
}

void LaunchThreads()
{
	std::thread threadUpdateTick(UpdateTick);
	[add_junk 1 5 /]
	threadUpdateTick.detach();
	LOGD << "Daemon thread UpdateTick launched.";
	[add_junk 1 5 /]
	std::thread threadBSPHandler(BSPHandler);
	[add_junk 1 5 /]
	threadBSPHandler.detach();
	LOGD << "Daemon thread BSPHandler launched.";
	[add_junk 1 5 /]
	std::thread threadTriggerbot(&Triggerbot::Start, Triggerbot());
	threadTriggerbot.detach();
	[add_junk 1 5 /]
	LOGD << "Daemon thread Triggerbot launched.";
	std::thread threadRCS(&RCS::Start, RCS());
	[add_junk 1 5 /]
	threadRCS.detach();
	LOGD << "Daemon thread RCS launched.";
	[add_junk 1 5 /]
}

// Update our entities
void UpdateTick()
{
	LOGD << "UpdateTick thread started!";
	[add_junk 1 5 /]

	while (true)
	{
		[add_junk 1 4 /]
		if (pCSGO == nullptr)
		{
			LOGD << "pCSGO was nullptr! Ending thread!";
			[add_junk 1 4 /]
			return;
		}
		else if (pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate)
		{
			[add_junk 1 4 /]
			LOGD << "Update bool was true, Ending thread!";
			return;
		}

		if (GetAsyncKeyState(VK_END))
			pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;

		currentMap = pCSGO->GetMapName();
		[add_junk 1 4 /]

		if (!strcmp(currentMap.c_str(), "Invalid Map Name"))
		{
			[add_junk 1 4 /]
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			continue;
		}

		if (strcmp(currentMap.c_str(), pBSP->GetMapName().c_str()))
		{
			pCSGO->ClearBases();
			//pHitboxes->ClearHitboxes();
			pCSGO->LoadBases(false);
			[add_junk 1 4 /]
		}

		if (!pCSGO->IsInGame())
		{
			[add_junk 1 4 /]
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 4 /]
			continue;
		}

		pCSGO->LoadBases(false);
		[add_junk 1 4 /]
		std::string newSettingsHash = pCSGO->m_Config.GetHash();

		if (strcmp(newSettingsHash.c_str(), pCSGO->m_Config.m_szHash.c_str()))
		{
			LOGD << "Hashes in settings.ini was found to be changed! Old Hash: " << pCSGO->m_Config.m_szHash.c_str() << " | New Hash: " << newSettingsHash.c_str();

			if (pCSGO->m_Config.LoadConfig())
			{
				[swap_lines]
				LOGD << "The new settings.ini successfully loaded and changed";
				Utils::PrintLine("> .ini file has been changed. Automatically loaded new settings!\n");
				[/swap_lines]
				[add_junk 1 4 /]
			}
			else
			{
				LOGE << "The new settings.ini FAILED to be loaded and changed";
				[add_junk 1 4 /]
				Utils::PrintLine("> .ini file could not be opened/changed. Failed to load new settings.\n");
			}
		}

		pCSGO->Update();
		[add_junk 1 4 /]
		std::this_thread::sleep_for(std::chrono::milliseconds(1));

	}

	[add_junk 1 4 /]
}

// Initialize the memory and stuff
void Init()
{
	// Logger
	plog::init(plog::debug, "log.txt");

	LOGD << "======= START =======";
	[add_junk 1 5 /]
	LOGD << "Zerowrite Initiated.";

	srand((unsigned int)time(NULL));
	rand();

	Utils::SetUpMinidump();
	Utils::DisableQuickEdit();
	[add_junk 1 5 /]
	Utils::SetRandomWindowTitle(20);
	Utils::AllowDebugging();

	std::string header =
		std::string("                                                                        $$               \n") +
		std::string(" /$$$$$$$$  /$$$$$$   /$$$$$$   /$$$$$$  /$$  /$$  /$$  /$$$$$$  /$$ /$$$$$$    /$$$$$$  \n") +
		std::string("|____ /$$/ /$$__  $$ /$$__  $$ /$$__  $$| $$ | $$ | $$ /$$__  $$| $$|_  $$_/   /$$__  $$ \n") +
		std::string("   /$$$$/ | $$$$$$$$| $$  \\__/| $$  \\ $$| $$ | $$ | $$| $$  \\__/| $$  | $$    | $$$$$$$$ \n") +
		std::string("  /$$__/  | $$_____/| $$      | $$  | $$| $$ | $$ | $$| $$      | $$  | $$ /$$| $$_____/ \n") +
		std::string(" /$$$$$$$$|  $$$$$$$| $$      |  $$$$$$/|  $$$$$/$$$$/| $$      | $$  |  $$$$/|  $$$$$$$ \n") +
		std::string("|________/ \\_______/|__/       \\______/  \\_____/\\___/ |__/      |__/   \\___/   \\_______/ \n");

	Utils::PrintLine(header);
	Utils::PrintLine("> Current Version: " + std::to_string(VERSION_MAJOR) + "." + std::to_string(VERSION_MINOR) + " - Build " + std::string(__DATE__) + " " + std::string(__TIME__));

#if _DEBUG
	Utils::PrintLine("> Developer Version~ \n");
#endif

	Utils::PrintLine("> Waiting for CSGO. If you haven't started CSGO yet, please do so.");

	while (!pCSGO->Attach())
		Sleep(100);

	LOGD << "CSGO has been loaded | ProcessID: " << pCSGO->m_Mem.GetProcessID();

	Utils::PrintLine("> CSGO has been loaded!\n");

	Utils::PrintLine("> Loading your config from settings.ini..");

	pCSGO->m_Config.Init(".\\settings.ini");

	if (pCSGO->m_Config.LoadConfig())
	{
		Utils::PrintLine("> settings.ini was successfully loaded!");
		[add_junk 1 5 /]
		LOGD << "settings.ini was successfully loaded!";
	}
	else
	{
		Utils::PrintLine("> settings.ini FAILED to load!");
		[add_junk 1 5 /]
		LOGE << "settings.ini FAILED to load!";
	}

	Utils::PrintLine("\n> Waiting until CSGO loads it's .dll's. This will only take a minute.");

	[add_junk 1 5 /]

	while (!pCSGO->m_Mem.GetModuleBase("client.dll"))
		Sleep(100);

	LOGD << "client.dll was detected | Base: " << std::hex << pCSGO->m_Mem.GetModuleBase("client.dll") << " Size: " << pCSGO->m_Mem.GetModuleSize("client.dll");

	while (!pCSGO->m_Mem.GetModuleBase("engine.dll"))
		Sleep(100);

	LOGD << "engine.dll was detected | Base: " << std::hex << pCSGO->m_Mem.GetModuleBase("engine.dll") << " Size: " << pCSGO->m_Mem.GetModuleSize("engine.dll");

	Utils::PrintLine("\n> CSGO has loaded their dlls!");
	[add_junk 1 5 /]
	Utils::PrintLine("\n> Scanning signatures and setting up netvars..\n");

	pCSGO->m_Offsets.Init();
	pCSGO->LoadBases(true);
	pCSGO->m_Offsets.LoadNetvars();

	LOGD << "Bases and Netvars were loaded and populated!";

	Utils::PrintLine("\n> Loading Cheat Threads..\n");

	ActivateAllThreads();

	LOGD << "Starting threads..";

	LaunchThreads();

	Utils::PrintLine("\n> Cheat Loaded..\n");

	Beep(0x500, 100);
	[add_junk 1 5 /]
}

// Our loop for checking key presses and handling toggles
void Loop()
{
	while (!GetAsyncKeyState(VK_END))
	{
		if (!Utils::DoesCSGOExist())
		{
			LOGE << "CSGO doesn't exist anymore. Exiting main loop!";
			[add_junk 1 5 /]
			break;
		}

		if (GetAsyncKeyState(pCSGO->m_Config.m_TriggerSettings.m_nToggleKey) & 1)
		{
			pCSGO->m_Config.m_TriggerSettings.m_bActive = !pCSGO->m_Config.m_TriggerSettings.m_bActive;
			[add_junk 1 5 /]
			LOGD << "Triggerbot was toggled " << ((pCSGO->m_Config.m_TriggerSettings.m_bActive) ? "ON" : "OFF");

			MessageBeep((pCSGO->m_Config.m_TriggerSettings.m_bActive) ? MB_ICONINFORMATION : MB_ICONERROR);
			[add_junk 1 5 /]
			Sleep(5);
		}

		Sleep(1);
	}

	LOGD << "END key detected, exiting main loop!";
	[add_junk 1 5 /]
}

// Cleanup memory to prevent memory leaks
void Cleanup()
{
	DeactivateAllThreads();

	LOGD << "All threads were deactivated.";
	[add_junk 1 5 /]

	Utils::PrintLine("> Ending threads...");

	pCSGO->m_Config.SaveConfig();
	LOGD << "settings.ini was saved";

	delete pHitboxes;
	pHitboxes = nullptr;

	delete pBSP;
	pBSP = nullptr;

	[add_junk 1 5 /]

	delete pRCS;
	pRCS = nullptr;

	[add_junk 1 5 /]

	delete pCSGO;
	pCSGO = nullptr;

	LOGD << "Self-deleting executable..";
	Utils::DeleteSelf(programPath);
}

// Main.
int main(int argc, char* argv[])
{
	if (argc > 0)
		programPath = argv[0];

	Init();

	[add_junk 1 5 /]

	Loop();

	Sleep(1);

	Cleanup();

	LOGD << "Cleanup has finished, exiting program";

	Beep(0x400, 600);
	[add_junk 1 5 /]

	LOGD << "======= END =======";
	[add_junk 1 5 /]

	return 0;
}

[enc_string_disable /]
[junk_disable /]