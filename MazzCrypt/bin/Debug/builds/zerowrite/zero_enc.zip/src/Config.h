// Config.h - Our config settings
#pragma once

#include "stdafx.h"

struct TriggerWeaponSettings
{
	std::vector<int> m_hitboxes;
	int m_nDelayBefore;
	int m_nDelayAfter;
	float m_fRCSScale;
};

struct TriggerSettings
{

public:
	// Is this feature on
	bool m_bActive;

	// Only shoot if we're scoped
	bool m_bSniperMode;

	// Only shoot while not moving
	bool m_bMoveCheck;

	// Shoot until the character is dead from recurring hit-tests
	bool m_bSprayUntilDeadMode;

	// Adjust waittimes for the revolver
	bool m_bRevolverMode;

	// Do we use a knifebot?
	bool m_bKnifebot;

	// Shoot after the target is dead for a bit
	bool m_bAfterburst;

	// Only shoot when they're fully spawned
	bool m_bDeathmatch;

	// Only shoot if we're not being spectated
	bool m_bAntiSpectate;

	// Only shoot when they're not jumping
	bool m_bAntiJump;

	// Inverted Mouse?
	bool m_bInvertMouse;

	// Only shoot if we're not flashed
	bool m_bAntiFlash;

	// Key to use to hold down
	int m_nKey;

	// Key to toggle it
	int m_nToggleKey;

	// Are we holding the key or is it always checking
	bool m_bKeyHeld;

	// 0 - Incross | 1 - Hitbox/Traceray [faceit]
	int m_nMethod;
	
	// 0 - Enemies | 1 - Teammates | 2 - Everyone
	int m_nTargetType;

	// Delay in ms before holding down the mouse
	int m_nDelayBefore;

	// Delay in ms before holding up the mouse
	int m_nDelayAfter;

	// Maximum FOV the target has be in order to fire
	float m_fFOV;

	// Minimum speed we need to be before shooting
	float m_fMinSpeed;

	// Weapon Settings

	// Pistols
	TriggerWeaponSettings m_tGlock;
	TriggerWeaponSettings m_tP2K;
	TriggerWeaponSettings m_tUSP;
	TriggerWeaponSettings m_tP250;
	TriggerWeaponSettings m_tFiveSeven;
	TriggerWeaponSettings m_tDeagle;
	TriggerWeaponSettings m_tDuelies;
	TriggerWeaponSettings m_tTec9;
	TriggerWeaponSettings m_tCZ75;
	TriggerWeaponSettings m_tRevolver;

	// Shotguns
	TriggerWeaponSettings m_tNova;
	TriggerWeaponSettings m_tXM1014;
	TriggerWeaponSettings m_tSawedOff;
	TriggerWeaponSettings m_tMag7;

	// SMGs
	TriggerWeaponSettings m_tMAC10;
	TriggerWeaponSettings m_tMP7;
	TriggerWeaponSettings m_tMP9;
	TriggerWeaponSettings m_tUMP45;
	TriggerWeaponSettings m_tBizon;
	TriggerWeaponSettings m_tP90;

	// Rifles
	TriggerWeaponSettings m_tGalil;
	TriggerWeaponSettings m_tAK47;
	TriggerWeaponSettings m_tM4A4;
	TriggerWeaponSettings m_tM4A1S;
	TriggerWeaponSettings m_tSG553;
	TriggerWeaponSettings m_tAUG;
	TriggerWeaponSettings m_tFAMAS;

	// Snipers
	TriggerWeaponSettings m_tAWP;
	TriggerWeaponSettings m_tSCAR20;
	TriggerWeaponSettings m_tScout;
	TriggerWeaponSettings m_tG3SG1;

	// LMGs
	TriggerWeaponSettings m_tM249;
	TriggerWeaponSettings m_tNegev;

};

struct ThreadHandling
{
public:

	bool m_bStopUpdate;
	bool m_bStopTriggerbot;
	bool m_bStopBSPHandler;
	bool m_bStopRCS;
};

class Config
{
public:

	Config() = default;
	~Config() = default;

	// Set the config file
	void Init(std::string szConfigName);

	// Generate the MD5 hash of the file
	std::string GetHash();

	// Load the config
	bool LoadConfig();

	// Save the config
	bool SaveConfig();

	// Helper functions for PrivateProfile functions
	// [in] - section - Name of the section
	// [in] - option - Name of the option in that set section

	// [section]
	// option = value

	int GetInt(char* section, char* option);
	float GetFloat(char* section, char* option);
	std::string GetString(char* section, char* option);
	bool GetBool(char* section, char* option);
	std::vector<int> GetCommaSeperatedInts(char* section, char* option);

	void SetInt(char* section, char* option, int nValue);
	void SetFloat(char* section, char* option, float fValue);
	void SetString(char* section, char* option, std::string szValue);
	void SetBool(char* section, char* option, bool bValue);
	void SetCommaSeperatedInts(char* section, char* option, std::vector<int> vValue);

public:

	std::string m_szHash;

	TriggerSettings m_TriggerSettings;
	ThreadHandling m_ThreadSettings;

private:

	std::string m_szConfigFile;
};