// Netvars.h - Class to hold netvars and scanning netvars
#pragma once

#include "stdafx.h"
#include "CSGO.h"

namespace Netvars
{
	class CRecvTable
	{
	public:

		class CRecvProp
		{
		public:
			const char* GetVarName()
			{
				DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this);
				char varName[128];
				pCSGO->m_Mem.Read(offset, varName, 128);
				return varName;
			}

			int GetOffset()
			{
				return pCSGO->m_Mem.Read<int>((DWORD)this + 0x2C);
			}
			CRecvTable* GetDataTable()
			{
				return pCSGO->m_Mem.Read<CRecvTable*>((DWORD)this + 0x28);
			}

		};

		const char* GetTableName()
		{
			DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this + 0xC);
			char tableName[128];
			pCSGO->m_Mem.Read(offset, tableName, 128);
			return tableName;
		}


		int GetMaxProp()
		{
			return pCSGO->m_Mem.Read< int >((DWORD)this + 0x4);
		}

		CRecvProp* GetProperty(int iIndex)
		{
			return (CRecvProp*)(pCSGO->m_Mem.Read<DWORD>((DWORD)this) + 0x3C * iIndex);
		}

	};

	class ClientClass
	{
	public:
		const char* GetNetworkName()
		{
			DWORD offset = pCSGO->m_Mem.Read<DWORD>((DWORD)this + 0x8);
			char networkName[128];
			pCSGO->m_Mem.Read(offset, networkName, 128);
			return networkName;
		}

		ClientClass* GetNextClass()
		{
			return pCSGO->m_Mem.Read< ClientClass* >((DWORD)this + 0x10);
		}
		CRecvTable* GetTable()
		{
			return pCSGO->m_Mem.Read< CRecvTable* >((DWORD)this + 0xC);
		}
	};

	DWORD GetNetVar(const char* szClassName, const char* szNetVar);
}
