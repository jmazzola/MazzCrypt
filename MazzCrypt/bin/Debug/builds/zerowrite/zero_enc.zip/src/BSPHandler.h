// BSPHandler.h - Handle the BSP check in the tick
#pragma once

#include "stdafx.h"
#include "CSGO.h"

#include "Decrypt.h"

[enc_string_enable /]

void BSPHandler()
{
	LOGD << "BSPHandler thread started!";

	while (true)
	{
		if (pCSGO == nullptr)
		{
			LOGD << "pCSGO was nullptr! Ending thread!";
			return;
		}
		else if (pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler)
		{
			LOGD << "Handler bool was true, Ending thread!";
			return;
		}

		if (GetAsyncKeyState(VK_END))
			pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = true;

		if (!pCSGO->IsInGame())
		{
			std::this_thread::sleep_for(std::chrono::seconds(10));
			continue;
		}

		if (pBSP->GetMapName().empty() || strcmp(pBSP->GetMapName().c_str(), pCSGO->GetMapName().c_str()))
		{
			LOGD << "Different map detected! Old Map: " << pBSP->GetMapName().c_str() << " | New Map: " << pCSGO->GetMapName().c_str();
			pBSP->Unload();
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
			pBSP->Load(pCSGO->GetGameDirectory(), pCSGO->GetMapName());
			LOGD << "BSP has loaded with " << pBSP->GetMapName().c_str() << " successfully!";
		}

#if _DEBUG
		if(!pBSP->IsNull())
			pBSP->DisplayInfo();
#endif

		std::this_thread::sleep_for(std::chrono::seconds(10));
	}
}

[enc_string_disable /]