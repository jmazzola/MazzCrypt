// Player.h - A CSGO Player and their information
#pragma once

#include "stdafx.h"
#include "Math.h"
#include "Vector.h"
#include "Matrix3x4.h"
#include "Enums.h"

#include "Hitboxes.h"

class player_info_t
{
public:

	char			name[32];
	int				userID;
	char			guid[33];
	__int32			friendsID;
	char			friendsName[32];
	bool			fakeplayer;
	bool			ishltv;
	unsigned long	customFiles[4];
	unsigned char	filesDownloaded;
	char			Pad[200];
};


class Player
{
public: 

	Player() = default;
	~Player() = default;

	// Get the ClassID
	int GetClassID();

	// Get the Class Name
#undef GetClassName
	char* GetClassName();

	// Update player stats per tick
	void Update(DWORD dwBaseAddr);

	// Get Bone Position
	Vector GetBonePosition(int nBone);

	// Get Bone Matrix
	// [in] - nBone - Bone for what bone matrix to return
	Matrix3x4 GetBoneMatrix(int nBone) const;

	// Get Weapon Type
	EWeaponType GetWeaponType();

	// Get Enemy Team
	int GetEnemyTeam();

	// Are we being spectated?
	bool IsBeingSpectated();

	// Get eye position/forward vector
	Vector GetEyePos() const;

	// Get Origin
	Vector GetOrigin() const;

	// Get Velocity
	Vector GetVelocity() const;

	// Get ViewAngles
	Vector GetViewAngles() const;

	// Get PunchAngles
	Vector2D GetPunchAngles() const;

	// Get Name
	std::string GetName() const;

	// Get Model Name
	std::string GetModelName() const;

	// Get Hitboxes
	std::vector<mstudiobbox_t> GetHitboxes() const;

	// Get Distance
	float GetDistanceFromMe() const;

	// Get ID
	int GetID() const;

	// Get Flags
	int GetFlags() const;

	// Get Team
	int GetTeam() const;

	// Get Health 
	int GetHealth() const;

	// Get WeaponID
	int GetWeaponID() const;
	
	// Get Ammo
	int GetAmmo() const;

	// Get Shots Fired
	int GetShotsFired() const;

	// Get MoveType
	int GetMoveType() const;

	// Get Alive
	bool IsAlive() const;

	// Get Dormancy
	bool IsDormant() const;

	// Are we reloading?
	bool IsReloading() const;

	// Are we shooting?
	bool IsShooting() const;

	// Are we scoped?
	bool IsScoped() const;

	// Are we spawned in?
	bool IsSpawned() const;

	// Are we flashed?
	bool IsFlashed() const;

	// Are we moving?
	bool IsMoving() const;

	// Is this a valid player?
	bool Valid();

	// Is this player visible?
	// [in] - nBone - Bone to check is visible
	bool IsVisible(int nBone);


public:

	DWORD m_dwBaseAddr;

	float m_fDistanceFromMe;

	Matrix3x4 m_matBone[128];

	Vector m_vecOrigin;
	Vector m_vecViewAngles;
	Vector m_vecVelocity;
	Vector m_vecViewOffset;
	Vector m_vecEyePos;

	Vector2D m_vecPunchAngles;
	Vector2D m_vecOldPunchAngles;

	player_info_t m_tPlayerInfo;

	std::vector<mstudiobbox_t> m_vHitboxes;

	char m_szModelName[0x80];

	int m_nID;
	int m_nSpecTarget;

	int m_nFlags;
	int m_nTeam;
	int m_nHealth;
	int m_nWeaponID;
	int m_nAmmo;
	int m_nShotsFired;

	int m_nMoveType;

	bool m_bAlive;
	bool m_bReloading;
	bool m_bShooting;
	bool m_bDormant;
	bool m_bScoped;
	bool m_bSpawned;
	bool m_bSpectated;
	bool m_bFlashed;
	bool m_bMoving;
};
