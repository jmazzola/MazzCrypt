#include "BSP.h"
#include "CSGO.h"
#include "Math.h"

#include "Decrypt.h"

[enc_string_enable /]

BSP* pBSP = new BSP();

BSP::~BSP()
{
	Unload();
}

bool BSP::Load(std::string& szPathName, std::string& szMapName)
{
	m_szMapName = szMapName;
	m_szPathName = szPathName;

	std::string fPath(m_szPathName);
	fPath += char(0x5C);
	fPath += "csgo";
	fPath += char(0x5C);
	fPath += "maps";
	fPath += char(0x5C);
	fPath += m_szMapName + ".bsp";

	HANDLE hFile = CreateFile(fPath.c_str(), GENERIC_READ, NULL, NULL, OPEN_ALWAYS, NULL, NULL);

	if (hFile == NULL)
		return false;

	DWORD dwSize = GetFileSize(hFile, NULL);

	if (!dwSize)
	{
		CloseHandle(hFile);
		return false;
	}

	m_pbData = new BYTE[dwSize];

	DWORD dwRead = NULL;
	if (!ReadFile(hFile, m_pbData, dwSize, &dwRead, NULL))
	{
		CloseHandle(hFile);

		delete[] m_pbData;
		m_pbData = nullptr;

		return false;
	}

	CloseHandle(hFile);

	m_pHeader = (dheader_t*)m_pbData;

	m_pNode = (dnode_t*)(m_pbData + m_pHeader->lumps[LUMP_NODES].fileofs);
	m_pPlane = (dplane_t*)(m_pbData + m_pHeader->lumps[LUMP_PLANES].fileofs);
	m_pLeaf = (dleaf_t*)(m_pbData + m_pHeader->lumps[LUMP_LEAVES].fileofs);

	return true;
}

void BSP::Unload()
{
	if (m_pPlane)
	{
		m_pPlane = nullptr;
	}

	if (m_pNode)
	{
		m_pNode = nullptr;
	}

	if (m_pLeaf)
	{
		m_pLeaf = nullptr;
	}

	if (m_pHeader)
	{
		m_pHeader = nullptr;
	}

	if (m_pbData)
	{
		delete[] m_pbData;
		m_pbData = nullptr;
	}
}

bool BSP::IsNull()
{
	if (m_pbData == nullptr)
		return true;

	if (m_szMapName.empty())
		return true;

	if (m_szPathName.empty())
		return true;

	if (m_pHeader == nullptr)
		return true;

	if (m_pPlane == nullptr)
		return true;

	if (m_pNode == nullptr)
		return true;

	if (m_pLeaf == nullptr)
		return true;

	return false;
}

void BSP::DisplayInfo()
{
	if (!pCSGO->IsInGame())
		return;

	printf("Map Version: %d | Revision %d\n", m_pHeader->version, m_pHeader->mapRevision);
	printf("Map Name: %s\n", m_szMapName.c_str());
}

dleaf_t * BSP::GetLeafFromPoint(Vector point)
{
	int nodenum = 0;
	dnode_t* pNode;
	dplane_t* pPlane;

	float dist = 0.0f;

	while (nodenum >= 0)
	{
		if (&m_pNode == NULL || &m_pPlane == NULL)
			return nullptr;

		pNode = &m_pNode[nodenum];
		pPlane = &m_pPlane[pNode->planenum];

		dist = point.DotProduct(pPlane->normal) - pPlane->dist;

		(dist > 0.0f) ?	nodenum = pNode->children[0] : 	nodenum = pNode->children[1];
	}

	return &m_pLeaf[-nodenum - 1];
}

bool BSP::IsVisible(Vector& vStart, Vector& vEnd)
{
	if (IsNull())
	{
		LOGE << "The BSP map information wasn't loaded or was NULL!";
		return false;
	}

	Vector dir = vEnd - vStart;
	Vector point = vStart;

	int steps = (int)Math::FastSQRT(pow(dir.x, 2) + pow(dir.y, 2) + pow(dir.z, 2));

	// fuck with this too
	if (steps > 4000)
		return false;

	dir /= (float)steps;

	dleaf_t* pLeaf = nullptr;

	while (steps)
	{
		point += dir;
		pLeaf = GetLeafFromPoint(point);

		// fuck with this for stuff
		if (pLeaf->contents & CONTENTS_SOLID)
			return false;

		--steps;
	}

	return true;
}

std::string BSP::GetMapName() const
{
	return m_szMapName;
}

[enc_string_disable /]