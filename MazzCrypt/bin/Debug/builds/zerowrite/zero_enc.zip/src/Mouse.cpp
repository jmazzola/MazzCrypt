#include "Mouse.h"

namespace Mouse
{
	void Move(float x, float y)
	{
		INPUT input = { 0 };
		
		input.type = INPUT_MOUSE;
		input.mi.dx = (LONG)x;
		input.mi.dy = (LONG)y;
		input.mi.dwFlags = MOUSEEVENTF_MOVE;
		
		SendInput(1, &input, sizeof(INPUT));
	}

	void Click(int type)
	{
		INPUT input = { 0 };

		input.type = INPUT_MOUSE;
		input.mi.dwFlags = type;

		SendInput(1, &input, sizeof(INPUT));
	}
}