// Ray.h - Class for rays and raytracing against AABB/OBBs
#pragma once

#include "stdafx.h"
#include "Vector.h"
#include "Matrix3x4.h"

class Ray
{
public:

	// Ctor of the ray to setup for collision detection
	// [in] - vOrigin - Set the origin
	// [in] - vDirection - Set the direction the ray is facing
	Ray(Vector vOrigin, Vector vDirection)
	{
		m_vOrigin = vOrigin;
		m_vDirection = vDirection;

		m_vInverseDir.x = (1.0f / m_vDirection.x);
		m_vInverseDir.y = (1.0f / m_vDirection.y);
		m_vInverseDir.z = (1.0f / m_vDirection.z);
	}


	// Does this ray intersect with a bounding box?
	// [in] - vOrigin - Origin of the ray
	// [in] - vDirection - Direction of the ray
	// [in] - vAABB_Min - Minimum of the AABB to test against
	// [in] - vAABB_Max - Maximum of the AABB to test against
	bool IntersectsWithAABB(const Vector& vOrigin, const Vector& vDirection, Vector& vAABB_Min, Vector& vAABB_Max)
	{
		float txMin, txMax;
		float tyMin, tyMax;
		float tzMin, tzMax;

		if (vDirection.x >= 0.0f)
		{
			txMin = (vAABB_Min.x - vOrigin.x) / vDirection.x;
			txMax = (vAABB_Max.x - vOrigin.x) / vDirection.x;
		}
		else
		{
			txMin = (vAABB_Max.x - vOrigin.x) / vDirection.x;
			txMax = (vAABB_Min.x - vOrigin.x) / vDirection.x;
		}

		if (vDirection.y >= 0.0f)
		{
			tyMin = (vAABB_Min.y - vOrigin.y) / vDirection.y;
			tyMax = (vAABB_Max.y - vOrigin.y) / vDirection.y;
		}
		else
		{
			tyMin = (vAABB_Max.y - vOrigin.y) / vDirection.y;
			tyMax = (vAABB_Min.y - vOrigin.y) / vDirection.y;
		}

		if (txMin > tyMax || tyMin > txMax)
			return false;

		if (tyMin > txMin)
			txMin = tyMin;

		if (tyMax < txMax)
			txMax = tyMax;

		if (vDirection.z >= 0.0f)
		{
			tzMin = (vAABB_Min.z - vOrigin.z) / vDirection.z;
			tzMax = (vAABB_Max.z - vOrigin.z) / vDirection.z;
		}
		else
		{
			tzMin = (vAABB_Max.z - vOrigin.z) / vDirection.z;
			tzMax = (vAABB_Min.z - vOrigin.z) / vDirection.z;
		}

		if (txMin > tzMax || tzMin > txMax)
			return false;

		if (txMin < 0 || txMax < 0)
			return false;

		return true;
	}

	// Does this ray intersect with an oriented bounding box?
	// [in] - mat - Matrix to use for rotation
	// [in] - vAABB_Min - Minimum of the AABB to test against
	// [in] - vAABB_Max - Maximum of the AABB to test against
	// [out] - fDist - Distance of the intersection
	bool IntersectsWithOBB(Matrix3x4 mat, Vector vAABB_Min, Vector vAABB_Max, float& fDist)
	{
		Vector transRay, dirRay;

		Math::VectorITransform(m_vOrigin, mat, transRay);
		Math::VectorIRotate(m_vDirection, mat, dirRay);

		return IntersectsWithAABB(transRay, dirRay, vAABB_Min, vAABB_Max);
	}
private:

	// Origin of the ray
	Vector m_vOrigin;

	// Direction of the ray
	Vector m_vDirection;

	// Inverse Direction of the ray
	Vector m_vInverseDir;
};
