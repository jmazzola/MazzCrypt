// Memory.h - Handle all memory accessing/reading and keep a process for neatness to the game's core
#pragma once

#include "stdafx.h"
#include <TlHelp32.h>

[junk_enable /]

class Memory
{
public:

	Memory() = default;
	~Memory() = default;

	// Attach to the process
	[swap_lines]
	bool Attach(const char* szProcName, DWORD dwRights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* szModName);
	DWORD GetModuleSize(const char* szModName);
	HANDLE GetHandle() const;
	bool IsAttached() const;
	DWORD GetProcessID() const;
	[/swap_lines]

	// Read Memory
	// [in] - dwAddr - The address we're reading
	template<typename T>
	T Read(DWORD dwAddr)
	{
		T mem;
		ReadProcessMemory(m_hProcess, (LPVOID)dwAddr, &mem, sizeof(T), NULL);

		return mem;
	}

	// Read Custom Memory
	// [in] - dwAddr - The address we're reading
	// [out] - buff - The data we want
	// [in] - bytesToRead - how many bytes to read
	void Read(DWORD addr, LPVOID buff, size_t bytesToRead)
	{
		ReadProcessMemory(m_hProcess, (LPCVOID)addr, buff, bytesToRead, NULL);
	}

	// Signature scanning - Compare bytes to a mask
	[swap_lines]
	bool DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask);
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask);
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern);
	[/swap_lines]


private:

	// Are we attached to the process?

	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers 1 7 /]

};

[junk_disable /]