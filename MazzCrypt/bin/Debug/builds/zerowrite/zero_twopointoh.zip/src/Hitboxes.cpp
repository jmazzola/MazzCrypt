#include "Hitboxes.h"
#include "CSGO.h"

Hitboxes* pHitboxes = new Hitboxes();

[junk_enable /]

mstudiobbox_t::mstudiobbox_t()
{
	[swap_lines]
	m_iBone = m_iGroup = 0;
	m_vecBBMax = m_vecBBMin = Vector(0, 0, 0);
	m_iHitboxNameIndex = -1;
	m_flRadius = -1.0f;
	[/swap_lines]

	[add_junk 1 3 /]
}


bool Hitboxes::LoadModelHitboxes(const std::string & strModelName, DWORD pStudioHdr)
{
	if (strModelName.empty() || !pStudioHdr)
		return false;

	[add_junk 1 3 /]

	for (auto& map_data : m_mapModelHitboxes)
	{
		[add_junk 1 3 /]

		if (!strModelName.compare(map_data.first))
			return true;
	}

	// studiohdr_t + 0xB0 = int	hitboxsetindex;
	DWORD iHitBoxSetIndex = pCSGO->m_Mem.Read<DWORD>(pStudioHdr + 0xB0);
	[add_junk 1 3 /]
	DWORD pStudioHitboxSet = pStudioHdr + iHitBoxSetIndex;

	// mstudiohitboxset_t {
	// int	sznameindex; // 0x00
	// int	numhitboxes; // 0x04
	// int  hitboxindex; // 0x08
	DWORD iNumHitboxes = pCSGO->m_Mem.Read<DWORD>(pStudioHitboxSet + 0x4);
	[add_junk 1 3 /]
	DWORD iHitboxIdx = pCSGO->m_Mem.Read<DWORD>(pStudioHitboxSet + 0x8);

	std::vector<mstudiobbox_t> vStudioHitboxes;
	vStudioHitboxes.reserve(iNumHitboxes);

	for (DWORD i = 0; i < iNumHitboxes; i++)
	{
		mstudiobbox_t studioHitbox;
		[add_junk 1 3 /]
		studioHitbox = pCSGO->m_Mem.Read<mstudiobbox_t>(0x44 * i + iHitboxIdx + pStudioHitboxSet);

		if (studioHitbox.m_flRadius != -1.0f)
		{
			studioHitbox.m_vecBBMin -= studioHitbox.m_flRadius;
			[add_junk 1 3 /]
			studioHitbox.m_vecBBMax += studioHitbox.m_flRadius;
		}

		vStudioHitboxes.push_back(studioHitbox);
	}

	if (vStudioHitboxes.empty())
		return false;

	m_mapModelHitboxes.insert(std::pair< std::string, std::vector< mstudiobbox_t > >(strModelName, vStudioHitboxes));

	return true;
}

std::vector<mstudiobbox_t> Hitboxes::GetModelHitboxes(const std::string & strModelName) const
{
	std::lock_guard< std::mutex > lock(m_mutex);

	[add_junk 1 3 /]

	if (strModelName.empty())
		return {};

	for (auto& map_data : m_mapModelHitboxes)
	{
		if (!strModelName.compare(map_data.first))
			return map_data.second;
	}

	[add_junk 1 3 /]
	
	return{};
}

[junk_disable /]