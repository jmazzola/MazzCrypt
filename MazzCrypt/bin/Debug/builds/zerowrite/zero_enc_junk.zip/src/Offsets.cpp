#include "Offsets.h"
#include "CSGO.h"
#include "Netvars.h"

#if _DEBUG
#include "Utils.h"
#endif

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]


void Offsets::Init()
{
	LOGD << "Initializing Offsets | Signatures";

	[swap_lines]
	DWORD clientBase = pCSGO->m_Mem.GetModuleBase("client.dll");
	DWORD clientSize = pCSGO->m_Mem.GetModuleSize("client.dll");
	DWORD engineBase = pCSGO->m_Mem.GetModuleBase("engine.dll");
	DWORD engineSize = pCSGO->m_Mem.GetModuleSize("engine.dll");
	DWORD csgoBase = pCSGO->m_Mem.GetModuleBase("csgo.exe");
	DWORD csgoSize = pCSGO->m_Mem.GetModuleSize("csgo.exe");
	[/swap_lines]

	[add_junk 1 5 /]


	#pragma region Entity List

	DWORD entList = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 11, (BYTE*)"\x05\x00\x00\x00\x00\xC1\xE9\x00\x39\x48\x04");
	DWORD entListPtr = pCSGO->m_Mem.Read<DWORD>(entList + 0x1);
	[add_junk 1 5 /]
	BYTE entListPtr2 = pCSGO->m_Mem.Read<BYTE>(entList + 0x7);
	[add_junk 1 5 /]
	m_dwEntityList = (entListPtr + entListPtr2) - clientBase;

#if _DEBUG
	printf("> EntityList Found @ 0x%08X\n", m_dwEntityList);
	[add_junk 1 5 /]
#endif

	LOGD << "EntityList : " << std::hex << m_dwEntityList;

#pragma endregion

	#pragma region Local Player

	DWORD locPly = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 19, (BYTE*)"\x8D\x34\x85\x00\x00\x00\x00\x89\x15\x00\x00\x00\x00\x8B\x41\x08\x8B\x48\x00");
	DWORD locPlyPtr = pCSGO->m_Mem.Read<DWORD>(locPly + 0x3);
	[add_junk 1 5 /]
	BYTE locPlyPtr2 = pCSGO->m_Mem.Read<BYTE>(locPly + 0x12);
	m_dwLocalPlayer = (locPlyPtr + locPlyPtr2) - clientBase;

#if _DEBUG
	printf("> LocalPlayer Found @ 0x%08X\n", m_dwLocalPlayer);
	[add_junk 1 5 /]
#endif

	LOGD << "LocalPlayer : " << std::hex << m_dwLocalPlayer;

#pragma endregion

	#pragma region Engine Pointer
	DWORD engPtr = pCSGO->m_Mem.FindPattern(engineBase, engineSize, 37, (BYTE*)"\xF3\x0F\x5C\xC1\xF3\x0F\x10\x15\x00\x00\x00\x00\x0F\x2F\xD0\x76\x04\xF3\x0F\x58\xC1\xA1\x00\x00\x00\x00\xF3\x0F\x11\x80\x00\x00\x00\x00\xD9\x46\x04");
	m_dwEnginePtr = pCSGO->m_Mem.Read<DWORD>(engPtr + 0x16) - engineBase;
	[add_junk 1 5 /]
	m_dwViewAngles = pCSGO->m_Mem.Read<DWORD>(engPtr + 0x1E);

#if _DEBUG
	printf("> EnginePtr Found @ 0x%08X\n", m_dwEnginePtr);
	[add_junk 1 5 /]
	printf("> Viewangles Found @ 0x%08X\n", m_dwViewAngles);
#endif

	LOGD << "EnginePtr : " << std::hex << m_dwEnginePtr;
	[add_junk 1 5 /]
	LOGD << "Viewangles : " << std::hex << m_dwViewAngles;


#pragma endregion

	#pragma region Crosshair Index
	DWORD xhair = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 20, (BYTE*)"\x56\x57\x8B\xF9\xC7\x87\x00\x00\x00\x00\x00\x00\x00\x00\x8B\x0D\x00\x00\x00\x00");
	m_dwCrosshairIndex = pCSGO->m_Mem.Read<DWORD>(xhair + 0x6);
	[add_junk 1 5 /]

#if _DEBUG
	printf("> CrosshairIndex Found @ 0x%08X\n", m_dwCrosshairIndex);
#endif

	LOGD << "CrosshairIndex : " << std::hex << m_dwCrosshairIndex;

#pragma endregion

	#pragma region Viewmatrix
	DWORD viewmatrix = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 33, (BYTE*)"\x53\x8B\xDC\x83\xEC\x08\x83\xE4\xF0\x83\xC4\x04\x55\x8B\x6B\x04\x89\x6C\x24\x04\x8B\xEC\xA1\x00\x00\x00\x00\x81\xEC\x98\x03\x00\x00");
	m_dwViewMatrix = pCSGO->m_Mem.Read<DWORD>(viewmatrix + 0x502);
	[add_junk 1 5 /]
	m_dwViewMatrix -= clientBase;
	[add_junk 1 5 /]
	m_dwViewMatrix += 0x80;

#if _DEBUG
	printf("> Viewmatrix Found @ 0x%08X\n", m_dwViewMatrix);
#endif

	LOGD << "Viewmatrix : " << std::hex << m_dwViewMatrix;
	[add_junk 1 5 /]


#pragma endregion

	#pragma region Punch Angles
	[add_junk 1 5 /]
	DWORD punchAngle = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 14, (BYTE*)"\x66\x0F\xD6\x45\xDC\x89\x45\xE4\x81\xF9\x00\x00\x00\x00") - 0x20;
	m_dwPunchAngles = pCSGO->m_Mem.Read<DWORD>(punchAngle);

#if _DEBUG
	printf("> PunchAngles Found @ 0x%08X\n", m_dwPunchAngles);
#endif

	[add_junk 1 5 /]
	LOGD << "PunchAngles : " << std::hex << m_dwPunchAngles;


#pragma endregion

	#pragma region Can Reload
	[add_junk 1 5 /]
	DWORD canReload = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 14, (BYTE*)"\x80\xB9\x00\x00\x00\x00\x00\x0F\x85\x00\x00\x00\x00\xA1") + 2;
	m_dwCanReload = pCSGO->m_Mem.Read<DWORD>(canReload);
	[add_junk 1 5 /]

#if _DEBUG
	printf("> CanReload Found @ 0x%08X\n", m_dwCanReload);
#endif

	LOGD << "CanReload : " << std::hex << m_dwCanReload;
	[add_junk 1 5 /]

#pragma endregion

	#pragma region Netvar Classes
	DWORD dwWorld = pCSGO->m_Mem.FindPattern(clientBase, 0xFFFFFF, (BYTE*)"DT_TEWorldDecal", "zzzzzzzzzzzzzzz");
	[add_junk 1 5 /]
	m_dwNetvarClasses = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_Mem.FindPattern(clientBase, 0xFFFFFF, (BYTE*)&dwWorld, "zzzz") + 0x2B);

#if _DEBUG
	printf("> NetvarClasses Found @ 0x%08X\n", m_dwNetvarClasses);
	[add_junk 1 5 /]
#endif

	LOGD << "NetvarClasses : " << std::hex << m_dwNetvarClasses;

#pragma endregion

	#pragma region PlayerInfo
	m_dwPlayerInfo = pCSGO->m_Mem.FindPattern(engineBase, engineSize, 15, (BYTE*)"\x8B\x88\x00\x00\x00\x00\x8B\x01\x8B\x40\x00\xFF\xD0\x8B\xF8") + 2;
	m_dwPlayerInfo = pCSGO->m_Mem.Read<DWORD>(m_dwPlayerInfo);
	[add_junk 1 5 /]

#if _DEBUG
	printf("> PlayerInfo Found @ 0x%08X\n", m_dwPlayerInfo);
#endif

	LOGD << "PlayerInfo : " << std::hex << m_dwPlayerInfo;
	[add_junk 1 5 /]


#pragma endregion

	#pragma region Attack
	DWORD attack = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 27, (BYTE*)"\x89\x15\x00\x00\x00\x00\x8B\x15\x00\x00\x00\x00\xF6\xC2\x03\x74\x03\x83\xCE\x04\xA8\x04\xBF\xFD\xFF\xFF\xFF") + 2;
	m_dwAttack = pCSGO->m_Mem.Read<DWORD>(attack) - clientBase;
	[add_junk 1 5 /]

#if _DEBUG
	printf("> Attack Found @ 0x%08X\n", m_dwAttack);
#endif

	LOGD << "Attack : " << std::hex << m_dwAttack;

#pragma endregion

	#pragma region Sensitivity
	DWORD sens = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 33, (BYTE*)"\x7A\x2C\x8B\x0D\x00\x00\x00\x00\x81\xF9\x00\x00\x00\x00\x75\x0A\xF3\x0F\x10\x05\x00\x00\x00\x00\xEB\x0F\x8B\x01\x8B\x40\x00\xFF\xD0") + 20;
	m_dwIngameSensitivity = pCSGO->m_Mem.Read<int>(sens) - clientBase;
	[add_junk 1 5 /]

#if _DEBUG
	printf("> InGameSensitivity Found @ 0x%08X\n", m_dwIngameSensitivity);
#endif

	LOGD << "InGameSensitivity : " << std::hex << m_dwIngameSensitivity;
	[add_junk 1 5 /]

#pragma endregion

	#pragma region MoveType
	DWORD movetype = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 14, (BYTE*)"\x8B\x4D\x0C\x8A\x40\x08\x88\x81\x00\x00\x00\x00\xC6\x81") + 8;
	m_dwMoveType = pCSGO->m_Mem.Read<int>(movetype);
	[add_junk 1 5 /]


#if _DEBUG
	printf("> MoveType Found @ 0x%08X\n", m_dwMoveType);
#endif

	LOGD << "MoveType : " << std::hex << m_dwMoveType;

#pragma endregion

	#pragma region CStudioHdr Pointer
	m_dwStudioHdrPtr = pCSGO->m_Mem.FindPattern(clientBase, clientSize, 14, (BYTE*)"\x8B\x86\x00\x00\x00\x00\x89\x44\x24\x0C\x85\xC0\x74\x05");
	m_dwStudioHdrPtr = pCSGO->m_Mem.Read<DWORD>(m_dwStudioHdrPtr + 2);
	[add_junk 1 5 /]

#if _DEBUG
	printf("> m_pStudioHdr Found @ 0x%08X\n", m_dwStudioHdrPtr);
#endif

	LOGD << "m_pStudioHdr : " << std::hex << m_dwStudioHdrPtr;

#pragma endregion

	#pragma region Map Name
	m_dwMapName = pCSGO->m_Mem.FindPattern(engineBase, engineSize, 14, (BYTE*)"\x05\x00\x00\x00\x00\xC3\xCC\xCC\xCC\xCC\xCC\xCC\xCC\xA1") + 1;
	m_dwMapName = pCSGO->m_Mem.Read<DWORD>(m_dwMapName);

#if _DEBUG
	printf("> Map Name Found @ 0x%08X\n", m_dwMapName);
#endif

	LOGD << "MapName : " << std::hex << m_dwMapName;

#pragma endregion

	#pragma region Game Directory
	m_dwGameDirectory = pCSGO->m_Mem.FindPattern(csgoBase, csgoSize, 7, (BYTE*)"\xB9\x00\x00\x00\x00\x8D\x51") + 1;
	m_dwGameDirectory = pCSGO->m_Mem.Read<DWORD>(m_dwGameDirectory);
	[add_junk 1 5 /]

#if _DEBUG
	printf("> Game Directory String Found @ 0x%08X\n", m_dwGameDirectory);
#endif

	LOGD << "Game Directory String : " << std::hex << m_dwGameDirectory;

#pragma endregion

	LOGD << "Finished initializing Offsets | Signatures!";
	[add_junk 1 5 /]

}

void Offsets::LoadNetvars()
{
	LOGD << "Starting to Load Netvars";

	[swap_lines]
	m_dwNetvar_iTeamNum = Netvars::GetNetVar("DT_BaseEntity", "m_iTeamNum");
	m_dwNetvar_iHealth = Netvars::GetNetVar("DT_CSPlayer", "m_iHealth");
	m_dwNetvar_AttributeManager = Netvars::GetNetVar("DT_BaseAttributableItem", "m_AttributeManager");
	m_dwNetvar_Item = Netvars::GetNetVar("DT_BaseAttributableItem", "m_Item");
	m_dwNetvar_iItemDefinitionIndex = Netvars::GetNetVar("DT_BaseAttributableItem", "m_iItemDefinitionIndex");
	m_dwNetvar_boneMatrix = Netvars::GetNetVar("DT_BaseAnimating", "m_nForceBone") + 0x1C;
	m_dwNetvar_iObserverMode = Netvars::GetNetVar("DT_CSPlayer", "m_iObserverMode");
	m_dwNetvar_iObserverTarget = Netvars::GetNetVar("DT_CSPlayer", "m_iObserverTarget");
	m_dwNetvar_fFlags = Netvars::GetNetVar("DT_CSPlayer", "m_fFlags");
	m_dwNetvar_vecOrigin = Netvars::GetNetVar("DT_CSPlayer", "m_vecOrigin");
	m_dwNetvar_vecVelocity = Netvars::GetNetVar("DT_CSPlayer", "m_vecVelocity[0]");
	m_dwNetvar_vecViewOffset = Netvars::GetNetVar("DT_CSPlayer", "m_vecViewOffset[0]");
	m_dwNetvar_iShotsFired = Netvars::GetNetVar("DT_CSPlayer", "m_iShotsFired");
	m_dwNetvar_hActiveWeapon = Netvars::GetNetVar("DT_CSPlayer", "m_hActiveWeapon");
	m_dwNetvar_iClip1 = Netvars::GetNetVar("DT_BaseCombatWeapon", "m_iClip1");
	m_dwNetvar_bInReload = Netvars::GetNetVar("DT_WeaponCSBase", "m_bReloadVisuallyComplete");
	m_dwNetvar_immuneTime = Netvars::GetNetVar("DT_CSPlayer", "m_fImmuneToGunGameDamageTime");
	m_dwNetvar_bIsScoped = Netvars::GetNetVar("DT_CSPlayer", "m_bIsScoped");
	m_dwNetvar_flFlashDuration = Netvars::GetNetVar("DT_CSPlayer", "m_flFlashDuration");
	[/swap_lines]

	[add_junk 1 5 /]

	LOGD << "Finished loading Netvars";
}

[enc_string_disable /]
[junk_disable /]