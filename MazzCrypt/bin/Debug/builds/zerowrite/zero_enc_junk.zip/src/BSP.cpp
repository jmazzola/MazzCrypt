#include "BSP.h"
#include "CSGO.h"
#include "Math.h"

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]

BSP* pBSP = new BSP();

BSP::~BSP()
{
	[add_junk 1 4 /]
	Unload();
}

bool BSP::Load(std::string& szPathName, std::string& szMapName)
{
	[swap_lines]
	m_szMapName = szMapName;
	m_szPathName = szPathName;
	[/swap_lines]

	[add_junk 1 4 /]

	std::string fPath(m_szPathName);
	fPath += char(0x5C);
	fPath += "csgo";
	fPath += char(0x5C);
	fPath += "maps";
	fPath += char(0x5C);
	fPath += m_szMapName + ".bsp";

	HANDLE hFile = CreateFile(fPath.c_str(), GENERIC_READ, NULL, NULL, OPEN_ALWAYS, NULL, NULL);

	if (hFile == NULL)
		return false;

	DWORD dwSize = GetFileSize(hFile, NULL);

	if (!dwSize)
	{
		CloseHandle(hFile);
		[add_junk 1 4 /]
		return false;
	}

	m_pbData = new BYTE[dwSize];
	[add_junk 1 4 /]

	DWORD dwRead = NULL;
	if (!ReadFile(hFile, m_pbData, dwSize, &dwRead, NULL))
	{
		CloseHandle(hFile);

		delete[] m_pbData;
		[add_junk 1 4 /]
		m_pbData = nullptr;

		return false;
	}

	CloseHandle(hFile);

	m_pHeader = (dheader_t*)m_pbData;

	m_pNode = (dnode_t*)(m_pbData + m_pHeader->lumps[LUMP_NODES].fileofs);
	[add_junk 1 4 /]
	m_pPlane = (dplane_t*)(m_pbData + m_pHeader->lumps[LUMP_PLANES].fileofs);
	[add_junk 1 4 /]
	m_pLeaf = (dleaf_t*)(m_pbData + m_pHeader->lumps[LUMP_LEAVES].fileofs);

	return true;
}

void BSP::Unload()
{
	if (m_pPlane)
	{
		[add_junk 1 4 /]
		m_pPlane = nullptr;
	}

	[add_junk 1 4 /]

	if (m_pNode)
	{
		m_pNode = nullptr;
	}

	if (m_pLeaf)
	{
		m_pLeaf = nullptr;
	}

	if (m_pHeader)
	{
		m_pHeader = nullptr;
	}

	[add_junk 1 4 /]

	if (m_pbData)
	{
		delete[] m_pbData;
		m_pbData = nullptr;
	}
}

bool BSP::IsNull()
{
	if (m_pbData == nullptr)
		return true;

	[add_junk 1 4 /]

	if (m_szMapName.empty())
		return true;

	if (m_szPathName.empty())
		return true;

	if (m_pHeader == nullptr)
		return true;

	if (m_pPlane == nullptr)
		return true;

	if (m_pNode == nullptr)
		return true;

	if (m_pLeaf == nullptr)
		return true;

	[add_junk 1 4 /]

	return false;
}

void BSP::DisplayInfo()
{
	if (!pCSGO->IsInGame())
		return;

	printf("Map Version: %d | Revision %d\n", m_pHeader->version, m_pHeader->mapRevision);
	[add_junk 1 4 /]
	printf("Map Name: %s\n", m_szMapName.c_str());
}

dleaf_t * BSP::GetLeafFromPoint(Vector point)
{
	int nodenum = 0;
	dnode_t* pNode;
	dplane_t* pPlane;

	float dist = 0.0f;

	while (nodenum >= 0)
	{
		if (&m_pNode == NULL || &m_pPlane == NULL)
			return nullptr;

		pNode = &m_pNode[nodenum];
		[add_junk 1 4 /]
		pPlane = &m_pPlane[pNode->planenum];

		dist = point.DotProduct(pPlane->normal) - pPlane->dist;

		(dist > 0.0f) ?	nodenum = pNode->children[0] : 	nodenum = pNode->children[1];
	}

	[add_junk 1 4 /]

	return &m_pLeaf[-nodenum - 1];
}

bool BSP::IsVisible(Vector& vStart, Vector& vEnd)
{
	if (IsNull())
	{
		LOGE << "The BSP map information wasn't loaded or was NULL!";
		[add_junk 1 4 /]
		return false;
	}

	Vector dir = vEnd - vStart;
	[add_junk 1 4 /]
	Vector point = vStart;

	int steps = (int)Math::FastSQRT(pow(dir.x, 2) + pow(dir.y, 2) + pow(dir.z, 2));

	// fuck with this too
	if (steps > 4000)
		return false;

	dir /= (float)steps;
	[add_junk 1 4 /]
	dleaf_t* pLeaf = nullptr;

	while (steps)
	{
		point += dir;
		pLeaf = GetLeafFromPoint(point);
		[add_junk 1 4 /]

		// fuck with this for stuff
		if (pLeaf->contents & CONTENTS_SOLID)
			return false;

		--steps;
	}

	[add_junk 1 4 /]

	return true;
}

std::string BSP::GetMapName() const
{
	[add_junk 1 4 /]
	return m_szMapName;
}

[enc_string_disable /]
[junk_disable /]