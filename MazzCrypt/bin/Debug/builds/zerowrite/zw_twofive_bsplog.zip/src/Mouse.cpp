#include "Mouse.h"

[junk_enable /]

namespace Mouse
{
	void Move(float x, float y)
	{
		INPUT input = { 0 };
		
		[swap_lines]
		input.type = INPUT_MOUSE;
		input.mi.dx = (LONG)x;
		input.mi.dy = (LONG)y;
		input.mi.dwFlags = MOUSEEVENTF_MOVE;
		[/swap_lines]

		[add_junk 1 5 /]
		
		SendInput(1, &input, sizeof(INPUT));
	}

	void Click(int type)
	{
		INPUT input = { 0 };

		input.type = INPUT_MOUSE;
		[add_junk 1 5 /]
		input.mi.dwFlags = type;
		[add_junk 1 5 /]

		SendInput(1, &input, sizeof(INPUT));
	}
}

[junk_disable /]