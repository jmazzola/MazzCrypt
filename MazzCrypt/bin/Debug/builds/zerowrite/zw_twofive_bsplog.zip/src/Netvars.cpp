#include "Netvars.h"
#include "Utils.h"

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]


namespace Netvars
{
	DWORD GetNetVar(const char* szClassName, const char* szNetVar)
	{
		if (!pCSGO->m_Offsets.m_dwNetvarClasses || !szClassName || !szNetVar)
		{
			[add_junk 1 4 /]
			Utils::PrintLine("> Classes are fucked. Netvars can't be grabbed.");
		}

		ClientClass* pClass = (ClientClass*)pCSGO->m_Offsets.m_dwNetvarClasses;

		if (!pClass)
		{
			[add_junk 1 4 /]
			return NULL;
		}

		for (; pClass; pClass = pClass->GetNextClass())
		{
			if (strcmp(szClassName, pClass->GetTable()->GetTableName()))
				continue;

			[add_junk 1 4 /]

			for (int i = 0; i < pClass->GetTable()->GetMaxProp(); i++)
			{
				CRecvTable::CRecvProp* pRecvProp = pClass->GetTable()->GetProperty(i);

				[add_junk 1 4 /]

				if (isdigit(pRecvProp->GetVarName()[0]))
					continue;

				if (!strcmp(pRecvProp->GetVarName(), szNetVar))
				{
					[add_junk 1 4 /]
					return pRecvProp->GetOffset();
				}

				if (!pRecvProp->GetDataTable())
					continue;

				[add_junk 1 4 /]

				for (int j = 0; j < pRecvProp->GetDataTable()->GetMaxProp(); ++j)
				{
					CRecvTable::CRecvProp* pRecvProp2 = pRecvProp->GetDataTable()->GetProperty(j);

					if (isdigit(pRecvProp2->GetVarName()[0]))
						continue;

					[add_junk 1 4 /]

					if (!strcmp(pRecvProp2->GetVarName(), szNetVar))
					{
						[add_junk 1 4 /]
						return pRecvProp2->GetOffset();
					}

					if (!pRecvProp2->GetDataTable())
						continue;

					for (int k = 0; k < pRecvProp2->GetDataTable()->GetMaxProp(); ++k)
					{
						[add_junk 1 4 /]
						CRecvTable::CRecvProp* pRecvProp3 = pRecvProp2->GetDataTable()->GetProperty(k);
						[add_junk 1 4 /]

						if (isdigit(pRecvProp3->GetVarName()[0]))
							continue;

						if (!strcmp(pRecvProp3->GetVarName(), szNetVar))
						{
							return pRecvProp3->GetOffset();
						}
					}
				}
			}

			[add_junk 1 4 /]
		}

		return NULL;
	}
}

[enc_string_disable /]
[junk_disable /]