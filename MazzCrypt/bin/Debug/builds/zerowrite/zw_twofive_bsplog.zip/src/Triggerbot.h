// Triggerbot.h - Triggerbot cheat thread
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Player.h"
#include "Utils.h"
#include "Enums.h"
#include "Mouse.h"
#include "Math.h"
#include "Ray.h"
#include "Config.h"

#include "RCS.h"

#include "Hitboxes.h"
#include "BSP.h"

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]


class Triggerbot
{
public:

	Triggerbot() = default;
	~Triggerbot() = default;

	// Load Weapon Settings from Config
	void GetWeaponSettings(TriggerWeaponSettings& tWeap)
	{
		switch (pCSGO->m_Me.GetWeaponID())
		{
			case WID_Glock:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tGlock.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tGlock.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tGlock.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tGlock.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WID_P2000:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tP2K.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tP2K.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tP2K.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tP2K.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_USP:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tUSP.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tUSP.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tUSP.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tUSP.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_P250:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tP250.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tP250.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tP250.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tP250.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Five_Seven:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tFiveSeven.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tFiveSeven.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tFiveSeven.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tFiveSeven.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Deagle:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tDeagle.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tDeagle.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tDeagle.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tDeagle.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Dual_Berettas:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tDuelies.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tDuelies.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tDuelies.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tDuelies.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Tec9:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tTec9.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tTec9.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tTec9.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tTec9.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_CZ75:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tCZ75.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tCZ75.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tCZ75.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tCZ75.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Revolver:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tRevolver.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tRevolver.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tRevolver.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tRevolver.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Galil:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tGalil.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tGalil.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tGalil.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tGalil.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_AK47:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tAK47.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tAK47.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tAK47.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tAK47.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_M4A4:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tM4A4.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tM4A4.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tM4A4.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tM4A4.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_M4A1S:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tM4A1S.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tM4A1S.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tM4A1S.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tM4A1S.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_SG553:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tSG553.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tSG553.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tSG553.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tSG553.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_AUG:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tAUG.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tAUG.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tAUG.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tAUG.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_FAMAS:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tFAMAS.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tFAMAS.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tFAMAS.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tFAMAS.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_MAC10:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tMAC10.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tMAC10.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tMAC10.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tMAC10.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_MP7:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tMP7.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tMP7.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tMP7.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tMP7.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_MP9:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tMP9.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tMP9.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tMP9.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tMP9.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_UMP45:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tUMP45.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tUMP45.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tUMP45.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tUMP45.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_PPBizon:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tBizon.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tBizon.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tBizon.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tBizon.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_P90:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tP90.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tP90.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tP90.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tP90.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_M249:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tM249.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tM249.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tM249.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tM249.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Negev:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tNegev.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tNegev.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tNegev.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tNegev.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_AWP:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tAWP.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tAWP.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tAWP.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tAWP.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_SCAR_Auto:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tSCAR20.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tSCAR20.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tSCAR20.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tSCAR20.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_G3SG1_Auto:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tG3SG1.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tG3SG1.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tG3SG1.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tG3SG1.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Scout:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tScout.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tScout.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tScout.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tScout.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_Nova:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tNova.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tNova.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tNova.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tNova.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_XM1014:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tXM1014.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tXM1014.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tXM1014.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tXM1014.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_SawedOff:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tSawedOff.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tSawedOff.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tSawedOff.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tSawedOff.m_fRCSScale;
				[/swap_lines]
				break;
			}

			case WID_MAG7:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tMag7.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tMag7.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tMag7.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tMag7.m_fRCSScale;
				[/swap_lines]
				break;
			}

			default:
			break;
		}

		pRCS->m_fRCSScale = tWeap.m_fRCSScale;
	}

	// Get Player with In-cross method
	Player* GetPlayerInCross()
	{
		[add_junk 1 6 /]
		DWORD xhairID = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwLocalBase + pCSGO->m_Offsets.m_dwCrosshairIndex);

		for (int i = 1; i < 64; i++)
		{
			Player* ply = &pCSGO->m_Players[i];

			[add_junk 1 6 /]

			if (!ply->Valid())
				continue;

			bool bEnemy = (pCSGO->m_Me.GetTeam() == ply->GetEnemyTeam());
			[add_junk 1 6 /]

			if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Enemies) && !bEnemy)
				continue;
			else if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Teammates) && bEnemy)
				continue;

			if (ply->GetID() == xhairID)
			{
				if (pCSGO->m_Config.m_TriggerSettings.m_bAntiJump && !(ply->GetFlags() & FL_ONGROUND) && (ply->GetMoveType() != EMoveType::MOVETYPE_LADDER))
					return nullptr;

				return ply;
			}

			[add_junk 1 6 /]
		}

		return nullptr;
	}

	// Get Player who is in our eye-rays
	Player* GetPlayerInRay(std::vector<int> hitboxes)
	{
		for (int i = 1; i < 64; i++)
		{
			Vector viewDirection = Math::AngleToDirection(pCSGO->m_Me.GetViewAngles());
			[add_junk 1 6 /]
			Ray viewRay(pCSGO->m_Me.GetEyePos(), viewDirection);
			float distance;

			Player* ply = &pCSGO->m_Players[i];

			bool bEnemy = (pCSGO->m_Me.GetTeam() == ply->GetEnemyTeam());

			if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Enemies) && !bEnemy)
				continue;
			else if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Teammates) && bEnemy)
				continue;

			[add_junk 1 6 /]

			if (!ply->Valid())
				continue;

			if (pCSGO->m_Config.m_TriggerSettings.m_bAntiJump && !(ply->GetFlags() & FL_ONGROUND) && (ply->GetMoveType() != EMoveType::MOVETYPE_LADDER))
				continue;

			if (ply->GetHitboxes().empty())
				return nullptr;

			[add_junk 1 6 /]

			for (size_t i = 0; i < hitboxes.size(); i++)
			{
				int numHitbox = hitboxes[i];

				if (ply->GetHitboxes().empty())
					break;

				[add_junk 1 6 /]
				auto hitbox = ply->GetHitboxes()[numHitbox];

				if (!ply->IsVisible(hitbox.m_iBone))
				{
					[add_junk 1 6 /]
#if _DEBUG
					printf("%s 's bone (%d) wasn't visible!\n", ply->GetName().c_str(), hitbox.m_iBone);
#endif

					if(pBSP->IsNull())
						LOGE << "[Triggerbot] BSP was infact NULL soooo..";
					
					continue;
				}

				if (viewRay.IntersectsWithOBB(ply->GetBoneMatrix(hitbox.m_iBone), hitbox.m_vecBBMin, hitbox.m_vecBBMax, distance))
				{
#if _DEBUG
					printf("Contact with %s!\n", ply->GetName().c_str());
#endif
					m_Hitboxes = hitboxes;
					return ply;
				}
			}
		}

		[add_junk 1 6 /]

		return nullptr;
	}

	// Shoot/Click 
	void Shoot(int delayBefore, int delayAfter)
	{
		const float flashpercentage = (pCSGO->m_Me.GetFlashedTime() / 5.0f) * 100.0f;
		
		// Prevent weird ass clicking if we're not fullscreened
		if (GetForegroundWindow() != Utils::GetGameWindow())
			return;

		[add_junk 1 6 /]

		if (pCSGO->m_Config.m_TriggerSettings.m_bSniperMode)
		{
			[add_junk 1 6 /]

			if (pCSGO->m_Me.GetWeaponType() == EWeaponType::WeapType_Sniper && !pCSGO->m_Me.IsScoped())
				return;
		}

		if (pCSGO->m_Config.m_TriggerSettings.m_bAntiSpectate && pCSGO->m_Me.IsBeingSpectated())
			return;

		[add_junk 1 6 /]

		if (flashpercentage >= pCSGO->m_Config.m_TriggerSettings.m_fMinFlash)
			return;

		[add_junk 1 6 /]

		if (pCSGO->m_Config.m_TriggerSettings.m_bMoveCheck && pCSGO->m_Me.IsMoving())
			return;

		if (pCSGO->m_Me.GetMoveType() == EMoveType::MOVETYPE_LADDER)
			return;

		if (pCSGO->m_Config.m_TriggerSettings.m_bRevolverMode && pCSGO->m_Me.GetWeaponID() == WID_Revolver)
			delayAfter = 1000;

		[add_junk 1 6 /]

		std::this_thread::sleep_for(std::chrono::milliseconds(delayBefore));
		[add_junk 1 6 /]
		Mouse::Click(MOUSEEVENTF_LEFTDOWN);

		if (pCSGO->m_Config.m_TriggerSettings.m_bSprayUntilDeadMode)
		{
			while (m_pTarget)
			{
				m_pTarget = GetPlayerInRay(m_Hitboxes);
				[add_junk 1 6 /]
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
			}

			Mouse::Click(MOUSEEVENTF_LEFTUP);

			[add_junk 1 6 /]
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(delayAfter));
			[add_junk 1 6 /]
			Mouse::Click(MOUSEEVENTF_LEFTUP);
		}
	}

	// BUG: Stabs when facing target
	bool IsBehindTarget(Player* pTarget)
	{
		Vector vecLOS = pTarget->GetOrigin() - pCSGO->m_Me.GetOrigin();
		[add_junk 1 6 /]
		vecLOS.Normalize();

		Vector vTargetForward;
		Math::AngleVectors(pTarget->GetViewAngles(), &vTargetForward);
		[add_junk 1 6 /]
		vTargetForward.z = 0.0f;

		return vecLOS.DotProduct(vTargetForward) > 0.475f;
	}

	// Knifebot
	void Knifebot(Player* pPlayer)
	{
		// Swipe if we're within knife range
		if (pPlayer->GetDistanceFromMe() <= 85.0f)
		{
			printf("%d Health\n", pPlayer->GetHealth());

			// TODO: Find if they have armor or not, otherwise, use different health values:
			// http://counterstrike.wikia.com/wiki/Knife

			if (pPlayer->GetHealth() <= 55 /*|| IsBehindTarget(pPlayer)*/)
			{
				Mouse::Click(MOUSEEVENTF_RIGHTDOWN);
				[add_junk 1 6 /]
				std::this_thread::sleep_for(std::chrono::milliseconds(10));
				Mouse::Click(MOUSEEVENTF_RIGHTUP);
				[add_junk 1 6 /]
			}
			else
			{
				Mouse::Click(MOUSEEVENTF_LEFTDOWN);
				std::this_thread::sleep_for(std::chrono::milliseconds(10));
				Mouse::Click(MOUSEEVENTF_LEFTUP);
				[add_junk 1 6 /]
			}
		}
	}

	// Disable RCS
	void DisableRCS()
	{
		pRCS->m_bActive = false;
		[add_junk 1 6 /]
	}

	// Enable RCS
	void EnableRCS()
	{
		[add_junk 1 6 /]
		pRCS->m_bActive = true;
	}

	// Thread routine
	void Start()
	{
		LOGD << "Triggerbot thread started!";
		[add_junk 1 6 /]

		while (true)
		{
			if (pCSGO == nullptr)
			{
				[add_junk 1 6 /]
				LOGD << "pCSGO was nullptr! Ending thread!";
				return;
			}
			else if (pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot)
			{
				LOGD << "Triggerbot bool was true, Ending thread!";
				return;
			}

			if (GetAsyncKeyState(VK_END))
			{
				[add_junk 1 6 /]
				pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = true;
			}

			if (!pCSGO->IsInGame())
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				[add_junk 1 6 /]
				continue;
			}

			bool bKeyCircumstance;

			[add_junk 1 6 /]

			(pCSGO->m_Config.m_TriggerSettings.m_bKeyHeld)
				? bKeyCircumstance = (GetAsyncKeyState(pCSGO->m_Config.m_TriggerSettings.m_nKey) & 0x8000)
				: bKeyCircumstance = (pCSGO->m_Config.m_TriggerSettings.m_bActive);

			if (!bKeyCircumstance)
			{
				// This will allow us to use regular spray control when not triggering
				DisableRCS();
				[add_junk 1 6 /]
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				continue;
			}

			// This prevents weird jumps since we set our mouse to those angles
			if (pCSGO->m_Me.IsShooting())
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				[add_junk 1 6 /]
				continue;
			}

			if(!pCSGO->m_Me.GetAmmo() ||  pCSGO->m_Me.IsReloading() || 
				pCSGO->m_Me.GetWeaponType() == WeapType_C4Explosive || 
				pCSGO->m_Me.GetWeaponType() == WeapType_Grenade || 
				pCSGO->m_Me.GetWeaponType() == WeapType_KnifeType)
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				[add_junk 1 5 /]
				continue;
			}

			EnableRCS();

			[add_junk 1 6 /]

			m_pTarget = nullptr;

			TriggerWeaponSettings tWeap;
			[add_junk 1 6 /]
			GetWeaponSettings(tWeap);

			switch (pCSGO->m_Config.m_TriggerSettings.m_nMethod)
			{
				case Trigger_InCross:
				{
					m_pTarget = GetPlayerInCross();
					[add_junk 1 6 /]
					break;
				}
				case Trigger_Hitbox:
				{
					m_pTarget = GetPlayerInRay(tWeap.m_hitboxes);
					[add_junk 1 6 /]
					break;
				}
			}

			if (m_pTarget == nullptr)
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				continue;
			}

			[add_junk 1 6 /]

			Shoot(tWeap.m_nDelayBefore, tWeap.m_nDelayAfter);
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}

private:

	// The current target of our triggerbot

	[swap_lines]
	Player* m_pTarget;
	std::vector<int> m_Hitboxes;
	[/swap_lines]

	[add_junk_datamembers 1 9 /]

};

[enc_string_disable /]
[junk_disable /]