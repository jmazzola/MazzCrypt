// Mouse.h - Controls all mouse stuff
#pragma once

#include "stdafx.h"

namespace Mouse
{
	[swap_lines]
	void Move(float x, float y);
	void Click(int type);
	[/swap_lines]
}
