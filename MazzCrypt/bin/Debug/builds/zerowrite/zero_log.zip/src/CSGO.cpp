#include "CSGO.h"
#include "Utils.h"

#include "Decrypt.h"

CSGO* pCSGO = new CSGO();

[enc_string_enable /]

bool CSGO::Attach()
{
	m_Config.Init("settings.ini");
	return (m_Mem.Attach("csgo.exe"));
}

void CSGO::Detach()
{
	m_Mem.Detach();
}

bool CSGO::LoadBases()
{
	if (!m_Mem.IsAttached())
		return false;

	m_dwClientBase = m_Mem.GetModuleBase("client.dll");

	if (!m_dwClientBase)
		return false;

	m_dwEngineBase = m_Mem.GetModuleBase("engine.dll");

	if (!m_dwEngineBase)
		return false;

	m_dwLocalBase = m_Mem.Read<DWORD>(m_dwClientBase + m_Offsets.m_dwLocalPlayer);
	m_dwEntityBase = m_dwClientBase + m_Offsets.m_dwEntityList;

	m_dwAnglePointer = m_Mem.Read<DWORD>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);

	m_dwStudioHdrPointer = m_Mem.Read<DWORD>(m_dwLocalBase + m_Offsets.m_dwStudioHdrPtr);
	m_dwStudioHdrPointer = m_Mem.Read<DWORD>(m_dwStudioHdrPointer);


	for (int i = 0; i < 16; i++)
		m_flViewMatrix[i] = m_Mem.Read<float>(m_dwClientBase + m_Offsets.m_dwViewMatrix + (4 * i));

	RECT rect;
	GetClientRect(Utils::GetGameWindow(), &rect);
	m_iWindowWidth = (int)(rect.right - rect.left);
	m_iWindowHeight = (int)(rect.bottom - rect.top);

	return true;
}

void CSGO::Update()
{
	if (!m_Mem.IsAttached())
		return;
	
	m_Me.Update(m_dwLocalBase);

	for (int i = 1; i < 64; i++)
	{
		DWORD entBase = m_Mem.Read<DWORD>(m_dwEntityBase + (i * 0x10));
		m_Players[i].Update(entBase);
	}
}

bool CSGO::IsInGame()
{
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	return (m_Mem.Read<int>(clientState + m_Offsets.m_dwSignOnState) == SOS_Full);
}

std::string CSGO::GetMapName()
{
	char mapName[64];
	int clientState = m_Mem.Read<int>(m_dwEngineBase + m_Offsets.m_dwEnginePtr);
	m_Mem.Read(clientState + m_Offsets.m_dwMapName, &mapName, sizeof(mapName));

	std::string map(mapName);

	if (map.empty())
		return "Invalid Map Name";
	
	return map;
}

std::string CSGO::GetGameDirectory()
{
	char dir[255];
	m_Mem.Read(m_Offsets.m_dwGameDirectory, &dir, sizeof(dir));
	return std::string(dir);
}

[enc_string_disable /]