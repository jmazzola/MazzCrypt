// BSPHandler.h - Handle the BSP check in the tick
#pragma once

#include "stdafx.h"
#include "CSGO.h"

void BSPHandler()
{
	LOGD << "BSPHandler thread started!";

	while (!pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler)
	{
		if (GetAsyncKeyState(VK_END))
			pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = true;

		if (!pCSGO->IsInGame())
		{
			std::this_thread::sleep_for(std::chrono::seconds(5));
			continue;
		}

		if (pBSP->GetMapName().empty() || strcmp(pBSP->GetMapName().c_str(), pCSGO->GetMapName().c_str()))
		{
			LOGD << "Different map detected! Old Map: " << pBSP->GetMapName().c_str() << " | New Map: " << pCSGO->GetMapName().c_str();
			pBSP->Unload();
			pBSP->Load(pCSGO->GetGameDirectory(), pCSGO->GetMapName());
			LOGD << "BSP has loaded with " << pBSP->GetMapName().c_str() << " successfully!";
		}

		std::this_thread::sleep_for(std::chrono::seconds(5));
	}

	LOGD << "BSPHandler thread ended!";
}