// RCS.h - RCS (Recoil Control System) cheat thread
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"
#include "Mouse.h"

class RCS
{
public:

	RCS() = default;
	~RCS() = default;

	void Start()
	{
		LOGD << "RCS thread started!";

		[swap_lines]
		static Vector2D delta, lastPunch;
		static float m_yaw = 0.022f;
		[/swap_lines]

		while (!pCSGO->m_Config.m_ThreadSettings.m_bStopRCS)
		{
			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = true;

			if (!m_bActive)
				continue;

			Vector2D punch = pCSGO->m_Me.GetPunchAngles();

			if (pCSGO->m_Me.IsShooting())
			{
				float sens = pCSGO->m_Mem.Read<float>(pCSGO->m_dwClientBase + pCSGO->m_Offsets.m_dwIngameSensitivity);

				delta.x = ((pCSGO->m_Me.GetPunchAngles().x - lastPunch.x) * m_fRCSScale) / (m_yaw * sens) * -1.0f;
				delta.y = ((pCSGO->m_Me.GetPunchAngles().y - lastPunch.y) * m_fRCSScale) / (m_yaw * sens);

				lastPunch = pCSGO->m_Me.GetPunchAngles();

				Mouse::Move(delta.y, delta.x);
			}
			else
			{
				delta = Vector2D(0, 0);
				lastPunch = punch;
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}

		LOGD << "RCS thread ended!";
	}

	static float m_fRCSScale;
	static bool m_bActive;
};

// extern
extern RCS* pRCS = new RCS();

// Statics
float RCS::m_fRCSScale = 0.0f;
bool RCS::m_bActive = true;