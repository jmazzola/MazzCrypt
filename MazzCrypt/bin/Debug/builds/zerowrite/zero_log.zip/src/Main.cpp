// Main.cpp - The base of the project

#include "stdafx.h"

#include "Utils.h"
#include "Memory.h"
#include "CSGO.h"

#include "Triggerbot.h"
#include "RCS.h"

#include "Hitboxes.h"

#include "BSP.h"
#include "BSPHandler.h"

#include <time.h>
#include <thread>

#define VERSION_MAJOR 1
#define VERSION_MINOR 0

char* programPath;


void ActivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = false;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = false;
	[/swap_lines]

}


void DeactivateAllThreads()
{
	[swap_lines]
	pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopBSPHandler = true;
	pCSGO->m_Config.m_ThreadSettings.m_bStopRCS = true;
	[/swap_lines]
}


void UpdateHitboxes()
{
	for (int i = 1; i < 64; i++)
	{
		Player* ply = &pCSGO->m_Players[i];

		if (ply->GetHitboxes().empty())
		{
			pHitboxes->LoadModelHitboxes(ply->GetModelName(), pCSGO->m_dwStudioHdrPointer);
			ply->m_vHitboxes = pHitboxes->GetModelHitboxes(ply->GetModelName());
		}
	}

	std::this_thread::sleep_for(std::chrono::milliseconds(1));
}


void UpdateTick()
{
	LOGD << "UpdateTick thread started!";

	while (!pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate)
	{
		if (GetAsyncKeyState(VK_END))
			pCSGO->m_Config.m_ThreadSettings.m_bStopUpdate = true;

		if (pCSGO->IsInGame())
		{
			pCSGO->LoadBases();

			std::string newSettingsHash = pCSGO->m_Config.GetHash();

			if (strcmp(newSettingsHash.c_str(), pCSGO->m_Config.m_szHash.c_str()))
			{
				LOGD << "Hashes in settings.ini was found to be changed! Old Hash: " << pCSGO->m_Config.m_szHash.c_str() << " | New Hash: " << newSettingsHash.c_str();
				if (pCSGO->m_Config.LoadConfig())
				{
					LOGD << "The new settings.ini successfully loaded and changed";
					Utils::PrintLine("> .ini file has been changed. Automatically loaded new settings!\n");
				}
				else
				{
					LOGE << "The new settings.ini FAILED to be loaded and changed";
					Utils::PrintLine("> .ini file could not be opened/changed. Failed to load new settings.\n");
				}
			}

			UpdateHitboxes();
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			continue;
		}

		pCSGO->Update();
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}

	LOGD << "UpdateTick thread ended!";
}


void Init()
{
	plog::init(plog::debug, "log.txt");

	LOGD << "======= START =======";
	LOGD << "Zerowrite Initiated.";

	srand((unsigned int)time(NULL));
	rand();

	Utils::SetUpMinidump();
	Utils::DisableQuickEdit();
	Utils::SetRandomWindowTitle(20);

	Utils::AllowDebugging();

	std::string header =
		"                                                                        $$               \n"
		" /$$$$$$$$  /$$$$$$   /$$$$$$   /$$$$$$  /$$  /$$  /$$  /$$$$$$  /$$ /$$$$$$    /$$$$$$  \n"
		"|____ /$$/ /$$__  $$ /$$__  $$ /$$__  $$| $$ | $$ | $$ /$$__  $$| $$|_  $$_/   /$$__  $$ \n"
		"   /$$$$/ | $$$$$$$$| $$  \\__/| $$  \\ $$| $$ | $$ | $$| $$  \\__/| $$  | $$    | $$$$$$$$ \n"
		"  /$$__/  | $$_____/| $$      | $$  | $$| $$ | $$ | $$| $$      | $$  | $$ /$$| $$_____/ \n"
		" /$$$$$$$$|  $$$$$$$| $$      |  $$$$$$/|  $$$$$/$$$$/| $$      | $$  |  $$$$/|  $$$$$$$ \n"
		"|________/ \\_______/|__/       \\______/  \\_____/\\___/ |__/      |__/   \\___/   \\_______/ \n";

	Utils::PrintLine(header);
	Utils::PrintLine("> Current Version: " + std::to_string(VERSION_MAJOR) + "." + std::to_string(VERSION_MINOR) + " - Build " + std::string(__DATE__) + " " + std::string(__TIME__));

#if _DEBUG
	Utils::PrintLine("> Developer Version~ \n");
#endif

	Utils::PrintLine("> Waiting for CSGO. If you haven't started CSGO yet, please do so.");

	while (!pCSGO->Attach())
		Sleep(100);

	LOGD << "CSGO has been loaded | ProcessID: " << pCSGO->m_Mem.GetProcessID();

	Utils::PrintLine("> CSGO has been loaded!\n");

	Utils::PrintLine("> Loading your config from settings.ini..");

	pCSGO->m_Config.Init(".\\settings.ini");

	if (pCSGO->m_Config.LoadConfig())
	{
		LOGD << "settings.ini was successfully loaded!";
		Utils::PrintLine("> settings.ini was successfully loaded!");
	}
	else
	{
		LOGE << "settings.ini FAILED to load!";
		Utils::PrintLine("> settings.ini FAILED to load!");
	}

	Utils::PrintLine("\n> Waiting until CSGO loads it's .dll's. This will only take a minute.");

	while (!pCSGO->m_Mem.GetModuleBase("client.dll"))
		Sleep(100);

	LOGD << "client.dll was detected | Base: " << std::hex <<  pCSGO->m_Mem.GetModuleBase("client.dll") << " Size: " << pCSGO->m_Mem.GetModuleSize("client.dll");

	while (!pCSGO->m_Mem.GetModuleBase("engine.dll"))
		Sleep(100);

	LOGD << "engine.dll was detected | Base: " << std::hex << pCSGO->m_Mem.GetModuleBase("engine.dll") << " Size: " << pCSGO->m_Mem.GetModuleSize("engine.dll");

	Utils::PrintLine("\n> CSGO has loaded their dlls!");

	Utils::PrintLine("\n> Scanning signatures and setting up netvars..\n");

	pCSGO->m_Offsets.Init();
	pCSGO->LoadBases();
	pCSGO->m_Offsets.LoadNetvars();

	LOGD << "Bases and Netvars were loaded and populated!";

	Utils::PrintLine("\n> Loading Cheat Threads..\n");

	ActivateAllThreads();

	LOGD << "Starting threads..";

	pCSGO->m_vThreadPool.emplace_back(UpdateTick);
	LOGD << "UpdateTick emplaced";
	pCSGO->m_vThreadPool.emplace_back(&Triggerbot::Start, Triggerbot());
	LOGD << "Triggerbot emplaced";
	pCSGO->m_vThreadPool.emplace_back(&RCS::Start, RCS());
	LOGD << "RCS emplaced";
	pCSGO->m_vThreadPool.emplace_back(BSPHandler);
	LOGD << "BSPHandling emplaced";

	Utils::PrintLine("\n> Cheat Loaded..\n");
}

void Loop()
{
	while (!GetAsyncKeyState(VK_END))
	{
		if (!Utils::DoesCSGOExist())
		{
			LOGE << "CSGO doesn't exist anymore. Exiting main loop!";
			break;
		}

		if (GetAsyncKeyState(pCSGO->m_Config.m_TriggerSettings.m_nToggleKey) & 1)
		{
			LOGD << "Triggerbot was toggled " << ((pCSGO->m_Config.m_TriggerSettings.m_bActive) ? "ON" : "OFF");
			pCSGO->m_Config.m_TriggerSettings.m_bActive = !pCSGO->m_Config.m_TriggerSettings.m_bActive;
			Sleep(1);
		}

		Sleep(1);
	}

	LOGD << "END key detected, exiting main loop!";
}

void Cleanup()
{
	DeactivateAllThreads();

	LOGD << "All threads were deactivated.";

	Utils::PrintLine("> Ending threads...");

	for (size_t i = 0; i < pCSGO->m_vThreadPool.size(); i++)
	{
		while (pCSGO->m_vThreadPool[i].joinable())
		{

			pCSGO->m_vThreadPool[i].join();
			Sleep(1);

#if _DEBUG
			printf("> Thread %d ended!\n", i);
#endif

			LOGD << "Thread " << i << " ended.";
		}
	}

	pCSGO->m_Config.SaveConfig();
	LOGD << "settings.ini was saved";

	delete pHitboxes;
	pHitboxes = nullptr;

	delete pBSP;
	pBSP = nullptr;

	delete pRCS;
	pRCS = nullptr;

	delete pCSGO;
	pCSGO = nullptr;

	LOGD << "Self-deleting executable..";
	Utils::DeleteSelf(programPath);
}


int main(int argc, char* argv[])
{
	if (argc > 0)
		programPath = argv[0];

	Init();
	Loop();
	Cleanup();

	LOGD << "Cleanup has finished, exiting program";

	Beep(0x400, 600);

	LOGD << "======= END =======";

	return 0;
}