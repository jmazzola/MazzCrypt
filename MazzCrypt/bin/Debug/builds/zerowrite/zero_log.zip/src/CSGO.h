// CSGO.h - An object to hold all the shit we're doing with the game. Players, offsets all that shiz
#pragma once

#include "stdafx.h"
#include "Memory.h"
#include "Offsets.h"
#include "Player.h"
#include "Config.h"
#include "Enums.h"

#define m_Me m_Players[0]

struct Hitbox
{
	[swap_lines]
	int m_nBone;
	Vector m_vMin;
	Vector m_vMax;
	[/swap_lines]

	void Setup(int b, Vector min, Vector max)
	{
		[swap_lines]
		m_nBone = b;
		m_vMin = min;
		m_vMax = max;
		[/swap_lines]
	}
};

class CSGO
{
public:

	[swap_lines]
	CSGO() = default;
	~CSGO() = default;
	bool Attach();
	void Detach();
	bool LoadBases();
	void Update();
	bool IsInGame();
	std::string GetMapName();
	std::string GetGameDirectory();
	[/swap_lines]

public:
	[swap_lines]
	Memory m_Mem;
	Config m_Config;
	std::vector<std::thread> m_vThreadPool;
	Player m_Players[64];
	float m_flViewMatrix[16];
	DWORD m_dwClientBase;
	DWORD m_dwEngineBase;
	DWORD m_dwLocalBase;
	DWORD m_dwEntityBase;
	DWORD m_dwBoneMatrix;
	DWORD m_dwAnglePointer;
	DWORD m_dwStudioHdrPointer;
	Offsets m_Offsets;
	int m_iWindowWidth;
	int m_iWindowHeight;
	[/swap_lines]
};

extern CSGO* pCSGO;