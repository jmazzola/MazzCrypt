// Config.h - Our config settings
#pragma once

#include "stdafx.h"

struct TriggerWeaponSettings
{
	[swap_lines]
	std::vector<int> m_hitboxes;
	int m_nDelayBefore;
	int m_nDelayAfter;
	float m_fRCSScale;
	[/swap_lines]
};

struct TriggerSettings
{
public:
	[swap_lines]
	bool m_bActive;
	bool m_bSniperMode;
	bool m_bRevolverMode;
	bool m_bKnifebot;
	bool m_bAfterburst;
	bool m_bDeathmatch;
	bool m_bAntiSpectate;
	bool m_bAntiJump;
	int m_nKey;
	int m_nToggleKey;
	bool m_bKeyHeld;
	int m_nMethod;
	int m_nTargetType;
	int m_nDelayBefore;
	int m_nDelayAfter;
	float m_fFOV;
	TriggerWeaponSettings m_tPistols;
	TriggerWeaponSettings m_tRifles;
	TriggerWeaponSettings m_tSnipers;
	TriggerWeaponSettings m_tShotguns;
	TriggerWeaponSettings m_tSMGs;
	TriggerWeaponSettings m_tLMGs;
	[/swap_lines]
};

struct ThreadHandling
{
public:
	[swap_lines]
	bool m_bStopUpdate;
	bool m_bStopTriggerbot;
	bool m_bStopBSPHandler;
	bool m_bStopRCS;
	[/swap_lines]
};

class Config
{
public:

	[swap_lines]
	Config() = default;
	~Config() = default;
	void Init(std::string szConfigName);
	std::string GetHash();
	bool LoadConfig();
	bool SaveConfig();
	int GetInt(char* section, char* option);
	float GetFloat(char* section, char* option);
	std::string GetString(char* section, char* option);
	bool GetBool(char* section, char* option);
	std::vector<int> GetCommaSeperatedInts(char* section, char* option);
	void SetInt(char* section, char* option, int nValue);
	void SetFloat(char* section, char* option, float fValue);
	void SetString(char* section, char* option, std::string szValue);
	void SetBool(char* section, char* option, bool bValue);
	void SetCommaSeperatedInts(char* section, char* option, std::vector<int> vValue);
	[/swap_lines]

public:

	[swap_lines]
	std::string m_szHash;
	TriggerSettings m_TriggerSettings;
	ThreadHandling m_ThreadSettings;
	[/swap_lines]

private:

	std::string m_szConfigFile;
};