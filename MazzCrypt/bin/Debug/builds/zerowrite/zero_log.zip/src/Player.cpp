#include "Player.h"
#include "CSGO.h"
#include "Utils.h"
#include "Math.h"
#include "BSP.h"
#include "Hitboxes.h"
#include <future>

int Player::GetClassID()
{
	int vt = pCSGO->m_Mem.Read<int>(m_dwBaseAddr + 0x8);
	int fn = pCSGO->m_Mem.Read<int>(vt + 2 * 0x4);
	int cls = pCSGO->m_Mem.Read<int>(fn + 0x1);
	int clsn = pCSGO->m_Mem.Read<int>(cls + 8);
	return pCSGO->m_Mem.Read<int>(cls + 20);
}

char* Player::GetClassName()
{
	int vt = pCSGO->m_Mem.Read<int>(m_dwBaseAddr + 0x8);
	int fn = pCSGO->m_Mem.Read<int>(vt + 2 * 0x4);
	int cls = pCSGO->m_Mem.Read<int>(fn + 0x1);
	int clsn = pCSGO->m_Mem.Read<int>(cls + 8);

	char* nameData = new char[32];
	pCSGO->m_Mem.Read(clsn, &nameData[0], 32);

	return nameData;
}

void Player::Update(DWORD dwBaseAddr)
{
	if (!dwBaseAddr)
		return;

	m_dwBaseAddr = dwBaseAddr;

	[swap_lines]
	m_nID = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwEntIndex);
	m_nFlags = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_fFlags);
	m_nHealth = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_iHealth);
	m_nTeam = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_iTeamNum);
	m_nShotsFired = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_iShotsFired);
	m_nSpecTarget = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_iObserverTarget);
	m_nMoveType = pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwMoveType);
	[/swap_lines]

	int clientState = pCSGO->m_Mem.Read<int>(pCSGO->m_dwEngineBase + pCSGO->m_Offsets.m_dwEnginePtr);
	int ecx = pCSGO->m_Mem.Read<int>(clientState + pCSGO->m_Offsets.m_dwPlayerInfo);
	int edx = pCSGO->m_Mem.Read<int>(ecx + 0x3C);
	int eax = pCSGO->m_Mem.Read<int>(edx + 0xC);
	int info = pCSGO->m_Mem.Read<int>(eax + 0x20 + (m_nID - 1) * 0x34);
	pCSGO->m_Mem.Read(info + 0x10, m_tPlayerInfo.name, sizeof(m_tPlayerInfo.name));
	m_tPlayerInfo.userID = Utils::EndianDwordConversion(pCSGO->m_Mem.Read<int>(info + 0x90));
	pCSGO->m_Mem.Read(info + 0x94, m_tPlayerInfo.guid, sizeof(m_tPlayerInfo.guid));

	DWORD m_pModel = pCSGO->m_Mem.Read< DWORD >(m_dwBaseAddr + pCSGO->m_Offsets.m_dwModel);
	pCSGO->m_Mem.Read(m_pModel + 0x4, (LPVOID)&m_szModelName[0], sizeof(m_szModelName));


	[swap_lines]
	m_bAlive = (m_nHealth > 0);
	m_bReloading = (pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_bInReload)) ? true : false;
	m_bDormant = (pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwDormant)) ? true : false;
	m_bScoped = (pCSGO->m_Mem.Read<int>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_bIsScoped)) ? true : false;
	m_bSpawned = (pCSGO->m_Mem.Read<float>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_immuneTime) <= 0.0001f);
	m_bShooting = ((pCSGO->m_Mem.Read<int>(pCSGO->m_dwClientBase + pCSGO->m_Offsets.m_dwAttack) == 5)) ? true : false;
	m_bSpectated = IsBeingSpectated();
	[/swap_lines]


	DWORD baseCombatHandle = pCSGO->m_Mem.Read<DWORD>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_hActiveWeapon);
	baseCombatHandle &= 0xFFF;

	DWORD weapBase = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);
	m_nWeaponID = pCSGO->m_Mem.Read<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_AttributeManager + pCSGO->m_Offsets.m_dwNetvar_Item + pCSGO->m_Offsets.m_dwNetvar_iItemDefinitionIndex);
	m_nAmmo = pCSGO->m_Mem.Read<int>(weapBase + pCSGO->m_Offsets.m_dwNetvar_iClip1);

	[swap_lines]
	m_vecOrigin = pCSGO->m_Mem.Read<Vector>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_vecOrigin);
	m_vecPunchAngles = pCSGO->m_Mem.Read<Vector2D>(dwBaseAddr + pCSGO->m_Offsets.m_dwPunchAngles);
	m_vecViewOffset = pCSGO->m_Mem.Read<Vector>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_vecViewOffset);
	m_vecVelocity = pCSGO->m_Mem.Read<Vector>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_vecVelocity);
	[/swap_lines]

	m_vecEyePos = m_vecOrigin + m_vecViewOffset;
	m_vecViewAngles = pCSGO->m_Mem.Read<Vector>(pCSGO->m_dwAnglePointer + pCSGO->m_Offsets.m_dwViewAngles);

	DWORD boneMat = pCSGO->m_Mem.Read<DWORD>(dwBaseAddr + pCSGO->m_Offsets.m_dwNetvar_boneMatrix);

	if (boneMat)
		pCSGO->m_Mem.Read(boneMat, m_matBone, sizeof(m_matBone));

	m_fDistanceFromMe = (float)abs((m_vecOrigin - pCSGO->m_Me.m_vecOrigin).Length());
}

Vector Player::GetBonePosition(int nBone)
{
	if (nBone < 0 || nBone >= Bone_MAX)
		return Vector(0, 0, 0);

	return Vector(m_matBone[nBone].m[0][3], m_matBone[nBone].m[1][3], m_matBone[nBone].m[2][3]);
}

EWeaponType Player::GetWeaponType()
{
	switch (m_nWeaponID)
	{
		case WID_C4:
		return EWeaponType::WeapType_C4Explosive;

		case WID_Zeus:
		return EWeaponType::WeapType_ZeusGun;

		case WID_Negev:
		case WID_M249:
		return EWeaponType::WeapType_LMG;

		case WID_AWP:
		case WID_G3SG1_Auto:
		case WID_SCAR_Auto:
		case WID_Scout:
		return EWeaponType::WeapType_Sniper;

		case WID_XM1014:
		case WID_MAG7:
		case WID_Nova:
		case WID_SawedOff:
		return EWeaponType::WeapType_Shotgun;

		case WID_Flashbang:
		case WID_Smoke:
		case WID_Firebomb:
		case WID_HEFrag:
		case WID_Molly:
		return EWeaponType::WeapType_Grenade;

		case WID_MAC10:
		case WID_P90:
		case WID_UMP45:
		case WID_PPBizon:
		case WID_MP7:
		case WID_MP9:
		return EWeaponType::WeapType_SMG;

		case WID_Deagle:
		case WID_Dual_Berettas:
		case WID_Five_Seven:
		case WID_USP:
		case WID_Glock:
		case WID_Tec9:
		case WID_P2000:
		case WID_P250:
		case WID_CZ75:
		case WID_Revolver:
		return EWeaponType::WeapType_Pistol;

		case WID_AK47:
		case WID_AUG:
		case WID_FAMAS:
		case WID_M4A4:
		case WID_M4A1S:
		case WID_Galil:
		case WID_SG553:
		return EWeaponType::WeapType_Rifle;

		case WID_Default_Knife:
		case WID_ButterflyKnife:
		case WID_FlipKnife:
		case WID_HuntsmanKnife:
		case WID_M9BayonetKnife:
		case WID_KarambitKnife:
		case WID_FalchionKnife:
		case WID_ShadowDaggerKnife:
		case WID_BayonetKnife:
		case WID_GutKnife:
		case WID_BowieKnife:
		return EWeaponType::WeapType_KnifeType;

		default:
		return (EWeaponType)-1;
	}
}

int Player::GetEnemyTeam()
{
	if (m_nTeam == Team_Terrorists)
		return Team_CounterTerrorists;
	else if (m_nTeam == Team_CounterTerrorists)
		return Team_Terrorists;

	return Team_NoTeam;
}

bool Player::IsBeingSpectated()
{
	for (int i = 0; i < 64; i++)
	{

		if (i == m_nID)
			continue;

		int specTarget = m_nSpecTarget & 0xFFF;

		if (specTarget == m_nID)
			return true;
	}

	return false;
}

Matrix3x4 Player::GetBoneMatrix(int nBone) const
{
	return m_matBone[nBone];
}

Vector Player::GetEyePos() const
{
	return m_vecEyePos;
}

int Player::GetID() const
{
	return m_nID;
}

Vector Player::GetOrigin() const
{
	return m_vecOrigin;
}

Vector Player::GetVelocity() const
{
	return m_vecVelocity;
}

Vector Player::GetViewAngles() const
{
	return m_vecViewAngles;
}

Vector2D Player::GetPunchAngles() const
{
	return m_vecPunchAngles;
}

std::string Player::GetName() const
{
	return std::string(m_tPlayerInfo.name);
}

std::string Player::GetModelName() const
{
	return std::string(m_szModelName);
}

std::vector<mstudiobbox_t> Player::GetHitboxes() const
{
	return m_vHitboxes;
}

float Player::GetDistanceFromMe() const
{
	return m_fDistanceFromMe;
}

int Player::GetFlags() const
{
	return m_nFlags;
}

int Player::GetTeam() const
{
	return m_nTeam;
}

int Player::GetHealth() const
{
	return m_nHealth;
}

int Player::GetWeaponID() const
{
	return m_nWeaponID;
}

int Player::GetAmmo() const
{
	return m_nAmmo;
}

int Player::GetShotsFired() const
{
	return m_nShotsFired;
}

int Player::GetMoveType() const
{
	return m_nMoveType;
}

bool Player::IsAlive() const
{
	return m_bAlive;
}

bool Player::IsDormant() const
{
	return m_bDormant;
}

bool Player::IsReloading() const
{
	return m_bReloading;
}

bool Player::IsShooting() const
{
	return m_bShooting;
}

bool Player::IsScoped() const
{
	return m_bScoped;
}

bool Player::IsSpawned() const
{
	return m_bSpawned;
}

bool Player::Valid()
{

	if (m_dwBaseAddr == NULL || m_bDormant || !m_bAlive)
		return false;

	if (pCSGO->m_Config.m_TriggerSettings.m_bDeathmatch && !m_bSpawned)
		return false;

	return true;
}

bool Player::IsVisible(int nBone)
{
	std::future<bool> ret = std::async(std::launch::async, &BSP::IsVisible, pBSP, pCSGO->m_Me.GetEyePos(), GetBonePosition(nBone));
	return ret.get();
}