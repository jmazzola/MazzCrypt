#include "Netvars.h"
#include "Utils.h"

namespace Netvars
{
	DWORD GetNetVar(const char* szClassName, const char* szNetVar)
	{
		ClientClass* pClass = (ClientClass*)pCSGO->m_Offsets.m_dwNetvarClasses;

		if (!pClass)
		{
			return NULL;
		}

		for (; pClass; pClass = pClass->GetNextClass())
		{
			if (strcmp(szClassName, pClass->GetTable()->GetTableName()))
				continue;

			for (int i = 0; i < pClass->GetTable()->GetMaxProp(); i++)
			{
				CRecvTable::CRecvProp* pRecvProp = pClass->GetTable()->GetProperty(i);

				if (isdigit(pRecvProp->GetVarName()[0]))
					continue;

				if (!strcmp(pRecvProp->GetVarName(), szNetVar))
				{
					return pRecvProp->GetOffset();
				}

				if (!pRecvProp->GetDataTable())
					continue;

				for (int j = 0; j < pRecvProp->GetDataTable()->GetMaxProp(); ++j)
				{
					CRecvTable::CRecvProp* pRecvProp2 = pRecvProp->GetDataTable()->GetProperty(j);

					if (isdigit(pRecvProp2->GetVarName()[0]))
						continue;

					if (!strcmp(pRecvProp2->GetVarName(), szNetVar))
					{
						return pRecvProp2->GetOffset();
					}

					if (!pRecvProp2->GetDataTable())
						continue;

					for (int k = 0; k < pRecvProp2->GetDataTable()->GetMaxProp(); ++k)
					{
						CRecvTable::CRecvProp* pRecvProp3 = pRecvProp2->GetDataTable()->GetProperty(k);

						if (isdigit(pRecvProp3->GetVarName()[0]))
							continue;

						if (!strcmp(pRecvProp3->GetVarName(), szNetVar))
						{
							return pRecvProp3->GetOffset();
						}
					}
				}
			}
		}

		return NULL;
	}
}