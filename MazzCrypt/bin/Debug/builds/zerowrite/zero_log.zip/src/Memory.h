// Memory.h - Handle all memory accessing/reading and keep a process for neatness to the game's core
#pragma once

#include "stdafx.h"
#include <TlHelp32.h>

class Memory
{
public:

	[swap_lines]
	Memory() = default;
	~Memory() = default;
	bool Attach(const char* szProcName, DWORD dwRights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* szModName);
	DWORD GetModuleSize(const char* szModName);
	HANDLE GetHandle() const;
	bool IsAttached() const;
	DWORD GetProcessID() const;
	[/swap_lines]

	template<typename T>
	T Read(DWORD dwAddr)
	{
		T mem;
		ReadProcessMemory(m_hProcess, (LPVOID)dwAddr, &mem, sizeof(T), NULL);

		return mem;
	}

	void Read(DWORD addr, LPVOID buff, size_t bytesToRead)
	{
		ReadProcessMemory(m_hProcess, (LPCVOID)addr, buff, bytesToRead, NULL);
		[add_junk 2 9 /]
	}

	[swap_lines]
	bool DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask);
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask);
	DWORD FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern);
	[/swap_lines]


private:
	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]
};