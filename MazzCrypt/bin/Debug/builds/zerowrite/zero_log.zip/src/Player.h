// Player.h - A CSGO Player and their information
#pragma once

#include "stdafx.h"
#include "Math.h"
#include "Vector.h"
#include "Matrix3x4.h"
#include "Enums.h"

#include "Hitboxes.h"

class player_info_t
{
public:

	char			name[32];
	int				userID;
	char			guid[33];
	__int32			friendsID;
	char			friendsName[32];
	bool			fakeplayer;
	bool			ishltv;
	unsigned long	customFiles[4];
	unsigned char	filesDownloaded;
	char			Pad[200];
};


class Player
{
public: 

	[swap_lines]
	Player() = default;
	~Player() = default;
	int GetClassID();
	[/swap_lines]

#undef GetClassName
	char* GetClassName();

	[swap_lines]
	void Update(DWORD dwBaseAddr);
	Vector GetBonePosition(int nBone);
	Matrix3x4 GetBoneMatrix(int nBone) const;
	EWeaponType GetWeaponType();
	int GetEnemyTeam();
	bool IsBeingSpectated();
	Vector GetEyePos() const;
	Vector GetOrigin() const;
	Vector GetVelocity() const;
	Vector GetViewAngles() const;
	Vector2D GetPunchAngles() const;
	std::string GetName() const;
	std::string GetModelName() const;
	std::vector<mstudiobbox_t> GetHitboxes() const;
	float GetDistanceFromMe() const;
	int GetID() const;
	int GetFlags() const;
	int GetTeam() const;
	int GetHealth() const;
	int GetWeaponID() const;
	int GetAmmo() const;
	int GetShotsFired() const;
	int GetMoveType() const;
	bool IsAlive() const;
	bool IsDormant() const;
	bool IsReloading() const;
	bool IsShooting() const;
	bool IsScoped() const;
	bool IsSpawned() const;
	bool Valid();
	bool IsVisible(int nBone);
	[/swap_lines]


public:

	[swap_lines]
	DWORD m_dwBaseAddr;
	float m_fDistanceFromMe;
	Matrix3x4 m_matBone[128];
	Vector m_vecOrigin;
	Vector m_vecViewAngles;
	Vector m_vecVelocity;
	Vector m_vecViewOffset;
	Vector m_vecEyePos;
	Vector2D m_vecPunchAngles;
	Vector2D m_vecOldPunchAngles;
	player_info_t m_tPlayerInfo;
	std::vector<mstudiobbox_t> m_vHitboxes;
	char m_szModelName[0x80];
	int m_nID;
	int m_nSpecTarget;
	int m_nFlags;
	int m_nTeam;
	int m_nHealth;
	int m_nWeaponID;
	int m_nAmmo;
	int m_nShotsFired;
	int m_nMoveType;
	bool m_bAlive;
	bool m_bReloading;
	bool m_bShooting;
	bool m_bDormant;
	bool m_bScoped;
	bool m_bSpawned;
	bool m_bSpectated;
	[/swap_lines]
};