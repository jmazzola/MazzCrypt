#include "Mouse.h"

namespace Mouse
{
	void Move(float x, float y)
	{
		INPUT input = { 0 };
		
		[swap_lines]
		input.type = INPUT_MOUSE;
		input.mi.dx = (LONG)x;
		input.mi.dy = (LONG)y;
		input.mi.dwFlags = MOUSEEVENTF_MOVE;
		[/swap_lines]
		
		SendInput(1, &input, sizeof(INPUT));
	}

	void Click(int type)
	{
		INPUT input = { 0 };

		[swap_lines]
		input.type = INPUT_MOUSE;
		input.mi.dwFlags = type;
		[/swap_lines]

		SendInput(1, &input, sizeof(INPUT));
	}
}