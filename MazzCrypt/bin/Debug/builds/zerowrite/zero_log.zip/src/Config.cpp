#include "Config.h"
#include "Utils.h"
#include "Enums.h"
#include <Wincrypt.h>
#include <cctype>
#include <algorithm>
#include <sstream>

#include "Decrypt.h"

[enc_string_enable /]

#define SECTION_TRIGGERBOT "triggerbot"
#define SECTION_TRIGGERBOT_PISTOLS "trigger_pistols"
#define SECTION_TRIGGERBOT_RIFLES "trigger_rifles"
#define SECTION_TRIGGERBOT_SMGS "trigger_smgs"
#define SECTION_TRIGGERBOT_LMGS "trigger_lmgs"
#define SECTION_TRIGGERBOT_SNIPERS "trigger_snipers"
#define SECTION_TRIGGERBOT_SHOTGUNS "trigger_shotguns"


void Config::Init(std::string szConfigName)
{
	[swap_lines]
	m_szConfigFile = szConfigName;
	m_TriggerSettings.m_bActive = true;
	m_TriggerSettings.m_bKeyHeld = true;
	m_TriggerSettings.m_bDeathmatch = true;
	m_TriggerSettings.m_bSniperMode = true;
	m_TriggerSettings.m_bKnifebot = true;
	m_TriggerSettings.m_bAntiSpectate = true;
	m_TriggerSettings.m_bAntiJump = false;
	m_TriggerSettings.m_nDelayBefore = 10;
	m_TriggerSettings.m_nDelayAfter = 10;
	m_TriggerSettings.m_nKey = VK_XBUTTON1;
	m_TriggerSettings.m_nToggleKey = VK_NUMPAD5;
	m_TriggerSettings.m_nMethod = Trigger_Hitbox;
	m_TriggerSettings.m_nTargetType = TargetType_Enemies;
	[/swap_lines]
}


[enc_string_disable /]
std::string Config::GetHash()
{
	HANDLE hFile = CreateFile(m_szConfigFile.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	HCRYPTPROV hProv;
	HCRYPTHASH hHash;

	DWORD cbHash = 16;
	BYTE rgbHash[16];
	CHAR rgbDigits[] = "0123456789abcdef";

[enc_string_enable /]

	if (hFile == INVALID_HANDLE_VALUE)
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error reading in .ini"));
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
	}

	BOOL bResult = FALSE;
	DWORD cbRead;
	BYTE rgbFile[1024];

	while (bResult = ReadFile(hFile, rgbFile, 1024, &cbRead, NULL))
	{
		if (!cbRead)
		{
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			int dwStatus = GetLastError();
			Utils::PrintLine(std::string("Error with CryptHashData"));
			CryptReleaseContext(hProv, 0);
			CryptDestroyHash(hHash);
			CloseHandle(hFile);
			return std::string("ERROR");
		}
	}

	if (!bResult)
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("ReadFile failed"));
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);
		}
	}

	CryptReleaseContext(hProv, 0);
	CryptDestroyHash(hHash);
	CloseHandle(hFile);

	return hashOutput;
}


bool Config::LoadConfig()
{
	m_szHash = GetHash();

	[swap_lines]
	m_TriggerSettings.m_bActive = GetBool(SECTION_TRIGGERBOT, "activated");
	m_TriggerSettings.m_bKeyHeld = GetBool(SECTION_TRIGGERBOT, "holdkey");
	m_TriggerSettings.m_bDeathmatch = GetBool(SECTION_TRIGGERBOT, "deathmatch_mode");
	m_TriggerSettings.m_bSniperMode = GetBool(SECTION_TRIGGERBOT, "sniper_mode");
	m_TriggerSettings.m_bRevolverMode = GetBool(SECTION_TRIGGERBOT, "revolver_mode");
	m_TriggerSettings.m_bAntiSpectate = GetBool(SECTION_TRIGGERBOT, "anti_spectate");
	m_TriggerSettings.m_bAntiJump = GetBool(SECTION_TRIGGERBOT, "anti_jumping");
	m_TriggerSettings.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT, "delay_before");
	m_TriggerSettings.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT, "delay_after");
	m_TriggerSettings.m_nKey = GetInt(SECTION_TRIGGERBOT, "key");
	m_TriggerSettings.m_nToggleKey = GetInt(SECTION_TRIGGERBOT, "togglekey");
	m_TriggerSettings.m_nMethod = GetInt(SECTION_TRIGGERBOT, "trigger_type");
	m_TriggerSettings.m_nTargetType = GetInt(SECTION_TRIGGERBOT, "target_type");
	m_TriggerSettings.m_tPistols.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_PISTOLS, "hitboxes");
	m_TriggerSettings.m_tPistols.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_PISTOLS, "delay_before");
	m_TriggerSettings.m_tPistols.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_PISTOLS, "delay_after");
	m_TriggerSettings.m_tPistols.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_PISTOLS, "rcs_scale");
	m_TriggerSettings.m_tRifles.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_RIFLES, "hitboxes");
	m_TriggerSettings.m_tRifles.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_RIFLES, "delay_before");
	m_TriggerSettings.m_tRifles.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_RIFLES, "delay_after");
	m_TriggerSettings.m_tRifles.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_RIFLES, "rcs_scale");
	m_TriggerSettings.m_tSMGs.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_SMGS, "hitboxes");
	m_TriggerSettings.m_tSMGs.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_SMGS, "delay_before");
	m_TriggerSettings.m_tSMGs.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_SMGS, "delay_after");
	m_TriggerSettings.m_tSMGs.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_SMGS, "rcs_scale");
	m_TriggerSettings.m_tLMGs.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_LMGS, "hitboxes");
	m_TriggerSettings.m_tLMGs.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_LMGS, "delay_before");
	m_TriggerSettings.m_tLMGs.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_LMGS, "delay_after");
	m_TriggerSettings.m_tLMGs.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_LMGS, "rcs_scale");
	m_TriggerSettings.m_tSnipers.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_SNIPERS, "hitboxes");
	m_TriggerSettings.m_tSnipers.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_SNIPERS, "delay_before");
	m_TriggerSettings.m_tSnipers.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_SNIPERS, "delay_after");
	m_TriggerSettings.m_tSnipers.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_SNIPERS, "rcs_scale");
	m_TriggerSettings.m_tShotguns.m_hitboxes = GetCommaSeperatedInts(SECTION_TRIGGERBOT_SHOTGUNS, "hitboxes");
	m_TriggerSettings.m_tShotguns.m_nDelayBefore = GetInt(SECTION_TRIGGERBOT_SHOTGUNS, "delay_before");
	m_TriggerSettings.m_tShotguns.m_nDelayAfter = GetInt(SECTION_TRIGGERBOT_SHOTGUNS, "delay_after");
	m_TriggerSettings.m_tShotguns.m_fRCSScale = GetFloat(SECTION_TRIGGERBOT_SHOTGUNS, "rcs_scale");
	[/swap_lines]

	return true;
}


bool Config::SaveConfig()
{
	[swap_lines]
	SetBool(SECTION_TRIGGERBOT, "activated", m_TriggerSettings.m_bActive);
	SetBool(SECTION_TRIGGERBOT, "holdkey", m_TriggerSettings.m_bKeyHeld);
	SetBool(SECTION_TRIGGERBOT, "deathmatch_mode", m_TriggerSettings.m_bDeathmatch);
	SetBool(SECTION_TRIGGERBOT, "sniper_mode", m_TriggerSettings.m_bSniperMode);
	SetBool(SECTION_TRIGGERBOT, "revolver_mode", m_TriggerSettings.m_bRevolverMode);
	SetBool(SECTION_TRIGGERBOT, "anti_spectate", m_TriggerSettings.m_bAntiSpectate);
	SetBool(SECTION_TRIGGERBOT, "anti_jumping", m_TriggerSettings.m_bAntiJump);
	SetInt(SECTION_TRIGGERBOT, "delay_before", m_TriggerSettings.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT, "delay_after", m_TriggerSettings.m_nDelayAfter);
	SetInt(SECTION_TRIGGERBOT, "key", m_TriggerSettings.m_nKey);
	SetInt(SECTION_TRIGGERBOT, "togglekey", m_TriggerSettings.m_nToggleKey);
	SetInt(SECTION_TRIGGERBOT, "trigger_type", m_TriggerSettings.m_nMethod);
	SetInt(SECTION_TRIGGERBOT, "target_type", m_TriggerSettings.m_nTargetType);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_PISTOLS, "hitboxes", m_TriggerSettings.m_tPistols.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_PISTOLS, "delay_before", m_TriggerSettings.m_tPistols.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_PISTOLS, "delay_after", m_TriggerSettings.m_tPistols.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_PISTOLS, "rcs_scale", m_TriggerSettings.m_tPistols.m_fRCSScale);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_RIFLES, "hitboxes", m_TriggerSettings.m_tRifles.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_RIFLES, "delay_before", m_TriggerSettings.m_tRifles.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_RIFLES, "delay_after", m_TriggerSettings.m_tRifles.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_RIFLES, "rcs_scale", m_TriggerSettings.m_tRifles.m_fRCSScale);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_SMGS, "hitboxes", m_TriggerSettings.m_tSMGs.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_SMGS, "delay_before", m_TriggerSettings.m_tSMGs.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_SMGS, "delay_after", m_TriggerSettings.m_tSMGs.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_SMGS, "rcs_scale", m_TriggerSettings.m_tSMGs.m_fRCSScale);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_LMGS, "hitboxes", m_TriggerSettings.m_tLMGs.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_LMGS, "delay_before", m_TriggerSettings.m_tLMGs.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_LMGS, "delay_after", m_TriggerSettings.m_tLMGs.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_LMGS, "rcs_scale", m_TriggerSettings.m_tLMGs.m_fRCSScale);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_SNIPERS, "hitboxes", m_TriggerSettings.m_tSnipers.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_SNIPERS, "delay_before", m_TriggerSettings.m_tSnipers.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_SNIPERS, "delay_after", m_TriggerSettings.m_tSnipers.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_SNIPERS, "rcs_scale", m_TriggerSettings.m_tSnipers.m_fRCSScale);
	SetCommaSeperatedInts(SECTION_TRIGGERBOT_SHOTGUNS, "hitboxes", m_TriggerSettings.m_tShotguns.m_hitboxes);
	SetInt(SECTION_TRIGGERBOT_SHOTGUNS, "delay_before", m_TriggerSettings.m_tShotguns.m_nDelayBefore);
	SetInt(SECTION_TRIGGERBOT_SHOTGUNS, "delay_after", m_TriggerSettings.m_tShotguns.m_nDelayAfter);
	SetFloat(SECTION_TRIGGERBOT_SHOTGUNS, "rcs_scale", m_TriggerSettings.m_tShotguns.m_fRCSScale);
	[/swap_lines]

	return true;
}


int Config::GetInt(char* section, char* option)
{
	return GetPrivateProfileIntA(section, option, NULL, m_szConfigFile.c_str());
}


float Config::GetFloat(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return (float)atof(val);
}


std::string Config::GetString(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return std::string(val);
}


bool Config::GetBool(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return (!_stricmp(val, "on"));
}

std::vector<int> Config::GetCommaSeperatedInts(char * section, char * option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	std::string str(val);

	std::vector<int> vec;
	std::stringstream ss(str);
	int i;

	while (ss >> i)
	{
		vec.push_back(i);

		if (ss.peek() == ',' || ss.peek() == ' ')
			ss.ignore();
	}

	return vec;
}

void Config::SetInt(char* section, char* option, int nValue)
{
	char val[255];
	sprintf_s(val, " %d", nValue);
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetFloat(char* section, char* option, float fValue)
{
	char val[255];
	sprintf_s(val, " %2.1f", fValue );
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetString(char* section, char* option, std::string szValue)
{
	WritePrivateProfileStringA(section, option, szValue.c_str(),  m_szConfigFile.c_str());
}

void Config::SetBool(char* section, char* option, bool bValue)
{
	char val[255];
	sprintf_s(val, "%s", bValue ? " on" : " off");
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetCommaSeperatedInts(char * section, char * option, std::vector<int> vValue)
{
	std::string input = " ";
	
	for (size_t i = 0; i < vValue.size(); i++)
	{
		if (i == vValue.size() - 1)
			input += std::to_string(i);
		else
			input += std::to_string(i) + ",";
	}

	WritePrivateProfileStringA(section, option, input.c_str(), m_szConfigFile.c_str());
}


[enc_string_disable /]