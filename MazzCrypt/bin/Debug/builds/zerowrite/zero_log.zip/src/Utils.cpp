#include "Utils.h"

#include "Decrypt.h"

namespace Utils
{
	std::string GenerateRandomString(int nLength)
	{
		static const char charset[] =
			"0123456789"
			"!@#$%^&*"
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			"abcdefghijklmnopqrstuvwxyz";

		std::string str;

		for (int i = 0; i < nLength; i++)
			str += charset[rand() % sizeof(charset) - 1];

		return str;
	}

	void SetRandomWindowTitle(int nLength)
	{
		SetConsoleTitleA(GenerateRandomString(nLength).c_str());
	}

	void PrintLine(std::string input)
	{
		printf("%s\n", input.c_str());
	}
	
	[enc_string_enable /]
	void AllowDebugging()
	{
		HANDLE hProcess = GetCurrentProcess();
		[add_junk 1 5 /]
		HANDLE hToken;
		TOKEN_PRIVILEGES tkPriv;
		LUID luid;

		OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES, &hToken);
		LookupPrivilegeValueA(NULL, "seDebugPrivilege", &luid);

		tkPriv.PrivilegeCount = 1;
		tkPriv.Privileges[0].Luid = luid;
		tkPriv.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

		AdjustTokenPrivileges(hToken, FALSE, &tkPriv, NULL, NULL, NULL);

		CloseHandle(hToken);
		CloseHandle(hProcess);
	}

	[enc_string_disable /]

	void DeleteSelf(char* szProgramPath)
	{
		char* batPath = new char[strlen(szProgramPath) + 5];
		strcpy_s(batPath, strlen(szProgramPath) + 5, szProgramPath);
		strcat_s(batPath, strlen(szProgramPath) + 5, ".bat");

		const char* batFormat = 
			":Repeat\n"
			"del \"%s\"\n"
			"if exist \"%s\" goto Repeat\n"
			"del \"%s\"\n";

		int size = strlen(batPath) + strlen(batFormat) + strlen(szProgramPath) * 2;
		char* batFile = new char[size];
		sprintf_s(batFile, size, batFormat, szProgramPath, szProgramPath, batPath);

		FILE* file;
		fopen_s(&file, batPath, "w");

		if (file)
		{
			fwrite(batFile, strlen(batFile), 1, file);
			fclose(file);
		}

		STARTUPINFOA startupInfo;
		PROCESS_INFORMATION procInfo;
		memset(&startupInfo, NULL, sizeof(startupInfo));

		startupInfo.cb = sizeof(startupInfo);

		CreateProcessA(batPath, NULL, NULL, NULL, FALSE, NULL, NULL, NULL, &startupInfo, &procInfo);

		delete[] batFile;
		delete[] batPath;
	}

	bool DoesCSGOExist()
	{
		HWND hwnd = GetGameWindow();
		return (hwnd != NULL);
	}

[enc_string_enable /]
	HWND GetGameWindow()
	{
		return FindWindowA(NULL, "Counter-Strike: Global Offensive");
	}

	void DisableQuickEdit()
	{
		HANDLE hConsole = GetStdHandle(STD_INPUT_HANDLE);
		DWORD dwConsoleMode;
		
		GetConsoleMode(hConsole, &dwConsoleMode);
		dwConsoleMode &= ~ENABLE_QUICK_EDIT_MODE;
		SetConsoleMode(hConsole, dwConsoleMode);
	}

	void MakeMinidump(_EXCEPTION_POINTERS *e)
	{
		char dumpName[MAX_PATH];

		SYSTEMTIME t;
		GetSystemTime(&t);
		wsprintf(dumpName, "zerowrite_%4d%02d%02d_%02d%02d%02d.dmp", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);

		auto hFile = CreateFile(dumpName, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

		if (hFile == INVALID_HANDLE_VALUE)
			return;

		MINIDUMP_EXCEPTION_INFORMATION info;
		info.ThreadId = GetCurrentThreadId();
		info.ExceptionPointers = e;
		info.ClientPointers = FALSE;

		char msg[MAX_PATH];

		if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpWithIndirectlyReferencedMemory, (e ? &info : nullptr), nullptr, nullptr))
		{
			LOGD << "Crashdump was created! : " << dumpName;
			sprintf(msg, "Crashdump created: '%s'\nPlease contact ChocolatePC with this ASAP.", dumpName);
			MessageBox(NULL, msg, "Crash!", MB_OK);
		}
		else
		{
			LOGE << "Unable to create the crashdump! Error:" << GetLastError();
			sprintf(msg, "Unable to create crashdump!\nPlease contact ChocolatePC with this:\n Error %d", GetLastError());
			MessageBox(NULL, msg, "Crash!", MB_OK);
		}

		CloseHandle(hFile);
	}

	LONG WINAPI unhandled_handler(_EXCEPTION_POINTERS* e)
	{
		MakeMinidump(e);
		return EXCEPTION_CONTINUE_SEARCH;
	}

	void SetUpMinidump()
	{
		SetUnhandledExceptionFilter(unhandled_handler);
	}

	unsigned int EndianDwordConversion(unsigned int dwDword)
	{
		return ((dwDword >> 24) & 0x000000FF) | ((dwDword >> 8) & 0x0000FF00) | ((dwDword << 8) & 0x00FF0000) | ((dwDword << 24) & 0xFF000000);
	}
}

[enc_string_disable /]