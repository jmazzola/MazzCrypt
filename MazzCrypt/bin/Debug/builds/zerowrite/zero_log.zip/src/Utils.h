// Utils.h - Misc utilities needed
#pragma once

#include "stdafx.h"

#define clamp(val, a, b) { if(val < a) val = a; if(val > b) val = b; }

namespace Utils
{
	[swap_lines]
	std::string GenerateRandomString(int nLength = 15);
	void SetRandomWindowTitle(int nLength = 15);
	void PrintLine(std::string input);
	void PrintLineFormatted(std::string input, ...);
	void AllowDebugging();
	void DeleteSelf(char* szProgramPath);
	bool DoesCSGOExist();
	HWND GetGameWindow();
	void DisableQuickEdit();
	void SetUpMinidump();
	unsigned int EndianDwordConversion(unsigned int dwDword);
	[/swap_lines]
}
