// Triggerbot.h - Triggerbot cheat thread
#pragma once

#include "stdafx.h"
#include "CSGO.h"
#include "Player.h"
#include "Utils.h"
#include "Enums.h"
#include "Mouse.h"
#include "Math.h"
#include "Ray.h"
#include "Config.h"

#include "RCS.h"

#include "Hitboxes.h"

class Triggerbot
{
public:

	Triggerbot() = default;
	~Triggerbot() = default;

	void GetWeaponSettings(TriggerWeaponSettings& tWeap)
	{
		switch (pCSGO->m_Me.GetWeaponType())
		{
			case WeapType_Pistol:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tPistols.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tPistols.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tPistols.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tPistols.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WeapType_Rifle:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tRifles.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tRifles.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tRifles.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tRifles.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WeapType_SMG:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tSMGs.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tSMGs.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tSMGs.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tSMGs.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WeapType_LMG:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tLMGs.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tLMGs.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tLMGs.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tLMGs.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WeapType_Sniper:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tSnipers.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tSnipers.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tSnipers.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tSnipers.m_fRCSScale;
				[/swap_lines]

				break;
			}

			case WeapType_Shotgun:
			{
				[swap_lines]
				tWeap.m_hitboxes = pCSGO->m_Config.m_TriggerSettings.m_tShotguns.m_hitboxes;
				tWeap.m_nDelayBefore = pCSGO->m_Config.m_TriggerSettings.m_tShotguns.m_nDelayBefore;
				tWeap.m_nDelayAfter = pCSGO->m_Config.m_TriggerSettings.m_tShotguns.m_nDelayAfter;
				tWeap.m_fRCSScale = pCSGO->m_Config.m_TriggerSettings.m_tShotguns.m_fRCSScale;
				[/swap_lines]

				break;
			}

			default:
				break;
		}

		pRCS->m_fRCSScale = tWeap.m_fRCSScale;
	}

	Player* GetPlayerInCross() const
	{
		DWORD xhairID = pCSGO->m_Mem.Read<DWORD>(pCSGO->m_dwLocalBase + pCSGO->m_Offsets.m_dwCrosshairIndex);

		for (int i = 1; i < 64; i++)
		{
			Player* ply = &pCSGO->m_Players[i];

			if (!ply->Valid())
				continue;

			bool bEnemy = (pCSGO->m_Me.GetTeam() == ply->GetEnemyTeam());

			if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Enemies) && !bEnemy)
				continue;
			else if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Teammates) && bEnemy)
				continue;

			if (ply->GetID() == xhairID)
			{
				if (pCSGO->m_Config.m_TriggerSettings.m_bAntiJump && !(ply->GetFlags() & FL_ONGROUND) && (ply->GetMoveType() != EMoveType::MOVETYPE_LADDER))
					return nullptr;

				return ply;
			}
		}

		return nullptr;
	}

	Player* GetPlayerInRay(std::vector<int> hitboxes) const
	{
		for (int i = 1; i < 64; i++)
		{
			Vector viewDirection = Math::AngleToDirection(pCSGO->m_Me.GetViewAngles());
			Ray viewRay(pCSGO->m_Me.GetEyePos(), viewDirection);
			float distance;

			Player* ply = &pCSGO->m_Players[i];

			bool bEnemy = (pCSGO->m_Me.GetTeam() == ply->GetEnemyTeam());

			if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Enemies) && !bEnemy)
				continue;
			else if ((pCSGO->m_Config.m_TriggerSettings.m_nTargetType == TargetType_Teammates) && bEnemy)
				continue;

			if (!ply->Valid())
				continue;

			if (ply->GetHitboxes().empty())
				return nullptr;

			for (size_t i = 0; i < hitboxes.size(); i++)
			{
				int numHitbox = hitboxes[i];
				auto hitbox = ply->GetHitboxes()[numHitbox];

				if (!ply->IsVisible(hitbox.m_iBone))
				{
					continue;
				}

				if (viewRay.IntersectsWithOBB(ply->GetBoneMatrix(hitbox.m_iBone), hitbox.m_vecBBMin, hitbox.m_vecBBMax, distance))
				{
					return ply;
				}
			}
		}

		return nullptr;
	}

	void Shoot(int delayBefore, int delayAfter)
	{
		if (pCSGO->m_Config.m_TriggerSettings.m_bSniperMode)
		{
			if(pCSGO->m_Me.GetWeaponType() == EWeaponType::WeapType_Sniper && !pCSGO->m_Me.m_bScoped)
				return;
		}

		if (pCSGO->m_Config.m_TriggerSettings.m_bAntiSpectate && pCSGO->m_Me.m_bSpectated)
			return;

		std::this_thread::sleep_for(std::chrono::milliseconds(delayBefore));
		Mouse::Click(MOUSEEVENTF_LEFTDOWN);

		if (pCSGO->m_Config.m_TriggerSettings.m_bRevolverMode && pCSGO->m_Me.GetWeaponID() == WID_Revolver)
			std::this_thread::sleep_for(std::chrono::seconds(1));
		else
			std::this_thread::sleep_for(std::chrono::milliseconds(delayAfter));

		Mouse::Click(MOUSEEVENTF_LEFTUP);
	}

	bool IsBehindTarget(Player* pTarget)
	{
		Vector vecLOS = pTarget->GetOrigin() - pCSGO->m_Me.GetOrigin();
		vecLOS.Normalize();

		Vector vTargetForward;
		Math::AngleVectors(pTarget->GetViewAngles(), &vTargetForward);
		vTargetForward.z = 0.0f;

		return vecLOS.DotProduct(vTargetForward) > 0.475f;
	}

	void Knifebot(Player* pPlayer)
	{

		if (pPlayer->GetDistanceFromMe() <= 85.0f)
		{
			printf("%d Health\n", pPlayer->GetHealth());

			if (pPlayer->GetHealth() <= 55)
			{
				Mouse::Click(MOUSEEVENTF_RIGHTDOWN);
				std::this_thread::sleep_for(std::chrono::milliseconds(10));
				Mouse::Click(MOUSEEVENTF_RIGHTUP);
			}
			else
			{
				Mouse::Click(MOUSEEVENTF_LEFTDOWN);
				std::this_thread::sleep_for(std::chrono::milliseconds(10));
				Mouse::Click(MOUSEEVENTF_LEFTUP);
			}
		}
	}

	void DisableRCS()
	{
		pRCS->m_bActive = false;
	}

	void EnableRCS()
	{
		pRCS->m_bActive = true;
	}

	void Start()
	{
		LOGD << "Triggerbot thread started!";

		while (!pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot)
		{
			if (GetForegroundWindow() != Utils::GetGameWindow())
				continue;

			if (GetAsyncKeyState(VK_END))
				pCSGO->m_Config.m_ThreadSettings.m_bStopTriggerbot = true;

			bool bKeyCircumstance;

			(pCSGO->m_Config.m_TriggerSettings.m_bKeyHeld) 
				? bKeyCircumstance = (GetAsyncKeyState(pCSGO->m_Config.m_TriggerSettings.m_nKey) & 0x8000) 
				: bKeyCircumstance = (pCSGO->m_Config.m_TriggerSettings.m_bActive);

			if (!bKeyCircumstance)
			{
				DisableRCS();
				continue;
			}

			if (pCSGO->m_Me.IsShooting())
				continue;

			EnableRCS();

			Player* pTarget = nullptr;

			TriggerWeaponSettings tWeap;
			GetWeaponSettings(tWeap);

			switch (pCSGO->m_Config.m_TriggerSettings.m_nMethod)
			{
				case Trigger_InCross:
				{
					pTarget = GetPlayerInCross();
					break;
				}
				case Trigger_Hitbox:
				{
					pTarget = GetPlayerInRay(tWeap.m_hitboxes);
					break;
				}
			}

			if (pTarget == nullptr || !pCSGO->m_Me.GetAmmo() || pCSGO->m_Me.IsReloading())
				continue;

			Shoot(tWeap.m_nDelayBefore, tWeap.m_nDelayAfter);
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
		
		LOGD << "Triggerbot thread ended!";
	}
};