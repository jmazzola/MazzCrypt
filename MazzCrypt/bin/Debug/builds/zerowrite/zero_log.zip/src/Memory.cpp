#include "Memory.h"

bool Memory::Attach(const char* szProcName, DWORD dwRights)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szExeFile, (LPSTR)szProcName))
		{
			m_dwProcessID = entry.th32ProcessID;
			CloseHandle(handle);
			m_hProcess = OpenProcess(dwRights, false, m_dwProcessID);
			m_bAttached = true;

			return true;
		}

	} while (Process32Next(handle, (LPPROCESSENTRY32)&entry));

	return false;
}

void Memory::Detach()
{
	CloseHandle(m_hProcess);

	[swap_lines]
	m_bAttached = false;
	m_dwProcessID = -1;
	[/swap_lines]
}


DWORD Memory::GetModuleBase(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			return (DWORD)entry.modBaseAddr;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	return NULL;
}


DWORD Memory::GetModuleSize(const char* szModName)
{
	HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, m_dwProcessID);
	MODULEENTRY32 entry;
	entry.dwSize = sizeof(entry);

	do
	{
		if (!strcmp(entry.szModule, (LPSTR)szModName))
		{
			CloseHandle(handle);
			return (DWORD)entry.modBaseSize;
		}

	} while (Module32Next(handle, (LPMODULEENTRY32)&entry));

	return NULL;
}

HANDLE Memory::GetHandle() const
{
	if (!m_bAttached)
		return NULL;

	return m_hProcess;
}

bool Memory::IsAttached() const
{
	return m_bAttached;
}


DWORD Memory::GetProcessID() const
{
	return m_dwProcessID;
}


bool Memory::DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* szMask)
{
	for (; *szMask; ++szMask, ++pbData, ++pbMask)
	{
		if (*szMask == 'z' && *pbData != *pbMask)
			return false;
	}

	return (*szMask == NULL);
}

DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask)
{
	PBYTE data = new BYTE[dwSize];

	unsigned long bytesRead;

	if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead))
	{
		delete[] data;
		data = nullptr;
		return NULL;
	}

	for (DWORD i = 0; i < dwSize; i++)
	{
		if (DataCompare((const BYTE*)(data + i), szSig, szMask))
		{
			delete[] data;
			data = nullptr;
			return dwStart + i;
		}
	}

	delete[] data;
	data = nullptr;
	return NULL;
}


DWORD Memory::FindPattern(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pbPattern)
{
	std::string szMask;
	szMask.resize(nCount);

	for (int i = 0; i < nCount; i++)
		(pbPattern[i]) ? szMask[i] = 'z' : szMask[i] = '?';

	return FindPattern(dwStart, dwSize, pbPattern, szMask.c_str());
}