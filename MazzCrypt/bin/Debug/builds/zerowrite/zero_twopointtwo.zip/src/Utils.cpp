#include "Utils.h"

#include "Decrypt.h"

[junk_enable /]

namespace Utils
{
	// Generate a random string using a charset
	// [in] nLength - The amount of characters the string returned will be
	std::string GenerateRandomString(int nLength)
	{
		static const char charset[] =
			"0123456789"
			"!@#$%^&*"
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			"abcdefghijklmnopqrstuvwxyz";

		std::string str;

		[add_junk 1 4 /]

		for (int i = 0; i < nLength; i++)
			str += charset[rand() % sizeof(charset) - 1];

		return str;
	}

	// Set the window title to a random string
	// [in] - nLength - The amount of characters the window title will be
	void SetRandomWindowTitle(int nLength)
	{
		SetConsoleTitleA(GenerateRandomString(nLength).c_str());
		[add_junk 1 4 /]
	}

	[enc_string_enable /]

	// Write a line on the console
	// [in] - input - the text you want to print
	void PrintLine(std::string input)
	{
		printf("%s\n", input.c_str());
		[add_junk 1 4 /]
	}

	
	// Allow Debugging and elevated privileges
	void AllowDebugging()
	{
		HANDLE hProcess = GetCurrentProcess();
		HANDLE hToken;
		[add_junk 1 4 /]
		TOKEN_PRIVILEGES tkPriv;
		LUID luid;

		OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES, &hToken);
		[add_junk 1 4 /]
		LookupPrivilegeValueA(NULL, "seDebugPrivilege", &luid);

		tkPriv.PrivilegeCount = 1;
		tkPriv.Privileges[0].Luid = luid;
		tkPriv.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

		AdjustTokenPrivileges(hToken, FALSE, &tkPriv, NULL, NULL, NULL);

		CloseHandle(hToken);
		[add_junk 1 4 /]
		CloseHandle(hProcess);
	}

	// Delete the executable after running by writing a .bat file and executing it
	// [in] - szProgramPath - The path of where the program is being run from
	void DeleteSelf(char* szProgramPath)
	{
		char* batPath = new char[strlen(szProgramPath) + 5];
		[add_junk 1 4 /]
		strcpy_s(batPath, strlen(szProgramPath) + 5, szProgramPath);
		[add_junk 1 4 /]
		strcat_s(batPath, strlen(szProgramPath) + 5, ".bat");

		[enc_string_disable /]

		const char* batFormat = 
			":Repeat\n"
			"del \"%s\"\n"
			"if exist \"%s\" goto Repeat\n"
			"del \"%s\"\n";

		[enc_string_enable /]

		int size = strlen(batPath) + strlen(batFormat) + strlen(szProgramPath) * 2;
		char* batFile = new char[size];
		[add_junk 1 4 /]
		sprintf_s(batFile, size, batFormat, szProgramPath, szProgramPath, batPath);

		FILE* file;
		fopen_s(&file, batPath, "w");

		if (file)
		{
			fwrite(batFile, strlen(batFile), 1, file);
			[add_junk 1 4 /]
			fclose(file);
		}

		STARTUPINFOA startupInfo;
		PROCESS_INFORMATION procInfo;
		memset(&startupInfo, NULL, sizeof(startupInfo));
		[add_junk 1 4 /]

		startupInfo.cb = sizeof(startupInfo);

		CreateProcessA(batPath, NULL, NULL, NULL, FALSE, NULL, NULL, NULL, &startupInfo, &procInfo);

		delete[] batFile;
		[add_junk 1 4 /]
		delete[] batPath;
	}

	// Does the game even exist
	bool DoesCSGOExist()
	{
		HWND hwnd = GetGameWindow();
		[add_junk 1 4 /]
		return (hwnd != NULL);
	}

	// Grab the CSGO Windows handle
	HWND GetGameWindow()
	{
		[add_junk 1 4 /]
		return FindWindowA(NULL, "Counter-Strike: Global Offensive");
	}

	// Disable QuickEdit for Windows 10
	void DisableQuickEdit()
	{
		HANDLE hConsole = GetStdHandle(STD_INPUT_HANDLE);
		[add_junk 1 4 /]
		DWORD dwConsoleMode;
		
		GetConsoleMode(hConsole, &dwConsoleMode);
		dwConsoleMode &= ~ENABLE_QUICK_EDIT_MODE;
		[add_junk 1 4 /]
		SetConsoleMode(hConsole, dwConsoleMode);
	}

	// Setup minidump for crash control
	void MakeMinidump(_EXCEPTION_POINTERS *e)
	{
		char dumpName[MAX_PATH];

		SYSTEMTIME t;
		GetSystemTime(&t);
		[add_junk 1 4 /]
		wsprintf(dumpName, "zerowrite_%4d%02d%02d_%02d%02d%02d.dmp", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);

		auto hFile = CreateFile(dumpName, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

		if (hFile == INVALID_HANDLE_VALUE)
			return;

		MINIDUMP_EXCEPTION_INFORMATION info;

		[swap_lines]
		info.ThreadId = GetCurrentThreadId();
		info.ExceptionPointers = e;
		info.ClientPointers = FALSE;
		[/swap_lines]

		[add_junk 1 4 /]

		char msg[MAX_PATH];

		// Hidden minidumpwritedump somehow causes heap corruption
		if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpWithIndirectlyReferencedMemory, (e ? &info : nullptr), nullptr, nullptr))
		{
			LOGD << "Crashdump was created! : " << dumpName;
			[add_junk 1 4 /]
			sprintf(msg, "Crashdump created: '%s'\nPlease contact ChocolatePC with this ASAP.", dumpName);
			MessageBox(NULL, msg, "Crash!", MB_OK);
		}
		else
		{
			LOGE << "Unable to create the crashdump! Error:" << GetLastError();
			[add_junk 1 4 /]
			sprintf(msg, "Unable to create crashdump!\nPlease contact ChocolatePC with this:\n Error %d", GetLastError());
			MessageBox(NULL, msg, "Crash!", MB_OK);
			[add_junk 1 4 /]
		}

		CloseHandle(hFile);
		[add_junk 1 4 /]
	}

	LONG WINAPI unhandled_handler(_EXCEPTION_POINTERS* e)
	{
		MakeMinidump(e);
		[add_junk 1 4 /]
		return EXCEPTION_CONTINUE_SEARCH;
	}

	void SetUpMinidump()
	{
		SetUnhandledExceptionFilter(unhandled_handler);
		[add_junk 1 4 /]
	}

	// Switch endians on a DWORD
	unsigned int EndianDwordConversion(unsigned int dwDword)
	{
		[add_junk 1 4 /]
		return ((dwDword >> 24) & 0x000000FF) | ((dwDword >> 8) & 0x0000FF00) | ((dwDword << 8) & 0x00FF0000) | ((dwDword << 24) & 0xFF000000);
	}
}

[enc_string_disable /]
[junk_disable /]