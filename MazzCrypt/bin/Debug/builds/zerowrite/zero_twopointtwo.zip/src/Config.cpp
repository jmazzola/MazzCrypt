#include "Config.h"
#include "Utils.h"
#include "Enums.h"
#include <Wincrypt.h>
#include <cctype>
#include <algorithm>
#include <sstream>

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]

#define SECTION_TRIGGERBOT "triggerbot"

// Set the config file
void Config::Init(std::string szConfigName)
{
	m_szConfigFile = szConfigName;

	[swap_lines]
	m_TriggerSettings.m_bActive = true;
	m_TriggerSettings.m_bKeyHeld = true;
	m_TriggerSettings.m_bDeathmatch = true;
	m_TriggerSettings.m_bSniperMode = true;
	m_TriggerSettings.m_bMoveCheck = true;
	m_TriggerSettings.m_bKnifebot = true;
	m_TriggerSettings.m_bAntiSpectate = true;
	m_TriggerSettings.m_bAntiJump = false;
	m_TriggerSettings.m_bInvertMouse = false;
	m_TriggerSettings.m_bSprayUntilDeadMode = true;
	m_TriggerSettings.m_nKey = VK_XBUTTON1;
	m_TriggerSettings.m_nToggleKey = VK_NUMPAD5;
	m_TriggerSettings.m_nMethod = Trigger_Hitbox;
	m_TriggerSettings.m_nTargetType = TargetType_Enemies;
	m_TriggerSettings.m_fMinSpeed = 25.0f;
	m_TriggerSettings.m_fMinFlash = 55.0f;
	[/swap_lines]
}

[enc_string_disable /]

// Get hash of the file
std::string Config::GetHash()
{
	HANDLE hFile = CreateFile(m_szConfigFile.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	HCRYPTPROV hProv;
	[add_junk 1 5 /]
	HCRYPTHASH hHash;

	DWORD cbHash = 16;
	BYTE rgbHash[16];
	CHAR rgbDigits[] = "0123456789abcdef";

[enc_string_enable /]


	if (hFile == INVALID_HANDLE_VALUE)
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error reading in .ini"));
		[add_junk 1 5 /]
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		int dwStatus = GetLastError();
		[add_junk 1 5 /]
		Utils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		[add_junk 1 5 /]
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
	}

	BOOL bResult = FALSE;
	DWORD cbRead;
	BYTE rgbFile[1024];

	while (bResult = ReadFile(hFile, rgbFile, 1024, &cbRead, NULL))
	{
		if (!cbRead)
		{
			[add_junk 1 5 /]
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			int dwStatus = GetLastError();
			Utils::PrintLine(std::string("Error with CryptHashData"));
			CryptReleaseContext(hProv, 0);
			[add_junk 1 5 /]
			CryptDestroyHash(hHash);
			CloseHandle(hFile);
			return std::string("ERROR");
		}
	}

	if (!bResult)
	{
		int dwStatus = GetLastError();
		Utils::PrintLine(std::string("ReadFile failed"));
		[add_junk 1 5 /]
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			[add_junk 1 5 /]
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);
		}
	}

	CryptReleaseContext(hProv, 0);
	CryptDestroyHash(hHash);
	[add_junk 1 5 /]
	CloseHandle(hFile);

	return hashOutput;
}

// Load the config
bool Config::LoadConfig()
{
	m_szHash = GetHash();

	[add_junk 1 5 /]

	[swap_lines]
	m_TriggerSettings.m_bActive = GetBool(SECTION_TRIGGERBOT, "activated");
	m_TriggerSettings.m_bKeyHeld = GetBool(SECTION_TRIGGERBOT, "holdkey");
	m_TriggerSettings.m_bDeathmatch = GetBool(SECTION_TRIGGERBOT, "deathmatch_mode");
	m_TriggerSettings.m_bSniperMode = GetBool(SECTION_TRIGGERBOT, "sniper_mode");
	m_TriggerSettings.m_bRevolverMode = GetBool(SECTION_TRIGGERBOT, "revolver_mode");
	m_TriggerSettings.m_bMoveCheck = GetBool(SECTION_TRIGGERBOT, "movecheck");
	m_TriggerSettings.m_bAntiSpectate = GetBool(SECTION_TRIGGERBOT, "anti_spectate");
	m_TriggerSettings.m_bAntiJump = GetBool(SECTION_TRIGGERBOT, "anti_jumping");
	m_TriggerSettings.m_bInvertMouse = GetBool(SECTION_TRIGGERBOT, "invertedmouse");
	m_TriggerSettings.m_bSprayUntilDeadMode = GetBool(SECTION_TRIGGERBOT, "spray_until_dead_mode");
	m_TriggerSettings.m_fMinSpeed = GetFloat(SECTION_TRIGGERBOT, "minspeed");
	m_TriggerSettings.m_fMinFlash = GetFloat(SECTION_TRIGGERBOT, "flash_percentage");
	m_TriggerSettings.m_nKey = GetKey(SECTION_TRIGGERBOT, "key");
	m_TriggerSettings.m_nToggleKey = GetKey(SECTION_TRIGGERBOT, "togglekey");
	m_TriggerSettings.m_nMethod = GetInt(SECTION_TRIGGERBOT, "trigger_type");
	m_TriggerSettings.m_nTargetType = GetInt(SECTION_TRIGGERBOT, "target_type");
	m_TriggerSettings.m_tGlock.m_hitboxes = GetCommaSeperatedInts("trigger_glock", "hitboxes");
	m_TriggerSettings.m_tGlock.m_nDelayBefore = GetInt("trigger_glock", "delay_before");
	m_TriggerSettings.m_tGlock.m_nDelayAfter = GetInt("trigger_glock", "delay_after");
	m_TriggerSettings.m_tGlock.m_fRCSScale = GetFloat("trigger_glock", "recoil_scale");
	m_TriggerSettings.m_tP2K.m_hitboxes = GetCommaSeperatedInts("trigger_p2000", "hitboxes");
	m_TriggerSettings.m_tP2K.m_nDelayBefore = GetInt("trigger_p2000", "delay_before");
	m_TriggerSettings.m_tP2K.m_nDelayAfter = GetInt("trigger_p2000", "delay_after");
	m_TriggerSettings.m_tP2K.m_fRCSScale = GetFloat("trigger_p2000", "recoil_scale");
	m_TriggerSettings.m_tUSP.m_hitboxes = GetCommaSeperatedInts("trigger_usps", "hitboxes");
	m_TriggerSettings.m_tUSP.m_nDelayBefore = GetInt("trigger_usps", "delay_before");
	m_TriggerSettings.m_tUSP.m_nDelayAfter = GetInt("trigger_usps", "delay_after");
	m_TriggerSettings.m_tUSP.m_fRCSScale = GetFloat("trigger_usps", "recoil_scale");
	m_TriggerSettings.m_tP250.m_hitboxes = GetCommaSeperatedInts("trigger_p250", "hitboxes");
	m_TriggerSettings.m_tP250.m_nDelayBefore = GetInt("trigger_p250", "delay_before");
	m_TriggerSettings.m_tP250.m_nDelayAfter = GetInt("trigger_p250", "delay_after");
	m_TriggerSettings.m_tP250.m_fRCSScale = GetFloat("trigger_p250", "recoil_scale");
	m_TriggerSettings.m_tFiveSeven.m_hitboxes = GetCommaSeperatedInts("trigger_fiveseven", "hitboxes");
	m_TriggerSettings.m_tFiveSeven.m_nDelayBefore = GetInt("trigger_fiveseven", "delay_before");
	m_TriggerSettings.m_tFiveSeven.m_nDelayAfter = GetInt("trigger_fiveseven", "delay_after");
	m_TriggerSettings.m_tFiveSeven.m_fRCSScale = GetFloat("trigger_fiveseven", "recoil_scale");
	m_TriggerSettings.m_tDeagle.m_hitboxes = GetCommaSeperatedInts("trigger_deagle", "hitboxes");
	m_TriggerSettings.m_tDeagle.m_nDelayBefore = GetInt("trigger_deagle", "delay_before");
	m_TriggerSettings.m_tDeagle.m_nDelayAfter = GetInt("trigger_deagle", "delay_after");
	m_TriggerSettings.m_tDeagle.m_fRCSScale = GetFloat("trigger_deagle", "recoil_scale");
	m_TriggerSettings.m_tDuelies.m_hitboxes = GetCommaSeperatedInts("trigger_dualberettas", "hitboxes");
	m_TriggerSettings.m_tDuelies.m_nDelayBefore = GetInt("trigger_dualberettas", "delay_before");
	m_TriggerSettings.m_tDuelies.m_nDelayAfter = GetInt("trigger_dualberettas", "delay_after");
	m_TriggerSettings.m_tDuelies.m_fRCSScale = GetFloat("trigger_dualberettas", "recoil_scale");
	m_TriggerSettings.m_tTec9.m_hitboxes = GetCommaSeperatedInts("trigger_tec9", "hitboxes");
	m_TriggerSettings.m_tTec9.m_nDelayBefore = GetInt("trigger_tec9", "delay_before");
	m_TriggerSettings.m_tTec9.m_nDelayAfter = GetInt("trigger_tec9", "delay_after");
	m_TriggerSettings.m_tTec9.m_fRCSScale = GetFloat("trigger_tec9", "recoil_scale");
	m_TriggerSettings.m_tCZ75.m_hitboxes = GetCommaSeperatedInts("trigger_cz75", "hitboxes");
	m_TriggerSettings.m_tCZ75.m_nDelayBefore = GetInt("trigger_cz75", "delay_before");
	m_TriggerSettings.m_tCZ75.m_nDelayAfter = GetInt("trigger_cz75", "delay_after");
	m_TriggerSettings.m_tCZ75.m_fRCSScale = GetFloat("trigger_cz75", "recoil_scale");
	m_TriggerSettings.m_tRevolver.m_hitboxes = GetCommaSeperatedInts("trigger_revolver", "hitboxes");
	m_TriggerSettings.m_tRevolver.m_nDelayBefore = GetInt("trigger_revolver", "delay_before");
	m_TriggerSettings.m_tRevolver.m_nDelayAfter = GetInt("trigger_revolver", "delay_after");
	m_TriggerSettings.m_tRevolver.m_fRCSScale = GetFloat("trigger_revolver", "recoil_scale");
	m_TriggerSettings.m_tNova.m_hitboxes = GetCommaSeperatedInts("trigger_nova", "hitboxes");
	m_TriggerSettings.m_tNova.m_nDelayBefore = GetInt("trigger_nova", "delay_before");
	m_TriggerSettings.m_tNova.m_nDelayAfter = GetInt("trigger_nova", "delay_after");
	m_TriggerSettings.m_tNova.m_fRCSScale = GetFloat("trigger_nova", "recoil_scale");
	m_TriggerSettings.m_tXM1014.m_hitboxes = GetCommaSeperatedInts("trigger_xm1014", "hitboxes");
	m_TriggerSettings.m_tXM1014.m_nDelayBefore = GetInt("trigger_xm1014", "delay_before");
	m_TriggerSettings.m_tXM1014.m_nDelayAfter = GetInt("trigger_xm1014", "delay_after");
	m_TriggerSettings.m_tXM1014.m_fRCSScale = GetFloat("trigger_xm1014", "recoil_scale");
	m_TriggerSettings.m_tSawedOff.m_hitboxes = GetCommaSeperatedInts("trigger_sawedoff", "hitboxes");
	m_TriggerSettings.m_tSawedOff.m_nDelayBefore = GetInt("trigger_sawedoff", "delay_before");
	m_TriggerSettings.m_tSawedOff.m_nDelayAfter = GetInt("trigger_sawedoff", "delay_after");
	m_TriggerSettings.m_tSawedOff.m_fRCSScale = GetFloat("trigger_sawedoff", "recoil_scale");
	m_TriggerSettings.m_tMag7.m_hitboxes = GetCommaSeperatedInts("trigger_mag7", "hitboxes");
	m_TriggerSettings.m_tMag7.m_nDelayBefore = GetInt("trigger_mag7", "delay_before");
	m_TriggerSettings.m_tMag7.m_nDelayAfter = GetInt("trigger_mag7", "delay_after");
	m_TriggerSettings.m_tMag7.m_fRCSScale = GetFloat("trigger_mag7", "recoil_scale");
	m_TriggerSettings.m_tMAC10.m_hitboxes = GetCommaSeperatedInts("trigger_mac10", "hitboxes");
	m_TriggerSettings.m_tMAC10.m_nDelayBefore = GetInt("trigger_mac10", "delay_before");
	m_TriggerSettings.m_tMAC10.m_nDelayAfter = GetInt("trigger_mac10", "delay_after");
	m_TriggerSettings.m_tMAC10.m_fRCSScale = GetFloat("trigger_mac10", "recoil_scale");
	m_TriggerSettings.m_tMP7.m_hitboxes = GetCommaSeperatedInts("trigger_mp7", "hitboxes");
	m_TriggerSettings.m_tMP7.m_nDelayBefore = GetInt("trigger_mp7", "delay_before");
	m_TriggerSettings.m_tMP7.m_nDelayAfter = GetInt("trigger_mp7", "delay_after");
	m_TriggerSettings.m_tMP7.m_fRCSScale = GetFloat("trigger_mp7", "recoil_scale");
	m_TriggerSettings.m_tMP9.m_hitboxes = GetCommaSeperatedInts("trigger_mp9", "hitboxes");
	m_TriggerSettings.m_tMP9.m_nDelayBefore = GetInt("trigger_mp9", "delay_before");
	m_TriggerSettings.m_tMP9.m_nDelayAfter = GetInt("trigger_mp9", "delay_after");
	m_TriggerSettings.m_tMP9.m_fRCSScale = GetFloat("trigger_mp9", "recoil_scale");
	m_TriggerSettings.m_tUMP45.m_hitboxes = GetCommaSeperatedInts("trigger_ump45", "hitboxes");
	m_TriggerSettings.m_tUMP45.m_nDelayBefore = GetInt("trigger_ump45", "delay_before");
	m_TriggerSettings.m_tUMP45.m_nDelayAfter = GetInt("trigger_ump45", "delay_after");
	m_TriggerSettings.m_tUMP45.m_fRCSScale = GetFloat("trigger_ump45", "recoil_scale");
	m_TriggerSettings.m_tBizon.m_hitboxes = GetCommaSeperatedInts("trigger_ppbizon", "hitboxes");
	m_TriggerSettings.m_tBizon.m_nDelayBefore = GetInt("trigger_ppbizon", "delay_before");
	m_TriggerSettings.m_tBizon.m_nDelayAfter = GetInt("trigger_ppbizon", "delay_after");
	m_TriggerSettings.m_tBizon.m_fRCSScale = GetFloat("trigger_ppbizon", "recoil_scale");
	m_TriggerSettings.m_tP90.m_hitboxes = GetCommaSeperatedInts("trigger_p90", "hitboxes");
	m_TriggerSettings.m_tP90.m_nDelayBefore = GetInt("trigger_p90", "delay_before");
	m_TriggerSettings.m_tP90.m_nDelayAfter = GetInt("trigger_p90", "delay_after");
	m_TriggerSettings.m_tP90.m_fRCSScale = GetFloat("trigger_p90", "recoil_scale");
	m_TriggerSettings.m_tGalil.m_hitboxes = GetCommaSeperatedInts("trigger_galil", "hitboxes");
	m_TriggerSettings.m_tGalil.m_nDelayBefore = GetInt("trigger_galil", "delay_before");
	m_TriggerSettings.m_tGalil.m_nDelayAfter = GetInt("trigger_galil", "delay_after");
	m_TriggerSettings.m_tGalil.m_fRCSScale = GetFloat("trigger_galil", "recoil_scale");
	m_TriggerSettings.m_tAK47.m_hitboxes = GetCommaSeperatedInts("trigger_ak47", "hitboxes");
	m_TriggerSettings.m_tAK47.m_nDelayBefore = GetInt("trigger_ak47", "delay_before");
	m_TriggerSettings.m_tAK47.m_nDelayAfter = GetInt("trigger_ak47", "delay_after");
	m_TriggerSettings.m_tAK47.m_fRCSScale = GetFloat("trigger_ak47", "recoil_scale");
	m_TriggerSettings.m_tM4A4.m_hitboxes = GetCommaSeperatedInts("trigger_m4a4", "hitboxes");
	m_TriggerSettings.m_tM4A4.m_nDelayBefore = GetInt("trigger_m4a4", "delay_before");
	m_TriggerSettings.m_tM4A4.m_nDelayAfter = GetInt("trigger_m4a4", "delay_after");
	m_TriggerSettings.m_tM4A4.m_fRCSScale = GetFloat("trigger_m4a4", "recoil_scale");
	m_TriggerSettings.m_tM4A1S.m_hitboxes = GetCommaSeperatedInts("trigger_m4a1s", "hitboxes");
	m_TriggerSettings.m_tM4A1S.m_nDelayBefore = GetInt("trigger_m4a1s", "delay_before");
	m_TriggerSettings.m_tM4A1S.m_nDelayAfter = GetInt("trigger_m4a1s", "delay_after");
	m_TriggerSettings.m_tM4A1S.m_fRCSScale = GetFloat("trigger_m4a1s", "recoil_scale");
	m_TriggerSettings.m_tSG553.m_hitboxes = GetCommaSeperatedInts("trigger_sg553", "hitboxes");
	m_TriggerSettings.m_tSG553.m_nDelayBefore = GetInt("trigger_sg553", "delay_before");
	m_TriggerSettings.m_tSG553.m_nDelayAfter = GetInt("trigger_sg553", "delay_after");
	m_TriggerSettings.m_tSG553.m_fRCSScale = GetFloat("trigger_sg553", "recoil_scale");
	m_TriggerSettings.m_tAUG.m_hitboxes = GetCommaSeperatedInts("trigger_aug", "hitboxes");
	m_TriggerSettings.m_tAUG.m_nDelayBefore = GetInt("trigger_aug", "delay_before");
	m_TriggerSettings.m_tAUG.m_nDelayAfter = GetInt("trigger_aug", "delay_after");
	m_TriggerSettings.m_tAUG.m_fRCSScale = GetFloat("trigger_aug", "recoil_scale");
	m_TriggerSettings.m_tFAMAS.m_hitboxes = GetCommaSeperatedInts("trigger_famas", "hitboxes");
	m_TriggerSettings.m_tFAMAS.m_nDelayBefore = GetInt("trigger_famas", "delay_before");
	m_TriggerSettings.m_tFAMAS.m_nDelayAfter = GetInt("trigger_famas", "delay_after");
	m_TriggerSettings.m_tFAMAS.m_fRCSScale = GetFloat("trigger_famas", "recoil_scale");
	m_TriggerSettings.m_tAWP.m_hitboxes = GetCommaSeperatedInts("trigger_awp", "hitboxes");
	m_TriggerSettings.m_tAWP.m_nDelayBefore = GetInt("trigger_awp", "delay_before");
	m_TriggerSettings.m_tAWP.m_nDelayAfter = GetInt("trigger_awp", "delay_after");
	m_TriggerSettings.m_tAWP.m_fRCSScale = GetFloat("trigger_awp", "recoil_scale");
	m_TriggerSettings.m_tSCAR20.m_hitboxes = GetCommaSeperatedInts("trigger_scar20", "hitboxes");
	m_TriggerSettings.m_tSCAR20.m_nDelayBefore = GetInt("trigger_scar20", "delay_before");
	m_TriggerSettings.m_tSCAR20.m_nDelayAfter = GetInt("trigger_scar20", "delay_after");
	m_TriggerSettings.m_tSCAR20.m_fRCSScale = GetFloat("trigger_scar20", "recoil_scale");
	m_TriggerSettings.m_tScout.m_hitboxes = GetCommaSeperatedInts("trigger_scout", "hitboxes");
	m_TriggerSettings.m_tScout.m_nDelayBefore = GetInt("trigger_scout", "delay_before");
	m_TriggerSettings.m_tScout.m_nDelayAfter = GetInt("trigger_scout", "delay_after");
	m_TriggerSettings.m_tScout.m_fRCSScale = GetFloat("trigger_scout", "recoil_scale");
	m_TriggerSettings.m_tG3SG1.m_hitboxes = GetCommaSeperatedInts("trigger_g3sg1", "hitboxes");
	m_TriggerSettings.m_tG3SG1.m_nDelayBefore = GetInt("trigger_g3sg1", "delay_before");
	m_TriggerSettings.m_tG3SG1.m_nDelayAfter = GetInt("trigger_g3sg1", "delay_after");
	m_TriggerSettings.m_tG3SG1.m_fRCSScale = GetFloat("trigger_g3sg1", "recoil_scale");
	m_TriggerSettings.m_tM249.m_hitboxes = GetCommaSeperatedInts("trigger_m249", "hitboxes");
	m_TriggerSettings.m_tM249.m_nDelayBefore = GetInt("trigger_m249", "delay_before");
	m_TriggerSettings.m_tM249.m_nDelayAfter = GetInt("trigger_m249", "delay_after");
	m_TriggerSettings.m_tM249.m_fRCSScale = GetFloat("trigger_m249", "recoil_scale");
	m_TriggerSettings.m_tNegev.m_hitboxes = GetCommaSeperatedInts("trigger_negev", "hitboxes");
	m_TriggerSettings.m_tNegev.m_nDelayBefore = GetInt("trigger_negev", "delay_before");
	m_TriggerSettings.m_tNegev.m_nDelayAfter = GetInt("trigger_negev", "delay_after");
	m_TriggerSettings.m_tNegev.m_fRCSScale = GetFloat("trigger_negev", "recoil_scale");
	[/swap_lines]

	return true;
}

// Save the config
bool Config::SaveConfig()
{
	[swap_lines]
	SetBool(SECTION_TRIGGERBOT, "activated", m_TriggerSettings.m_bActive);
	SetBool(SECTION_TRIGGERBOT, "holdkey", m_TriggerSettings.m_bKeyHeld);
	SetBool(SECTION_TRIGGERBOT, "deathmatch_mode", m_TriggerSettings.m_bDeathmatch);
	SetBool(SECTION_TRIGGERBOT, "sniper_mode", m_TriggerSettings.m_bSniperMode);
	SetBool(SECTION_TRIGGERBOT, "revolver_mode", m_TriggerSettings.m_bRevolverMode);
	SetBool(SECTION_TRIGGERBOT, "movecheck", m_TriggerSettings.m_bMoveCheck);
	SetBool(SECTION_TRIGGERBOT, "anti_spectate", m_TriggerSettings.m_bAntiSpectate);
	SetBool(SECTION_TRIGGERBOT, "anti_jumping", m_TriggerSettings.m_bAntiJump);
	SetBool(SECTION_TRIGGERBOT, "invertedmouse", m_TriggerSettings.m_bInvertMouse);
	SetBool(SECTION_TRIGGERBOT, "spray_until_dead_mode", m_TriggerSettings.m_bSprayUntilDeadMode);
	SetFloat(SECTION_TRIGGERBOT, "minspeed", m_TriggerSettings.m_fMinSpeed);
	SetFloat(SECTION_TRIGGERBOT, "flash_percentage", m_TriggerSettings.m_fMinFlash);
	SetKey(SECTION_TRIGGERBOT, "key", m_TriggerSettings.m_nKey);
	SetKey(SECTION_TRIGGERBOT, "togglekey", m_TriggerSettings.m_nToggleKey);
	SetInt(SECTION_TRIGGERBOT, "trigger_type", m_TriggerSettings.m_nMethod);
	SetInt(SECTION_TRIGGERBOT, "target_type", m_TriggerSettings.m_nTargetType);
	SetCommaSeperatedInts("trigger_glock", "hitboxes", m_TriggerSettings.m_tGlock.m_hitboxes);
	SetInt("trigger_glock", "delay_before", m_TriggerSettings.m_tGlock.m_nDelayBefore);
	SetInt("trigger_glock", "delay_after", m_TriggerSettings.m_tGlock.m_nDelayAfter);
	SetFloat("trigger_glock", "recoil_scale", m_TriggerSettings.m_tGlock.m_fRCSScale);
	SetCommaSeperatedInts("trigger_p2000", "hitboxes", m_TriggerSettings.m_tP2K.m_hitboxes);
	SetInt("trigger_p2000", "delay_before", m_TriggerSettings.m_tP2K.m_nDelayBefore);
	SetInt("trigger_p2000", "delay_after", m_TriggerSettings.m_tP2K.m_nDelayAfter);
	SetFloat("trigger_p2000", "recoil_scale", m_TriggerSettings.m_tP2K.m_fRCSScale);
	SetCommaSeperatedInts("trigger_usps", "hitboxes", m_TriggerSettings.m_tUSP.m_hitboxes);
	SetInt("trigger_usps", "delay_before", m_TriggerSettings.m_tUSP.m_nDelayBefore);
	SetInt("trigger_usps", "delay_after", m_TriggerSettings.m_tUSP.m_nDelayAfter);
	SetFloat("trigger_usps", "recoil_scale", m_TriggerSettings.m_tUSP.m_fRCSScale);
	SetCommaSeperatedInts("trigger_p250", "hitboxes", m_TriggerSettings.m_tP250.m_hitboxes);
	SetInt("trigger_p250", "delay_before", m_TriggerSettings.m_tP250.m_nDelayBefore);
	SetInt("trigger_p250", "delay_after", m_TriggerSettings.m_tP250.m_nDelayAfter);
	SetFloat("trigger_p250", "recoil_scale", m_TriggerSettings.m_tP250.m_fRCSScale);
	SetCommaSeperatedInts("trigger_fiveseven", "hitboxes", m_TriggerSettings.m_tFiveSeven.m_hitboxes);
	SetInt("trigger_fiveseven", "delay_before", m_TriggerSettings.m_tFiveSeven.m_nDelayBefore);
	SetInt("trigger_fiveseven", "delay_after", m_TriggerSettings.m_tFiveSeven.m_nDelayAfter);
	SetFloat("trigger_fiveseven", "recoil_scale", m_TriggerSettings.m_tFiveSeven.m_fRCSScale);
	SetCommaSeperatedInts("trigger_deagle", "hitboxes", m_TriggerSettings.m_tDeagle.m_hitboxes);
	SetInt("trigger_deagle", "delay_before", m_TriggerSettings.m_tDeagle.m_nDelayBefore);
	SetInt("trigger_deagle", "delay_after", m_TriggerSettings.m_tDeagle.m_nDelayAfter);
	SetFloat("trigger_deagle", "recoil_scale", m_TriggerSettings.m_tDeagle.m_fRCSScale);
	SetCommaSeperatedInts("trigger_dualberettas", "hitboxes", m_TriggerSettings.m_tDuelies.m_hitboxes);
	SetInt("trigger_dualberettas", "delay_before", m_TriggerSettings.m_tDuelies.m_nDelayBefore);
	SetInt("trigger_dualberettas", "delay_after", m_TriggerSettings.m_tDuelies.m_nDelayAfter);
	SetFloat("trigger_dualberettas", "recoil_scale", m_TriggerSettings.m_tDuelies.m_fRCSScale);
	SetCommaSeperatedInts("trigger_tec9", "hitboxes", m_TriggerSettings.m_tTec9.m_hitboxes);
	SetInt("trigger_tec9", "delay_before", m_TriggerSettings.m_tTec9.m_nDelayBefore);
	SetInt("trigger_tec9", "delay_after", m_TriggerSettings.m_tTec9.m_nDelayAfter);
	SetFloat("trigger_tec9", "recoil_scale", m_TriggerSettings.m_tTec9.m_fRCSScale);
	SetCommaSeperatedInts("trigger_cz75", "hitboxes", m_TriggerSettings.m_tCZ75.m_hitboxes);
	SetInt("trigger_cz75", "delay_before", m_TriggerSettings.m_tCZ75.m_nDelayBefore);
	SetInt("trigger_cz75", "delay_after", m_TriggerSettings.m_tCZ75.m_nDelayAfter);
	SetFloat("trigger_cz75", "recoil_scale", m_TriggerSettings.m_tCZ75.m_fRCSScale);
	SetCommaSeperatedInts("trigger_revolver", "hitboxes", m_TriggerSettings.m_tRevolver.m_hitboxes);
	SetInt("trigger_revolver", "delay_before", m_TriggerSettings.m_tRevolver.m_nDelayBefore);
	SetInt("trigger_revolver", "delay_after", m_TriggerSettings.m_tRevolver.m_nDelayAfter);
	SetFloat("trigger_revolver", "recoil_scale", m_TriggerSettings.m_tRevolver.m_fRCSScale);
	SetCommaSeperatedInts("trigger_nova", "hitboxes", m_TriggerSettings.m_tNova.m_hitboxes);
	SetInt("trigger_nova", "delay_before", m_TriggerSettings.m_tNova.m_nDelayBefore);
	SetInt("trigger_nova", "delay_after", m_TriggerSettings.m_tNova.m_nDelayAfter);
	SetFloat("trigger_nova", "recoil_scale", m_TriggerSettings.m_tNova.m_fRCSScale);
	SetCommaSeperatedInts("trigger_xm1014", "hitboxes", m_TriggerSettings.m_tXM1014.m_hitboxes);
	SetInt("trigger_xm1014", "delay_before", m_TriggerSettings.m_tXM1014.m_nDelayBefore);
	SetInt("trigger_xm1014", "delay_after", m_TriggerSettings.m_tXM1014.m_nDelayAfter);
	SetFloat("trigger_xm1014", "recoil_scale", m_TriggerSettings.m_tXM1014.m_fRCSScale);
	SetCommaSeperatedInts("trigger_sawedoff", "hitboxes", m_TriggerSettings.m_tSawedOff.m_hitboxes);
	SetInt("trigger_sawedoff", "delay_before", m_TriggerSettings.m_tSawedOff.m_nDelayBefore);
	SetInt("trigger_sawedoff", "delay_after", m_TriggerSettings.m_tSawedOff.m_nDelayAfter);
	SetFloat("trigger_sawedoff", "recoil_scale", m_TriggerSettings.m_tSawedOff.m_fRCSScale);
	SetCommaSeperatedInts("trigger_mag7", "hitboxes", m_TriggerSettings.m_tMag7.m_hitboxes);
	SetInt("trigger_mag7", "delay_before", m_TriggerSettings.m_tMag7.m_nDelayBefore);
	SetInt("trigger_mag7", "delay_after", m_TriggerSettings.m_tMag7.m_nDelayAfter);
	SetFloat("trigger_mag7", "recoil_scale", m_TriggerSettings.m_tMag7.m_fRCSScale);
	SetCommaSeperatedInts("trigger_mac10", "hitboxes", m_TriggerSettings.m_tMAC10.m_hitboxes);
	SetInt("trigger_mac10", "delay_before", m_TriggerSettings.m_tMAC10.m_nDelayBefore);
	SetInt("trigger_mac10", "delay_after", m_TriggerSettings.m_tMAC10.m_nDelayAfter);
	SetFloat("trigger_mac10", "recoil_scale", m_TriggerSettings.m_tMAC10.m_fRCSScale);
	SetCommaSeperatedInts("trigger_mp7", "hitboxes", m_TriggerSettings.m_tMP7.m_hitboxes);
	SetInt("trigger_mp7", "delay_before", m_TriggerSettings.m_tMP7.m_nDelayBefore);
	SetInt("trigger_mp7", "delay_after", m_TriggerSettings.m_tMP7.m_nDelayAfter);
	SetFloat("trigger_mp7", "recoil_scale", m_TriggerSettings.m_tMP7.m_fRCSScale);
	SetCommaSeperatedInts("trigger_mp9", "hitboxes", m_TriggerSettings.m_tMP9.m_hitboxes);
	SetInt("trigger_mp9", "delay_before", m_TriggerSettings.m_tMP9.m_nDelayBefore);
	SetInt("trigger_mp9", "delay_after", m_TriggerSettings.m_tMP9.m_nDelayAfter);
	SetFloat("trigger_mp9", "recoil_scale", m_TriggerSettings.m_tMP9.m_fRCSScale);
	SetCommaSeperatedInts("trigger_ump45", "hitboxes", m_TriggerSettings.m_tUMP45.m_hitboxes);
	SetInt("trigger_ump45", "delay_before", m_TriggerSettings.m_tUMP45.m_nDelayBefore);
	SetInt("trigger_ump45", "delay_after", m_TriggerSettings.m_tUMP45.m_nDelayAfter);
	SetFloat("trigger_ump45", "recoil_scale", m_TriggerSettings.m_tUMP45.m_fRCSScale);
	SetCommaSeperatedInts("trigger_ppbizon", "hitboxes", m_TriggerSettings.m_tBizon.m_hitboxes);
	SetInt("trigger_ppbizon", "delay_before", m_TriggerSettings.m_tBizon.m_nDelayBefore);
	SetInt("trigger_ppbizon", "delay_after", m_TriggerSettings.m_tBizon.m_nDelayAfter);
	SetFloat("trigger_ppbizon", "recoil_scale", m_TriggerSettings.m_tBizon.m_fRCSScale);
	SetCommaSeperatedInts("trigger_p90", "hitboxes", m_TriggerSettings.m_tP90.m_hitboxes);
	SetInt("trigger_p90", "delay_before", m_TriggerSettings.m_tP90.m_nDelayBefore);
	SetInt("trigger_p90", "delay_after", m_TriggerSettings.m_tP90.m_nDelayAfter);
	SetFloat("trigger_p90", "recoil_scale", m_TriggerSettings.m_tP90.m_fRCSScale);
	SetCommaSeperatedInts("trigger_galil", "hitboxes", m_TriggerSettings.m_tGalil.m_hitboxes);
	SetInt("trigger_galil", "delay_before", m_TriggerSettings.m_tGalil.m_nDelayBefore);
	SetInt("trigger_galil", "delay_after", m_TriggerSettings.m_tGalil.m_nDelayAfter);
	SetFloat("trigger_galil", "recoil_scale", m_TriggerSettings.m_tGalil.m_fRCSScale);
	SetCommaSeperatedInts("trigger_ak47", "hitboxes", m_TriggerSettings.m_tAK47.m_hitboxes);
	SetInt("trigger_ak47", "delay_before", m_TriggerSettings.m_tAK47.m_nDelayBefore);
	SetInt("trigger_ak47", "delay_after", m_TriggerSettings.m_tAK47.m_nDelayAfter);
	SetFloat("trigger_ak47", "recoil_scale", m_TriggerSettings.m_tAK47.m_fRCSScale);
	SetCommaSeperatedInts("trigger_m4a4", "hitboxes", m_TriggerSettings.m_tM4A4.m_hitboxes);
	SetInt("trigger_m4a4", "delay_before", m_TriggerSettings.m_tM4A4.m_nDelayBefore);
	SetInt("trigger_m4a4", "delay_after", m_TriggerSettings.m_tM4A4.m_nDelayAfter);
	SetFloat("trigger_m4a4", "recoil_scale", m_TriggerSettings.m_tM4A4.m_fRCSScale);
	SetCommaSeperatedInts("trigger_m4a1s", "hitboxes", m_TriggerSettings.m_tM4A1S.m_hitboxes);
	SetInt("trigger_m4a1s", "delay_before", m_TriggerSettings.m_tM4A1S.m_nDelayBefore);
	SetInt("trigger_m4a1s", "delay_after", m_TriggerSettings.m_tM4A1S.m_nDelayAfter);
	SetFloat("trigger_m4a1s", "recoil_scale", m_TriggerSettings.m_tM4A1S.m_fRCSScale);
	SetCommaSeperatedInts("trigger_sg553", "hitboxes", m_TriggerSettings.m_tSG553.m_hitboxes);
	SetInt("trigger_sg553", "delay_before", m_TriggerSettings.m_tSG553.m_nDelayBefore);
	SetInt("trigger_sg553", "delay_after", m_TriggerSettings.m_tSG553.m_nDelayAfter);
	SetFloat("trigger_sg553", "recoil_scale", m_TriggerSettings.m_tSG553.m_fRCSScale);
	SetCommaSeperatedInts("trigger_aug", "hitboxes", m_TriggerSettings.m_tAUG.m_hitboxes);
	SetInt("trigger_aug", "delay_before", m_TriggerSettings.m_tAUG.m_nDelayBefore);
	SetInt("trigger_aug", "delay_after", m_TriggerSettings.m_tAUG.m_nDelayAfter);
	SetFloat("trigger_aug", "recoil_scale", m_TriggerSettings.m_tAUG.m_fRCSScale);
	SetCommaSeperatedInts("trigger_famas", "hitboxes", m_TriggerSettings.m_tFAMAS.m_hitboxes);
	SetInt("trigger_famas", "delay_before", m_TriggerSettings.m_tFAMAS.m_nDelayBefore);
	SetInt("trigger_famas", "delay_after", m_TriggerSettings.m_tFAMAS.m_nDelayAfter);
	SetFloat("trigger_famas", "recoil_scale", m_TriggerSettings.m_tFAMAS.m_fRCSScale);
	SetCommaSeperatedInts("trigger_awp", "hitboxes", m_TriggerSettings.m_tAWP.m_hitboxes);
	SetInt("trigger_awp", "delay_before", m_TriggerSettings.m_tAWP.m_nDelayBefore);
	SetInt("trigger_awp", "delay_after", m_TriggerSettings.m_tAWP.m_nDelayAfter);
	SetFloat("trigger_awp", "recoil_scale", m_TriggerSettings.m_tAWP.m_fRCSScale);
	SetCommaSeperatedInts("trigger_scar20", "hitboxes", m_TriggerSettings.m_tSCAR20.m_hitboxes);
	SetInt("trigger_scar20", "delay_before", m_TriggerSettings.m_tSCAR20.m_nDelayBefore);
	SetInt("trigger_scar20", "delay_after", m_TriggerSettings.m_tSCAR20.m_nDelayAfter);
	SetFloat("trigger_scar20", "recoil_scale", m_TriggerSettings.m_tSCAR20.m_fRCSScale);
	SetCommaSeperatedInts("trigger_scout", "hitboxes", m_TriggerSettings.m_tScout.m_hitboxes);
	SetInt("trigger_scout", "delay_before", m_TriggerSettings.m_tScout.m_nDelayBefore);
	SetInt("trigger_scout", "delay_after", m_TriggerSettings.m_tScout.m_nDelayAfter);
	SetFloat("trigger_scout", "recoil_scale", m_TriggerSettings.m_tScout.m_fRCSScale);
	SetCommaSeperatedInts("trigger_g3sg1", "hitboxes", m_TriggerSettings.m_tG3SG1.m_hitboxes);
	SetInt("trigger_g3sg1", "delay_before", m_TriggerSettings.m_tG3SG1.m_nDelayBefore);
	SetInt("trigger_g3sg1", "delay_after", m_TriggerSettings.m_tG3SG1.m_nDelayAfter);
	SetFloat("trigger_g3sg1", "recoil_scale", m_TriggerSettings.m_tG3SG1.m_fRCSScale);
	SetCommaSeperatedInts("trigger_m249", "hitboxes", m_TriggerSettings.m_tM249.m_hitboxes);
	SetInt("trigger_m249", "delay_before", m_TriggerSettings.m_tM249.m_nDelayBefore);
	SetInt("trigger_m249", "delay_after", m_TriggerSettings.m_tM249.m_nDelayAfter);
	SetFloat("trigger_m249", "recoil_scale", m_TriggerSettings.m_tM249.m_fRCSScale);
	SetCommaSeperatedInts("trigger_negev", "hitboxes", m_TriggerSettings.m_tNegev.m_hitboxes);
	SetInt("trigger_negev", "delay_before", m_TriggerSettings.m_tNegev.m_nDelayBefore);
	SetInt("trigger_negev", "delay_after", m_TriggerSettings.m_tNegev.m_nDelayAfter);
	SetFloat("trigger_negev", "recoil_scale", m_TriggerSettings.m_tNegev.m_fRCSScale);
	[/swap_lines]

	[add_junk 1 5 /]

	return true;
}

// Return an integer
int Config::GetInt(char* section, char* option)
{
	[add_junk 1 5 /]
	return GetPrivateProfileIntA(section, option, NULL, m_szConfigFile.c_str());
}

// Return a float
float Config::GetFloat(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	[add_junk 1 5 /]
	return (float)atof(val);
}

// Return a string
std::string Config::GetString(char* section, char* option)
{
	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	return std::string(val);
}

// Return a boolean
bool Config::GetBool(char* section, char* option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());
	[add_junk 1 5 /]
	return (!_stricmp(val, "on"));
}

// Return a vector of ints from csvs
std::vector<int> Config::GetCommaSeperatedInts(char * section, char * option)
{
	char val[255];
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	std::string str(val);

	std::vector<int> vec;
	[add_junk 1 5 /]
	std::stringstream ss(str);
	int i;

	while (ss >> i)
	{
		vec.push_back(i);

		[add_junk 1 5 /]

		if (ss.peek() == ',' || ss.peek() == ' ')
			ss.ignore();
	}

	return vec;
}

int Config::GetKey(char * section, char * option)
{
	[add_junk 1 5 /]

	char val[255];
	[add_junk 1 5 /]
	GetPrivateProfileStringA(section, option, NULL, val, sizeof(val), m_szConfigFile.c_str());

	std::string str(val);

	char data = str.c_str()[0];

	[add_junk 1 5 /]

	if ((data >= '0' && data <= '9') || (data >= 'A' && data <= 'Z'))
		return (int)data;

	[add_junk 1 5 /]

	if (str == "mouse1") return VK_LBUTTON;
	else if (str == "mouse2") return VK_RBUTTON;
	else if (str == "mouse3") return VK_MBUTTON;
	else if (str == "mouse4") return VK_XBUTTON1;
	else if (str == "mouse5") return VK_XBUTTON2;
	else if (str == "backspace") return VK_BACK;
	else if (str == "tab") return VK_TAB;
	else if (str == "enter") return VK_RETURN;
	else if (str == "shift") return VK_SHIFT;
	else if (str == "ctrl") return VK_CONTROL;
	else if (str == "alt") return VK_MENU;
	else if (str == "capslock") return VK_CAPITAL;
	else if (str == "escape") return VK_ESCAPE;
	else if (str == "space") return VK_SPACE;
	else if (str == "pgup") return VK_PRIOR;
	else if (str == "pgdn") return VK_NEXT;
	else if (str == "end") return VK_END;
	else if (str == "home") return VK_HOME;
	else if (str == "leftarrow") return VK_LEFT;
	else if (str == "rightarrow") return VK_RIGHT;
	else if (str == "uparrow") return VK_UP;
	else if (str == "downarrow") return VK_DOWN;
	else if (str == "ins") return VK_INSERT;
	else if (str == "del") return VK_DELETE;
	else if (str == "numpad_0") return VK_NUMPAD0;
	else if (str == "numpad_1") return VK_NUMPAD1;
	else if (str == "numpad_2") return VK_NUMPAD2;
	else if (str == "numpad_3") return VK_NUMPAD3;
	else if (str == "numpad_4") return VK_NUMPAD4;
	else if (str == "numpad_5") return VK_NUMPAD5;
	else if (str == "numpad_6") return VK_NUMPAD6;
	else if (str == "numpad_7") return VK_NUMPAD7;
	else if (str == "numpad_8") return VK_NUMPAD8;
	else if (str == "numpad_9") return VK_NUMPAD9;
	else if (str == "kp_multiply") return VK_MULTIPLY;
	else if (str == "kp_plus") return VK_ADD;
	else if (str == "kp_minus") return VK_SUBTRACT;
	else if (str == "kp_slash") return VK_DIVIDE;
	else if (str == "f1") return VK_F1;
	else if (str == "f2") return VK_F2;
	else if (str == "f3") return VK_F3;
	else if (str == "f4") return VK_F4;
	else if (str == "f5") return VK_F5;
	else if (str == "f6") return VK_F6;
	else if (str == "f7") return VK_F7;
	else if (str == "f8") return VK_F8;
	else if (str == "f9") return VK_F9;
	else if (str == "f10") return VK_F10;
	else if (str == "f11") return VK_F11;
	else if (str == "f12") return VK_F12;
	else if (str == ";") return VK_OEM_1;
	else if (str == "+") return VK_OEM_PLUS;
	else if (str == "-") return VK_OEM_MINUS;
	else if (str == ",") return VK_OEM_COMMA;
	else if (str == ".") return VK_OEM_PERIOD;
	else if (str == "/") return VK_OEM_2;
	else if (str == "~") return VK_OEM_3;
	else if (str == "[") return VK_OEM_4;
	else if (str == std::to_string(char(0x5C))) return VK_OEM_5;
	else if (str == "]") return VK_OEM_6;
	else if (str == std::to_string(char(0x22))) return VK_OEM_7;

	[add_junk 1 5 /]

	return -1;
}

void Config::SetInt(char* section, char* option, int nValue)
{
	char val[255];
	sprintf_s(val, " %d", nValue);
	[add_junk 1 5 /]
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetFloat(char* section, char* option, float fValue)
{
	char val[255];
	[add_junk 1 5 /]
	sprintf_s(val, " %2.1f", fValue );
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetString(char* section, char* option, std::string szValue)
{
	WritePrivateProfileStringA(section, option, szValue.c_str(),  m_szConfigFile.c_str());
	[add_junk 1 5 /]
}

void Config::SetBool(char* section, char* option, bool bValue)
{
	char val[255];
	sprintf_s(val, "%s", bValue ? " on" : " off");
	[add_junk 1 5 /]
	WritePrivateProfileStringA(section, option, val, m_szConfigFile.c_str());
}

void Config::SetCommaSeperatedInts(char * section, char * option, std::vector<int> vValue)
{
	std::string input = " ";

	for (size_t i = 0; i < vValue.size(); i++)
	{
		[add_junk 1 5 /]
		
		if (i == vValue.size() - 1)
			input += std::to_string(i);
		else
			input += std::to_string(i) + ",";
	}

	WritePrivateProfileStringA(section, option, input.c_str(), m_szConfigFile.c_str());
}

void Config::SetKey(char * section, char * option, int nKey)
{
	char c[2] = { 0 };
	[add_junk 1 5 /]

	if ((nKey >= '0' && nKey <= '9') || (nKey >= 'A' && nKey <= 'Z'))
	{
		[add_junk 1 5 /]
		c[0] = (char)nKey;
		std::string sweg(c);
		[add_junk 1 5 /]
		std::transform(sweg.begin(), sweg.end(), sweg.begin(), ::tolower);
		[add_junk 1 5 /]
		WritePrivateProfileStringA(section, option, sweg.c_str(), m_szConfigFile.c_str());
		return;
	}

	std::string retStr = " ";
	[add_junk 1 5 /]

	switch (nKey)
	{
		case VK_LBUTTON: retStr += "mouse1"; break;
		case VK_RBUTTON: retStr += "mouse2"; break;
		case VK_MBUTTON: retStr += "mouse3"; break;
		case VK_XBUTTON1: retStr += "mouse4"; break;
		case VK_XBUTTON2: retStr += "mouse5"; break;
		case VK_BACK: retStr += "backspace"; break;
		case VK_TAB: retStr += "tab"; break;
		case VK_RETURN: retStr += "enter"; break;
		case VK_SHIFT: retStr += "shift"; break;
		case VK_CONTROL: retStr += "ctrl"; break;
		case VK_MENU: retStr += "alt"; break;
		case VK_CAPITAL: retStr += "capslock"; break;
		case VK_ESCAPE: retStr += "escape"; break;
		case VK_SPACE: retStr += "space"; break;
		case VK_PRIOR: retStr += "pgup"; break;
		case VK_NEXT: retStr += "pgdn"; break;
		case VK_END: retStr += "end"; break;
		case VK_HOME: retStr += "home"; break;
		case VK_LEFT: retStr += "leftarrow"; break;
		case VK_UP: retStr += "uparrow"; break;
		case VK_DOWN: retStr += "downarrow"; break;
		case VK_RIGHT: retStr += "rightarrow"; break;
		case VK_INSERT: retStr += "ins"; break;
		case VK_DELETE: retStr += "del"; break;
		case VK_NUMPAD0: retStr += "numpad_0"; break;
		case VK_NUMPAD1: retStr += "numpad_1"; break;
		case VK_NUMPAD2: retStr += "numpad_2"; break;
		case VK_NUMPAD3: retStr += "numpad_3"; break;
		case VK_NUMPAD4: retStr += "numpad_4"; break;
		case VK_NUMPAD5: retStr += "numpad_5"; break;
		case VK_NUMPAD6: retStr += "numpad_6"; break;
		case VK_NUMPAD7: retStr += "numpad_7"; break;
		case VK_NUMPAD8: retStr += "numpad_8"; break;
		case VK_NUMPAD9: retStr += "numpad_9"; break;
		case VK_MULTIPLY: retStr += "kp_multiply"; break;
		case VK_ADD: retStr += "kp_plus"; break;
		case VK_SUBTRACT: retStr += "kp_minus"; break;
		case VK_DIVIDE: retStr += "kp_slash"; break;
		case VK_F1: retStr += "f1"; break;
		case VK_F2: retStr += "f2"; break;
		case VK_F3: retStr += "f3"; break;
		case VK_F4: retStr += "f4"; break;
		case VK_F5: retStr += "f5"; break;
		case VK_F6: retStr += "f6"; break;
		case VK_F7: retStr += "f7"; break;
		case VK_F8: retStr += "f8"; break;
		case VK_F9: retStr += "f9"; break;
		case VK_F10: retStr += "f10"; break;
		case VK_F11: retStr += "f11"; break;
		case VK_F12: retStr += "f12"; break;
		case VK_OEM_1: retStr += ";"; break;
		case VK_OEM_PLUS: retStr += "+"; break;
		case VK_OEM_MINUS: retStr += "-"; break;
		case VK_OEM_COMMA: retStr += ","; break;
		case VK_OEM_PERIOD: retStr += "."; break;
		case VK_OEM_2: retStr += "/"; break;
		case VK_OEM_3: retStr += "~"; break;
		case VK_OEM_4: retStr += "["; break;
		case VK_OEM_5: retStr += std::to_string(char(0x5C)); break;
		case VK_OEM_6: retStr += "]"; break;
		case VK_OEM_7: retStr += std::to_string(char(0x22)); break;
		default: retStr += "unknown key"; break;
	}

	[add_junk 1 5 /]

	if (!retStr.empty())
		WritePrivateProfileStringA(section, option, retStr.c_str(), m_szConfigFile.c_str());
	else
		WritePrivateProfileStringA(section, option, " error", m_szConfigFile.c_str());

	[add_junk 1 5 /]
}

[enc_string_disable /]
[junk_disable /]