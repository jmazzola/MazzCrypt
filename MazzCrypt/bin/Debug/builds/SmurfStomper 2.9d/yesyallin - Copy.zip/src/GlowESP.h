#ifndef _GLOWESP_H_
#define _GLOWESP_H_

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

struct GlowObjectDefinition
{
	DWORD			pEntity;
	CVector			rgb;
	float			a; // 0x10
	unsigned char	unk1[16];
	bool			bRenderWhenOccluded; // 0x24
	bool			bRenderWhenUnoccluded; // 0x25
	bool			bFullBloom; // 0x26
	unsigned char	unk2[14];

};

class GlowESP
{
public:

	GlowESP() { }

	void WriteGlowStruct(DWORD& mObj, GlowObjectDefinition& glowObj)
	{
		[swap_lines]
		csgo->m_Mem.Write<CVector>(mObj + 0x4, glowObj.rgb);
		csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
		csgo->m_Mem.Write<bool>(mObj + 0x24, glowObj.bRenderWhenOccluded);
		csgo->m_Mem.Write<bool>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
		csgo->m_Mem.Write<bool>(mObj + 0x26, glowObj.bFullBloom);
		[/swap_lines]
	}

	void Start()
	{
		while (!csgo->m_Hacks.tThreadHandling.bGlowThreadStop)
		{
			[swap_lines]
			static DWORD objGlowArray = 0;
			static int objCount = 0;
			[/swap_lines]

			if (GetAsyncKeyState(VK_END))
				csgo->m_Hacks.tThreadHandling.bGlowThreadStop = true;

			if (csgo->m_Hacks.CheckBit(BIT_ESP))
			{
				[swap_lines]
				m_Enemies.clear();
				m_Teammates.clear();
				[/swap_lines]

				for (int i = 1; i < 64; i++)
				{
					Player ply = csgo->m_Players[i];
					if (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam))
						m_Enemies.push_back(ply);
					else if (csgo->m_Me.iTeam == ply.iTeam)
						m_Teammates.push_back(ply);
				}

				[swap_lines]
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);
				[/swap_lines]

				if (objGlowArray != NULL)
				{
					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						[add_junk 1 8 /]
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						if (!glowObj.pEntity)
							continue;

						#pragma region Bomb Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowBomb)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CC4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4)
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowBomb_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowBomb_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								WriteGlowStruct(mObj, glowObj);
							}


						}

						#pragma region Bomb Info Check
						if (csgo->m_Hacks.tGlowOptions.bBombInfo)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4 && csgo->m_Mem.Read<bool>(glowObj.pEntity + csgo->m_dynamicOffsets.netvar_bBombTicking))
							{
								[swap_lines]
								float bombTime = csgo->m_Mem.Read<float>(glowObj.pEntity + csgo->m_dynamicOffsets.netvar_flC4Blow) - csgo->m_Mem.Read<float>(csgo->m_dwGlobalVarsBase + 0x10);
								float r, g, b;
								[/swap_lines]

								[add_junk 1 8 /]

								if (bombTime >= 10.0f)
								{
									[swap_lines]
									r = 0.0f;
									g = 1.0f;
									b = 0.0f;
									[/swap_lines]
								}
								else if (bombTime >= 5.0f)
								{
									[swap_lines]
									r = 0.0f;
									g = 0.0f;
									b = 1.0f;
									[/swap_lines]

									[add_junk 1 8 /]
								}
								else
								{
									[swap_lines]
									r = 1.0f;
									g = 0.0f;
									b = 0.0f;
									[/swap_lines]
								}

								[swap_lines]
								glowObj.rgb = CVector(r,g,b);
								glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowBomb_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 8 /]

								WriteGlowStruct(mObj, glowObj);
							}
						}
#pragma endregion


#pragma endregion


						#pragma region Grenade Glow Check
						if (csgo->m_Hacks.tGlowOptions.bGlowGrenades)
						{
							if (csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fNades_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fNades_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 8 /]

								WriteGlowStruct(mObj, glowObj);
							}
						}

#pragma endregion


						#pragma region Weapon Glow Check

						if (csgo->m_Hacks.tGlowOptions.bGlowWeapons)
						{
							if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)))
							{
								[swap_lines]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fWeapons_RGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fWeapons_A;
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								glowObj.bFullBloom = false;
								[/swap_lines]

								[add_junk 1 8 /]

								WriteGlowStruct(mObj, glowObj);
							}

						}
#pragma endregion

						#pragma region Chicken Glow Check

						if (csgo->m_Hacks.tGlowOptions.bChickenGlow)
						{
							if (csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CChicken)
							{
								[add_junk 1 8 /]
								glowObj.rgb = csgo->m_Hacks.tGlowOptions.fChickenRGB;
								glowObj.a = csgo->m_Hacks.tGlowOptions.fChicken_A;
								[add_junk 1 8 /]
								glowObj.bRenderWhenOccluded = true;
								glowObj.bRenderWhenUnoccluded = false;
								[add_junk 1 8 /]
								glowObj.bFullBloom = false;

								WriteGlowStruct(mObj, glowObj);
							}

						}
#pragma endregion

						switch (csgo->m_Hacks.tGlowOptions.targetType)
						{
							case ETargetType::Target_Enemies:
							{
								#pragma region Enemies

								for (size_t i = 0; i < m_Enemies.size(); i++)
								{
									if (m_Enemies[i].baseAddr == glowObj.pEntity)
									{
										[swap_lines]
										glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB;
										glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowEnemy_A;
										[/swap_lines]

										if (csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->IsSpottedBy(m_Enemies[i], csgo->m_Me))
										{
											[swap_lines]
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB;
											glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A;
											[/swap_lines]
										}


										if (csgo->m_Hacks.tGlowOptions.bHealthGlow)
										{
											int health = m_Enemies[i].iHealth;

											[swap_lines]
											glowObj.rgb = CVector((100.f - health) / 100.f, health / 100.f, 0.f);
											glowObj.a = 0.7f;
											[/swap_lines]

											[add_junk 1 8 /]
										}

										if (csgo->m_Hacks.tGlowOptions.bFlashGlow && m_Enemies[i].fFlashDuration > 0.001f)
										{
											[swap_lines]
											glowObj.rgb = CVector(1.f, 1.f, 1.f);
											glowObj.a = 0.7f;
											[/swap_lines]
										}

										if (csgo->m_Hacks.tGlowOptions.bDefuseGlow && m_Enemies[i].bIsDefusing)
										{
											[swap_lines]
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fDefuse_RGB;
											glowObj.a = csgo->m_Hacks.tGlowOptions.fDefuse_A;
											[/swap_lines]
										}

										if (m_Enemies[i].bIsDormant)
											glowObj.a = 0.0f;

										[add_junk 1 8 /]

										[swap_lines]
										glowObj.bRenderWhenOccluded = true;
										glowObj.bRenderWhenUnoccluded = false;
										glowObj.bFullBloom = false;
										[/swap_lines]

										WriteGlowStruct(mObj, glowObj);
									}
								}
#pragma endregion
								break;
							}

							case ETargetType::Target_Teammates:
							{
								#pragma region Teammates

								for (size_t i = 0; i < m_Teammates.size(); i++)
								{
									if (m_Teammates[i].baseAddr == glowObj.pEntity)
									{
										[swap_lines]
										glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB;
										glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowTeam_A;
										[/swap_lines]

										if (csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->IsSpottedBy(m_Teammates[i], csgo->m_Me))
										{
											[swap_lines]
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB;
											glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A;
											[/swap_lines]

											[add_junk 1 8 /]
										}

										if (csgo->m_Hacks.tGlowOptions.bHealthGlow)
										{
											int health = m_Teammates[i].iHealth;
											[add_junk 1 8 /]
											glowObj.rgb = CVector((100.f - health) / 100.f, health / 100.f, 0.f);
										}

										if (csgo->m_Hacks.tGlowOptions.bFlashGlow && m_Teammates[i].fFlashDuration > 0.001f)
										{
											[add_junk 1 8 /]

											[swap_lines]
											glowObj.rgb = CVector(1.f, 1.f, 1.f);
											glowObj.a = 0.7f;
											[/swap_lines]

										}

										if (csgo->m_Hacks.tGlowOptions.bDefuseGlow && m_Teammates[i].bIsDefusing)
										{
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fDefuse_RGB;
											[add_junk 1 8 /]
											glowObj.a = csgo->m_Hacks.tGlowOptions.fDefuse_A;
										}

										if (m_Teammates[i].bIsDormant)
											glowObj.a = 0.0f;

										[swap_lines]
										glowObj.bRenderWhenOccluded = true;
										glowObj.bRenderWhenUnoccluded = false;
										glowObj.bFullBloom = false;
										[/swap_lines]

										[add_junk 1 8 /]

										WriteGlowStruct(mObj, glowObj);
									}
								}
#pragma endregion
								break;
							}

							case ETargetType::Target_Everyone:
							{
								#pragma region Everyone

								for (int i = 1; i < 64; i++)
								{
									if (csgo->m_Players[i].baseAddr == glowObj.pEntity)
									{
										// Enemies
										if (csgo->m_Players[i].iTeam == csgo->GetEnemyTeam(csgo->m_Me.iTeam))
										{
											[swap_lines]
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB;
											glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowEnemy_A;
											[/swap_lines]

											[add_junk 1 8 /]

											if (csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->IsSpottedBy(csgo->m_Players[i], csgo->m_Me))
											{
												[swap_lines]
												glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB;
												glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A;
												[/swap_lines]
											}

										}
										// Teammates
										else if (csgo->m_Players[i].iTeam == csgo->m_Me.iTeam)
										{
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB;
											[add_junk 1 8 /]
											glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowTeam_A;

											if (csgo->m_Hacks.tGlowOptions.bVisibleGlow && !csgo->IsSpottedBy(csgo->m_Players[i], csgo->m_Me))
											{
												glowObj.rgb = csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB;
												[add_junk 1 8 /]
												glowObj.a = csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A;
											}
										}

										if (csgo->m_Hacks.tGlowOptions.bHealthGlow)
										{
											int health = csgo->m_Players[i].iHealth;
											[add_junk 1 8 /]
											glowObj.rgb = CVector((100.f - health) / 100.f, health / 100.f, 0.f);
										}

										if (csgo->m_Hacks.tGlowOptions.bFlashGlow && csgo->m_Players[i].fFlashDuration > 0.001f)
										{
											glowObj.rgb = CVector(1.f, 1.f, 1.f);
											glowObj.a = 0.7f;
											[add_junk 1 8 /]
										}

										if (csgo->m_Hacks.tGlowOptions.bDefuseGlow && csgo->m_Players[i].bIsDefusing)
										{
											[swap_lines]
											glowObj.rgb = csgo->m_Hacks.tGlowOptions.fDefuse_RGB;
											glowObj.a = csgo->m_Hacks.tGlowOptions.fDefuse_A;
											[/swap_lines]
										}


										if (csgo->m_Players[i].bIsDormant)
											glowObj.a = 0.0f;

										[swap_lines]
										glowObj.bRenderWhenOccluded = true;
										glowObj.bRenderWhenUnoccluded = false;
										glowObj.bFullBloom = false;
										[/swap_lines]

										WriteGlowStruct(mObj, glowObj);
									}
								}
#pragma endregion
								break;
							}
						}
					}
				}
			}
			else
			{
				objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
				objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);

				if (objGlowArray != NULL)
				{
					#pragma region Toggle Off

					for (int i = 0; i < objCount; i++)
					{
						DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
						GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

						if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)) || csgo->IsClassIDAGrenade(csgo->GetClassID((Player*)&glowObj.pEntity))
							|| csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CC4 || csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CPlantedC4
							|| csgo->GetClassID((Player*)&glowObj.pEntity) == CID_CChicken)
						{

							[swap_lines]
							glowObj.rgb = CVector(0, 0, 0);
							glowObj.a = 0.0f;
							glowObj.bRenderWhenOccluded = true;
							glowObj.bRenderWhenUnoccluded = false;
							glowObj.bFullBloom = false;
							[/swap_lines]

							WriteGlowStruct(mObj, glowObj);
						}

					}
#pragma endregion
				}
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
	}

	GlowESP(CSGO* c)
	{
		csgo = c;
		[add_junk 1 8 /]
	}

	~GlowESP() = default;


private:

	CSGO* csgo;
	std::vector<Player> m_Enemies, m_Teammates;

	[add_junk_datamembers 1 8 /]
};

#endif // _GLOWESP_H_


[junk_disable /]