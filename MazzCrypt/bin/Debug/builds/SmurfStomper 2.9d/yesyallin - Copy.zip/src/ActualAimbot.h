#ifndef _ACTUALAIMBOT_H_
#define _ACTUALAIMBOT_H_

#include "stdafx.h"
#include "CSGO.h"
#include "Vector.h"

#include <random>

#define M_PI       3.14159265358979323846

[junk_enable /]

class ActualAimbot
{
public:

	ActualAimbot(CSGO* c)
	{
		[add_junk 1 4 /]
		m_Target = NULL;
		csgo = c;
	}

	~ActualAimbot() = default;

	void ClampAngles(CVector& angle)
	{
		while (angle.y > 180.0f)
		{
			angle.y -= 360.0f;
			[add_junk 1 4 /]
		}

		while (angle.y < -180.0f)
			angle.y += 360.0f;

		if (angle.x > 89.0f)
		{
			angle.x = 89.0f;
			[add_junk 1 4 /]
		}

		if (angle.x < -89.0f)
			angle.x = -89.0f;

		if (angle.z != 0.0f)
			angle.z = 0.0f;

		[add_junk 1 4 /]
	}

	CVector2D WorldToScreen(CVector point)
	{
		CVector returnVector(0, 0, 0);

		[add_junk 1 4 /]

		float w = csgo->m_ViewMatrix[12] * point.x + csgo->m_ViewMatrix[13] * point.y + csgo->m_ViewMatrix[14] * point.z + csgo->m_ViewMatrix[15];
		if (w >= 0.01f)
		{
			[add_junk 2 9 /]
			float inverseWidth = 1.0f / w;

			[swap_lines]
			returnVector.x = (csgo->m_iWindowWidth / 2.0f) + (0.5f * ((csgo->m_ViewMatrix[0] * point.x + csgo->m_ViewMatrix[1] * point.y + csgo->m_ViewMatrix[2] * point.z + csgo->m_ViewMatrix[3]) * inverseWidth) * csgo->m_iWindowWidth + 0.5f);
			returnVector.y = (csgo->m_iWindowHeight / 2.0f) - (0.5f * ((csgo->m_ViewMatrix[4] * point.x + csgo->m_ViewMatrix[5] * point.y + csgo->m_ViewMatrix[6] * point.z + csgo->m_ViewMatrix[7]) * inverseWidth) * csgo->m_iWindowHeight + 0.5f);
			[/swap_lines]
		}

		return returnVector;
	}

	Player* GetPlayerClosestToCrosshair(int bone)
	{
		int index = -1;
		float best = FLT_MAX;

		if (m_Target)
			return m_Target;

		switch (csgo->m_Hacks.tActualAimbotOptions.targetType)
		{
			case ETargetType::Target_Enemies:
			{
				for (size_t i = 0; i < m_Enemies.size(); i++)
				{
					[add_junk 1 4 /]

					Player ply = m_Enemies[i];

					if (!IsTargetValid(&ply, bone))
						continue;

					float tmp = GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(&ply, bone));

					if (tmp < best)
					{
						[add_junk 1 4 /]

						[swap_lines]
						best = tmp;
						index = i;
						[/swap_lines]
					}
				}


				if (index != -1)
					return &m_Enemies[index];
				else
					return NULL;

				break;
			}

			case ETargetType::Target_Teammates:
			{
				for (size_t i = 0; i < m_Teammates.size(); i++)
				{
					Player ply = m_Teammates[i];
					[add_junk 1 4 /]

					if (!IsTargetValid(&ply, bone))
						continue;

					[add_junk 1 4 /]

					float tmp = GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(&ply, bone));

					if (tmp < best)
					{
						best = tmp;
						[add_junk 1 4 /]
						index = i;
					}
				}


				if (index != -1)
					return &m_Teammates[index];
				else
				{
					m_Target = NULL;
					return NULL;
				}

				break;
			}

			case ETargetType::Target_Everyone:
			{
				for (int i = 1; i < 64; i++)
				{
					Player ply = csgo->m_Players[i];
					[add_junk 1 4 /]

					if (!IsTargetValid(&ply, bone))
						continue;

					float tmp = GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(&ply, bone));

					if (tmp < best)
					{
						[swap_lines]
						best = tmp;
						index = i;
						[/swap_lines]

						[add_junk 1 4 /]
					}
				}


				if (index != -1)
					return &csgo->m_Players[index];
				else
				{
					m_Target = NULL;
					[add_junk 1 4 /]
					return NULL;
				}

				break;
			}

			default:
				return NULL;

		}
		
		return NULL;
	}

	Player* GetPlayerClosestToPlayer(int bone)
	{
		int index = -1;
		float best = FLT_MAX;

		if (m_Target)
			return m_Target;

		switch (csgo->m_Hacks.tActualAimbotOptions.targetType)
		{
			case ETargetType::Target_Enemies:
			{

				for (size_t i = 0; i < m_Enemies.size(); i++)
				{
					[add_junk 1 4 /]
					Player ply = m_Enemies[i];

					if (!IsTargetValid(&ply, bone))
						continue;
					
					//CVector targetPos = csgo->m_Mem.Read<CVector>(ply.baseAddr + csgo->m_dynamicOffsets.netvar_vecOrigin);
					//CVector myPos = csgo->m_Mem.Read<CVector>(csgo->m_Me.baseAddr + csgo->m_dynamicOffsets.netvar_vecOrigin);

					float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length());

					[add_junk 1 4 /]

					if (dist < best)
					{
						[swap_lines]
						best = dist;
						index = i;
						[/swap_lines]
					}
				}

				if (index != -1)
					return &m_Enemies[index];
				else
					return NULL;

				break;
			}

			case ETargetType::Target_Teammates:
			{
				for (size_t i = 0; i < m_Teammates.size(); i++)
				{
					[add_junk 1 4 /]
					Player ply = m_Teammates[i];

					if (!IsTargetValid(&ply, bone))
						continue;

					//CVector targetPos = csgo->m_Mem.Read<CVector>(ply.baseAddr + csgo->m_dynamicOffsets.netvar_vecOrigin);
					//CVector myPos = csgo->m_Mem.Read<CVector>(csgo->m_Me.baseAddr + csgo->m_dynamicOffsets.netvar_vecOrigin);

					float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length());

					if (dist < best)
					{
						[add_junk 1 4 /]

						[swap_lines]
						best = dist;
						index = i;
						[/swap_lines]
					}
				}


				if (index != -1)
					return &m_Teammates[index];
				else
					return NULL;

				break;
			}

			case ETargetType::Target_Everyone:
			{
				for (int i = 1; i < 64; i++)
				{
					Player ply = csgo->m_Players[i];

					if (!IsTargetValid(&ply, bone))
						continue;

					[add_junk 1 4 /]

					float dist = (float)abs((ply.vOrigin - csgo->m_Me.vOrigin).Length());

					if (dist < best)
					{
						[swap_lines]
						best = dist;
						index = i;
						[/swap_lines]
					}
				}


				if (index != -1)
					return &csgo->m_Players[index];
				else
					return NULL;
				
				break;
			}

			default:
				return NULL;
		}

		return NULL;
	}

	void MakeVector(CVector angle, CVector& vector)
	{
		[add_junk 1 4 /]

		[swap_lines]
		float pitch = float(angle[0] * M_PI / 180);
		float yaw = float(angle[1] * M_PI / 180);
		[/swap_lines]

		float tmp = float(cos(pitch));

		[add_junk 1 7 /]

		[swap_lines]
		vector.x = float(-tmp * -cos(yaw));
		vector.y = float(sin(yaw)*tmp);
		vector.z = float(-sin(pitch));
		[/swap_lines]
	}

	float GetFov(CVector angle, CVector src, CVector dst)
	{
		CVector ang, aim;
		ang = CalcAngle(src, dst);
		MakeVector(angle, aim);
		MakeVector(ang, ang);

		[add_junk 2 9 /]

		[swap_lines]
		float mag = FastSQRT(pow(aim.x, 2) + pow(aim.y, 2) + pow(aim.z, 2));
		float u_dot_v = aim.DotProduct(ang);
		[/swap_lines]

		[add_junk 2 9 /]

		return RAD2DEG(acos(u_dot_v / (pow(mag, 2))));
	}

	CVector CalcAngle(CVector src, CVector dst)
	{
		CVector ret;
		CVector vDelta = src - dst;
		[add_junk 2 9 /]

		float fHyp = FastSQRT((vDelta.x * vDelta.x) + (vDelta.y * vDelta.y));

		[swap_lines]
		ret.x = (atanf(vDelta.z / fHyp)) * (180.0f / (float)M_PI);
		ret.y = (atanf(vDelta.y / vDelta.x)) * (180.0f / (float)M_PI);
		[/swap_lines]

		if (vDelta.x >= 0.0f)
			ret.y += 180.0f;

		[add_junk 1 6 /]

		return ret;
	}

	bool IsTargetValid(Player* ply, int bone)
	{
		if (ply->baseAddr == NULL || ply->bIsDormant || !ply->bAlive)
			return false;

		if (ply->fImmuneTime >= 0.001f)
			return false;

		if (csgo->m_Hacks.tActualAimbotOptions.bVisibleCheck && !csgo->IsSpottedBy(*ply, csgo->m_Me))
			return false;

		if (!csgo->m_Hacks.tActualAimbotOptions.bRageMode && GetFov(csgo->m_Me.vViewAngles, csgo->m_Me.vEyePos, csgo->BonePosition(ply, bone)) > csgo->m_Hacks.tActualAimbotOptions.fFOVRadius)
			return false;

		if (csgo->m_Hacks.tActualAimbotOptions.bJumpCheck && !(ply->iFlags & (1 << 0)))
 			return false;

		[add_junk 2 9 /]

		return true;
	}

	void DropTarget()
	{
		m_Target = NULL;
		[add_junk 2 9 /]
	}

	bool CanShoot()
 	{
 		DWORD baseCombatHandle = csgo->m_Mem.Read<DWORD>(csgo->m_Me.baseAddr + csgo->m_dynamicOffsets.netvar_hActiveWeapon);
 		[add_junk 1 9 /]
 		baseCombatHandle &= 0xFFF;
 		DWORD weapBase = csgo->m_Mem.Read<DWORD>(csgo->m_dwEntityBase + (baseCombatHandle * 0x10) - 0x10);

 		[swap_lines]
 	 	float nextPrimaryAttack = csgo->m_Mem.Read<float>(weapBase + csgo->m_dynamicOffsets.netvar_flNextPrimaryAttack);
 		float tickBase = csgo->m_Mem.Read<float>(csgo->m_dwLocalBase + csgo->m_dynamicOffsets.netvar_nTickBase);
 		float intervalPerTick = csgo->m_Mem.Read<float>(csgo->m_dwGlobalVarsBase + 0x20);
 		[/swap_lines]

 		[add_junk 1 9 /]

 		float flServerTime = tickBase * intervalPerTick;

 	 	return (!(nextPrimaryAttack > flServerTime));
 	}

	void Start()
	{
		while (!csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop)
		{
			if (GetAsyncKeyState(VK_END))
			{
				csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop = true;
				[add_junk 1 9 /]
			}

			if (csgo->m_Hacks.CheckBit(BIT_AIMBOT))
			{
				[swap_lines]
				int boneToAimAt = 0;
				float rcsScale = 0.0f;
				[/swap_lines]

				switch (csgo->GetWeaponType(csgo->m_Me))
				{
					case EWeaponType::WeapType_Pistol:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale;
						[/swap_lines]
						break;
					}

					case EWeaponType::WeapType_Sniper:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale;
						[/swap_lines]
						break;
					}

					case EWeaponType::WeapType_Rifle:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale;
						[/swap_lines]
						break;
					}

					case EWeaponType::WeapType_SMG:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale;
						[/swap_lines]
						break;
					}

					case EWeaponType::WeapType_LMG:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale;
						[/swap_lines]
						break;
					}
					case EWeaponType::WeapType_Shotgun:
					{
						[swap_lines]
						boneToAimAt = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt;
						rcsScale = csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale;
						[/swap_lines]
						break;
					}

					default:
					{
						continue;
					}
				}

				if (m_Target && !IsTargetValid(m_Target, boneToAimAt))
					DropTarget();

				[add_junk 2 9 /]

				if (csgo->m_Me.bIsReloading || !csgo->m_Me.iAmmo_Primary)
					continue;

				[swap_lines]
				m_Enemies.clear();
				m_Teammates.clear();
				[/swap_lines]

				for (int i = 1; i < 64; i++)
				{
					Player ply = csgo->m_Players[i];

					[add_junk 2 9 /]

					if (ply.baseAddr == csgo->m_dwLocalBase)
						continue;

					if (csgo->m_Me.iTeam == csgo->GetEnemyTeam(ply.iTeam))
					{
						m_Enemies.push_back(ply);
						[add_junk 2 9 /]
					}
					else if (csgo->m_Me.iTeam == ply.iTeam)
					{
						m_Teammates.push_back(ply);
						[add_junk 2 9 /]
					}
				}

				switch (csgo->m_Hacks.tActualAimbotOptions.eAimMethod)
				{
					case 0:
					{
						[add_junk 2 9 /]
						m_Target = GetPlayerClosestToCrosshair(boneToAimAt);
						break;
					}
					case 1:
					{
						[add_junk 2 9 /]
						m_Target = GetPlayerClosestToPlayer(boneToAimAt);
						break;
					}
				}

				if (m_Target == nullptr)
					continue;

				[swap_lines]
				CVector targetOrigin = m_Target->vOrigin;
				CVector enemyPos = csgo->BonePosition(m_Target, boneToAimAt);
				[/swap_lines]

				float check = (float)abs((targetOrigin - enemyPos).Length());
				
				if (check > 75.0f)
					continue;

				[swap_lines]
				CVector viewAngles = csgo->m_Me.vViewAngles;
				CVector position = csgo->m_Me.vOrigin + csgo->m_Me.vVecViewOffset;
				CVector myVelocity = csgo->m_Me.vVelocity; 
				CVector targetVelocity = m_Target->vVelocity;
				[/swap_lines]

				CVector distVec = csgo->BonePosition(m_Target, boneToAimAt) - enemyPos;
				[add_junk 2 9 /]
				float dist = FastSQRT((distVec.x * distVec.x) + (distVec.y * distVec.y) + (distVec.z * distVec.z));

				if (dist > 0.001f)
				{
					[swap_lines]
					enemyPos.x += (targetVelocity.x) / dist;
					enemyPos.y += (targetVelocity.y) / dist;
					enemyPos.z += (targetVelocity.z) / dist;
					[/swap_lines]
					[swap_lines]
					enemyPos.x -= (myVelocity.x) / dist;
					enemyPos.y -= (myVelocity.y) / dist;
					enemyPos.z -= (myVelocity.z) / dist;
					[/swap_lines]
				}

				// Calculate Angle to look at
				viewAngles = CalcAngle(position, enemyPos);
				[add_junk 2 9 /]
				ClampAngles(viewAngles);

				// RCS 
				CVector punchAngle(csgo->m_Me.vPunchAngles.x, csgo->m_Me.vPunchAngles.y, 0.0f);
				[add_junk 2 9 /]
				viewAngles -= punchAngle * rcsScale;

				ClampAngles(viewAngles);

				// Smooth Angles
				CVector curView = csgo->m_Me.vViewAngles;//csgo->m_Mem.Read<CVector>(anglePointer + csgo->m_dynamicOffsets.viewAngles);
				CVector qDelta(viewAngles.x - curView.x, viewAngles.y - curView.y, 0.0f);

				ClampAngles(qDelta);

				[add_junk 2 9 /]

				[swap_lines]
				viewAngles.x = curView.x + qDelta.x / csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor;
				viewAngles.y = curView.y + qDelta.y / csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor;
				[/swap_lines]

				ClampAngles(viewAngles);

				[add_junk 2 9 /]

				if (!csgo->m_Hacks.tActualAimbotOptions.bSilentAim)
				{
					[add_junk 2 9 /]
					csgo->m_Mem.Write<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles, viewAngles);
				}
				else
				{
					if (!CanShoot())
						continue;

					[swap_lines]
					int seqNum = 0;
					CVector oldAngles;
					DWORD userCMD = csgo->m_dynamicOffsets.userCMDOffset;
					[/swap_lines]

					int curSequenceNum = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr + 0x4C7C);
					[add_junk 2 9 /]
					curSequenceNum += 1;

					userCMD += (curSequenceNum % 150) * 0x64;

					csgo->m_Mem.Write<bool>(csgo->m_dynamicOffsets.bSendPacketOffset, false);

					while (seqNum != curSequenceNum)
					{
						[add_junk 2 9 /]
						oldAngles = csgo->m_Mem.Read<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles);
						seqNum = csgo->m_Mem.Read<int>(userCMD + 0x4);
					}

					for (int i = 0; i < 20; i++)
					{
						[add_junk 2 9 /]
						csgo->m_Mem.Write<CVector>(userCMD + 0xC, viewAngles);
					}

					[add_junk 2 9 /]

					csgo->m_Mem.Write<CVector>(csgo->m_dwAnglePointer + csgo->m_dynamicOffsets.viewAngles, oldAngles);
					std::this_thread::sleep_for(std::chrono::milliseconds(6));

					csgo->m_Mem.Write<bool>(csgo->m_dynamicOffsets.bSendPacketOffset, true);
					[add_junk 2 9 /]
					
				}
			}
			else
			{
				[add_junk 2 9 /]
				DropTarget();
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}

	}

private:

	[swap_lines]
	CSGO* csgo;
	Player* m_Target;
	std::vector<Player> m_Enemies, m_Teammates;
	[/swap_lines]
	
	[add_junk_datamembers 1 6 /]
};

#endif //_ACTUALAIMBOT_H_

[junk_disable /]