#ifndef _FAKELAG_H_
#define _FAKELAG_H_

#include "stdafx.h"
#include "CSGO.h"

[junk_enable /]

class Fakelag
{
public:

	Fakelag(CSGO* c)
	{
		csgo = c;
		[add_junk 1 6 /]
	}

	void Start()
	{
		static bool doOnce = false;
		while (!csgo->m_Hacks.tThreadHandling.bFakeLagThreadStop)
		{
			if (GetAsyncKeyState(VK_END))
			{
				[add_junk 1 6 /]

				[swap_lines]
				csgo->m_Hacks.tThreadHandling.bFakeLagThreadStop = true;
				csgo->m_Mem.WriteProtected<BYTE>(csgo->m_dynamicOffsets.bSendPacketOffset, 1);
				[/swap_lines]
			}

			if (csgo->m_Hacks.CheckBit(BIT_FAKELAG))
			{
				csgo->m_Mem.WriteProtected<BYTE>(csgo->m_dynamicOffsets.bSendPacketOffset, 0);
				[add_junk 1 6 /]
				std::this_thread::sleep_for(std::chrono::milliseconds(csgo->m_Hacks.tFakeLagOptions.iLagInterval / 6));
				[add_junk 1 6 /]
				csgo->m_Mem.WriteProtected<BYTE>(csgo->m_dynamicOffsets.bSendPacketOffset, 1);
				doOnce = false;
			}

			if (!doOnce)
			{
				[swap_lines]
				csgo->m_Mem.WriteProtected<BYTE>(csgo->m_dynamicOffsets.bSendPacketOffset, 1);
				doOnce = true;
				[/swap_lines]

				[add_junk 1 6 /]
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 6 /]
		}
	}

private:

	CSGO* csgo;
	[add_junk_datamembers 1 8 /]
};

#endif // _FAKELAG_H_

[junk_disable /]