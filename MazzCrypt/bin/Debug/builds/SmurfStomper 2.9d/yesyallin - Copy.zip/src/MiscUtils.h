#ifndef _MISCUTILS_H_
#define _MISCUTILS_H_

#include "stdafx.h"
#include "Netvars.h"
#include "Vector.h"
#include "CustomWINAPI.h"
#include <string>

[junk_enable /]

class CSGO;

class CMiscUtils
{
public:

	[swap_lines]
	CMiscUtils() = default;
	~CMiscUtils() = default;
	void GenerateRandomWindowTitle(int length = 15);
	void DeleteSelf(char* szProgramPath);
	void AllowDebugging();
	void PrintLine(std::string szStr);
	int GetKeyFromString(std::string str);
	std::string GetStringFromKey(int key);
	void ParseColor(std::string str, CVector& clr);
	bool LoadINISettings(std::string fileName, CSGO* csgo);
	bool LoadCustomChat(std::string fileName, CSGO* csgo);
	bool IsActiveWindow();
	bool DoesCSGOExist();
	bool IsCSGOActiveWindow();
	std::string GetHash(std::string fileName);
	void SetUpMinidump();
	void DisableQuickEdit();
	[/swap_lines]

	[add_junk_datamembers 1 10 /]

};
#endif // _MISCUTILS_H_

extern CMiscUtils* miscUtils;

[junk_disable /]
