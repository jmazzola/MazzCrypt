#ifndef _CUSTOMWINAPI_H_
#define _CUSTOMWINAPI_H_

#include <Windows.h>
#include <TlHelp32.h>
#include <Wincrypt.h>
#include <DbgHelp.h>
#include <cctype>
#include <algorithm>

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]


DWORD GetKernel32Address();
//DWORD GetKernel32Address_W64();

PVOID GetProcAddress(DWORD dwModule, const char* szProcName);
PVOID CallWINAPIFunc(const char* szModule, const char* szFunc, int nArguments, ...);

// Hidden WINAPI functions 

// kernel32.dll
inline HANDLE CreateToolhelp32Snapshot_Hidden(DWORD dwFlags, DWORD th32ProcessID)
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "CreateToolhelp32Snapshot", 2, th32ProcessID, dwFlags);
}

inline BOOL CloseHandle_Hidden(HANDLE hObject)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "CloseHandle", 1, hObject);
}

inline HANDLE OpenProcess_Hidden(DWORD dwDesiredAccess, BOOL bInheritHandle, DWORD dwProcessId)
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "OpenProcess", 3, dwProcessId, bInheritHandle, dwDesiredAccess);
}

inline BOOL Process32Next_Hidden(HANDLE hSnapshot, LPPROCESSENTRY32 lppe)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "Process32Next", 2, lppe, hSnapshot);
}

inline BOOL Module32Next_Hidden(HANDLE hSnapshot, LPMODULEENTRY32 lpme)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "Module32Next", 2, lpme, hSnapshot);
}

inline LPVOID VirtualAllocEx_Hidden(HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocationType, DWORD flProtect)
{
	[add_junk 1 10 /]
	return (LPVOID)CallWINAPIFunc("kernel32.dll", "VirtualAllocEx", 5, flProtect, flAllocationType, dwSize, lpAddress, hProcess);
}

inline BOOL VirtualFreeEx_Hidden(HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD dwFreeType)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "VirtualFreeEx", 4, dwFreeType, dwSize, lpAddress, hProcess);
}

inline HANDLE CreateRemoteThread_Hidden(HANDLE hProcess, LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId)
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "CreateRemoteThread", 7, lpThreadId, dwCreationFlags, lpParameter, lpStartAddress, dwStackSize, lpThreadAttributes, hProcess);
}

inline DWORD WaitForSingleObject_Hidden(HANDLE hHandle, DWORD dwMilliseconds)
{
	[add_junk 1 10 /]
	return (DWORD)CallWINAPIFunc("kernel32.dll", "WaitForSingleObject", 2, dwMilliseconds, hHandle);
}

inline BOOL ReadProcessMemory_Hidden(HANDLE hProcess, LPCVOID lpBaseAddress, LPVOID lpBuffer, SIZE_T nSize, SIZE_T* lpNumberOfBytesRead)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "ReadProcessMemory", 5, lpNumberOfBytesRead, nSize, lpBuffer, lpBaseAddress, hProcess);
}

inline BOOL WriteProcessMemory_Hidden(HANDLE hProcess, LPVOID lpBaseAddress, LPCVOID lpBuffer, SIZE_T nSize, SIZE_T* lpNumberOfBytesWritten)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "WriteProcessMemory", 5, lpNumberOfBytesWritten, nSize, lpBuffer, lpBaseAddress, hProcess);
}

inline BOOL VirtualProtectEx_Hidden(HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "VirtualProtectEx", 5, lpflOldProtect, flNewProtect, dwSize, lpAddress, hProcess);
}

inline VOID Sleep_Hidden(DWORD dwMilliseconds)
{
	[add_junk 1 10 /]
	return (VOID)CallWINAPIFunc("kernel32.dll", "Sleep", 1, dwMilliseconds);
}

inline DWORD GetConsoleTitle_Hidden(LPTSTR lpConsoleTitle, DWORD nSize)
{
	[add_junk 1 10 /]
	return (DWORD)CallWINAPIFunc("kernel32.dll", "GetConsoleTitleA", 2, nSize, lpConsoleTitle);
}

inline BOOL SetConsoleTitle_Hidden(LPCTSTR lpConsoleTitle)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "SetConsoleTitleA", 1, lpConsoleTitle);
}

inline LPTOP_LEVEL_EXCEPTION_FILTER SetUnhandledExceptionFilter_Hidden(LPTOP_LEVEL_EXCEPTION_FILTER lpTopLevelExceptionFilter)
{
	[add_junk 1 10 /]
	return (LPTOP_LEVEL_EXCEPTION_FILTER)CallWINAPIFunc("kernel32.dll", "SetUnhandledExceptionFilter", 1, lpTopLevelExceptionFilter);
}

inline HANDLE GetStdHandle_Hidden(DWORD nStdHandle)
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "GetStdHandle", 1, nStdHandle);
}

inline BOOL GetConsoleMode_Hidden(HANDLE hConsoleHandle, LPDWORD lpMode)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "GetConsoleMode", 2, lpMode, hConsoleHandle);
}

inline BOOL SetConsoleMode_Hidden(HANDLE hConsoleHandle, DWORD dwMode)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "SetConsoleMode", 2, dwMode, hConsoleHandle);
}

inline BOOL CreateProcess_Hidden(LPCTSTR lpApplicationName, LPTSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPCTSTR lpCurrentDirectory, LPSTARTUPINFO lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "CreateProcessA", 10, lpProcessInformation, lpStartupInfo, lpCurrentDirectory, lpEnvironment, dwCreationFlags, bInheritHandles, lpThreadAttributes, lpProcessAttributes, lpCommandLine, lpApplicationName);
}

inline HANDLE GetCurrentProcess_Hidden()
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "GetCurrentProcess", 0);
}

inline DWORD GetLastError_Hidden()
{
	[add_junk 1 10 /]
	return (DWORD)CallWINAPIFunc("kernel32.dll", "GetLastError", 0);
}

inline HANDLE CreateFile_Hidden(LPCTSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile)
{
	[add_junk 1 10 /]
	return (HANDLE)CallWINAPIFunc("kernel32.dll", "CreateFileA", 7, hTemplateFile, dwFlagsAndAttributes, dwCreationDisposition, lpSecurityAttributes, dwShareMode, dwDesiredAccess, lpFileName);
}

inline BOOL ReadFile_Hidden(HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("kernel32.dll", "ReadFile", 5, lpOverlapped, lpNumberOfBytesRead, nNumberOfBytesToRead, lpBuffer, hFile);
}

inline void GetLocalTime_Hidden(LPSYSTEMTIME lpSystemTime)
{
	[add_junk 1 10 /]
	return (void)CallWINAPIFunc("kernel32.dll", "GetLocalTime", 1, lpSystemTime);
}

inline DWORD GetCurrentThreadId_Hidden()
{
	[add_junk 1 10 /]
	return (DWORD)CallWINAPIFunc("kernel32.dll", "GetCurrentThreadId", 0);
}

inline DWORD GetCurrentProcessId_Hidden()
{
	[add_junk 1 10 /]
	return (DWORD)CallWINAPIFunc("kernel32.dll", "GetCurrentProcessId", 0);
}



// User32.dll
inline SHORT GetAsyncKeyState_Hidden(int vKey)
{
	[add_junk 1 10 /]
	return (SHORT)CallWINAPIFunc("User32.dll", "GetAsyncKeyState", 1, vKey);
}

inline HWND GetForegroundWindow_Hidden()
{
	[add_junk 1 10 /]
	return (HWND)CallWINAPIFunc("User32.dll", "GetForegroundWindow", 0);
}

inline int GetWindowText_Hidden(HWND hWnd, LPTSTR lpString, int nMaxCount)
{
	[add_junk 1 10 /]
	return (int)CallWINAPIFunc("User32.dll", "GetWindowTextA", 3, nMaxCount, lpString, hWnd);
}

inline int MessageBox_Hidden(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType)
{
	[add_junk 1 10 /]
	return (int)CallWINAPIFunc("User32.dll", "MessageBoxA", 4, uType, lpCaption, lpText, hWnd);
}

inline HWND FindWindow_Hidden(LPCTSTR lpClassName, LPCTSTR lpWindowName)
{
	[add_junk 1 10 /]
	return (HWND)CallWINAPIFunc("User32.dll", "FindWindowA", 2, lpWindowName, lpClassName);
}


// Advapi32.dll
inline BOOL LookupPrivilegeValue_Hidden(LPCTSTR lpSystemName, LPCTSTR lpName, PLUID lpLuid)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "LookupPrivilegeValueA", 3, lpLuid, lpName, lpSystemName);
}

inline BOOL AdjustTokenPrivileges_Hidden(HANDLE TokenHandle, BOOL DisableAllPrivileges, PTOKEN_PRIVILEGES NewState, DWORD BufferLength, PTOKEN_PRIVILEGES PreviousState, PDWORD ReturnLength)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "AdjustTokenPrivileges", 6, ReturnLength, PreviousState, BufferLength, NewState, DisableAllPrivileges, TokenHandle);
}

inline BOOL OpenProcessToken_Hidden(HANDLE ProcessHandle, DWORD DesiredAccess, PHANDLE TokenHandle)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "OpenProcessToken", 3, TokenHandle, DesiredAccess, ProcessHandle);
}

inline BOOL CryptAcquireContext_Hidden(HCRYPTPROV *phProv, LPCTSTR pszContainer, LPCTSTR pszProvider, DWORD dwProvType, DWORD dwFlags)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptAcquireContextA", 5, dwFlags, dwProvType, pszProvider, pszContainer, phProv);
}

inline BOOL CryptCreateHash_Hidden(HCRYPTPROV hProv, ALG_ID Algid, HCRYPTKEY hKey, DWORD dwFlags, HCRYPTHASH *phHash)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptCreateHash", 5, phHash, dwFlags, hKey, Algid, hProv);
}

inline BOOL CryptReleaseContext_Hidden(HCRYPTPROV hProv, DWORD dwFlags)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptReleaseContext", 2, dwFlags, hProv);
}

inline BOOL CryptHashData_Hidden(HCRYPTHASH hHash, BYTE *pbData, DWORD dwDataLen, DWORD dwFlags)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptHashData", 4, dwFlags, dwDataLen, pbData, hHash);
}

inline BOOL CryptDestroyHash_Hidden(HCRYPTHASH hHash)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptDestroyHash", 1, hHash);
}

inline BOOL CryptGetHashParam_Hidden(HCRYPTHASH hHash, DWORD dwParam, BYTE *pbData, DWORD *pdwDataLen, DWORD dwFlags)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Advapi32.dll", "CryptGetHashParam", 5, dwFlags, pdwDataLen, pbData, dwParam, hHash);
}




// Dbghelp.dll

inline BOOL MiniDumpWriteDump_Hidden(HANDLE hProcess, DWORD ProcessId, HANDLE hFile, MINIDUMP_TYPE DumpType, PMINIDUMP_EXCEPTION_INFORMATION ExceptionParam, PMINIDUMP_USER_STREAM_INFORMATION UserStreamParam, PMINIDUMP_CALLBACK_INFORMATION CallbackParam)
{
	[add_junk 1 10 /]
	return (BOOL)CallWINAPIFunc("Dbghelp.dll", "MiniDumpWriteDump", 7, CallbackParam, UserStreamParam, ExceptionParam, DumpType, hFile, ProcessId, hProcess);
}

#endif // _CUSTOMWINAPI_H_

[enc_string_disable /]
[junk_disable /]