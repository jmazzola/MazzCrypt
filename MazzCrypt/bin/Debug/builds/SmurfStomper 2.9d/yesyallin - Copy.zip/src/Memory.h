#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "stdafx.h"
#include <TlHelp32.h>
#include <string>
#include "CustomWINAPI.h"

[junk_enable /]

class CMemory
{
public:

	[swap_lines]
	CMemory() = default;
	~CMemory() = default;
	bool Attach(const char* procName, DWORD rights = PROCESS_ALL_ACCESS);
	void Detach();
	DWORD GetModuleBase(const char* modName);
	DWORD GetModuleSize(const char* modName);
	[/swap_lines]

	inline void* Allocate(DWORD dwSize, bool pageExecute)
	{
		float flProtect;

		[add_junk 1 5 /]

		if (pageExecute)
			flProtect = PAGE_EXECUTE_READWRITE;
		else
			flProtect = PAGE_READWRITE;

		if (m_hProcess)
		{
			[add_junk 1 5 /]
			return VirtualAllocEx(m_hProcess, NULL, dwSize, MEM_COMMIT | MEM_RESERVE, flProtect);
		}
	}

	inline void Free(LPVOID lpAddress)
	{
		VirtualFreeEx(m_hProcess, lpAddress, 0, MEM_RELEASE);
		[add_junk 1 5 /]
	}

	inline void Execute(LPVOID lpAddress, HANDLE& hThread)
	{
		hThread = CreateRemoteThread(m_hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)lpAddress, NULL, 0, NULL);
		[add_junk 1 5 /]
		WaitForSingleObject(hThread, INFINITE);
	}

	HANDLE GetHandle() const
	{
		[add_junk 1 5 /]

		if (!m_bAttached)
		{
			[add_junk 1 5 /]
			return NULL;
		}

		return m_hProcess;
	}

	template<typename T>
	T inline Read(DWORD addr)
	{
		T mem;
		ReadProcessMemory(m_hProcess, (LPVOID)addr, &mem, sizeof(T), NULL);
		[add_junk 1 5 /]
		return mem;
	}

	void inline ReadCustom(DWORD addr, LPVOID buff, size_t bytesToRead)
	{
		[add_junk 1 5 /]
		ReadProcessMemory(m_hProcess, (LPCVOID)addr, buff, bytesToRead, NULL);
	}

	template<typename T>
	T inline ReadProtected(DWORD addr, T data)
	{
		T mem;
		[add_junk 1 5 /]
		DWORD oldProtect;
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		[add_junk 1 5 /]
		mem = Read(addr);
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), oldProtect, NULL);
		[add_junk 1 5 /]
		return mem;
	}


	template<typename T>
	void inline Write(DWORD addr, T data)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, &data, sizeof(T), NULL);
		[add_junk 1 5 /]
	}

	void inline WriteCustom(DWORD addr, LPCVOID buff, size_t bytesToWrite)
	{
		WriteProcessMemory(m_hProcess, (LPVOID)addr, buff, bytesToWrite, NULL);
		[add_junk 1 5 /]
	}

	template<typename T>
	void inline WriteProtected(DWORD addr, T data)
	{
		DWORD oldProtect;
		[add_junk 1 5 /]
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), PAGE_EXECUTE_READWRITE, &oldProtect);
		[add_junk 1 5 /]
		Write(addr, data);
		[add_junk 1 5 /]
		VirtualProtectEx(m_hProcess, (LPVOID)addr, sizeof(T), oldProtect, NULL);
	}

	bool inline IsAttached() const
	{
		[add_junk 1 5 /]
		return m_bAttached;
	}

	bool inline DataCompare(const BYTE* pbData, const BYTE* pbMask, const char* pszMask) 
	{
		for (; *pszMask; ++pszMask, ++pbData, ++pbMask)
		{
			[add_junk 1 5 /]

			if (*pszMask == 'c' && *pbData != *pbMask)
			{
				[add_junk 1 5 /]
				return false;
			}
		}

		return (*pszMask == NULL);
	}

	DWORD inline FindPattern(DWORD dwStart, DWORD dwSize, const BYTE* szSig, const char* szMask) 
	{
		PBYTE data = new BYTE[dwSize];

		unsigned long bytesRead;

		[add_junk 1 5 /]

		if (!ReadProcessMemory(m_hProcess, (LPVOID)dwStart, data, dwSize, &bytesRead)) 
		{
			[add_junk 1 5 /]

			delete[] data;
			data = nullptr;
			return NULL;
		}

		for (DWORD i = 0; i < dwSize; i++) 
		{
			if (DataCompare((const BYTE*)(data + i), szSig, szMask))
			{
				[add_junk 1 5 /]

				delete[] data;
				data = nullptr;
				return dwStart + i;
			}
		}

		[add_junk 1 5 /]

		delete[] data;
		data = nullptr;
		return NULL;
	}

	DWORD inline FindPatternArr(DWORD dwStart, DWORD dwSize, int nCount, BYTE* pattern) 
	{
		[add_junk 1 5 /]

		std::string szMask;
		szMask.resize(nCount);

		for (int i = 0; i < nCount; i++)
		{
			[add_junk 1 5 /]
			
			(pattern[i]) ? szMask[i] = 'c' : szMask[i] = '?';
		}

		return FindPattern(dwStart, dwSize, pattern, szMask.c_str());
	}

private:

	[swap_lines]
	bool m_bAttached;
	HANDLE m_hProcess;
	DWORD m_dwProcessID;
	[/swap_lines]

	[add_junk_datamembers 1 9 /]
};

#endif // _MEMORY_H_

[junk_disable /]