#include "MiscUtils.h"
#include "INIReader.h"
#include "CSGO.h"
#include <Wincrypt.h>
#include <cctype>
#include <algorithm>

#define BUFSIZE 1024
#define MD5LEN  16

#define clamp(value, minval, maxval) { if(value < minval) value = minval; if(value > maxval) value = maxval; }

[junk_enable /]

CMiscUtils* miscUtils = new CMiscUtils();

void CMiscUtils::GenerateRandomWindowTitle(int stringLength)
{
	// Generate random window title
	static const char alphanum[] =
		"0123456789"
		"!@#$%^&*"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	std::string str;

	for (int i = 0; i < stringLength; i++)
	{
		[add_junk 1 4 /]
		str += alphanum[rand() % sizeof(alphanum) - 1];
	}

	SetConsoleTitle(str.c_str());
}

void CMiscUtils::DeleteSelf(char* ProgramPath)
{
	// Windows keeps .exe files open during execution...
	char* batPath = new char[strlen(ProgramPath) + 5];
	strcpy_s(batPath, strlen(ProgramPath) + 5, ProgramPath);
	strcat_s(batPath, strlen(ProgramPath) + 5, ".bat");

	const char* batFormat =
		":Repeat\n"
		"del \"%s\"\n"
		"if exist \"%s\" goto Repeat\n"
		"del \"%s\"\n";

	char* batFile = new char[strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2];
	sprintf_s(batFile, strlen(batPath) + strlen(batFormat) + strlen(ProgramPath) * 2,
			  batFormat, ProgramPath, ProgramPath, batPath);

	FILE* f;
	fopen_s(&f, batPath, "w");
	if (f != NULL)
	{
		[add_junk 1 4 /]

		fwrite(batFile, strlen(batFile), 1, f);
		fclose(f);
	}

	STARTUPINFOA startupInfo;
	PROCESS_INFORMATION procInfo;
	memset(&startupInfo, 0, sizeof(startupInfo));

	[add_junk 1 4 /]

	startupInfo.cb = sizeof(startupInfo);

	CreateProcess(batPath, NULL, NULL, NULL, FALSE, 0, NULL, NULL,
				   &startupInfo, &procInfo);

	delete[] batFile;
	delete[] batPath;
}

[enc_string_enable /]

void CMiscUtils::AllowDebugging()
{
	HANDLE _HandleProcess = GetCurrentProcess();
	HANDLE _HandleToken;
	TOKEN_PRIVILEGES tkPrivileges;
	[add_junk 1 4 /]
	LUID _LUID;

	OpenProcessToken(_HandleProcess, TOKEN_ADJUST_PRIVILEGES, &_HandleToken);
	LookupPrivilegeValue(0, "seDebugPrivilege", &_LUID);

	tkPrivileges.PrivilegeCount = 1;
	tkPrivileges.Privileges[0].Luid = _LUID;
	[add_junk 1 4 /]
	tkPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	AdjustTokenPrivileges(_HandleToken, false, &tkPrivileges, 0, 0, 0);

	CloseHandle(_HandleToken);
	[add_junk 1 4 /]
	CloseHandle(_HandleProcess);
}

void CMiscUtils::PrintLine(std::string s)
{
	[add_junk 1 4 /]
	printf("%s\n", s.c_str());
}

int CMiscUtils::GetKeyFromString(std::string str)
{
	char data = str.c_str()[0];

	if ((data >= '0' && data <= '9') || (data >= 'A' && data <= 'Z'))
		return (int)data;

	if (str == "mouse1") return VK_LBUTTON;

	[swap_lines]
	else if (str == "mouse2") return VK_RBUTTON;
	else if (str == "mouse3") return VK_MBUTTON;
	else if (str == "mouse4") return VK_XBUTTON1;
	else if (str == "mouse5") return VK_XBUTTON2;
	else if (str == "backspace") return VK_BACK;
	else if (str == "tab") return VK_TAB;
	else if (str == "enter") return VK_RETURN;
	else if (str == "shift") return VK_SHIFT;
	else if (str == "ctrl") return VK_CONTROL;
	else if (str == "alt") return VK_MENU;
	else if (str == "capslock") return VK_CAPITAL;
	else if (str == "escape") return VK_ESCAPE;
	else if (str == "space") return VK_SPACE;
	else if (str == "pgup") return VK_PRIOR;
	else if (str == "pgdn") return VK_NEXT;
	else if (str == "end") return VK_END;
	else if (str == "home") return VK_HOME;
	else if (str == "leftarrow") return VK_LEFT;
	else if (str == "rightarrow") return VK_RIGHT;
	else if (str == "uparrow") return VK_UP;
	else if (str == "downarrow") return VK_DOWN;
	else if (str == "ins") return VK_INSERT;
	else if (str == "del") return VK_DELETE;
	else if (str == "numpad_0") return VK_NUMPAD0;
	else if (str == "numpad_1") return VK_NUMPAD1;
	else if (str == "numpad_2") return VK_NUMPAD2;
	else if (str == "numpad_3") return VK_NUMPAD3;
	else if (str == "numpad_4") return VK_NUMPAD4;
	else if (str == "numpad_5") return VK_NUMPAD5;
	else if (str == "numpad_6") return VK_NUMPAD6;
	else if (str == "numpad_7") return VK_NUMPAD7;
	else if (str == "numpad_8") return VK_NUMPAD8;
	else if (str == "numpad_9") return VK_NUMPAD9;
	else if (str == "kp_multiply") return VK_MULTIPLY;
	else if (str == "kp_plus") return VK_ADD;
	else if (str == "kp_minus") return VK_SUBTRACT;
	else if (str == "kp_slash") return VK_DIVIDE;
	else if (str == "f1") return VK_F1;
	else if (str == "f2") return VK_F2;
	else if (str == "f3") return VK_F3;
	else if (str == "f4") return VK_F4;
	else if (str == "f5") return VK_F5;
	else if (str == "f6") return VK_F6;
	else if (str == "f7") return VK_F7;
	else if (str == "f8") return VK_F8;
	else if (str == "f9") return VK_F9;
	else if (str == "f10") return VK_F10;
	else if (str == "f11") return VK_F11;
	else if (str == "f12") return VK_F12;
	else if (str == ";") return VK_OEM_1;
	else if (str == "+") return VK_OEM_PLUS;
	else if (str == "-") return VK_OEM_MINUS;
	else if (str == ",") return VK_OEM_COMMA;
	else if (str == ".") return VK_OEM_PERIOD;
	else if (str == "/") return VK_OEM_2;
	else if (str == "~") return VK_OEM_3;
	else if (str == "[") return VK_OEM_4;
	else if (str == std::to_string(char(0x5C))) return VK_OEM_5;
	else if (str == "]") return VK_OEM_6;
	else if (str == std::to_string(char(0x22))) return VK_OEM_7;
	[/swap_lines]

	else return -1;
	
}

std::string CMiscUtils::GetStringFromKey(int key)
{
	char c[2] = { 0 };

	if ((key >= '0' && key <= '9') || (key >= 'A' && key <= 'Z'))
	{ 
		c[0] = (char)key; 
		std::string sweg(c);
		std::transform(sweg.begin(), sweg.end(), sweg.begin(), ::tolower);
		return sweg;
	}

	switch (key) 
	{
		[swap_lines]
		case VK_LBUTTON: return std::string("mouse1");
		case VK_RBUTTON: return std::string("mouse2");
		case VK_MBUTTON: return std::string("mouse3");
		case VK_XBUTTON1: return std::string("mouse4");
		case VK_XBUTTON2: return std::string("mouse5");
		case VK_BACK: return std::string("backspace");
		case VK_TAB: return std::string("tab");
		case VK_RETURN: return std::string("enter");
		case VK_SHIFT: return std::string("shift");
		case VK_CONTROL: return std::string("ctrl");
		case VK_MENU: return std::string("alt");
		case VK_CAPITAL: return std::string("capslock");
		case VK_ESCAPE: return std::string("escape");
		case VK_SPACE: return std::string("space");
		case VK_PRIOR: return std::string("pgup");
		case VK_NEXT: return std::string("pgdn");
		case VK_END: return std::string("end");
		case VK_HOME: return std::string("home");
		case VK_LEFT: return std::string("leftarrow");
		case VK_UP: return std::string("uparrow");
		case VK_DOWN: return std::string("downarrow");
		case VK_RIGHT: return std::string("rightarrow");
		case VK_INSERT: return std::string("ins");
		case VK_DELETE: return std::string("del");
		case VK_NUMPAD0: return std::string("numpad_0");
		case VK_NUMPAD1: return std::string("numpad_1");
		case VK_NUMPAD2: return std::string("numpad_2");
		case VK_NUMPAD3: return std::string("numpad_3");
		case VK_NUMPAD4: return std::string("numpad_4");
		case VK_NUMPAD5: return std::string("numpad_5");
		case VK_NUMPAD6: return std::string("numpad_6");
		case VK_NUMPAD7: return std::string("numpad_7");
		case VK_NUMPAD8: return std::string("numpad_8");
		case VK_NUMPAD9: return std::string("numpad_9");
		case VK_MULTIPLY: return std::string("kp_multiply");
		case VK_ADD: return std::string("kp_plus");
		case VK_SUBTRACT: return std::string("kp_minus");
		case VK_DIVIDE: return std::string("kp_slash");
		case VK_F1: return std::string("f1");
		case VK_F2: return std::string("f2");
		case VK_F3: return std::string("f3");
		case VK_F4: return std::string("f4");
		case VK_F5: return std::string("f5");
		case VK_F6: return std::string("f6");
		case VK_F7: return std::string("f7");
		case VK_F8: return std::string("f8");
		case VK_F9: return std::string("f9");
		case VK_F10: return std::string("f10");
		case VK_F11: return std::string("f11");
		case VK_F12: return std::string("f12");
		case VK_OEM_1: return std::string(";");
		case VK_OEM_PLUS: return std::string("+");
		case VK_OEM_MINUS: return std::string("-");
		case VK_OEM_COMMA: return std::string(",");
		case VK_OEM_PERIOD: return std::string(".");
		case VK_OEM_2: return std::string("/");
		case VK_OEM_3: return std::string("~");
		case VK_OEM_4: return std::string("[");
		case VK_OEM_5: return std::to_string(char(0x5C));
		case VK_OEM_6: return std::string("]");
		case VK_OEM_7: return std::to_string(char(0x22));
		[/swap_lines]

		default: return std::string("unknown key");
	}
}

void CMiscUtils::ParseColor(std::string str, CVector& clr)
{
	LPTSTR pStop;
	int color = _tcstol(str.c_str(), &pStop, 16);

	[add_junk 1 4 /]

	[swap_lines]
	clr.x = ((color & 0xFF0000) >> 16) / 255.0f;
	clr.y = ((color & 0xFF00) >> 8) / 255.0f;
	clr.z = (color & 0xFF) / 255.0f;
	[/swap_lines]
}

EBones GetBoneFromString(std::string bone)
{
	if (bone == "head") return EBones::Bone_Head;
	[swap_lines]
	else if (bone == "neck") return EBones::Bone_Neck;
	else if (bone == "stomach") return EBones::Bone_Spine0;
	else if (bone == "chest") return EBones::Bone_Spine3;
	[/swap_lines]

	else return EBones::Bone_Head;
}

bool CMiscUtils::LoadINISettings(std::string fileName, CSGO* csgo)
{
	INIReader r = INIReader(fileName); 

	if (r.ParseError() < 0)
	{
		std::cout << "> Unable to read .ini. Resetting settings to defaults.\n";
		[add_junk 1 4 /]
		return false;
	}

	csgo->m_Hacks.hacksHash = CMiscUtils::GetHash(fileName);

	[add_junk 1 4 /]

	[swap_lines]
	csgo->m_Hacks.tFakeLagOptions.bCanToggle = r.GetBoolean("fakelag", "canToggle", false);
 	csgo->m_Hacks.tFakeLagOptions.bActivated = r.GetBoolean("fakelag", "defaultSetting", false);
 	csgo->m_Hacks.tFakeLagOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("fakelag", "togglekey", "numpad_0"));
 	csgo->m_Hacks.tFakeLagOptions.iLagInterval = r.GetInteger("fakelag", "packetsToDrop", 12);
 	[/swap_lines]

 	clamp(csgo->m_Hacks.tFakeLagOptions.iLagInterval, 1, 100);
 	[add_junk 1 4 /]

 	[swap_lines]
	csgo->m_Hacks.tChatSpamOptions.bCanToggle = r.GetBoolean("chatspam", "canToggle", false);
	csgo->m_Hacks.tChatSpamOptions.bActivated = r.GetBoolean("chatspam", "defaultSetting", false);
	csgo->m_Hacks.tChatSpamOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("chatspam", "togglekey", "kp_plus"));
	csgo->m_Hacks.tChatSpamOptions.iChatInterval = r.GetInteger("chatspam", "interval", 5);
	csgo->m_Hacks.tChatSpamOptions.bParseFile = r.GetBoolean("chatspam", "customchat", false);
	csgo->m_Hacks.tChatSpamOptions.eSpamMethod = (ESpamMethod)r.GetInteger("chatspam", "spamtype", ESpamMethod::Advertisement);
	csgo->m_Hacks.tChatSpamOptions.iUserID = r.GetInteger("chatspam", "userid", 1);
	csgo->m_Hacks.tChatSpamOptions.bRandomParse = r.GetBoolean("chatspam", "randomparse", false);
	[/swap_lines]

	[add_junk 1 4 /]

	[swap_lines]
	clamp(csgo->m_Hacks.tChatSpamOptions.iChatInterval, 1, 60);
	clamp(csgo->m_Hacks.tChatSpamOptions.eSpamMethod, ESpamMethod::Advertisement, ESpamMethod::ParsedFile);
	[/swap_lines]

	[add_junk 1 4 /]

	[swap_lines]
	csgo->m_Hacks.tBhopOptions.bCanToggle = r.GetBoolean("bhop", "canToggle", false);
	csgo->m_Hacks.tBhopOptions.bActivated = r.GetBoolean("bhop", "defaultSetting", false);
	csgo->m_Hacks.tBhopOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("bhop", "togglekey", "numpad_2"));
	[/swap_lines]

	[add_junk 1 4 /]

	[swap_lines]
	csgo->m_Hacks.tGlowOptions.bCanToggle = r.GetBoolean("glowesp", "canToggle", false);
	csgo->m_Hacks.tGlowOptions.bActivated = r.GetBoolean("glowesp", "defaultSetting", false);
	csgo->m_Hacks.tGlowOptions.bBombInfo = r.GetBoolean("glowesp", "bombInfo", false);
	csgo->m_Hacks.tGlowOptions.targetType = (ETargetType)r.GetInteger("glowesp", "targettype", ETargetType::Target_Enemies);
	csgo->m_Hacks.tGlowOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("glowesp", "togglekey", "mouse3"));
	csgo->m_Hacks.tGlowOptions.bVisibleGlow = r.GetBoolean("glowesp", "visibleCheck", false);
	csgo->m_Hacks.tGlowOptions.bHealthGlow = r.GetBoolean("glowesp", "health", false);
	csgo->m_Hacks.tGlowOptions.bDefuseGlow = r.GetBoolean("glowesp", "defuse", false);
	csgo->m_Hacks.tGlowOptions.bFlashGlow = r.GetBoolean("glowesp", "flash", false);
	csgo->m_Hacks.tGlowOptions.bGlowBomb = r.GetBoolean("glowesp", "bomb", false);
	csgo->m_Hacks.tGlowOptions.bGlowWeapons = r.GetBoolean("glowesp", "weapons", false);
	csgo->m_Hacks.tGlowOptions.bGlowGrenades = r.GetBoolean("glowesp", "nades", false);
	csgo->m_Hacks.tGlowOptions.bChickenGlow = r.GetBoolean("glowesp", "chicken", false);
	[/swap_lines]

	clamp(csgo->m_Hacks.tGlowOptions.targetType, ETargetType::Target_Enemies, ETargetType::Target_Everyone);
	csgo->m_Hacks.tGlowOptions.fGlowEnemy_A = r.GetFloat("glowesp", "enemy_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowEnemy_A, 0.0f, 1.0f);
	[add_junk 1 4 /]
	CMiscUtils::ParseColor(r.GetString("glowesp", "enemy_color", "FF0000"), csgo->m_Hacks.tGlowOptions.fGlowEnemy_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A = r.GetFloat("glowesp", "notvisible_enemy_thickness", 1.f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "notvisible_enemy_color", "690000"), csgo->m_Hacks.tGlowOptions.fGlowEnemyNotVisible_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowTeam_A = r.GetFloat("glowesp", "teammate_thickness", 1.f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tGlowOptions.fGlowTeam_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "teammate_color", "00FF00"), csgo->m_Hacks.tGlowOptions.fGlowTeam_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A = r.GetFloat("glowesp", "notvisible_teammate_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_A, 0.0f, 1.0f);
	[add_junk 1 4 /]
	CMiscUtils::ParseColor(r.GetString("glowesp", "notvisible_teammate_color", "006900"), csgo->m_Hacks.tGlowOptions.fGlowTeamNotVisible_RGB);

	csgo->m_Hacks.tGlowOptions.fWeapons_A = r.GetFloat("glowesp", "weapon_thickness", 1.f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tGlowOptions.fWeapons_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "weapon_color", "00FFFF"), csgo->m_Hacks.tGlowOptions.fWeapons_RGB);

	csgo->m_Hacks.tGlowOptions.fGlowBomb_A = r.GetFloat("glowesp", "bomb_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fGlowBomb_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "bomb_color", "FFBF00"), csgo->m_Hacks.tGlowOptions.fGlowBomb_RGB);

	csgo->m_Hacks.tGlowOptions.fNades_A = r.GetFloat("glowesp", "nades_thickness", 1.f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tGlowOptions.fNades_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "nades_color", "7300FF"), csgo->m_Hacks.tGlowOptions.fNades_RGB);

	csgo->m_Hacks.tGlowOptions.fDefuse_A = r.GetFloat("glowesp", "defuse_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fDefuse_A, 0.0f, 1.0f);
	[add_junk 1 4 /]
	CMiscUtils::ParseColor(r.GetString("glowesp", "defuse_color", "E4B5FF"), csgo->m_Hacks.tGlowOptions.fDefuse_RGB);
	[add_junk 1 4 /]
	csgo->m_Hacks.tGlowOptions.fChicken_A = r.GetFloat("glowesp", "chicken_thickness", 1.f);
	clamp(csgo->m_Hacks.tGlowOptions.fChicken_A, 0.0f, 1.0f);
	CMiscUtils::ParseColor(r.GetString("glowesp", "chicken_color", "FFFF00"), csgo->m_Hacks.tGlowOptions.fChickenRGB);

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.bCanToggle = r.GetBoolean("subtleaimbot", "canToggle", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bActivated = r.GetBoolean("subtleaimbot", "defaultSetting", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bVisibleCheck = r.GetBoolean("subtleaimbot", "visibleCheck", false);
	csgo->m_Hacks.tSubtleAimbotOptions.iKey = CMiscUtils::GetKeyFromString(r.GetString("subtleaimbot", "togglekey", "numpad_5"));
	csgo->m_Hacks.tSubtleAimbotOptions.targetType = (ETargetType)r.GetInteger("subtleaimbot", "targettype", ETargetType::Target_Enemies);
	csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor = r.GetFloat("subtleaimbot", "smoothFactor", 1.0f);
	csgo->m_Hacks.tSubtleAimbotOptions.bRageMode = r.GetBoolean("subtleaimbot", "ragemode", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bJumpCheck = r.GetBoolean("subtleaimbot", "jumpcheck", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bIntelligentAim = r.GetBoolean("subtleaimbot", "intelligentaim", false);
	csgo->m_Hacks.tSubtleAimbotOptions.bRandomPos = r.GetBoolean("subtleaimbot", "randompos", false);
	[/swap_lines]

	clamp(csgo->m_Hacks.tSubtleAimbotOptions.targetType, ETargetType::Target_Enemies, ETargetType::Target_Everyone);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.fSmoothFactor, 1.0f, 100.0f);

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_pistols", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance = r.GetInteger("subtleaimbot_pistols", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance = r.GetInteger("subtleaimbot_pistols", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale =  r.GetFloat("subtleaimbot_pistols", "rcsScale", 1.0f);
	[/swap_lines]

	[swap_lines]
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMinChance, 0, 24);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Pistol.iSubtleMaxChance, 0, 24);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_rifles", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance = r.GetInteger("subtleaimbot_rifles", "minChance", 2);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance = r.GetInteger("subtleaimbot_rifles", "maxChance", 10);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale =  r.GetFloat("subtleaimbot_rifles", "rcsScale", 1.0f);
	[/swap_lines]

	[swap_lines]
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMinChance, 0, 35);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Rifle.iSubtleMaxChance, 0, 35);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_smgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_smgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_smgs", "maxChance", 15);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale =  r.GetFloat("subtleaimbot_smgs", "rcsScale", 1.5f);
	[/swap_lines]

	[swap_lines]
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMinChance, 0, 64);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_SMGs.iSubtleMaxChance, 0, 64);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_lmgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance = r.GetInteger("subtleaimbot_lmgs", "minChance", 5);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance = r.GetInteger("subtleaimbot_lmgs", "maxChance", 20);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale =  r.GetFloat("subtleaimbot_lmgs", "rcsScale", 1.7f);
	[/swap_lines]

	[swap_lines]	
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMinChance, 0, 150);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_LMGs.iSubtleMaxChance, 0, 150);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_snipers", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance = r.GetInteger("subtleaimbot_snipers", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance = r.GetInteger("subtleaimbot_snipers", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale =  r.GetFloat("subtleaimbot_snipers", "rcsScale", 1.0f);
	[/swap_lines]

	[swap_lines]	
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMinChance, 0, 25);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Sniper.iSubtleMaxChance, 0, 25);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt = GetBoneFromString(r.GetString("subtleaimbot_shotguns", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance = r.GetInteger("subtleaimbot_shotguns", "minChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance = r.GetInteger("subtleaimbot_shotguns", "maxChance", 0);
	csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale =  r.GetFloat("subtleaimbot_shotguns", "rcsScale", 0.0f);
	[/swap_lines]
	
	[swap_lines]
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale, 0.0f, 1.0f);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMinChance, 0, 10);
	clamp(csgo->m_Hacks.tSubtleAimbotOptions.tWeaponSettings_Shotguns.iSubtleMaxChance, 0, 10);
	[/swap_lines]

	[swap_lines]
	csgo->m_Hacks.tActualAimbotOptions.bCanToggle = r.GetBoolean("aimlock", "canToggle", false);
	csgo->m_Hacks.tActualAimbotOptions.bActivated = r.GetBoolean("aimlock", "defaultSetting", false);
	csgo->m_Hacks.tActualAimbotOptions.iToggleKey = CMiscUtils::GetKeyFromString(r.GetString("aimlock", "togglekey", "numpad_8"));
	csgo->m_Hacks.tActualAimbotOptions.iAimKey = CMiscUtils::GetKeyFromString(r.GetString("aimlock", "aimkey", "mouse4"));
	csgo->m_Hacks.tActualAimbotOptions.bVisibleCheck = r.GetBoolean("aimlock", "visibleCheck", false);
	csgo->m_Hacks.tActualAimbotOptions.targetType = (ETargetType)r.GetInteger("aimlock", "targettype", ETargetType::Target_Enemies);
	csgo->m_Hacks.tActualAimbotOptions.fFOVRadius = r.GetFloat("aimlock", "fovRadius", 25.0f);
	csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor = r.GetFloat("aimlock", "smoothFactor", 1.0f);
	csgo->m_Hacks.tActualAimbotOptions.eAimMethod = (EAimMethod)r.GetInteger("aimlock", "aimMethod", EAimMethod::ClosestToCrosshair);
	csgo->m_Hacks.tActualAimbotOptions.bRageMode = r.GetBoolean("aimlock", "ragemode", false);
	csgo->m_Hacks.tActualAimbotOptions.bSilentAim = r.GetBoolean("aimlock", "silentaim", false);
	csgo->m_Hacks.tActualAimbotOptions.bJumpCheck = r.GetBoolean("aimlock", "jumpcheck", false);
	[/swap_lines]

	[add_junk 1 4 /]

	[swap_lines]
	clamp(csgo->m_Hacks.tActualAimbotOptions.targetType, ETargetType::Target_Enemies, ETargetType::Target_Everyone);
	clamp(csgo->m_Hacks.tActualAimbotOptions.fFOVRadius, 0.1f, 360.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.fSmoothFactor, 1.0f, 100.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.eAimMethod, EAimMethod::ClosestToCrosshair, EAimMethod::ClosestToPlayer);
	[/swap_lines]

	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_pistols", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale = r.GetFloat("aimlock_pistols", "rcsScale", 1.0f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Pistol.fSubtleRCSScale, 0.0f, 2.0f);
	[add_junk 1 4 /]
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_rifles", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale = r.GetFloat("aimlock_rifles", "rcsScale", 1.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Rifle.fSubtleRCSScale, 0.0f, 2.0f);
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_smgs", "boneToAimAt", "head"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale = r.GetFloat("aimlock_smgs", "rcsScale", 1.5f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_SMGs.fSubtleRCSScale, 0.0f, 2.0f);
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_lmgs", "boneToAimAt", "head"));
	[add_junk 1 4 /]
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale = r.GetFloat("aimlock_lmgs", "rcsScale", 1.7f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_LMGs.fSubtleRCSScale, 0.0f, 2.0f);
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_snipers", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale = r.GetFloat("aimlock_snipers", "rcsScale", 1.0f);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Sniper.fSubtleRCSScale, 0.0f, 2.0f);
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt = GetBoneFromString(r.GetString("aimlock_shotguns", "boneToAimAt", "stomach"));
	csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale = r.GetFloat("aimlock_shotguns", "rcsScale", 0.0f);
	[add_junk 1 4 /]
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.eBoneToAimAt, EBones::Bone_Spine0, EBones::Bone_RightAnkle);
	clamp(csgo->m_Hacks.tActualAimbotOptions.tWeaponSettings_Shotguns.fSubtleRCSScale, 0.0f, 2.0f);
	[add_junk 1 4 /]

	std::cout << "> .ini loaded successfully!\n";
	return true;
}

bool CMiscUtils::LoadCustomChat(std::string fileName, CSGO* csgo)
{
	csgo->m_Hacks.parseLines.clear();

	std::ifstream parseFile;
	parseFile.open("chat.txt");
	std::string line;

	[add_junk 1 4 /]

	if (!parseFile.is_open() || !parseFile.good())
	{
		parseFile.close();
		return false;
	}

	while (std::getline(parseFile, line))
		csgo->m_Hacks.parseLines.push_back(line);

	[add_junk 1 4 /]

	parseFile.close();

	csgo->m_Hacks.chatHash = CMiscUtils::GetHash("chat.txt");

	return true;
}

bool CMiscUtils::IsActiveWindow()
{
	char windowTitle[256];
	char consoleTitle[256];
	[add_junk 1 4 /]
	HWND hwnd = GetForegroundWindow();
	GetWindowText(hwnd, windowTitle, sizeof(windowTitle));
	[add_junk 1 4 /]
	GetConsoleTitle(consoleTitle, sizeof(consoleTitle));

	return (!strcmp(windowTitle, consoleTitle));
}

bool CMiscUtils::IsCSGOActiveWindow()
 {
	[add_junk 1 4 /]
	char windowTitle[256];
	HWND hwnd = GetForegroundWindow();
	[add_junk 1 4 /]
	GetWindowText(hwnd, windowTitle, sizeof(windowTitle));
	[add_junk 1 4 /]
	[add_junk 1 4 /]
	
	return(!strcmp(windowTitle, "Counter-Strike: Global Offensive"));
}

bool CMiscUtils::DoesCSGOExist()
{
	HWND hwnd = FindWindow(NULL, "Counter-Strike: Global Offensive");
	[add_junk 1 4 /]
	return (hwnd != NULL);
}

[enc_string_disable /]

std::string CMiscUtils::GetHash(std::string fileName)
{
	HANDLE hFile = CreateFile(fileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	HCRYPTPROV hProv;
	[add_junk 1 4 /]
	HCRYPTHASH hHash;

	DWORD cbHash = MD5LEN;
	BYTE rgbHash[MD5LEN];
	CHAR rgbDigits[] = "0123456789abcdef";

[enc_string_enable /]

	if (hFile == INVALID_HANDLE_VALUE)
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("Error reading in .ini"));
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	// Get handle to the crypto provider
	if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
	{
		int dwStatus = GetLastError();
		[add_junk 1 4 /]
		CMiscUtils::PrintLine(std::string("Error acquiring CryptAcquireContext"));
		[add_junk 1 4 /]
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
	{
		int dwStatus = GetLastError();
		[add_junk 1 4 /]
		CMiscUtils::PrintLine(std::string("Error creating hash"));
		CloseHandle(hFile);
		[add_junk 1 4 /]
		CryptReleaseContext(hProv, 0);
		return std::string("ERROR");
	}

	BOOL bResult = FALSE;
	DWORD cbRead;
	BYTE rgbFile[BUFSIZE];

	while (bResult = ReadFile(hFile, rgbFile, BUFSIZE, &cbRead, NULL))
	{
		if (!cbRead)
		{
			break;
		}

		if (!CryptHashData(hHash, rgbFile, cbRead, 0))
		{
			int dwStatus = GetLastError();
			[add_junk 1 4 /]
			CMiscUtils::PrintLine(std::string("Error with CryptHashData"));
			[add_junk 1 4 /]
			CryptReleaseContext(hProv, 0);
			CryptDestroyHash(hHash);
			CloseHandle(hFile);
			[add_junk 1 4 /]
			return std::string("ERROR");
		}
	}

	if (!bResult)
	{
		int dwStatus = GetLastError();
		CMiscUtils::PrintLine(std::string("ReadFile failed"));
		[add_junk 1 4 /]
		CryptReleaseContext(hProv, 0);
		CryptDestroyHash(hHash);
		[add_junk 1 4 /]
		CloseHandle(hFile);
		return std::string("ERROR");
	}

	std::string hashOutput;

	if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
	{
		//printf("MD5 hash of file %s is: ", fileName.c_str());

		for (DWORD i = 0; i < cbHash; i++)
		{
			hashOutput += std::to_string(rgbDigits[rgbHash[i] >> 4]);
			[add_junk 1 4 /]
			hashOutput += std::to_string(rgbDigits[rgbHash[i] & 0xf]);

			//printf("%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
		}
		//printf("\n");
	}


	CryptReleaseContext(hProv, 0);
	[add_junk 1 4 /]
	CryptDestroyHash(hHash);
	CloseHandle(hFile);

	return hashOutput;
}

void CMiscUtils::DisableQuickEdit()
{
	[swap_lines]
 	HANDLE hConsole = GetStdHandle(STD_INPUT_HANDLE);
 	DWORD consoleMode;
 	[/swap_lines]

 	[add_junk 1 4 /]
 	GetConsoleMode(hConsole, &consoleMode);
 	[add_junk 1 4 /]
 	consoleMode &= ~ENABLE_QUICK_EDIT_MODE;
 	SetConsoleMode(hConsole, consoleMode);
 	[add_junk 1 4 /]
 }

void MakeMinidump(_EXCEPTION_POINTERS *e)
{
	char dumpName[MAX_PATH];

	SYSTEMTIME t;
	[add_junk 1 4 /]
	GetSystemTime(&t);
	wsprintf(dumpName, "smurfstomper_%4d%02d%02d_%02d%02d%02d.dmp", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
	[add_junk 1 4 /]

	auto hFile = CreateFile(dumpName, GENERIC_WRITE, FILE_SHARE_READ, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

	[add_junk 1 4 /]

	if (hFile == INVALID_HANDLE_VALUE)
		return;

	MINIDUMP_EXCEPTION_INFORMATION info;

	[swap_lines]
	info.ThreadId = GetCurrentThreadId();
	info.ExceptionPointers = e;
	info.ClientPointers = FALSE;
	[/swap_lines]

	[add_junk 1 4 /]

	char msg[MAX_PATH];

	// Hidden minidumpwritedump somehow causes heap corruption
	if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpWithIndirectlyReferencedMemory, (e ? &info : nullptr), nullptr, nullptr))
	{
		sprintf(msg, "Crashdump created: '%s'\nPlease contact ChocolatePC with this ASAP.", dumpName);
		[add_junk 1 4 /]
		MessageBox(NULL, msg, "Crash!", MB_OK);
	}
	else
	{
		sprintf(msg, "Unable to create crashdump!\nPlease contact ChocolatePC with this:\n Error %d", GetLastError());
		[add_junk 1 4 /]
		MessageBox(NULL, msg, "Crash!", MB_OK);
	}

	CloseHandle(hFile);
	[add_junk 1 4 /]
}

LONG WINAPI unhandled_handler(_EXCEPTION_POINTERS* e)
{
	MakeMinidump(e);
	[add_junk 1 4 /]
	return EXCEPTION_CONTINUE_SEARCH;
}

void CMiscUtils::SetUpMinidump()
{
	SetUnhandledExceptionFilter(unhandled_handler);
	[add_junk 1 4 /]
}

[enc_string_disable /]
[junk_disable /]
