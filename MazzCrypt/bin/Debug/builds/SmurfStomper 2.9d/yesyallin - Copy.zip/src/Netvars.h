#ifndef _NETVARS_H_
#define _NETVARS_H_

#include "stdafx.h"
#include "Memory.h"

#endif // _NETVARS_H_