#include "stdafx.h"
#include "MiscUtils.h"
#include "Vector.h"
#include "Memory.h"
#include "CustomWINAPI.h"
#include "CSGO.h"
#include "GlowESP.h"
#include "SubtleAimbot.h"
#include "ActualAimbot.h"
#include "Bhop.h"
#include "Chatspam.h"
#include "Fakelag.h"

#include <time.h>
#include <thread>
#include <vector>

// Memory Leak Detection
//#include <vld.h>

// Globals
char* programPath = "";

[junk_enable /]
[enc_string_enable /]

void UpdateEntitiesConstantly(CSGO* csgo)
{
	[add_junk 1 9 /]

	while (!csgo->m_Hacks.tThreadHandling.bUpdateStop)
	{
		if (GetAsyncKeyState(VK_END))
			csgo->m_Hacks.tThreadHandling.bUpdateStop = true;

		[add_junk 1 9 /]
		int clientState = csgo->m_Mem.Read<int>(csgo->m_dwEngineBase + csgo->m_dynamicOffsets.enginePtr);
		int sos = csgo->m_Mem.Read<int>(clientState + SignOnState);

		if (sos == SOS_Full)
		{
			csgo->LoadBases();

			[add_junk 1 9 /]

			[swap_lines]
			std::string newSettingsHash = miscUtils->GetHash("settings.ini");
			std::string newChatHash = miscUtils->GetHash("chat.txt");
			[/swap_lines]

			[add_junk 1 9 /]

			if (strcmp(newSettingsHash.c_str(), csgo->m_Hacks.hacksHash.c_str()))
			{
				[add_junk 1 9 /]

				if (miscUtils->LoadINISettings("settings.ini", csgo))
				{
					csgo->DisplayControls();
					[add_junk 1 9 /]
					miscUtils->PrintLine("> .ini file has been changed. Automatically loaded new settings!\n");
				}
				else
				{
					csgo->DisplayControls();
					[add_junk 1 9 /]
					miscUtils->PrintLine("> .ini file could not be opened/changed. Failed to load new settings.\n");
				}
			}

			if (strcmp(newChatHash.c_str(), csgo->m_Hacks.chatHash.c_str()))
			{
				if (miscUtils->LoadCustomChat("chat.txt", csgo))
				{
					csgo->DisplayControls();
					[add_junk 1 9 /]
					miscUtils->PrintLine("> chat.txt file has been changed. Automatically loaded new spam!\n");
				}
				else
				{
					csgo->DisplayControls();
					[add_junk 1 9 /]
					miscUtils->PrintLine("> chat.txt file couldn't be changed. Failed to load new spam.\n");
				}
			}
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			[add_junk 1 9 /]
			continue;
		}

		csgo->UpdateEntities();
		[add_junk 1 9 /]

		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}
}

int main(int argc, char** argv)
{
	// Seed random
	srand((unsigned int)time(NULL));
	rand();

	[swap_lines]
	miscUtils->SetUpMinidump();
	miscUtils->DisableQuickEdit();
	[/swap_lines]

	if (argc > 0)
		programPath = argv[0];

	// Create a random title and allow debugging access for this process
	miscUtils->GenerateRandomWindowTitle(20);
	miscUtils->AllowDebugging();

	miscUtils->PrintLine(std::string("                           __     _                                  "));
	miscUtils->PrintLine(std::string(" ___ _ __ ___  _   _ _ __ / _|___| |_ ___  _ __ ___  _ __   ___ _ __ "));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("/ __| '_ ` _ \\| | | | '__| |_/ __| __/ _ \\| '_ ` _ \\| '_ \\ / _ \\ '__|"));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("\\__ \\ | | | | | |_| | |  |  _\\__ \\ || (_) | | | | | | |_) |  __/ |   "));
	miscUtils->PrintLine(std::string("|___/_| |_| |_|\\__,_|_|  |_| |___/\\__\\___/|_| |_| |_| .__/ \\___|_|   "));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("                                                    |_|              "));
	miscUtils->PrintLine(std::string("~ Proudly Protected by Private Polymorphic Parser: MazzCrypt ~"));
	miscUtils->PrintLine(std::string("----------------------------------------------------------------------\n"));
	[add_junk 1 9 /]

	miscUtils->PrintLine(std::string("> Attempting to attach to Counter-Strike: Global Offensive\nIf you haven't started CSGO yet, please do so now."));
	[add_junk 1 9 /]
	std::cout << "\b\b";

	CSGO* csgo = new CSGO();

	while (!csgo->Attach())
	{
		std::cout << ".";
		Sleep(100);
		std::cout << "\b.";
	}

	miscUtils->PrintLine(std::string("\n> CSGO attached!"));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	miscUtils->PrintLine(std::string("> Loading INI Settings [settings.ini]..."));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	if (!miscUtils->LoadINISettings(std::string("settings.ini"), csgo))
	{
		csgo->m_Hacks.UnsetAll();
	}
	else
	{
		miscUtils->PrintLine(std::string("> settings.ini Loaded!..."));
		[add_junk 1 9 /]
		miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	}

	miscUtils->PrintLine(std::string("> Loading Custom Spam Table [chat.txt]..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	[add_junk 1 9 /]

	if (miscUtils->LoadCustomChat(std::string("chat.txt"), csgo))
	{
		miscUtils->PrintLine(std::string("> chat.txt Loaded!..."));
		[add_junk 1 9 /]
		miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	}

	miscUtils->PrintLine(std::string("> Waiting for game .dlls to be loaded..."));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	while (!csgo->m_Mem.GetModuleBase("client.dll"))
	{
		std::cout << ".";
		Sleep(100);
		std::cout << "\b.";
	}

	miscUtils->PrintLine(std::string("\n> DLLs loaded!"));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("------------------------------------------\n"));


	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("> Signature scanning offsets..."));
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	csgo->ScanOffsets();

	// Load our basic information
	csgo->LoadBases();

	miscUtils->PrintLine(std::string("> Grabbing netvars..."));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));
	csgo->UpdateNetvars();

	miscUtils->PrintLine(std::string("\n> Netvars Grabbed!"));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	miscUtils->PrintLine(std::string("> Press INSERT whenever you're ready to 'toggle'"));
	[add_junk 1 9 /]
	miscUtils->PrintLine(std::string("-----------------------------------------\n"));

	while (!GetAsyncKeyState(VK_INSERT))
	{
		Sleep(100);
	}

	miscUtils->PrintLine(std::string("> Starting cheat threads..."));

	[swap_lines]
	csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bGlowThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bUpdateStop = false;
	csgo->m_Hacks.tThreadHandling.bBhopThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bChatspamThreadStop = false;
	csgo->m_Hacks.tThreadHandling.bFakeLagThreadStop = false;
	[/swap_lines]

	[swap_lines]
	csgo->threadPool.emplace_back(UpdateEntitiesConstantly, csgo);
	csgo->threadPool.emplace_back(&GlowESP::Start, GlowESP(csgo));
	csgo->threadPool.emplace_back(&SubtleAimbot::Start, SubtleAimbot(csgo));
	csgo->threadPool.emplace_back(&ActualAimbot::Start, ActualAimbot(csgo));
	csgo->threadPool.emplace_back(&BHop::Start, BHop(csgo));
	csgo->threadPool.emplace_back(&ChatSpam::Start, ChatSpam(csgo));
	csgo->threadPool.emplace_back(&Fakelag::Start, Fakelag(csgo));
	[/swap_lines]


	[add_junk 1 9 /]
	csgo->DisplayControls();


	// Do the loop for allowing toggles
	while (!GetAsyncKeyState(VK_END))
	{
		// Check if CSGO exists
		if (!miscUtils->DoesCSGOExist())
			break;

		[add_junk 1 9 /]

		// Handle Rank/Win Dump Info
		if (GetAsyncKeyState(VK_PRIOR) & 1)
		{
			csgo->DisplayRankInfo();
		}

		[add_junk 1 9 /]

		// Handle Fakelag
		if (csgo->m_Hacks.tFakeLagOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tFakeLagOptions.iKey) & 1)
		{
			csgo->m_Hacks.tFakeLagOptions.bActivated = !csgo->m_Hacks.tFakeLagOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		if (csgo->m_Hacks.tFakeLagOptions.bCanToggle && csgo->m_Hacks.tFakeLagOptions.bActivated)
		{
			csgo->m_Hacks.Set(BIT_FAKELAG);
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_FAKELAG);
			Sleep(5);
		}

		[add_junk 1 9 /]
		
		// Handle ChatSpam
		if (csgo->m_Hacks.tChatSpamOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tChatSpamOptions.iKey) & 1)
		{
			csgo->m_Hacks.tChatSpamOptions.bActivated = !csgo->m_Hacks.tChatSpamOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		if (csgo->m_Hacks.tChatSpamOptions.bCanToggle && csgo->m_Hacks.tChatSpamOptions.bActivated)
		{
			csgo->m_Hacks.Set(BIT_CHATSPAM);
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_CHATSPAM);
			Sleep(5);
		}

		[add_junk 1 9 /]

		// Handle GlowESP
		if (csgo->m_Hacks.tGlowOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tGlowOptions.iKey) & 1)
		{
			csgo->m_Hacks.tGlowOptions.bActivated = !csgo->m_Hacks.tGlowOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		[add_junk 1 9 /]

		if (csgo->m_Hacks.tGlowOptions.bCanToggle && csgo->m_Hacks.tGlowOptions.bActivated)
		{
			csgo->m_Hacks.Set(BIT_ESP);
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_ESP);
			Sleep(5);
		}

		[add_junk 1 9 /]

		// Handle Subtle Aimbot
		if (csgo->m_Hacks.tSubtleAimbotOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tSubtleAimbotOptions.iKey) & 1)
		{
			csgo->m_Hacks.tSubtleAimbotOptions.bActivated = !csgo->m_Hacks.tSubtleAimbotOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		[add_junk 1 9 /]


		if (csgo->m_Hacks.tSubtleAimbotOptions.bCanToggle && csgo->m_Hacks.tSubtleAimbotOptions.bActivated)
		{
			csgo->m_Hacks.Set(BIT_SUBTLEAIMBOT);
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_SUBTLEAIMBOT);
			Sleep(5);
		}

		[add_junk 1 9 /]

		// Handle BHOP
		if (csgo->m_Hacks.tBhopOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tBhopOptions.iKey) & 1)
		{
			csgo->m_Hacks.tBhopOptions.bActivated = !csgo->m_Hacks.tBhopOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		if (csgo->m_Hacks.tBhopOptions.bCanToggle && csgo->m_Hacks.tBhopOptions.bActivated && GetAsyncKeyState(VK_SPACE) & 0x8000)
		{
			csgo->m_Hacks.Set(BIT_BHOP);
			[add_junk 1 9 /]
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_BHOP);
			[add_junk 1 9 /]
			Sleep(5);
		}

		// Handle Actual Aimbot
		if (csgo->m_Hacks.tActualAimbotOptions.bCanToggle && GetAsyncKeyState(csgo->m_Hacks.tActualAimbotOptions.iToggleKey) & 1)
		{
			csgo->m_Hacks.tActualAimbotOptions.bActivated = !csgo->m_Hacks.tActualAimbotOptions.bActivated;
			Sleep(5);
			csgo->DisplayControls();
		}

		if (csgo->m_Hacks.tActualAimbotOptions.bCanToggle && csgo->m_Hacks.tActualAimbotOptions.bActivated && GetAsyncKeyState(csgo->m_Hacks.tActualAimbotOptions.iAimKey) & 0x8000)
		{
			csgo->m_Hacks.Set(BIT_AIMBOT);
			Sleep(5);
		}
		else
		{
			csgo->m_Hacks.Unset(BIT_AIMBOT);
			Sleep(5);
		}

		[add_junk 1 9 /]

		Sleep(1);
	}

	[swap_lines]
	csgo->m_Hacks.tGlowOptions.bGlowWeapons = false;
	csgo->m_Hacks.tGlowOptions.bChickenGlow = false;
	csgo->m_Hacks.tGlowOptions.bDefuseGlow = false;
	csgo->m_Hacks.tGlowOptions.bFlashGlow = false;
	csgo->m_Hacks.tGlowOptions.bGlowGrenades = false;
	csgo->m_Hacks.tGlowOptions.bGlowBomb = false;
	[/swap_lines]

	[add_junk 1 9 /]

	[swap_lines]
	int objGlowArray = csgo->m_Mem.Read<DWORD>(csgo->m_dwGlowObjectArrayBase);
	int objCount = csgo->m_Mem.Read<int>(csgo->m_dwGlowObjectArrayBase + 4);
	[/swap_lines]

	[add_junk 1 9 /]

	if (objGlowArray != NULL)
	{
		for (int i = 0; i < objCount; i++)
		{

			DWORD mObj = objGlowArray + i * sizeof(GlowObjectDefinition);
			GlowObjectDefinition glowObj = csgo->m_Mem.Read<GlowObjectDefinition>(mObj);

			if (!glowObj.pEntity)
				continue;

			if (csgo->IsClassIDAWeapon(csgo->GetClassID((Player*)&glowObj.pEntity)))
			{
				[swap_lines]
				glowObj.rgb = CVector(0.f, 0.f, 0.f);
				glowObj.a = 0.0f;
				glowObj.bRenderWhenOccluded = false;
				glowObj.bRenderWhenUnoccluded = false;
				glowObj.bFullBloom = false;
				[/swap_lines]

				[add_junk 1 9 /]

				[swap_lines]
				csgo->m_Mem.Write<CVector>(mObj + 0x4, glowObj.rgb);
				csgo->m_Mem.Write<float>(mObj + 0x10, glowObj.a);
				csgo->m_Mem.Write<BOOL>(mObj + 0x24, glowObj.bRenderWhenOccluded);
				csgo->m_Mem.Write<BOOL>(mObj + 0x25, glowObj.bRenderWhenUnoccluded);
				csgo->m_Mem.Write<BOOL>(mObj + 0x26, glowObj.bFullBloom);
				[/swap_lines]
			}
		}
	}


	[swap_lines]
	csgo->m_Hacks.tThreadHandling.bFakeLagThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bChatspamThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bBhopThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bActualAimbotThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bSubtleAimbotThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bGlowThreadStop = true;
	csgo->m_Hacks.tThreadHandling.bUpdateStop = true;
	[/swap_lines]


	miscUtils->PrintLine(std::string("> Ending threads..."));
	miscUtils->PrintLine(std::string("> [!] If a thread doesn't end please press END [!] "));

	for (size_t i = 0; i < csgo->threadPool.size(); i++)
	{
		while (csgo->threadPool[i].joinable())
		{
			std::cout << ".";
			csgo->threadPool[i].join();
			Sleep(1);
			std::cout << "\nThread " << i << " ended!\n";
		}
	}


	miscUtils->PrintLine(std::string("> Detaching csgo.."));
	csgo->m_Mem.Detach();
	[add_junk 1 9 /]

	delete csgo;
	csgo = nullptr;

	miscUtils->DeleteSelf(programPath);
	[add_junk 1 9 /]

	delete miscUtils;
	miscUtils = nullptr;

	return 0;
}

[junk_disable /]
[enc_string_disable /]