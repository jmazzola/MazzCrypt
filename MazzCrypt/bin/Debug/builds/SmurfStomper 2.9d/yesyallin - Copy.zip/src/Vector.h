#ifndef _VECTOR_H_
#define _VECTOR_H_

#include "stdafx.h"
#include <xmmintrin.h>
#include <math.h>
#include <cmath>
#include <float.h>

[junk_enable /]

#define X_INDEX 0
#define Y_INDEX 1
#define Z_INDEX 2

#define M_PI 3.14159265358979323846
#define M_PI_F		((float)(M_PI))
#define RAD2DEG( x  )  ( (float)(x) * (float)( 180.f/M_PI_F ) )
#define DEG2RAD(x)  ((float)(x)* (float)(M_PI_F / 180.f))

#define RAND_INT(a, b) (a - b + 1) + b
 
float inline RAND_FLOAT(float a, float b)
{
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = b - a;
	float r = random * diff;
	return a + r;
}

double inline __declspec (naked) __fastcall FastSQRT(double n)
{
	_asm fld qword ptr[esp + 4];
	_asm fsqrt;
	_asm ret 8;
}

class CVector
{

public:

	// Data members
	float x, y, z;

	// Ctors
	inline CVector() : x(0.0f), y(0.0f), z(0.0f)
	{
		[add_junk 1 4 /]
	}

	inline CVector(float fX, float fY, float fZ) : x(fX), y(fY), z(fZ)
	{
	}

	inline CVector(const CVector& v) : x(v.x), y(v.y), z(v.z)
	{
	}

	inline CVector(float num[3]) : x(num[X_INDEX]), y(num[Y_INDEX]), z(num[Z_INDEX])
	{
	}

	inline void PrintInfo()
	{
		[add_junk 1 4 /]
		printf_s("%f | %f | %f", x, y, z);
	}


	inline void ZeroOut()
	{
		x = y = z = 0.0f;
		[add_junk 1 4 /]
	}

	inline float Length() 
	{ 
		return FastSQRT(x*x + y*y + z*z);
	}

	inline float DotProduct(CVector v)
	{
		return (x * v.x + y * v.y + z * v.z);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();

		[swap_lines]
		x *= l;
		y *= l;
		z *= l;
		[/swap_lines]
	}

	inline float ToDegree(CVector to)
	{
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		return *(&x + i);
	}

	inline CVector operator+(const CVector& v)
	{
		return CVector(x + v.x, y + v.y, z + v.z);
	}
	
	inline void operator+= (const CVector& v)
	{
		[swap_lines]
		x += v.x;
		y += v.y;
		z += v.z;
		[/swap_lines]
	}

	inline CVector operator-(const CVector& v)
	{
		return CVector(x - v.x, y - v.y, z - v.z);
	}

	inline void operator-=(const CVector& v)
	{
		[swap_lines]
		x -= v.x;
		y -= v.y;
		z -= v.z;
		[/swap_lines]
	}

	inline CVector operator*(const float f)
	{
		return CVector(x * f, y * f, z * f);
	}

	inline void operator*=(const float f)
	{
		[swap_lines]
		x *= f;
		y *= f;
		z *= f;
		[/swap_lines]
	}

	inline CVector operator/(const float f)
	{
		return CVector(x / f, y / f, z / f);
	}

	inline void operator/=(const float f)
	{
		[swap_lines]
		x /= f;
		y /= f;
		z /= f;
		[/swap_lines]
	}
	
	inline void operator=(const float* f)
	{
		[swap_lines]
		x = f[0];
		y = f[1];
		z = f[2];
		[/swap_lines]
	}

	inline void operator=(const float& f)
	{
		x = y = z = f;
	}

	inline bool operator==(const CVector& v)
	{
		return (x == v.x && y == v.y && z == v.z);
	}

	inline bool operator!=(const CVector& v)
	{
		return (x != v.x && y != v.y && z != v.z);
	}

	inline bool operator<=(const CVector& v)
	{
		return (x <= v.x && y <= v.y && z <= v.z);
	}

	inline bool operator>=(const CVector& v)
	{
		return (x >= v.x && y >= v.y && z >= v.z);
	}

	inline bool operator>(const CVector& v)
	{
		return (x > v.x && y > v.y && z > v.z);
	}

	inline bool operator<(const CVector& v)
	{
		return (x < v.x && y < v.y && z < v.z);
	}
};

class CVector2D
{

public:

	// Data members
	float x, y;

	// Ctors
	inline CVector2D() : x(0.0f), y(0.0f)
	{
	}

	inline CVector2D(float fX, float fY) : x(fX), y(fY)
	{
	}

	inline CVector2D(const CVector& v) : x(v.x), y(v.y)
	{
	}

	inline CVector2D(float num[2]) : x(num[X_INDEX]), y(num[Y_INDEX])
	{
	}

	inline void PrintInfo()
	{
		[add_junk 1 4 /]
		printf_s("%f | %f", x, y);
	}

	inline void ZeroOut()
	{
		x = y = 0.0f;
		[add_junk 1 4 /]
	}

	inline float Length()
	{
		return FastSQRT(x*x + y*y);
	}

	inline float DotProduct(CVector2D v)
	{
		return (x * v.x + y * v.y);
	}

	inline void Normalize()
	{
		float l = 1.0f / Length();

		[swap_lines]
		x *= l;
		y *= l;
		[/swap_lines]
	}

	inline float ToDegree(CVector2D to)
	{
		return (180.0f / 3.141f) * asinf(DotProduct(to));
	}

	inline float operator[] (int i)
	{
		return *(&x + i);
	}

	inline CVector2D operator+(const CVector2D& v)
	{
		return CVector2D(x + v.x, y + v.y);
	}

	inline void operator+= (const CVector2D& v)
	{
		[swap_lines]
		x += v.x;
		y += v.y;
		[/swap_lines]
	}

	inline CVector2D operator-(const CVector2D& v)
	{
		return CVector2D(x - v.x, y - v.y);
	}

	inline void operator-=(const CVector2D& v)
	{
		[swap_lines]
		x -= v.x;
		y -= v.y;
		[/swap_lines]
	}

	inline CVector2D operator*(const float f)
	{
		return CVector2D(x * f, y * f);
	}

	inline void operator*=(const float f)
	{
		[swap_lines]
		x *= f;
		y *= f;
		[/swap_lines]
	}

	inline CVector2D operator/(const float f)
	{
		return CVector2D(x / f, y / f);
	}

	inline void operator/=(const float f)
	{
		[swap_lines]
		x /= f;
		y /= f;
		[/swap_lines]
	}

	inline void operator=(const float* f)
	{
		[swap_lines]
		x = f[0];
		y = f[1];
		[/swap_lines]
	}

	inline void operator=(const float& f)
	{
		x = y = f;
	}

	inline bool operator==(const CVector2D& v)
	{
		return (x == v.x && y == v.y);
	}

	inline bool operator!=(const CVector2D& v)
	{
		return (x != v.x && y != v.y);
	}

	inline bool operator<=(const CVector2D& v)
	{
		return (x <= v.x && y <= v.y);
	}

	inline bool operator>=(const CVector2D& v)
	{
		return (x >= v.x && y >= v.y);
	}

	inline bool operator>(const CVector2D& v)
	{
		return (x > v.x && y > v.y);
	}

	inline bool operator<(const CVector2D& v)
	{
		return (x < v.x && y < v.y);
	}
};

class Matrix3x4
{
public:
	union
	{
		struct
		{
			float _11, _12, _13, _14;
			float _21, _22, _23, _24;
			float _31, _32, _33, _34;
		};

		float m[3][4];
		float mm[12];
	};

	inline CVector& GetAxis(int i)
	{
		[add_junk 1 4 /]
		return *(CVector*)&m[i][0];
	}
};

#endif

[junk_disable /]