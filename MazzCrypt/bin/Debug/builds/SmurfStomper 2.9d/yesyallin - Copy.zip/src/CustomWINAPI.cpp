#include "CustomWINAPI.h"

#include "Decrypt.h"

[enc_string_enable /]
[junk_enable /]



DWORD GetKernel32Address()
{
	[add_junk 1 10 /]
	DWORD kernelAddr = 0;

	__asm
	{
		mov ebx, fs:[0x30]		// Get PEB
		mov ebx, [ebx + 0xC]	// Get PEB->Ldr
		mov ebx, [ebx + 0x14]	// Get 1st Entry
		mov ebx, [ebx]			// Get 2nd Entry
		mov ebx, [ebx]			// Get 3rd Entry
		mov ebx, [ebx + 0x10]	// Get the 3rd entry's base address (kernel32)
		mov kernelAddr, ebx
	}

	[add_junk 1 10 /]

	return kernelAddr;
}

PVOID GetProcAddress(DWORD dwModule, const char* szProcName)
{
	[add_junk 1 10 /]
	char* module = (char*)dwModule;

	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)module;
	[add_junk 1 10 /]
	PIMAGE_NT_HEADERS ntHeader = (PIMAGE_NT_HEADERS)(module + dosHeader->e_lfanew);
	PIMAGE_OPTIONAL_HEADER optHeader = &ntHeader->OptionalHeader;
	PIMAGE_DATA_DIRECTORY expEntry = (PIMAGE_DATA_DIRECTORY)(&optHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT]);
	[add_junk 1 10 /]
	PIMAGE_EXPORT_DIRECTORY expDir = (PIMAGE_EXPORT_DIRECTORY)(module + expEntry->VirtualAddress);

	PVOID* funcTable = (PVOID*)(module + expDir->AddressOfFunctions);
	[add_junk 1 10 /]
	PWORD  ordTable = (PWORD)(module + expDir->AddressOfNameOrdinals);
	[add_junk 1 10 /]
	PCHAR* nameTable = (PCHAR*)(module + expDir->AddressOfNames);

	PVOID address = NULL;

	if (((DWORD)szProcName >> 16) == 0)
	{
		[swap_lines]
		WORD ord = LOWORD(szProcName);
		DWORD ordBase = expDir->Base;
		[/swap_lines]

		if (ord < ordBase || ord > ordBase + expDir->NumberOfFunctions)
			return NULL;

		address = (PVOID)(module + (DWORD)funcTable[ord - ordBase]);
	}
	else
	{
		for (int i = 0; i < expDir->NumberOfNames; i++)
		{
			[add_junk 1 10 /]

			if (!strcmp(szProcName, module + (DWORD)nameTable[i]))
				address = (PVOID)(module + (DWORD)funcTable[ordTable[i]]);
		}
	}

	if (((char*)address >= (char*)expDir) && ((char*)address < (char*)expDir + expEntry->Size))
	{
		[swap_lines]
		char* dllName, *funcName;
		HMODULE forwardModule;
		[/swap_lines]

		dllName = _strdup((char*)address);

		if (!dllName)
			return NULL;

		address = NULL;

		funcName = strchr(dllName, '.');
		[add_junk 1 10 /]
		*funcName++ = 0;

		DWORD dwGetModuleHandle = (DWORD)GetProcAddress(GetKernel32Address(), "GetModuleHandleA");

		__asm
		{
			push dllName
			call dwGetModuleHandle
			mov forwardModule, eax
		}

		if (!forwardModule)
		{
			DWORD dwLoadLibrary = (DWORD)GetProcAddress(GetKernel32Address(), "LoadLibraryA");

			__asm
			{
				push dllName
				call dwLoadLibrary
				mov forwardModule, eax
			}
		}

		if (forwardModule)
		{
			address = GetProcAddress((DWORD)forwardModule, funcName);
			[add_junk 1 10 /]
		}

		[swap_lines]
		free(dllName);
		free(funcName);
		[/swap_lines]

		[add_junk 1 10 /]
	}

	[add_junk 1 10 /]

	return address;
}

PVOID CallWINAPIFunc(const char* szModule, const char* szFunc, int nArguments, ...)
{
	[swap_lines]
	HANDLE hModule;
	DWORD dwLoadLibrary = (DWORD)GetProcAddress(GetKernel32Address(), "LoadLibraryA");
	PVOID returnVal;
	[/swap_lines]

	[add_junk 1 10 /]

	__asm
	{
		push szModule
		call dwLoadLibrary
		mov hModule, eax
	}

	if (!hModule)
		return NULL;

	DWORD funcAddr = (DWORD)GetProcAddress((DWORD)hModule, szFunc);

	if (!funcAddr)
		return NULL;

	va_list params;
	[add_junk 1 10 /]
	PVOID param;
	va_start(params, nArguments);

	for (int i = 0; i < nArguments; i++)
	{
		param = va_arg(params, PVOID);
		[add_junk 1 10 /]
		__asm { push param }
	}

	__asm
	{
		call DWORD PTR funcAddr
		mov returnVal, eax
	}

	va_end(params);
	[add_junk 1 10 /]
	return returnVal;
}